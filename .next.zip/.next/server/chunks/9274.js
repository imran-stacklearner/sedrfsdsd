"use strict";
exports.id = 9274;
exports.ids = [9274];
exports.modules = {

/***/ 898394:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "A": () => (/* reexport */ Layout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ArrowLeft.js
var ArrowLeft = __webpack_require__(627178);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Breadcrumbs/index.js
var Breadcrumbs = __webpack_require__(175668);
var Breadcrumbs_default = /*#__PURE__*/__webpack_require__.n(Breadcrumbs);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
;// CONCATENATED MODULE: ./src/components/breadcrumbs-separator.tsx


const BreadcrumbsSeparator = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: "neutral.500",
            borderRadius: "50%",
            height: 4,
            width: 4
        }
    });

// EXTERNAL MODULE: ./src/components/router-link.tsx
var router_link = __webpack_require__(510079);
// EXTERNAL MODULE: ./src/paths.ts
var paths = __webpack_require__(287842);
;// CONCATENATED MODULE: ./src/layouts/components/layout.tsx















const LayoutRoot = (0,styles.styled)("div")(({ theme  })=>({
        backgroundColor: theme.palette.background.default,
        display: "flex",
        flex: "1 1 auto",
        flexDirection: "column"
    }));
const LayoutContainer = (0,styles.styled)("div")({
    display: "flex",
    flex: "1 1 auto",
    flexDirection: "column",
    width: "100%"
});
const Layout = (props)=>{
    const { breadcrumbs , children , title  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(LayoutRoot, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.50",
                    py: "120px"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                    maxWidth: "lg",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        spacing: 3,
                        children: [
                            !breadcrumbs && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Link_default()), {
                                    color: "text.primary",
                                    component: router_link/* RouterLink */.r,
                                    href: paths/* paths.components.index */.H.components.index,
                                    sx: {
                                        alignItems: "center",
                                        display: "inline-flex"
                                    },
                                    underline: "hover",
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            sx: {
                                                mr: 1
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowLeft/* default */.Z, {})
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Components"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h1",
                                    children: title
                                })
                            }),
                            breadcrumbs && /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Breadcrumbs_default()), {
                                    separator: /*#__PURE__*/ jsx_runtime_.jsx(BreadcrumbsSeparator, {}),
                                    children: breadcrumbs.map((item, index)=>{
                                        const isLast = breadcrumbs.length - 1 === index;
                                        if (isLast) {
                                            return /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "subtitle2",
                                                children: item.title
                                            }, index);
                                        }
                                        return /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                            color: "text.primary",
                                            component: router_link/* RouterLink */.r,
                                            href: item.href,
                                            variant: "subtitle2",
                                            children: item.title
                                        }, index);
                                    })
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx(LayoutContainer, {
                children: children
            })
        ]
    });
};
Layout.propTypes = {
    breadcrumbs: (prop_types_default()).array,
    children: (prop_types_default()).node.isRequired,
    title: (prop_types_default()).string.isRequired
};

;// CONCATENATED MODULE: ./src/layouts/components/index.ts



/***/ }),

/***/ 213718:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ Previewer)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(869232);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _untitled_ui_icons_react_build_esm_Moon01__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(92759);
/* harmony import */ var _untitled_ui_icons_react_build_esm_Sun__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(218600);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(746661);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(176395);
/* harmony import */ var _mui_material_Card__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Card__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(260493);
/* harmony import */ var _mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(973638);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(916816);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(381394);
/* harmony import */ var _mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(522166);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var src_hooks_use_settings__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(488141);
/* harmony import */ var src_theme__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(188053);














const Previewer = (props)=>{
    const { children , title , ...other } = props;
    const settings = (0,src_hooks_use_settings__WEBPACK_IMPORTED_MODULE_4__/* .useSettings */ .r)();
    const [paletteMode, setPaletteMode] = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(settings.paletteMode);
    const theme = (0,react__WEBPACK_IMPORTED_MODULE_1__.useMemo)(()=>{
        return (0,src_theme__WEBPACK_IMPORTED_MODULE_5__/* .createTheme */ .j)({
            ...settings,
            paletteMode
        });
    }, [
        settings,
        paletteMode
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        setPaletteMode(settings.paletteMode);
    }, [
        settings.paletteMode
    ]);
    const handleModeSwitch = (0,react__WEBPACK_IMPORTED_MODULE_1__.useCallback)(()=>{
        setPaletteMode((prevState)=>{
            return prevState === "light" ? "dark" : "light";
        });
    }, []);
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Card__WEBPACK_IMPORTED_MODULE_6___default()), {
        variant: "outlined",
        ...other,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CardHeader__WEBPACK_IMPORTED_MODULE_7___default()), {
                action: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_8___default()), {
                    onClick: handleModeSwitch,
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_9___default()), {
                        fontSize: "small",
                        children: paletteMode === "light" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_untitled_ui_icons_react_build_esm_Moon01__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {}) : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_untitled_ui_icons_react_build_esm_Sun__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
                    })
                }),
                title: title
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_10___default()), {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_styles__WEBPACK_IMPORTED_MODULE_11__.ThemeProvider, {
                theme: theme,
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_12__["default"], {
                    sx: {
                        colorScheme: paletteMode
                    },
                    children: children
                })
            })
        ]
    });
};
Previewer.propTypes = {
    children: (prop_types__WEBPACK_IMPORTED_MODULE_13___default().node.isRequired),
    title: (prop_types__WEBPACK_IMPORTED_MODULE_13___default().string.isRequired)
};


/***/ })

};
;