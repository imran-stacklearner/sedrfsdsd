"use strict";
exports.id = 3580;
exports.ids = [3580];
exports.modules = {

/***/ 102165:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = ClassNameConfigurator;
exports.useClassNamesOverride = useClassNamesOverride;
var React = _interopRequireWildcard(__webpack_require__(18038));
var _jsxRuntime = __webpack_require__(556786);
function _getRequireWildcardCache(nodeInterop) { if (typeof WeakMap !== "function") return null; var cacheBabelInterop = new WeakMap(); var cacheNodeInterop = new WeakMap(); return (_getRequireWildcardCache = function (nodeInterop) { return nodeInterop ? cacheNodeInterop : cacheBabelInterop; })(nodeInterop); }
function _interopRequireWildcard(obj, nodeInterop) { if (!nodeInterop && obj && obj.__esModule) { return obj; } if (obj === null || typeof obj !== "object" && typeof obj !== "function") { return { default: obj }; } var cache = _getRequireWildcardCache(nodeInterop); if (cache && cache.has(obj)) { return cache.get(obj); } var newObj = {}; var hasPropertyDescriptor = Object.defineProperty && Object.getOwnPropertyDescriptor; for (var key in obj) { if (key !== "default" && Object.prototype.hasOwnProperty.call(obj, key)) { var desc = hasPropertyDescriptor ? Object.getOwnPropertyDescriptor(obj, key) : null; if (desc && (desc.get || desc.set)) { Object.defineProperty(newObj, key, desc); } else { newObj[key] = obj[key]; } } } newObj.default = obj; if (cache) { cache.set(obj, newObj); } return newObj; }
const defaultContextValue = {
  disableDefaultClasses: false
};
const ClassNameConfiguratorContext = /*#__PURE__*/React.createContext(defaultContextValue);
/**
 * @ignore - internal hook.
 *
 * Wraps the `generateUtilityClass` function and controls how the classes are generated.
 * Currently it only affects whether the classes are applied or not.
 *
 * @returns Function to be called with the `generateUtilityClass` function specific to a component to generate the classes.
 */
function useClassNamesOverride(generateUtilityClass) {
  const {
    disableDefaultClasses
  } = React.useContext(ClassNameConfiguratorContext);
  return slot => {
    if (disableDefaultClasses) {
      return '';
    }
    return generateUtilityClass(slot);
  };
}

/**
 * Allows to configure the components within to not apply any built-in classes.
 */
function ClassNameConfigurator(props) {
  const {
    disableDefaultClasses,
    children
  } = props;
  const contextValue = React.useMemo(() => ({
    disableDefaultClasses: disableDefaultClasses != null ? disableDefaultClasses : false
  }), [disableDefaultClasses]);
  return /*#__PURE__*/(0, _jsxRuntime.jsx)(ClassNameConfiguratorContext.Provider, {
    value: contextValue,
    children: children
  });
}

/***/ }),

/***/ 828223:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));

/***/ }),

/***/ 639786:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



var _interopRequireDefault = __webpack_require__(327574);
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = appendOwnerState;
var _extends2 = _interopRequireDefault(__webpack_require__(859651));
var _isHostComponent = _interopRequireDefault(__webpack_require__(260496));
/**
 * Type of the ownerState based on the type of an element it applies to.
 * This resolves to the provided OwnerState for React components and `undefined` for host components.
 * Falls back to `OwnerState | undefined` when the exact type can't be determined in development time.
 */

/**
 * Appends the ownerState object to the props, merging with the existing one if necessary.
 *
 * @param elementType Type of the element that owns the `existingProps`. If the element is a DOM node or undefined, `ownerState` is not applied.
 * @param otherProps Props of the element.
 * @param ownerState
 */
function appendOwnerState(elementType, otherProps, ownerState) {
  if (elementType === undefined || (0, _isHostComponent.default)(elementType)) {
    return otherProps;
  }
  return (0, _extends2.default)({}, otherProps, {
    ownerState: (0, _extends2.default)({}, otherProps.ownerState, ownerState)
  });
}

/***/ }),

/***/ 920549:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = areArraysEqual;
function areArraysEqual(array1, array2, itemComparer = (a, b) => a === b) {
  return array1.length === array2.length && array1.every((value, index) => itemComparer(value, array2[index]));
}

/***/ }),

/***/ 326460:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = extractEventHandlers;
/**
 * Extracts event handlers from a given object.
 * A prop is considered an event handler if it is a function and its name starts with `on`.
 *
 * @param object An object to extract event handlers from.
 * @param excludeKeys An array of keys to exclude from the returned object.
 */
function extractEventHandlers(object, excludeKeys = []) {
  if (object === undefined) {
    return {};
  }
  const result = {};
  Object.keys(object).filter(prop => prop.match(/^on[A-Z]/) && typeof object[prop] === 'function' && !excludeKeys.includes(prop)).forEach(prop => {
    result[prop] = object[prop];
  });
  return result;
}

/***/ }),

/***/ 733580:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



var _interopRequireDefault = __webpack_require__(327574);
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
var _exportNames = {
  appendOwnerState: true,
  areArraysEqual: true,
  ClassNameConfigurator: true,
  extractEventHandlers: true,
  isHostComponent: true,
  resolveComponentProps: true,
  useSlotProps: true,
  mergeSlotProps: true
};
Object.defineProperty(exports, "ClassNameConfigurator", ({
  enumerable: true,
  get: function () {
    return _ClassNameConfigurator.default;
  }
}));
Object.defineProperty(exports, "appendOwnerState", ({
  enumerable: true,
  get: function () {
    return _appendOwnerState.default;
  }
}));
Object.defineProperty(exports, "areArraysEqual", ({
  enumerable: true,
  get: function () {
    return _areArraysEqual.default;
  }
}));
Object.defineProperty(exports, "extractEventHandlers", ({
  enumerable: true,
  get: function () {
    return _extractEventHandlers.default;
  }
}));
Object.defineProperty(exports, "isHostComponent", ({
  enumerable: true,
  get: function () {
    return _isHostComponent.default;
  }
}));
Object.defineProperty(exports, "mergeSlotProps", ({
  enumerable: true,
  get: function () {
    return _mergeSlotProps.default;
  }
}));
Object.defineProperty(exports, "resolveComponentProps", ({
  enumerable: true,
  get: function () {
    return _resolveComponentProps.default;
  }
}));
Object.defineProperty(exports, "useSlotProps", ({
  enumerable: true,
  get: function () {
    return _useSlotProps.default;
  }
}));
var _appendOwnerState = _interopRequireDefault(__webpack_require__(639786));
var _areArraysEqual = _interopRequireDefault(__webpack_require__(920549));
var _ClassNameConfigurator = _interopRequireDefault(__webpack_require__(102165));
var _extractEventHandlers = _interopRequireDefault(__webpack_require__(326460));
var _isHostComponent = _interopRequireDefault(__webpack_require__(260496));
var _resolveComponentProps = _interopRequireDefault(__webpack_require__(691682));
var _useSlotProps = _interopRequireDefault(__webpack_require__(510358));
var _mergeSlotProps = _interopRequireDefault(__webpack_require__(818218));
var _PolymorphicComponent = __webpack_require__(828223);
Object.keys(_PolymorphicComponent).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (Object.prototype.hasOwnProperty.call(_exportNames, key)) return;
  if (key in exports && exports[key] === _PolymorphicComponent[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _PolymorphicComponent[key];
    }
  });
});
var _types = __webpack_require__(292103);
Object.keys(_types).forEach(function (key) {
  if (key === "default" || key === "__esModule") return;
  if (Object.prototype.hasOwnProperty.call(_exportNames, key)) return;
  if (key in exports && exports[key] === _types[key]) return;
  Object.defineProperty(exports, key, {
    enumerable: true,
    get: function () {
      return _types[key];
    }
  });
});

/***/ }),

/***/ 260496:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = isHostComponent;
/**
 * Determines if a given element is a DOM element name (i.e. not a React component).
 */
function isHostComponent(element) {
  return typeof element === 'string';
}

/***/ }),

/***/ 818218:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



var _interopRequireDefault = __webpack_require__(327574);
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = mergeSlotProps;
var _extends2 = _interopRequireDefault(__webpack_require__(859651));
var _clsx = _interopRequireDefault(__webpack_require__(314889));
var _extractEventHandlers = _interopRequireDefault(__webpack_require__(326460));
var _omitEventHandlers = _interopRequireDefault(__webpack_require__(856486));
/**
 * Merges the slot component internal props (usually coming from a hook)
 * with the externally provided ones.
 *
 * The merge order is (the latter overrides the former):
 * 1. The internal props (specified as a getter function to work with get*Props hook result)
 * 2. Additional props (specified internally on a Base UI component)
 * 3. External props specified on the owner component. These should only be used on a root slot.
 * 4. External props specified in the `slotProps.*` prop.
 * 5. The `className` prop - combined from all the above.
 * @param parameters
 * @returns
 */
function mergeSlotProps(parameters) {
  const {
    getSlotProps,
    additionalProps,
    externalSlotProps,
    externalForwardedProps,
    className
  } = parameters;
  if (!getSlotProps) {
    // The simpler case - getSlotProps is not defined, so no internal event handlers are defined,
    // so we can simply merge all the props without having to worry about extracting event handlers.
    const joinedClasses = (0, _clsx.default)(externalForwardedProps == null ? void 0 : externalForwardedProps.className, externalSlotProps == null ? void 0 : externalSlotProps.className, className, additionalProps == null ? void 0 : additionalProps.className);
    const mergedStyle = (0, _extends2.default)({}, additionalProps == null ? void 0 : additionalProps.style, externalForwardedProps == null ? void 0 : externalForwardedProps.style, externalSlotProps == null ? void 0 : externalSlotProps.style);
    const props = (0, _extends2.default)({}, additionalProps, externalForwardedProps, externalSlotProps);
    if (joinedClasses.length > 0) {
      props.className = joinedClasses;
    }
    if (Object.keys(mergedStyle).length > 0) {
      props.style = mergedStyle;
    }
    return {
      props,
      internalRef: undefined
    };
  }

  // In this case, getSlotProps is responsible for calling the external event handlers.
  // We don't need to include them in the merged props because of this.

  const eventHandlers = (0, _extractEventHandlers.default)((0, _extends2.default)({}, externalForwardedProps, externalSlotProps));
  const componentsPropsWithoutEventHandlers = (0, _omitEventHandlers.default)(externalSlotProps);
  const otherPropsWithoutEventHandlers = (0, _omitEventHandlers.default)(externalForwardedProps);
  const internalSlotProps = getSlotProps(eventHandlers);

  // The order of classes is important here.
  // Emotion (that we use in libraries consuming Base UI) depends on this order
  // to properly override style. It requires the most important classes to be last
  // (see https://github.com/mui/material-ui/pull/33205) for the related discussion.
  const joinedClasses = (0, _clsx.default)(internalSlotProps == null ? void 0 : internalSlotProps.className, additionalProps == null ? void 0 : additionalProps.className, className, externalForwardedProps == null ? void 0 : externalForwardedProps.className, externalSlotProps == null ? void 0 : externalSlotProps.className);
  const mergedStyle = (0, _extends2.default)({}, internalSlotProps == null ? void 0 : internalSlotProps.style, additionalProps == null ? void 0 : additionalProps.style, externalForwardedProps == null ? void 0 : externalForwardedProps.style, externalSlotProps == null ? void 0 : externalSlotProps.style);
  const props = (0, _extends2.default)({}, internalSlotProps, additionalProps, otherPropsWithoutEventHandlers, componentsPropsWithoutEventHandlers);
  if (joinedClasses.length > 0) {
    props.className = joinedClasses;
  }
  if (Object.keys(mergedStyle).length > 0) {
    props.style = mergedStyle;
  }
  return {
    props,
    internalRef: internalSlotProps.ref
  };
}

/***/ }),

/***/ 856486:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = omitEventHandlers;
/**
 * Removes event handlers from the given object.
 * A field is considered an event handler if it is a function with a name beginning with `on`.
 *
 * @param object Object to remove event handlers from.
 * @returns Object with event handlers removed.
 */
function omitEventHandlers(object) {
  if (object === undefined) {
    return {};
  }
  const result = {};
  Object.keys(object).filter(prop => !(prop.match(/^on[A-Z]/) && typeof object[prop] === 'function')).forEach(prop => {
    result[prop] = object[prop];
  });
  return result;
}

/***/ }),

/***/ 691682:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = resolveComponentProps;
/**
 * If `componentProps` is a function, calls it with the provided `ownerState`.
 * Otherwise, just returns `componentProps`.
 */
function resolveComponentProps(componentProps, ownerState) {
  if (typeof componentProps === 'function') {
    return componentProps(ownerState);
  }
  return componentProps;
}

/***/ }),

/***/ 292103:
/***/ ((__unused_webpack_module, exports) => {



Object.defineProperty(exports, "__esModule", ({
  value: true
}));

/***/ }),

/***/ 510358:
/***/ ((__unused_webpack_module, exports, __webpack_require__) => {



var _interopRequireDefault = __webpack_require__(327574);
Object.defineProperty(exports, "__esModule", ({
  value: true
}));
exports["default"] = useSlotProps;
var _extends2 = _interopRequireDefault(__webpack_require__(859651));
var _objectWithoutPropertiesLoose2 = _interopRequireDefault(__webpack_require__(820820));
var _utils = __webpack_require__(490480);
var _appendOwnerState = _interopRequireDefault(__webpack_require__(639786));
var _mergeSlotProps = _interopRequireDefault(__webpack_require__(818218));
var _resolveComponentProps = _interopRequireDefault(__webpack_require__(691682));
const _excluded = ["elementType", "externalSlotProps", "ownerState"];
/**
 * @ignore - do not document.
 * Builds the props to be passed into the slot of an unstyled component.
 * It merges the internal props of the component with the ones supplied by the user, allowing to customize the behavior.
 * If the slot component is not a host component, it also merges in the `ownerState`.
 *
 * @param parameters.getSlotProps - A function that returns the props to be passed to the slot component.
 */
function useSlotProps(parameters) {
  var _parameters$additiona;
  const {
      elementType,
      externalSlotProps,
      ownerState
    } = parameters,
    rest = (0, _objectWithoutPropertiesLoose2.default)(parameters, _excluded);
  const resolvedComponentsProps = (0, _resolveComponentProps.default)(externalSlotProps, ownerState);
  const {
    props: mergedProps,
    internalRef
  } = (0, _mergeSlotProps.default)((0, _extends2.default)({}, rest, {
    externalSlotProps: resolvedComponentsProps
  }));
  const ref = (0, _utils.unstable_useForkRef)(internalRef, resolvedComponentsProps == null ? void 0 : resolvedComponentsProps.ref, (_parameters$additiona = parameters.additionalProps) == null ? void 0 : _parameters$additiona.ref);
  const props = (0, _appendOwnerState.default)(elementType, (0, _extends2.default)({}, mergedProps, {
    ref
  }), ownerState);
  return props;
}

/***/ })

};
;