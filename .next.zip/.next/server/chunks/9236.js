"use strict";
exports.id = 9236;
exports.ids = [9236];
exports.modules = {

/***/ 82365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.useSearchParams)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 819236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "V": () => (/* binding */ VoucherDetails)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./node_modules/yup/index.js
var yup = __webpack_require__(158952);
// EXTERNAL MODULE: ./src/utils/common.ts
var common = __webpack_require__(867644);
// EXTERNAL MODULE: ./src/sections/dashboard/voucher/voucher-list-table.tsx
var voucher_list_table = __webpack_require__(93417);
// EXTERNAL MODULE: ./src/paths.ts
var paths = __webpack_require__(287842);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(333518);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/index.js
var node = __webpack_require__(664085);
// EXTERNAL MODULE: ./src/components/file-dropzone.tsx
var file_dropzone = __webpack_require__(452235);
// EXTERNAL MODULE: ./node_modules/@mui/x-date-pickers/node/index.js
var x_date_pickers_node = __webpack_require__(998591);
// EXTERNAL MODULE: ./src/hooks/use-auth.ts
var use_auth = __webpack_require__(796372);
;// CONCATENATED MODULE: ./src/utils/file-to-base64.ts
const fileToBase64 = (file)=>new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = ()=>resolve(reader.result);
        reader.onerror = (error)=>reject(error);
    });

// EXTERNAL MODULE: ./node_modules/formik/dist/index.js
var formik_dist = __webpack_require__(906135);
// EXTERNAL MODULE: ./src/hooks/use-mounted.ts
var use_mounted = __webpack_require__(887408);
// EXTERNAL MODULE: ./src/hooks/use-router.ts
var use_router = __webpack_require__(840513);
// EXTERNAL MODULE: ./src/hooks/use-search-params.ts
var use_search_params = __webpack_require__(82365);
// EXTERNAL MODULE: ./src/api/main/index.ts
var main = __webpack_require__(15708);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/cjs/index.js
var cjs = __webpack_require__(845801);
// EXTERNAL MODULE: ./src/sections/components/buttons/button.tsx
var buttons_button = __webpack_require__(633743);
;// CONCATENATED MODULE: ./src/sections/dashboard/voucher/voucher-drawer/voucher-details.tsx























const VoucherDetails = (props)=>{
    const { voucher , onClose , onRatingUpdate , viaVoucher  } = props;
    const [cover, setCover] = (0,react_.useState)();
    const user = (0,use_auth/* useAuth */.a)();
    const isMounted = (0,use_mounted/* useMounted */.s)();
    const router = (0,use_router/* useRouter */.t)();
    const searchParams = (0,use_search_params/* useSearchParams */.l)();
    const returnTo = searchParams.get("returnTo");
    const [files, setFiles] = (0,react_.useState)([]);
    const [hoverState, setHoverState] = (0,react_.useState)(voucher?.partnerRating || 0);
    // Initialize hover state for each item
    (0,react_.useEffect)(()=>{
        setFiles([]);
    }, [
        open
    ]);
    const handleDrop = (0,react_.useCallback)((newFiles)=>{
        setFiles((prevFiles)=>{
            return [
                ...prevFiles,
                ...newFiles
            ];
        });
    }, []);
    const handleRemove = (0,react_.useCallback)((file)=>{
        setFiles((prevFiles)=>{
            return prevFiles.filter((_file)=>_file !== file);
        });
    }, []);
    const handleRemoveAll = (0,react_.useCallback)(()=>{
        setFiles([]);
    }, []);
    const initialValues = {
        name: `${voucher?.userFirstName ?? ""} ${voucher?.userLastName ?? ""}`,
        feedbackDate: new Date(),
        rating: voucher?.partnerRating ?? 0,
        feedback: "",
        partnerName: user?.user?.name ?? "",
        submit: null
    };
    const validationSchema = yup/* object */.Ry({
        name: yup/* string */.Z_().max(255).required("Member name is required"),
        feedback: yup/* string */.Z_().max(750).required("Feedback is required")
    });
    function resetForm() {
        formik.resetForm();
        setFiles([]);
        onClose?.();
    }
    const formik = (0,formik_dist.useFormik)({
        initialValues,
        validationSchema,
        onSubmit: async (values, helpers)=>{
            const base64FilePromises = files.map((file)=>fileToBase64(file));
            try {
                const base64Files = await Promise.all(base64FilePromises);
                const res = await main/* mainApi.postPartnerFeedback */.m.postPartnerFeedback(1, values, // @ts-ignore
                base64Files);
                if (res.response.status === 200) {
                    dist/* default.success */.ZP.success("Feedback submitted to Future Golf");
                    resetForm();
                } else {
                    dist/* default.error */.ZP.error(`Whoops, there was an error in submitting this feedback`);
                }
            } catch (err) {
                console.error(err);
                if (isMounted()) {
                    helpers.setStatus({
                        success: false
                    });
                    helpers.setErrors({
                        submit: err.message
                    });
                    helpers.setSubmitting(false);
                }
            }
        }
    });
    let statusColor;
    if (voucher?.status && voucher_list_table/* statusMap */.h[voucher.status]) {
        statusColor = voucher_list_table/* statusMap */.h[voucher.status];
    } else {
        statusColor = "warning"; // Default value
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
        spacing: 6,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            noValidate: true,
            onSubmit: formik.handleSubmit,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.Card, {
                            elevation: 16,
                            sx: {
                                borderRadius: 1,
                                justifyContent: "space-between",
                                px: 3,
                                py: 2
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(node.Grid, {
                                    xs: 12,
                                    sm: 6,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormControl, {
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.FormLabel, {
                                                sx: {
                                                    color: "text.primary",
                                                    mb: 1
                                                },
                                                children: "Member Name"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.OutlinedInput, {
                                                error: !!(formik.touched.name && formik.errors.name),
                                                fullWidth: true,
                                                placeholder: "John Smith",
                                                disabled: viaVoucher,
                                                name: "name",
                                                onBlur: formik.handleBlur,
                                                onChange: formik.handleChange,
                                                type: "text",
                                                value: formik.values.name
                                            })
                                        ]
                                    })
                                }),
                                voucher?.partnerRating && onRatingUpdate && /*#__PURE__*/ jsx_runtime_.jsx(node.Grid, {
                                    xs: 12,
                                    sm: 6,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormControl, {
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.FormLabel, {
                                                sx: {
                                                    color: "text.primary",
                                                    mt: 2,
                                                    mb: 1
                                                },
                                                children: "Rating"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.Rating, {
                                                name: "hover-feedback",
                                                value: voucher.partnerRating,
                                                getLabelText: common/* getLabelText */.Kh,
                                                onChange: (event, newValue)=>onRatingUpdate(voucher, newValue ?? 0, voucher.partnerRating),
                                                onChangeActive: (event, newHover)=>{
                                                    setHoverState(newHover);
                                                },
                                                emptyIcon: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* Star01 */.M_q, {
                                                    style: {
                                                        opacity: 0.55
                                                    },
                                                    fontSize: "inherit"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.Box, {
                                                sx: {
                                                    ml: 2
                                                },
                                                children: common/* labels */.p8[hoverState !== -1 && hoverState !== null && hoverState !== undefined ? hoverState : voucher.partnerRating]
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.Card, {
                            elevation: 16,
                            sx: {
                                borderRadius: 1,
                                justifyContent: "space-between",
                                px: 3,
                                py: 2
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(node.Grid, {
                                    xs: 12,
                                    sm: 6,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormControl, {
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.FormLabel, {
                                                sx: {
                                                    color: "text.primary",
                                                    mb: 1
                                                },
                                                children: "Feedback Date"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(x_date_pickers_node.DateTimePicker, {
                                                label: "Feedback Date",
                                                onChange: formik.handleChange,
                                                value: formik.values.feedbackDate,
                                                format: "dd/MM/yyyy hh:mm a"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(node.Grid, {
                                    xs: 12,
                                    sm: 6,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormControl, {
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.FormLabel, {
                                                sx: {
                                                    color: "text.primary",
                                                    mt: 2,
                                                    mb: 1
                                                },
                                                children: "Feedback"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.OutlinedInput, {
                                                error: !!(formik.touched.feedback && formik.errors.feedback),
                                                fullWidth: true,
                                                placeholder: "Your feedback...",
                                                minRows: 4,
                                                multiline: true,
                                                name: "feedback",
                                                onBlur: formik.handleBlur,
                                                onChange: formik.handleChange,
                                                type: "text",
                                                value: formik.values.feedback
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(node.Card, {
                            elevation: 16,
                            sx: {
                                borderRadius: 1,
                                justifyContent: "space-between",
                                px: 3,
                                py: 2
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(node.Grid, {
                                xs: 12,
                                sm: 6,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormControl, {
                                    fullWidth: true,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormLabel, {
                                            sx: {
                                                color: "text.primary",
                                                mb: 1
                                            },
                                            children: [
                                                "Attachments",
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "subtitle2",
                                                    children: "Maximum of 10 files"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "subtitle2",
                                                    children: "(optional)"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(file_dropzone/* FileDropzone */.Y, {
                                            accept: {
                                                "image/*": [],
                                                "application/pdf": [
                                                    ".pdf"
                                                ]
                                            },
                                            caption: "(PDF, JPG, PNG or SVG files only)",
                                            files: files,
                                            onDrop: handleDrop,
                                            onRemove: handleRemove,
                                            onRemoveAll: handleRemoveAll
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.Card, {
                    elevation: 16,
                    sx: {
                        alignItems: "center",
                        borderRadius: 1,
                        display: "flex",
                        justifyContent: "space-between",
                        mt: 2,
                        mb: 8,
                        px: 3,
                        py: 2
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                            variant: "subtitle2",
                            sx: {
                                fontWeight: 300
                            },
                            children: [
                                "We appreciate your feedback,",
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "subtitle2",
                                    children: user.user?.name
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            spacing: 2,
                            children: [
                                !voucher && /*#__PURE__*/ jsx_runtime_.jsx(buttons_button/* Button */.z, {
                                    color: "inherit",
                                    //     component={RouterLink}
                                    href: paths/* paths.dashboard.memberFeedback */.H.dashboard.memberFeedback,
                                    onClick: ()=>(resetForm(), dist/* default.error */.ZP.error("Feedback cancelled")),
                                    children: "Cancel"
                                }),
                                formik.errors.submit && /*#__PURE__*/ jsx_runtime_.jsx(node.FormHelperText, {
                                    error: true,
                                    sx: {
                                        mt: 3
                                    },
                                    children: formik.errors.submit
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(buttons_button/* Button */.z, {
                                    disabled: formik.isSubmitting,
                                    type: "submit",
                                    variant: "contained",
                                    children: "Submit feedback"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
VoucherDetails.propTypes = {
    onApprove: (prop_types_default()).func,
    onEdit: (prop_types_default()).func,
    onReject: (prop_types_default()).func,
    // @ts-ignore
    voucher: (prop_types_default()).object
};


/***/ }),

/***/ 93417:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ VoucherListTable),
/* harmony export */   "h": () => (/* binding */ statusMap)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(869232);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _untitled_ui_icons_react_build_esm_CheckCircle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(959982);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(746661);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(916816);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_material_Link__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(115917);
/* harmony import */ var _mui_material_Link__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Link__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(381394);
/* harmony import */ var _mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(620390);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Table__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(843606);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(340514);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_TableHead__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(30092);
/* harmony import */ var _mui_material_TableHead__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableHead__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(893761);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(66609);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var date_fns_tz__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(189371);
/* harmony import */ var date_fns_tz__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(771879);
/* harmony import */ var src_components_scrollbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(851716);
/* harmony import */ var _untitled_ui_icons_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(845801);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(556020);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var src_components_severity_pill__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(594368);
/* harmony import */ var src_utils_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(867644);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(247022);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Rating__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(664085);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_21__);






















const statusMap = {
    1: "success",
    2: "info",
    3: "warning",
    4: "success"
};
const VoucherListTable = (props)=>{
    const { items =[] , onMarkAsVerified , onOpenVoucher , onRatingUpdate , selected =[] , isLoading  } = props;
    // Initialize hover state for each item
    const [hoverStates, setHoverStates] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(items.map(()=>-1));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_7__["default"], {
            sx: {
                position: "relative"
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(src_components_scrollbar__WEBPACK_IMPORTED_MODULE_3__/* .Scrollbar */ .L, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Table__WEBPACK_IMPORTED_MODULE_8___default()), {
                        stickyHeader: true,
                        size: "small",
                        "aria-label": "a dense table",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableHead__WEBPACK_IMPORTED_MODULE_9___default()), {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Member Rating"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Action"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Name"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Claimed On"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "GOLF Link"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Voucher Code"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Verified On"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_12___default()), {
                                children: items.length > 0 && items.map((voucher, index)=>{
                                    const isSelected = selected.includes(String(voucher.id));
                                    const hoverState = hoverStates[index]; // Get hover state for the current row
                                    // Create a hover state for the current row
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_10___default()), {
                                        hover: true,
                                        selected: isSelected,
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Rating__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                        name: "hover-feedback",
                                                        value: voucher.partnerRating,
                                                        getLabelText: src_utils_common__WEBPACK_IMPORTED_MODULE_6__/* .getLabelText */ .Kh,
                                                        onChange: (event, newValue)=>onRatingUpdate(voucher, newValue ?? 0, voucher.partnerRating),
                                                        onChangeActive: (event, newHover)=>{
                                                            // Update the hover state for the current row
                                                            const newHoverStates = [
                                                                ...hoverStates
                                                            ];
                                                            newHoverStates[index] = newHover;
                                                            setHoverStates(newHoverStates);
                                                        },
                                                        emptyIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_untitled_ui_icons_react__WEBPACK_IMPORTED_MODULE_4__/* .Star01 */ .M_q, {
                                                            style: {
                                                                opacity: 0.55
                                                            },
                                                            fontSize: "inherit"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_7__["default"], {
                                                        sx: {
                                                            ml: 2
                                                        },
                                                        children: src_utils_common__WEBPACK_IMPORTED_MODULE_6__/* .labels */ .p8[hoverState !== -1 && hoverState !== null && hoverState !== undefined ? hoverState : voucher.partnerRating]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: [
                                                    voucher.status === "1" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        title: "Mark as verified",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                            onClick: ()=>onMarkAsVerified(voucher, "2"),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_16___default()), {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_untitled_ui_icons_react_build_esm_CheckCircle__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        title: "Provide member feedback",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                            onClick: ()=>onOpenVoucher(voucher),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_16___default()), {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_untitled_ui_icons_react__WEBPACK_IMPORTED_MODULE_4__/* .AlertHexagon */ .YfB, {})
                                                            })
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: [
                                                    voucher.userFirstName,
                                                    " ",
                                                    voucher.userLastName
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: voucher.claimedDate
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: Number(voucher.userGolfLink) ? voucher.userGolfLink : "Unknown"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: voucher.voucherCode
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: voucher.verifiedDate || [
                                                    "2"
                                                ].includes(voucher.status) ? voucher.verifiedDate ? (0,date_fns_tz__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)((0,date_fns_tz__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)((0,date_fns__WEBPACK_IMPORTED_MODULE_19__.fromUnixTime)(Number(voucher.verifiedDate)), "UTC"), "dd/MM/yyyy hh:mm:ss a", {
                                                    timeZone: "UTC"
                                                }) : "Unable to determine" : [
                                                    "4"
                                                ].includes(voucher.status) ? "Expired" : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                    title: "Mark as verified",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Link__WEBPACK_IMPORTED_MODULE_20___default()), {
                                                        variant: "inherit",
                                                        onClick: ()=>onMarkAsVerified(voucher, "2"),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_components_severity_pill__WEBPACK_IMPORTED_MODULE_5__/* .SeverityPill */ .I, {
                                                            color: "warning",
                                                            children: "Mark as verified"
                                                        })
                                                    })
                                                })
                                            })
                                        ]
                                    }, voucher.id);
                                })
                            })
                        ]
                    }),
                    !isLoading && items.length <= 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_21__.Typography, {
                        py: 6,
                        variant: "body2",
                        align: "center",
                        children: "\uD83D\uDE14 No vouchers found."
                    }),
                    isLoading && items.length <= 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material_Box__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        py: 5,
                        sx: {
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            justifyContent: "center"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_21__.CircularProgress, {
                                size: 20
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_21__.Typography, {
                                py: 1,
                                variant: "body2",
                                align: "center",
                                children: "Loading"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
VoucherListTable.propTypes = {
    count: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().number),
    items: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().array),
    onDeselectAll: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    onDeselectOne: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    onPageChange: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    onRowsPerPageChange: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    onSelect: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    onSelectAll: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    page: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().number),
    rowsPerPage: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().number),
    selected: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().array)
};


/***/ }),

/***/ 867644:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kh": () => (/* binding */ getLabelText),
/* harmony export */   "p8": () => (/* binding */ labels)
/* harmony export */ });
/* unused harmony exports VOUCHER_TYPES, VOUCHER_STATUS */
const VOUCHER_TYPES = {
    "1": {
        name: "Round of golf"
    },
    "2": {
        name: "Round of mini golf"
    },
    "3": {
        name: "Bucket of range balls"
    },
    "6": {
        name: "Skillest voucher"
    },
    "7": {
        name: "X-Golf $10 Credit voucher"
    },
    "8": {
        name: "X-Golf $25 Credit voucher"
    },
    "9": {
        name: "X-Golf $50 Credit voucher"
    },
    "10": {
        name: "X-Golf $75 Credit voucher"
    },
    undefined: {
        name: "Error"
    }
};
const VOUCHER_STATUS = {
    "1": {
        name: "Pending"
    },
    "2": {
        name: "Verified"
    },
    "3": {
        name: "Cancelled"
    },
    "6": {
        name: "Expired"
    },
    undefined: {
        name: "Error"
    }
};
const labels = {
    0: "No rating given",
    1: "Very bad",
    2: "Negative",
    3: "Average",
    4: "Great",
    5: "Brilliant"
};
function getLabelText(value) {
    return `${value} Star${value !== 1 ? "s" : ""}, ${labels[value]}`;
}


/***/ })

};
;