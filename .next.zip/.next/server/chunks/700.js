"use strict";
exports.id = 700;
exports.ids = [700];
exports.modules = {

/***/ 925115:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ PropertyListItem)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(869232);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(746661);
/* harmony import */ var _mui_material_ListItem__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(790777);
/* harmony import */ var _mui_material_ListItem__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(846517);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(243360);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3__);






const PropertyListItem = (props)=>{
    const { align ="vertical" , children , disableGutters , value , label , ...other } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_1___default()), {
        sx: {
            px: disableGutters ? 0 : 3,
            py: 1.5
        },
        ...other,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_2___default()), {
            disableTypography: true,
            primary: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default()), {
                sx: {
                    minWidth: align === "vertical" ? "inherit" : 180
                },
                variant: "subtitle2",
                children: label
            }),
            secondary: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_4__["default"], {
                sx: {
                    flex: 1,
                    mt: align === "vertical" ? 0.5 : 0
                },
                children: children || /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default()), {
                    color: "text.secondary",
                    variant: "body2",
                    children: value
                })
            }),
            sx: {
                display: "flex",
                flexDirection: align === "vertical" ? "column" : "row",
                my: 0
            }
        })
    });
};
PropertyListItem.propTypes = {
    align: prop_types__WEBPACK_IMPORTED_MODULE_5___default().oneOf([
        "horizontal",
        "vertical"
    ]),
    children: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().node),
    disableGutters: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().bool),
    label: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().string.isRequired),
    value: (prop_types__WEBPACK_IMPORTED_MODULE_5___default().string)
};


/***/ }),

/***/ 982009:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "c": () => (/* binding */ PropertyList)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(869232);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(854436);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_List__WEBPACK_IMPORTED_MODULE_1__);



const PropertyList = (props)=>{
    const { children  } = props;
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_List__WEBPACK_IMPORTED_MODULE_1___default()), {
        disablePadding: true,
        children: children
    });
};
PropertyList.propTypes = {
    children: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().node)
};


/***/ })

};
;