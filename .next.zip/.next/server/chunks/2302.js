exports.id = 2302;
exports.ids = [2302];
exports.modules = {

/***/ 365621:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 10585))

/***/ }),

/***/ 10585:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* reexport */ Layout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./src/hooks/use-auth.ts
var use_auth = __webpack_require__(796372);
// EXTERNAL MODULE: ./src/hooks/use-router.ts
var use_router = __webpack_require__(840513);
// EXTERNAL MODULE: ./src/paths.ts
var paths = __webpack_require__(287842);
// EXTERNAL MODULE: ./src/utils/auth.ts
var utils_auth = __webpack_require__(85403);
;// CONCATENATED MODULE: ./src/guards/auth-guard.tsx







const loginPaths = {
    [utils_auth/* Issuer.JWT */.M.JWT]: paths/* paths.auth.login */.H.auth.login
};
const AuthGuard = (props)=>{
    const { children  } = props;
    const router = (0,use_router/* useRouter */.t)();
    const { isAuthenticated , issuer  } = (0,use_auth/* useAuth */.a)();
    const [checked, setChecked] = (0,react_.useState)(false);
    const check = (0,react_.useCallback)(()=>{
        if (!isAuthenticated) {
            const searchParams = new URLSearchParams({
                returnTo: window.location.pathname
            }).toString();
            const href = loginPaths[issuer] + `?${searchParams}`;
            router.replace(href);
        } else {
            setChecked(true);
        }
    }, [
        isAuthenticated,
        issuer,
        router
    ]);
    // Only check on mount, this allows us to redirect the user manually when auth state changes
    (0,react_.useEffect)(()=>{
        check();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []);
    if (!checked) {
        return null;
    }
    // If got here, it means that the redirect did not occur, and that tells us that the user is
    // authenticated / authorized.
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: children
    });
};
AuthGuard.propTypes = {
    children: (prop_types_default()).node
};

;// CONCATENATED MODULE: ./src/hocs/with-auth-guard.tsx


const withAuthGuard = (Component)=>{
    return function WithAuthGuard(props) {
        return /*#__PURE__*/ jsx_runtime_.jsx(AuthGuard, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                ...props
            })
        });
    };
};

// EXTERNAL MODULE: ./src/hooks/use-settings.ts
var use_settings = __webpack_require__(488141);
// EXTERNAL MODULE: ./node_modules/react-i18next/dist/es/index.js + 14 modules
var es = __webpack_require__(791148);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
;// CONCATENATED MODULE: ./src/icons/untitled-ui/duocolor/users-03.tsx

const Users03 = (props)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 24,
        height: 24,
        fill: "none",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                fill: "currentColor",
                d: "M9.4998 12c2.4853 0 4.5-2.0147 4.5-4.5S11.9851 3 9.4998 3s-4.5 2.0147-4.5 4.5 2.0148 4.5 4.5 4.5Zm0 3c-2.8306 0-5.3464 1.5446-6.9407 3.9383-.3493.5245-.524.7867-.5038 1.1216.0156.2608.1866.5801.395.7377C2.7179 21 3.086 21 3.8222 21h11.3553c.7362 0 1.1043 0 1.3719-.2024.2084-.1576.3793-.4769.395-.7377.0201-.3349-.1545-.5971-.5038-1.1216C14.8463 16.5446 12.3305 15 9.4998 15Z",
                opacity: 0.12
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M17.9998 15.8369c1.4559.7314 2.7042 1.9051 3.6153 3.3727.1804.2907.2706.436.3018.6372.0634.409-.2163.9117-.5971 1.0736-.1875.0796-.3983.0796-.82.0796m-4.5-9.4678c1.4818-.7363 2.5-2.2653 2.5-4.0322 0-1.7669-1.0182-3.2959-2.5-4.0322m-2 4.0322c0 2.4853-2.0147 4.5-4.5 4.5s-4.5-2.0147-4.5-4.5S7.0146 3 9.4998 3c2.4853 0 4.5 2.0147 4.5 4.5ZM2.5591 18.9383C4.1534 16.5446 6.6692 15 9.4998 15c2.8307 0 5.3465 1.5446 6.9408 3.9383.3493.5245.5239.7867.5038 1.1216-.0157.2608-.1866.5801-.395.7377C16.2818 21 15.9137 21 15.1775 21H3.8222c-.7362 0-1.1043 0-1.372-.2024-.2083-.1576-.3793-.4769-.395-.7377-.02-.3349.1546-.5971.5039-1.1216Z"
            })
        ]
    });
/* harmony default export */ const users_03 = (Users03);

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/cjs/index.js
var cjs = __webpack_require__(845801);
// EXTERNAL MODULE: ./src/locales/tokens.ts
var tokens = __webpack_require__(288411);
;// CONCATENATED MODULE: ./src/layouts/dashboard/config.tsx









const useSections = ()=>{
    const { t  } = (0,es/* useTranslation */.$G)();
    return (0,react_.useMemo)(()=>{
        return [
            {
                items: [
                    {
                        title: t(tokens/* tokens.nav.overview */.T.nav.overview),
                        path: paths/* paths.dashboard.index */.H.dashboard.index,
                        icon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            fontSize: "small",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(users_03, {})
                        })
                    },
                    {
                        title: t(tokens/* tokens.nav.list */.T.nav.list),
                        path: paths/* paths.dashboard.teeTimes */.H.dashboard.teeTimes,
                        icon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            fontSize: "small",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* WatchCircle */.ouh, {})
                        })
                    },
                    {
                        title: t(tokens/* tokens.nav.memberFeedback */.T.nav.memberFeedback),
                        path: paths/* paths.dashboard.memberFeedback */.H.dashboard.memberFeedback,
                        icon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            fontSize: "small",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* NotificationBox */.LZ0, {})
                        })
                    },
                    {
                        title: t(tokens/* tokens.nav.marketing */.T.nav.marketing),
                        path: paths/* paths.dashboard.marketingContact */.H.dashboard.marketingContact,
                        icon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            fontSize: "small",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* Announcement01 */.CCt, {})
                        })
                    },
                    {
                        title: t(tokens/* tokens.nav.contact */.T.nav.contact),
                        path: paths/* paths.dashboard.contact */.H.dashboard.contact,
                        icon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            fontSize: "small",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* MessageSquare01 */.PEp, {})
                        })
                    }
                ]
            }
        ];
    }, [
        t
    ]);
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/useMediaQuery/index.js
var useMediaQuery = __webpack_require__(975983);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Drawer/index.js
var Drawer = __webpack_require__(379499);
var Drawer_default = /*#__PURE__*/__webpack_require__.n(Drawer);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./src/components/logo.tsx
var logo = __webpack_require__(4286);
// EXTERNAL MODULE: ./src/components/router-link.tsx
var router_link = __webpack_require__(510079);
// EXTERNAL MODULE: ./src/components/scrollbar.tsx
var scrollbar = __webpack_require__(851716);
// EXTERNAL MODULE: ./src/hooks/use-pathname.ts
var use_pathname = __webpack_require__(903268);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/index.js
var node = __webpack_require__(664085);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(333518);
// EXTERNAL MODULE: ./src/sections/components/buttons/button.tsx
var buttons_button = __webpack_require__(633743);
;// CONCATENATED MODULE: ./src/components/logout.tsx

 // Import React










const Logout = (props)=>{
    const { onClose  } = props;
    const router = (0,use_router/* useRouter */.t)();
    const auth = (0,use_auth/* useAuth */.a)();
    const [submitting, setSubmitting] = (0,react_.useState)(false);
    const handleLogout = (0,react_.useCallback)(async ()=>{
        setSubmitting(true);
        try {
            onClose?.();
            switch(auth.issuer){
                case utils_auth/* Issuer.JWT */.M.JWT:
                    {
                        await auth.signOut();
                        break;
                    }
                default:
                    {
                        console.warn("Using an unknown Auth Issuer, did not log out");
                    }
            }
            router.push(paths/* paths.auth.login */.H.auth.login);
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
        setSubmitting(false);
    }, [
        auth,
        router,
        onClose
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(buttons_button/* Button */.z, {
        fullWidth: true,
        variant: "contained",
        disabled: submitting,
        startIcon: /*#__PURE__*/ jsx_runtime_.jsx(node.SvgIcon, {
            children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* LogOut01 */.msg, {})
        }),
        onClick: handleLogout,
        size: "small",
        children: "Logout"
    });
};
Logout.propTypes = {
    onClose: (prop_types_default()).func
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronDown.js
var ChevronDown = __webpack_require__(870261);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronRight.js
var ChevronRight = __webpack_require__(492382);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ButtonBase/index.js
var ButtonBase = __webpack_require__(269860);
var ButtonBase_default = /*#__PURE__*/__webpack_require__.n(ButtonBase);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Collapse/index.js
var Collapse = __webpack_require__(836136);
var Collapse_default = /*#__PURE__*/__webpack_require__.n(Collapse);
;// CONCATENATED MODULE: ./src/layouts/dashboard/mobile-nav/mobile-nav-item.tsx










const MobileNavItem = (props)=>{
    const { active , children , depth =0 , disabled , external , icon , label , open: openProp , path , title  } = props;
    const [open, setOpen] = (0,react_.useState)(!!openProp);
    const handleToggle = (0,react_.useCallback)(()=>{
        setOpen((prevOpen)=>!prevOpen);
    }, []);
    // Icons can be defined at top level only, deep levels have bullets instead of actual icons.
    let startIcon;
    if (depth === 0) {
        startIcon = icon;
    } else {
        startIcon = /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
            sx: {
                alignItems: "center",
                display: "center",
                height: 20,
                justifyContent: "center",
                width: 20
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    borderRadius: "50%",
                    backgroundColor: "var(--nav-item-icon-color)",
                    height: 4,
                    opacity: 0,
                    width: 4,
                    ...active && {
                        backgroundColor: "var(--nav-item-icon-active-color)",
                        height: 6,
                        opacity: 1,
                        width: 6
                    }
                }
            })
        });
    }
    const offset = depth === 0 ? 0 : (depth - 1) * 16;
    // Branch
    if (children) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
                    disabled: disabled,
                    onClick: handleToggle,
                    sx: {
                        alignItems: "center",
                        borderRadius: 1,
                        display: "flex",
                        justifyContent: "flex-start",
                        pl: `${16 + offset}px`,
                        pr: "16px",
                        py: "6px",
                        textAlign: "left",
                        width: "100%",
                        ...active && {
                            ...depth === 0 && {
                                backgroundColor: "var(--nav-item-active-bg)"
                            }
                        },
                        "&:hover": {
                            backgroundColor: "var(--nav-item-hover-bg)"
                        }
                    },
                    children: [
                        startIcon && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            component: "span",
                            sx: {
                                alignItems: "center",
                                color: "var(--nav-item-icon-color)",
                                display: "inline-flex",
                                justifyContent: "center",
                                mr: 2,
                                ...active && {
                                    color: "var(--nav-item-icon-active-color)"
                                }
                            },
                            children: startIcon
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            component: "span",
                            sx: {
                                color: "var(--nav-item-color)",
                                flexGrow: 1,
                                fontFamily: (theme)=>theme.typography.fontFamily,
                                fontSize: depth > 0 ? 13 : 14,
                                fontWeight: depth > 0 ? 500 : 600,
                                lineHeight: "24px",
                                whiteSpace: "nowrap",
                                ...active && {
                                    color: "var(--nav-item-active-color)"
                                },
                                ...disabled && {
                                    color: "var(--nav-item-disabled-color)"
                                }
                            },
                            children: title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            sx: {
                                color: "var(--nav-item-chevron-color)",
                                fontSize: 16,
                                ml: 2
                            },
                            children: open ? /*#__PURE__*/ jsx_runtime_.jsx(ChevronDown/* default */.Z, {}) : /*#__PURE__*/ jsx_runtime_.jsx(ChevronRight/* default */.Z, {})
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Collapse_default()), {
                    in: open,
                    sx: {
                        mt: 0.5
                    },
                    children: children
                })
            ]
        });
    }
    // Leaf
    const linkProps = path ? external ? {
        component: "a",
        href: path,
        target: "_blank"
    } : {
        component: router_link/* RouterLink */.r,
        href: path
    } : {};
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
            disabled: disabled,
            sx: {
                alignItems: "center",
                borderRadius: 1,
                display: "flex",
                justifyContent: "flex-start",
                pl: `${16 + offset}px`,
                pr: "16px",
                py: "6px",
                textAlign: "left",
                width: "100%",
                ...active && {
                    ...depth === 0 && {
                        backgroundColor: "var(--nav-item-active-bg)"
                    }
                },
                "&:hover": {
                    backgroundColor: "var(--nav-item-hover-bg)"
                }
            },
            ...linkProps,
            children: [
                startIcon && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "span",
                    sx: {
                        alignItems: "center",
                        color: "var(--nav-item-icon-color)",
                        display: "inline-flex",
                        justifyContent: "center",
                        mr: 2,
                        ...active && {
                            color: "var(--nav-item-icon-active-color)"
                        }
                    },
                    children: startIcon
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "span",
                    sx: {
                        color: "var(--nav-item-color)",
                        flexGrow: 1,
                        fontFamily: (theme)=>theme.typography.fontFamily,
                        fontSize: depth > 0 ? 13 : 14,
                        fontWeight: depth > 0 ? 500 : 600,
                        lineHeight: "24px",
                        whiteSpace: "nowrap",
                        ...active && {
                            color: "var(--nav-item-active-color)"
                        },
                        ...disabled && {
                            color: "var(--nav-item-disabled-color)"
                        }
                    },
                    children: title
                }),
                label && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "span",
                    sx: {
                        ml: 2
                    },
                    children: label
                })
            ]
        })
    });
};
MobileNavItem.propTypes = {
    active: (prop_types_default()).bool,
    children: (prop_types_default()).node,
    depth: (prop_types_default()).number,
    disabled: (prop_types_default()).bool,
    external: (prop_types_default()).bool,
    icon: (prop_types_default()).node,
    label: (prop_types_default()).node,
    open: (prop_types_default()).bool,
    path: (prop_types_default()).string,
    title: (prop_types_default()).string.isRequired
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/mobile-nav/mobile-nav-section.tsx





const renderItems = ({ depth =0 , items , pathname  })=>items.reduce((acc, item)=>reduceChildRoutes({
            acc,
            depth,
            item,
            pathname
        }), []);
const reduceChildRoutes = ({ acc , depth , item , pathname  })=>{
    const checkPath = !!(item.path && pathname);
    const partialMatch = checkPath ? pathname.includes(item.path) : false;
    const exactMatch = checkPath ? pathname === item.path : false;
    if (item.items) {
        acc.push(/*#__PURE__*/ jsx_runtime_.jsx(MobileNavItem, {
            active: partialMatch,
            depth: depth,
            disabled: item.disabled,
            icon: item.icon,
            label: item.label,
            open: partialMatch,
            title: item.title,
            children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                component: "ul",
                spacing: 0.5,
                sx: {
                    listStyle: "none",
                    m: 0,
                    p: 0
                },
                children: renderItems({
                    depth: depth + 1,
                    items: item.items,
                    pathname
                })
            })
        }, item.title));
    } else {
        acc.push(/*#__PURE__*/ jsx_runtime_.jsx(MobileNavItem, {
            active: exactMatch,
            depth: depth,
            disabled: item.disabled,
            external: item.external,
            icon: item.icon,
            label: item.label,
            path: item.path,
            title: item.title
        }, item.title));
    }
    return acc;
};
const MobileNavSection = (props)=>{
    const { items =[] , pathname , subheader ="" , ...other } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        component: "ul",
        spacing: 0.5,
        sx: {
            listStyle: "none",
            m: 0,
            p: 0
        },
        ...other,
        children: [
            subheader && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "li",
                sx: {
                    color: "var(--nav-section-title-color)",
                    fontSize: 14,
                    fontWeight: 700,
                    lineHeight: 1.66,
                    mb: 1,
                    ml: 1,
                    textTransform: "uppercase"
                },
                children: subheader
            }),
            renderItems({
                items,
                pathname
            })
        ]
    });
};
MobileNavSection.propTypes = {
    items: (prop_types_default()).array,
    pathname: (prop_types_default()).string,
    subheader: (prop_types_default()).string
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/mobile-nav/mobile-nav.tsx














const MOBILE_NAV_WIDTH = 280;
const useCssVars = (color)=>{
    const theme = (0,styles.useTheme)();
    return (0,react_.useMemo)(()=>{
        switch(color){
            // Blend-in and discrete have no difference on mobile because
            // there's a backdrop and differences are not visible
            case "blend-in":
            case "discrete":
                if (theme.palette.mode === "dark") {
                    return {
                        "--nav-bg": theme.palette.background.default,
                        "--nav-color": theme.palette.neutral[100],
                        "--nav-logo-border": theme.palette.neutral[700],
                        "--nav-section-title-color": theme.palette.neutral[400],
                        "--nav-item-color": theme.palette.neutral[400],
                        "--nav-item-hover-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-color": theme.palette.text.primary,
                        "--nav-item-disabled-color": theme.palette.neutral[600],
                        "--nav-item-icon-color": theme.palette.neutral[500],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[700],
                        "--nav-item-chevron-color": theme.palette.neutral[700],
                        "--nav-scrollbar-color": theme.palette.neutral[400]
                    };
                } else {
                    return {
                        "--nav-bg": theme.palette.background.default,
                        "--nav-color": theme.palette.text.primary,
                        "--nav-logo-border": theme.palette.neutral[100],
                        "--nav-section-title-color": theme.palette.neutral[400],
                        "--nav-item-color": theme.palette.text.secondary,
                        "--nav-item-hover-bg": theme.palette.action.hover,
                        "--nav-item-active-bg": theme.palette.action.selected,
                        "--nav-item-active-color": theme.palette.text.primary,
                        "--nav-item-disabled-color": theme.palette.neutral[400],
                        "--nav-item-icon-color": theme.palette.neutral[400],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[400],
                        "--nav-item-chevron-color": theme.palette.neutral[400],
                        "--nav-scrollbar-color": theme.palette.neutral[900]
                    };
                }
            case "evident":
                if (theme.palette.mode === "dark") {
                    return {
                        "--nav-bg": theme.palette.neutral[800],
                        "--nav-color": theme.palette.common.white,
                        "--nav-logo-border": theme.palette.neutral[700],
                        "--nav-section-title-color": theme.palette.neutral[400],
                        "--nav-item-color": theme.palette.neutral[400],
                        "--nav-item-hover-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-color": theme.palette.common.white,
                        "--nav-item-disabled-color": theme.palette.neutral[500],
                        "--nav-item-icon-color": theme.palette.neutral[400],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[500],
                        "--nav-item-chevron-color": theme.palette.neutral[600],
                        "--nav-scrollbar-color": theme.palette.neutral[400]
                    };
                } else {
                    return {
                        "--nav-bg": theme.palette.neutral[800],
                        "--nav-color": theme.palette.common.white,
                        "--nav-logo-border": theme.palette.neutral[700],
                        "--nav-section-title-color": theme.palette.neutral[400],
                        "--nav-item-color": theme.palette.neutral[400],
                        "--nav-item-hover-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-color": theme.palette.common.white,
                        "--nav-item-disabled-color": theme.palette.neutral[500],
                        "--nav-item-icon-color": theme.palette.neutral[400],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[500],
                        "--nav-item-chevron-color": theme.palette.neutral[600],
                        "--nav-scrollbar-color": theme.palette.neutral[400]
                    };
                }
            default:
                return {};
        }
    }, [
        theme,
        color
    ]);
};
const MobileNav = (props)=>{
    const { color ="evident" , open , onClose , sections =[]  } = props;
    const pathname = (0,use_pathname/* usePathname */.j)();
    const cssVars = useCssVars(color);
    return /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
        anchor: "left",
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                ...cssVars,
                backgroundColor: "var(--nav-bg)",
                color: "var(--nav-color)",
                width: MOBILE_NAV_WIDTH
            }
        },
        variant: "temporary",
        children: /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
            sx: {
                height: "100%",
                "& .simplebar-content": {
                    height: "100%"
                },
                "& .simplebar-scrollbar:before": {
                    background: "var(--nav-scrollbar-color)"
                }
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                sx: {
                    height: "100%"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 2,
                        sx: {
                            p: 3
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            component: router_link/* RouterLink */.r,
                            href: paths/* paths.index */.H.index,
                            sx: {
                                display: "flex",
                                height: 40,
                                width: 150
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(logo/* Logo */.T, {
                                fillColor: "white"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                        component: "nav",
                        spacing: 2,
                        sx: {
                            flexGrow: 1,
                            px: 2
                        },
                        children: sections.map((section, index)=>/*#__PURE__*/ jsx_runtime_.jsx(MobileNavSection, {
                                items: section.items,
                                pathname: pathname,
                                subheader: section.subheader
                            }, index))
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            p: 3
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Logout, {})
                    })
                ]
            })
        })
    });
};
MobileNav.propTypes = {
    color: prop_types_default().oneOf([
        "blend-in",
        "discrete",
        "evident"
    ]),
    onClose: (prop_types_default()).func,
    open: (prop_types_default()).bool,
    sections: (prop_types_default()).array
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/mobile-nav/index.ts


// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Menu01.js
var Menu01 = __webpack_require__(913629);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./src/hooks/use-popover.ts
var use_popover = __webpack_require__(69281);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Popover/index.js
var Popover = __webpack_require__(980798);
var Popover_default = /*#__PURE__*/__webpack_require__.n(Popover);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
;// CONCATENATED MODULE: ./src/layouts/dashboard/account-button/account-popover.tsx









const AccountPopover = (props)=>{
    const { anchorEl , onClose , open , ...other } = props;
    const router = (0,use_router/* useRouter */.t)();
    const auth = (0,use_auth/* useAuth */.a)();
    const { user  } = (0,use_auth/* useAuth */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Popover_default()), {
        anchorEl: anchorEl,
        anchorOrigin: {
            horizontal: "center",
            vertical: "bottom"
        },
        disableScrollLock: true,
        onClose: onClose,
        open: !!open,
        PaperProps: {
            sx: {
                width: 200
            }
        },
        ...other,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                sx: {
                    p: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "body1",
                        children: user?.name
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        color: "text.secondary",
                        variant: "body2",
                        children: user?.email
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                sx: {
                    my: "0 !important"
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    display: "flex",
                    p: 1,
                    justifyContent: "center"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(Logout, {
                    onClose: onClose
                })
            })
        ]
    });
};
AccountPopover.propTypes = {
    anchorEl: (prop_types_default()).any,
    onClose: (prop_types_default()).func,
    open: (prop_types_default()).bool
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/account-button/account-button.tsx






const AccountButton = ()=>{
    const popover = (0,use_popover/* usePopover */.S)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: (ButtonBase_default()),
                onClick: popover.handleOpen,
                ref: popover.anchorRef,
                sx: {
                    alignItems: "center",
                    display: "flex",
                    borderWidth: 2,
                    borderStyle: "solid",
                    borderColor: "divider",
                    height: 40,
                    width: 40,
                    borderRadius: "50%"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(logo/* Logo */.T, {
                    variant: "secondary"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(AccountPopover, {
                anchorEl: popover.anchorRef.current,
                onClose: popover.handleClose,
                open: popover.open
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/account-button/index.ts


// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Users03.js
var esm_Users03 = __webpack_require__(851241);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tooltip/index.js
var Tooltip = __webpack_require__(556020);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/List/index.js
var List = __webpack_require__(854436);
var List_default = /*#__PURE__*/__webpack_require__.n(List);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItem/index.js
var ListItem = __webpack_require__(790777);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemAvatar/index.js
var ListItemAvatar = __webpack_require__(372355);
var ListItemAvatar_default = /*#__PURE__*/__webpack_require__.n(ListItemAvatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemText/index.js
var ListItemText = __webpack_require__(846517);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText);
// EXTERNAL MODULE: ./src/components/presence.tsx
var presence = __webpack_require__(159356);
// EXTERNAL MODULE: ./src/utils/date-locale.ts
var date_locale = __webpack_require__(268003);
;// CONCATENATED MODULE: ./src/layouts/dashboard/contacts-button/contacts-popover.tsx














const ContactsPopover = (props)=>{
    const { anchorEl , contacts =[] , onClose , open =false , ...other } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Popover_default()), {
        anchorEl: anchorEl,
        anchorOrigin: {
            horizontal: "center",
            vertical: "bottom"
        },
        disableScrollLock: true,
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                width: 320
            }
        },
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    p: 2
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "h6",
                    children: "Contacts"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    p: 2
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                    disablePadding: true,
                    children: contacts.map((contact)=>{
                        const showOnline = contact.isActive;
                        const lastActivity = !contact.isActive && contact.lastActivity ? (0,date_fns.formatDistanceStrict)(contact.lastActivity, new Date(), {
                            addSuffix: true,
                            locale: date_locale/* customLocale */.Z
                        }) : undefined;
                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                            disableGutters: true,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                        src: contact.avatar,
                                        sx: {
                                            cursor: "pointer"
                                        }
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                    disableTypography: true,
                                    primary: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                        color: "text.primary",
                                        noWrap: true,
                                        sx: {
                                            cursor: "pointer"
                                        },
                                        underline: "none",
                                        variant: "subtitle2",
                                        children: contact.name
                                    })
                                }),
                                showOnline && /*#__PURE__*/ jsx_runtime_.jsx(presence/* Presence */.z, {
                                    size: "small",
                                    status: "online"
                                }),
                                lastActivity && /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    noWrap: true,
                                    variant: "caption",
                                    children: lastActivity
                                })
                            ]
                        }, contact.id);
                    })
                })
            })
        ]
    });
};
ContactsPopover.propTypes = {
    anchorEl: (prop_types_default()).any,
    contacts: (prop_types_default()).array,
    onClose: (prop_types_default()).func,
    open: (prop_types_default()).bool
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/contacts-button/contacts-button.tsx








const now = new Date();
const useContacts = ()=>{
    return [
        {
            id: "5e8891ab188cd2855e6029b7",
            avatar: "/assets/avatars/avatar-alcides-antonio.png",
            isActive: true,
            lastActivity: now.getTime(),
            name: "Alcides Antonio"
        },
        {
            id: "5e887a62195cc5aef7e8ca5d",
            avatar: "/assets/avatars/avatar-marcus-finn.png",
            isActive: false,
            lastActivity: (0,date_fns.subHours)(now, 2).getTime(),
            name: "Marcus Finn"
        },
        {
            id: "5e887ac47eed253091be10cb",
            avatar: "/assets/avatars/avatar-carson-darrin.png",
            isActive: false,
            lastActivity: (0,date_fns.subMinutes)(now, 15).getTime(),
            name: "Carson Darrin"
        },
        {
            id: "5e887b209c28ac3dd97f6db5",
            avatar: "/assets/avatars/avatar-fran-perez.png",
            isActive: true,
            lastActivity: now.getTime(),
            name: "Fran Perez"
        },
        {
            id: "5e887b7602bdbc4dbb234b27",
            avatar: "/assets/avatars/avatar-jie-yan-song.png",
            isActive: true,
            lastActivity: now.getTime(),
            name: "Jie Yan Song"
        }
    ];
};
const ContactsButton = ()=>{
    const popover = (0,use_popover/* usePopover */.S)();
    const contacts = useContacts();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                title: "Contacts",
                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                    onClick: popover.handleOpen,
                    ref: popover.anchorRef,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(esm_Users03/* default */.Z, {})
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ContactsPopover, {
                anchorEl: popover.anchorRef.current,
                contacts: contacts,
                onClose: popover.handleClose,
                open: popover.open
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/contacts-button/index.ts


// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemIcon/index.js
var ListItemIcon = __webpack_require__(126765);
var ListItemIcon_default = /*#__PURE__*/__webpack_require__.n(ListItemIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/MenuItem/index.js
var MenuItem = __webpack_require__(662360);
var MenuItem_default = /*#__PURE__*/__webpack_require__.n(MenuItem);
;// CONCATENATED MODULE: ./src/layouts/dashboard/language-switch/language-popover.tsx












const languageOptions = {
    en: {
        icon: "/assets/flags/flag-uk.svg",
        label: "English"
    },
    de: {
        icon: "/assets/flags/flag-de.svg",
        label: "German"
    },
    es: {
        icon: "/assets/flags/flag-es.svg",
        label: "Spanish"
    }
};
const LanguagePopover = (props)=>{
    const { anchorEl , onClose , open =false , ...other } = props;
    const { i18n , t  } = (0,es/* useTranslation */.$G)();
    const handleChange = (0,react_.useCallback)(async (language)=>{
        onClose?.();
        await i18n.changeLanguage(language);
        const message = t(tokens/* tokens.common.languageChanged */.T.common.languageChanged);
        dist/* toast.success */.Am.success(message);
    }, [
        onClose,
        i18n,
        t
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx((Popover_default()), {
        anchorEl: anchorEl,
        anchorOrigin: {
            horizontal: "right",
            vertical: "bottom"
        },
        disableScrollLock: true,
        transformOrigin: {
            horizontal: "right",
            vertical: "top"
        },
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                width: 220
            }
        },
        ...other,
        children: Object.keys(languageOptions).map((language)=>{
            const option = languageOptions[language];
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                onClick: ()=>handleChange(language),
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                width: 28,
                                "& img": {
                                    width: "100%"
                                }
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                alt: option.label,
                                src: option.icon
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                        primary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "subtitle2",
                            children: option.label
                        })
                    })
                ]
            }, language);
        })
    });
};
LanguagePopover.propTypes = {
    anchorEl: (prop_types_default()).any,
    onClose: (prop_types_default()).func,
    open: (prop_types_default()).bool
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/language-switch/language-switch.tsx







const languages = {
    en: "/assets/flags/flag-uk.svg",
    de: "/assets/flags/flag-de.svg",
    es: "/assets/flags/flag-es.svg"
};
const LanguageSwitch = ()=>{
    const { i18n  } = (0,es/* useTranslation */.$G)();
    const popover = (0,use_popover/* usePopover */.S)();
    const flag = languages[i18n.language];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                title: "Language",
                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                    onClick: popover.handleOpen,
                    ref: popover.anchorRef,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            width: 28,
                            "& img": {
                                width: "100%"
                            }
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            src: flag
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(LanguagePopover, {
                anchorEl: popover.anchorRef.current,
                onClose: popover.handleClose,
                open: popover.open
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/language-switch/index.ts


// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Bell01.js
var Bell01 = __webpack_require__(493577);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Badge/index.js
var Badge = __webpack_require__(382361);
var Badge_default = /*#__PURE__*/__webpack_require__.n(Badge);
;// CONCATENATED MODULE: ./src/layouts/dashboard/notifications-button/notifications.ts

const notifications_now = new Date();
const notifications_notifications = [
    {
        id: "5e8883f1b51cc1956a5a1ec0",
        author: "Jie Yang Song",
        avatar: "/assets/avatars/avatar-jie-yan-song.png",
        createdAt: (0,date_fns.subHours)(notifications_now, 2).getTime(),
        job: "Remote React / React Native Developer",
        read: true,
        type: "job_add"
    },
    {
        id: "bfb21a370c017acc416757c7",
        author: "Jie Yang Song",
        avatar: "/assets/avatars/avatar-jie-yan-song.png",
        createdAt: (0,date_fns.subHours)(notifications_now, 2).getTime(),
        job: "Senior Golang Backend Engineer",
        read: false,
        type: "job_add"
    },
    {
        id: "20d9df4f23fff19668d7031c",
        createdAt: (0,date_fns.subDays)(notifications_now, 1).getTime(),
        description: "Logistics management is now available",
        read: true,
        type: "new_feature"
    },
    {
        id: "5e8883fca0e8612044248ecf",
        author: "Jie Yang Song",
        avatar: "/assets/avatars/avatar-jie-yan-song.png",
        company: "Augmastic Inc",
        createdAt: (0,date_fns.subHours)(notifications_now, 2).getTime(),
        read: false,
        type: "company_created"
    }
];

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/User01.js
var User01 = __webpack_require__(325055);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Mail04.js
var Mail04 = __webpack_require__(815318);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/MessageChatSquare.js
var MessageChatSquare = __webpack_require__(332500);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/X.js
var X = __webpack_require__(180501);
;// CONCATENATED MODULE: ./src/layouts/dashboard/notifications-button/notifications-popover.tsx





















const renderContent = (notification)=>{
    switch(notification.type){
        case "job_add":
            {
                const createdAt = (0,date_fns.format)(notification.createdAt, "MMM dd, h:mm a");
                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                            sx: {
                                mt: 0.5
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                src: notification.avatar,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(User01/* default */.Z, {})
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                            primary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    alignItems: "center",
                                    display: "flex",
                                    flexWrap: "wrap"
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        sx: {
                                            mr: 0.5
                                        },
                                        variant: "subtitle2",
                                        children: notification.author
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        sx: {
                                            mr: 0.5
                                        },
                                        variant: "body2",
                                        children: "added a new job"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                        href: "#",
                                        underline: "always",
                                        variant: "body2",
                                        children: notification.job
                                    })
                                ]
                            }),
                            secondary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.secondary",
                                variant: "caption",
                                children: createdAt
                            }),
                            sx: {
                                my: 0
                            }
                        })
                    ]
                });
            }
        case "new_feature":
            {
                const createdAt = (0,date_fns.format)(notification.createdAt, "MMM dd, h:mm a");
                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                            sx: {
                                mt: 0.5
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(MessageChatSquare/* default */.Z, {})
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                            primary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    alignItems: "center",
                                    display: "flex",
                                    flexWrap: "wrap"
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "subtitle2",
                                        sx: {
                                            mr: 0.5
                                        },
                                        children: "New feature!"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "body2",
                                        children: notification.description
                                    })
                                ]
                            }),
                            secondary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.secondary",
                                variant: "caption",
                                children: createdAt
                            }),
                            sx: {
                                my: 0
                            }
                        })
                    ]
                });
            }
        case "company_created":
            {
                const createdAt = (0,date_fns.format)(notification.createdAt, "MMM dd, h:mm a");
                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                            sx: {
                                mt: 0.5
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                src: notification.avatar,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(User01/* default */.Z, {})
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                            primary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    alignItems: "center",
                                    display: "flex",
                                    flexWrap: "wrap",
                                    m: 0
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        sx: {
                                            mr: 0.5
                                        },
                                        variant: "subtitle2",
                                        children: notification.author
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        sx: {
                                            mr: 0.5
                                        },
                                        variant: "body2",
                                        children: "created"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                        href: "#",
                                        underline: "always",
                                        variant: "body2",
                                        children: notification.company
                                    })
                                ]
                            }),
                            secondary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.secondary",
                                variant: "caption",
                                children: createdAt
                            }),
                            sx: {
                                my: 0
                            }
                        })
                    ]
                });
            }
        default:
            return null;
    }
};
const NotificationsPopover = (props)=>{
    const { anchorEl , notifications , onClose , onMarkAllAsRead , onRemoveOne , open =false , ...other } = props;
    const isEmpty = notifications.length === 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Popover_default()), {
        anchorEl: anchorEl,
        anchorOrigin: {
            horizontal: "left",
            vertical: "bottom"
        },
        disableScrollLock: true,
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                width: 380
            }
        },
        ...other,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                justifyContent: "space-between",
                spacing: 2,
                sx: {
                    px: 3,
                    py: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        color: "inherit",
                        variant: "h6",
                        children: "Notifications"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                        title: "Mark all as read",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            onClick: onMarkAllAsRead,
                            size: "small",
                            color: "inherit",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Mail04/* default */.Z, {})
                            })
                        })
                    })
                ]
            }),
            isEmpty ? /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    p: 2
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "subtitle2",
                    children: "There are no notifications"
                })
            }) : /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                sx: {
                    maxHeight: 400
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                    disablePadding: true,
                    children: notifications.map((notification)=>/*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                            divider: true,
                            sx: {
                                alignItems: "flex-start",
                                "&:hover": {
                                    backgroundColor: "action.hover"
                                },
                                "& .MuiListItemSecondaryAction-root": {
                                    top: "24%"
                                }
                            },
                            secondaryAction: /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                title: "Remove",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    edge: "end",
                                    onClick: ()=>onRemoveOne?.(notification.id),
                                    size: "small",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(X/* default */.Z, {})
                                    })
                                })
                            }),
                            children: renderContent(notification)
                        }, notification.id))
                })
            })
        ]
    });
};
NotificationsPopover.propTypes = {
    anchorEl: (prop_types_default()).any,
    notifications: (prop_types_default()).array.isRequired,
    onClose: (prop_types_default()).func,
    onMarkAllAsRead: (prop_types_default()).func,
    onRemoveOne: (prop_types_default()).func,
    open: (prop_types_default()).bool
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/notifications-button/notifications-button.tsx










const useNotifications = ()=>{
    const [notifications, setNotifications] = (0,react_.useState)(notifications_notifications);
    const unread = (0,react_.useMemo)(()=>{
        return notifications.reduce((acc, notification)=>acc + (notification.read ? 0 : 1), 0);
    }, [
        notifications
    ]);
    const handleRemoveOne = (0,react_.useCallback)((notificationId)=>{
        setNotifications((prevState)=>{
            return prevState.filter((notification)=>notification.id !== notificationId);
        });
    }, []);
    const handleMarkAllAsRead = (0,react_.useCallback)(()=>{
        setNotifications((prevState)=>{
            return prevState.map((notification)=>({
                    ...notification,
                    read: true
                }));
        });
    }, []);
    return {
        handleMarkAllAsRead,
        handleRemoveOne,
        notifications,
        unread
    };
};
const NotificationsButton = ()=>{
    const popover = (0,use_popover/* usePopover */.S)();
    const { handleRemoveOne , handleMarkAllAsRead , notifications , unread  } = useNotifications();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                title: "Notifications",
                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                    ref: popover.anchorRef,
                    onClick: popover.handleOpen,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Badge_default()), {
                        color: "error",
                        badgeContent: unread,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Bell01/* default */.Z, {})
                        })
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(NotificationsPopover, {
                anchorEl: popover.anchorRef.current,
                notifications: notifications,
                onClose: popover.handleClose,
                onMarkAllAsRead: handleMarkAllAsRead,
                onRemoveOne: handleRemoveOne,
                open: popover.open
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/notifications-button/index.ts


// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemButton/index.js
var ListItemButton = __webpack_require__(729234);
var ListItemButton_default = /*#__PURE__*/__webpack_require__.n(ListItemButton);
;// CONCATENATED MODULE: ./src/components/dropdown/dropdown-context.tsx

const noop = (...args)=>{};
const DropdownContext = /*#__PURE__*/ (0,react_.createContext)({
    anchorEl: null,
    onMenuEnter: noop,
    onMenuLeave: noop,
    onTriggerEnter: noop,
    onTriggerLeave: noop,
    open: false
});

;// CONCATENATED MODULE: ./src/components/dropdown/dropdown.tsx




const Dropdown = (props)=>{
    const { children , delay =50  } = props;
    const [anchorEl, setAnchorEl] = (0,react_.useState)(null);
    const cleanupRef = (0,react_.useRef)(null);
    const handleTriggerEnter = (0,react_.useCallback)((event)=>{
        clearTimeout(cleanupRef.current);
        setAnchorEl(event.currentTarget);
    }, []);
    const handleTriggerLeave = (0,react_.useCallback)((_)=>{
        cleanupRef.current = setTimeout(()=>{
            setAnchorEl(null);
        }, delay);
    }, [
        delay
    ]);
    const handleMenuEnter = (0,react_.useCallback)((_)=>{
        clearTimeout(cleanupRef.current);
    }, []);
    const handleMenuLeave = (0,react_.useCallback)((_)=>{
        cleanupRef.current = setTimeout(()=>{
            setAnchorEl(null);
        }, delay);
    }, [
        delay
    ]);
    const open = !!anchorEl;
    return /*#__PURE__*/ jsx_runtime_.jsx(DropdownContext.Provider, {
        value: {
            anchorEl,
            onMenuEnter: handleMenuEnter,
            onMenuLeave: handleMenuLeave,
            onTriggerEnter: handleTriggerEnter,
            onTriggerLeave: handleTriggerLeave,
            open
        },
        children: children
    });
};
Dropdown.propTypes = {
    children: prop_types_default().arrayOf((prop_types_default()).any).isRequired,
    delay: (prop_types_default()).number
};

;// CONCATENATED MODULE: ./src/components/dropdown/dropdown-trigger.tsx



const DropdownTrigger = (props)=>{
    const { children  } = props;
    const { onTriggerEnter , onTriggerLeave  } = (0,react_.useContext)(DropdownContext);
    return /*#__PURE__*/ (0,react_.cloneElement)(children, {
        onMouseEnter: (event)=>{
            children.props.onMouseEnter?.(event);
            onTriggerEnter(event);
        },
        onMouseLeave: (event)=>{
            children.props.onMouseLeave?.(event);
            onTriggerLeave(event);
        }
    });
};
DropdownTrigger.propTypes = {
    children: (prop_types_default()).element.isRequired
};

;// CONCATENATED MODULE: ./src/components/dropdown/dropdown-menu.tsx





const DropdownMenu = (props)=>{
    const { anchorEl , children , PaperProps , ...other } = props;
    const ctx = (0,react_.useContext)(DropdownContext);
    return /*#__PURE__*/ jsx_runtime_.jsx((Popover_default()), {
        anchorEl: anchorEl || ctx.anchorEl,
        anchorOrigin: {
            horizontal: "left",
            vertical: "bottom"
        },
        open: ctx.open,
        PaperProps: {
            ...PaperProps,
            onMouseEnter: ctx.onMenuEnter,
            onMouseLeave: ctx.onMenuLeave,
            sx: {
                ...PaperProps?.sx,
                pointerEvents: "auto"
            }
        },
        sx: {
            pointerEvents: "none"
        },
        transformOrigin: {
            horizontal: "left",
            vertical: "top"
        },
        ...other,
        children: children
    });
};
DropdownMenu.propTypes = {
    anchorEl: (prop_types_default()).any,
    // @ts-ignore
    anchorOrigin: (prop_types_default()).object,
    children: (prop_types_default()).any,
    disableScrollLock: (prop_types_default()).bool,
    PaperProps: (prop_types_default()).object,
    // @ts-ignore
    transformOrigin: (prop_types_default()).object
};

;// CONCATENATED MODULE: ./src/components/dropdown/index.ts




;// CONCATENATED MODULE: ./src/layouts/dashboard/horizontal-layout/top-nav-item.tsx











const renderChildItems = ({ items , depth =0  })=>{
    return items.map((item)=>{
        // Branch
        if (item.items) {
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Dropdown, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(DropdownTrigger, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItemButton_default()), {
                            disabled: item.disabled,
                            sx: {
                                borderRadius: 1,
                                px: 1.5,
                                py: 0.5
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                    primary: item.title,
                                    primaryTypographyProps: {
                                        sx: {
                                            color: "text.secondary",
                                            fontSize: 14,
                                            fontWeight: 500
                                        }
                                    }
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    fontSize: "small",
                                    sx: {
                                        color: "neutral.400"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronRight/* default */.Z, {})
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(DropdownMenu, {
                        anchorOrigin: {
                            horizontal: "right",
                            vertical: "top"
                        },
                        disableScrollLock: true,
                        PaperProps: {
                            elevation: 8,
                            sx: {
                                maxWidth: "100%",
                                ml: 1,
                                p: 1,
                                width: 200
                            }
                        },
                        transformOrigin: {
                            horizontal: "left",
                            vertical: "top"
                        },
                        children: renderChildItems({
                            items: item.items,
                            depth: depth + 1
                        })
                    })
                ]
            }, item.title);
        }
        const linkProps = item.path ? item.external ? {
            component: "a",
            href: item.path,
            target: "_blank"
        } : {
            component: router_link/* RouterLink */.r,
            href: item.path
        } : {};
        // Leaf
        return /*#__PURE__*/ jsx_runtime_.jsx((ListItemButton_default()), {
            disabled: item.disabled,
            sx: {
                borderRadius: 1,
                px: 1.5,
                py: 0.5
            },
            ...linkProps,
            children: /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                primary: item.title,
                primaryTypographyProps: {
                    sx: {
                        color: "text.secondary",
                        fontSize: 14,
                        fontWeight: 500
                    }
                }
            })
        }, item.title);
    });
};
const TopNavItem = (props)=>{
    const { active , disabled , external , items , icon , label , path , title  } = props;
    // With dropdown
    if (items) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Dropdown, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(DropdownTrigger, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx("li", {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
                            disabled: disabled,
                            sx: {
                                alignItems: "center",
                                borderRadius: 1,
                                display: "flex",
                                justifyContent: "flex-start",
                                px: "16px",
                                py: "6px",
                                textAlign: "left",
                                width: "100%",
                                ...active && {
                                    backgroundColor: "var(--nav-item-active-bg)"
                                },
                                "&:hover": {
                                    backgroundColor: "var(--nav-item-hover-bg)"
                                }
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                    component: "span",
                                    sx: {
                                        alignItems: "center",
                                        color: "var(--nav-item-icon-color)",
                                        display: "inline-flex",
                                        justifyContent: "center",
                                        mr: 2,
                                        ...active && {
                                            color: "var(--nav-item-icon-active-color)"
                                        }
                                    },
                                    children: icon
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                    component: "span",
                                    sx: {
                                        color: "var(--nav-item-color)",
                                        flexGrow: 1,
                                        fontFamily: (theme)=>theme.typography.fontFamily,
                                        fontSize: 14,
                                        fontWeight: 600,
                                        lineHeight: "24px",
                                        whiteSpace: "nowrap",
                                        ...active && {
                                            color: "var(--nav-item-active-color)"
                                        },
                                        ...disabled && {
                                            color: "var(--nav-item-disabled-color)"
                                        }
                                    },
                                    children: title
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    sx: {
                                        color: "var(--nav-item-chevron-color)",
                                        fontSize: 16,
                                        ml: 1
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronDown/* default */.Z, {})
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(DropdownMenu, {
                    disableScrollLock: true,
                    PaperProps: {
                        elevation: 8,
                        sx: {
                            maxWidth: "100%",
                            p: 1,
                            width: 200
                        }
                    },
                    children: renderChildItems({
                        items,
                        depth: 0
                    })
                })
            ]
        });
    }
    // Without dropdown
    const linkProps = path ? external ? {
        component: "a",
        href: path,
        target: "_blank"
    } : {
        component: router_link/* RouterLink */.r,
        href: path
    } : {};
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
            disabled: disabled,
            sx: {
                alignItems: "center",
                borderRadius: 1,
                display: "flex",
                justifyContent: "flex-start",
                px: "16px",
                py: "6px",
                textAlign: "left",
                width: "100%",
                ...active && {
                    backgroundColor: "var(--nav-item-active-bg)"
                },
                "&:hover": {
                    backgroundColor: "var(--nav-item-hover-bg)"
                }
            },
            ...linkProps,
            children: [
                icon && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "span",
                    sx: {
                        alignItems: "center",
                        color: "var(--nav-item-icon-color)",
                        display: "inline-flex",
                        justifyContent: "center",
                        mr: 2,
                        ...active && {
                            color: "var(--nav-item-icon-active-color)"
                        }
                    },
                    children: icon
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "span",
                    sx: {
                        color: "var(--nav-item-color)",
                        flexGrow: 1,
                        fontFamily: (theme)=>theme.typography.fontFamily,
                        fontSize: 14,
                        fontWeight: 600,
                        lineHeight: "24px",
                        whiteSpace: "nowrap",
                        ...active && {
                            color: "var(--nav-item-active-color)"
                        },
                        ...disabled && {
                            color: "var(--nav-item-disabled-color)"
                        }
                    },
                    children: title
                }),
                label && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "span",
                    sx: {
                        ml: 1
                    },
                    children: label
                })
            ]
        })
    });
};
TopNavItem.propTypes = {
    active: (prop_types_default()).bool,
    disabled: (prop_types_default()).bool,
    external: (prop_types_default()).bool,
    icon: (prop_types_default()).node,
    items: (prop_types_default()).array,
    label: (prop_types_default()).node,
    path: (prop_types_default()).string,
    title: (prop_types_default()).string.isRequired
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/horizontal-layout/top-nav-section.tsx




const TopNavSection = (props)=>{
    const { items =[] , pathname  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
        component: "ul",
        direction: "row",
        spacing: 1,
        sx: {
            listStyle: "none",
            m: 0,
            p: 0
        },
        children: items.map((item)=>{
            const checkPath = !!(item.path && pathname);
            const partialMatch = checkPath ? pathname.includes(item.path) : false;
            const exactMatch = checkPath ? pathname === item.path : false;
            // Branch
            if (item.items) {
                return /*#__PURE__*/ jsx_runtime_.jsx(TopNavItem, {
                    active: partialMatch,
                    disabled: item.disabled,
                    icon: item.icon,
                    items: item.items,
                    label: item.label,
                    title: item.title
                }, item.title);
            }
            // Leaf
            return /*#__PURE__*/ jsx_runtime_.jsx(TopNavItem, {
                active: exactMatch,
                disabled: item.disabled,
                external: item.external,
                icon: item.icon,
                label: item.label,
                path: item.path,
                title: item.title
            }, item.title);
        })
    });
};
TopNavSection.propTypes = {
    items: (prop_types_default()).array,
    pathname: (prop_types_default()).string,
    subheader: (prop_types_default()).string
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/horizontal-layout/top-nav.tsx


















const top_nav_useCssVars = (color)=>{
    const theme = (0,styles.useTheme)();
    return (0,react_.useMemo)(()=>{
        switch(color){
            case "blend-in":
                if (theme.palette.mode === "dark") {
                    return {
                        "--nav-bg": theme.palette.background.default,
                        "--nav-color": theme.palette.neutral[100],
                        "--nav-divider-color": theme.palette.neutral[800],
                        "--nav-border-color": theme.palette.neutral[700],
                        "--nav-logo-border": theme.palette.neutral[700],
                        "--nav-item-color": theme.palette.neutral[400],
                        "--nav-item-hover-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-color": theme.palette.text.primary,
                        "--nav-item-disabled-color": theme.palette.neutral[600],
                        "--nav-item-icon-color": theme.palette.neutral[500],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[700],
                        "--nav-item-chevron-color": theme.palette.neutral[700],
                        "--nav-scrollbar-color": theme.palette.neutral[400]
                    };
                } else {
                    return {
                        "--nav-bg": theme.palette.background.default,
                        "--nav-color": theme.palette.text.primary,
                        "--nav-divider-color": theme.palette.divider,
                        "--nav-border-color": theme.palette.neutral[100],
                        "--nav-logo-border": theme.palette.neutral[100],
                        "--nav-section-title-color": theme.palette.neutral[400],
                        "--nav-item-color": theme.palette.text.secondary,
                        "--nav-item-hover-bg": theme.palette.action.hover,
                        "--nav-item-active-bg": theme.palette.action.selected,
                        "--nav-item-active-color": theme.palette.text.primary,
                        "--nav-item-disabled-color": theme.palette.neutral[400],
                        "--nav-item-icon-color": theme.palette.neutral[400],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[400],
                        "--nav-item-chevron-color": theme.palette.neutral[400],
                        "--nav-scrollbar-color": theme.palette.neutral[900]
                    };
                }
            case "discrete":
                if (theme.palette.mode === "dark") {
                    return {
                        "--nav-bg": theme.palette.neutral[900],
                        "--nav-color": theme.palette.neutral[100],
                        "--nav-divider-color": theme.palette.neutral[800],
                        "--nav-border-color": theme.palette.neutral[700],
                        "--nav-logo-border": theme.palette.neutral[700],
                        "--nav-item-color": theme.palette.neutral[400],
                        "--nav-item-hover-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-color": theme.palette.text.primary,
                        "--nav-item-disabled-color": theme.palette.neutral[600],
                        "--nav-item-icon-color": theme.palette.neutral[500],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[700],
                        "--nav-item-chevron-color": theme.palette.neutral[700],
                        "--nav-scrollbar-color": theme.palette.neutral[400]
                    };
                } else {
                    return {
                        "--nav-bg": theme.palette.neutral[50],
                        "--nav-color": theme.palette.text.primary,
                        "--nav-divider-color": theme.palette.neutral[200],
                        "--nav-border-color": theme.palette.divider,
                        "--nav-logo-border": theme.palette.neutral[200],
                        "--nav-section-title-color": theme.palette.neutral[500],
                        "--nav-item-color": theme.palette.neutral[500],
                        "--nav-item-hover-bg": theme.palette.action.hover,
                        "--nav-item-active-bg": theme.palette.action.selected,
                        "--nav-item-active-color": theme.palette.text.primary,
                        "--nav-item-disabled-color": theme.palette.neutral[400],
                        "--nav-item-icon-color": theme.palette.neutral[400],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[400],
                        "--nav-item-chevron-color": theme.palette.neutral[400],
                        "--nav-scrollbar-color": theme.palette.neutral[900]
                    };
                }
            case "evident":
                if (theme.palette.mode === "dark") {
                    return {
                        "--nav-bg": theme.palette.neutral[800],
                        "--nav-color": theme.palette.common.white,
                        "--nav-divider-color": theme.palette.neutral[700],
                        "--nav-border-color": "transparent",
                        "--nav-logo-border": theme.palette.neutral[700],
                        "--nav-item-color": theme.palette.neutral[400],
                        "--nav-item-hover-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-color": theme.palette.common.white,
                        "--nav-item-disabled-color": theme.palette.neutral[500],
                        "--nav-item-icon-color": theme.palette.neutral[400],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[500],
                        "--nav-item-chevron-color": theme.palette.neutral[600],
                        "--nav-scrollbar-color": theme.palette.neutral[400]
                    };
                } else {
                    return {
                        "--nav-bg": theme.palette.neutral[800],
                        "--nav-color": theme.palette.common.white,
                        "--nav-divider-color": theme.palette.neutral[700],
                        "--nav-border-color": "transparent",
                        "--nav-logo-border": theme.palette.neutral[700],
                        "--nav-item-color": theme.palette.neutral[400],
                        "--nav-item-hover-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-color": theme.palette.common.white,
                        "--nav-item-disabled-color": theme.palette.neutral[500],
                        "--nav-item-icon-color": theme.palette.neutral[400],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[500],
                        "--nav-item-chevron-color": theme.palette.neutral[600],
                        "--nav-scrollbar-color": theme.palette.neutral[400]
                    };
                }
            default:
                return {};
        }
    }, [
        theme,
        color
    ]);
};
const TopNav = (props)=>{
    const { color ="evident" , onMobileNav , sections =[]  } = props;
    const pathname = (0,use_pathname/* usePathname */.j)();
    const mdUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("md"));
    const cssVars = top_nav_useCssVars(color);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
        component: "header",
        sx: {
            ...cssVars,
            backgroundColor: "var(--nav-bg)",
            borderBottomColor: "var(--nav-border-color)",
            borderBottomStyle: "solid",
            borderBottomWidth: 1,
            color: "var(--nav-color)",
            left: 0,
            position: "sticky",
            top: 0,
            zIndex: (theme)=>theme.zIndex.appBar
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                justifyContent: "space-between",
                spacing: 2,
                sx: {
                    px: 3,
                    py: 1
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 2,
                        children: [
                            !mdUp && /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: onMobileNav,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Menu01/* default */.Z, {})
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(logo/* Logo */.T, {
                                fillColor: "white"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(LanguageSwitch, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(NotificationsButton, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(ContactsButton, {}),
                            /*#__PURE__*/ jsx_runtime_.jsx(AccountButton, {})
                        ]
                    })
                ]
            }),
            mdUp && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    borderTopWidth: 1,
                    borderTopStyle: "solid",
                    borderTopColor: "var(--nav-divider-color)"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                    sx: {
                        "& .simplebar-scrollbar:before": {
                            background: "var(--nav-scrollbar-color)"
                        }
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                        alignItems: "center",
                        component: "nav",
                        direction: "row",
                        spacing: 1,
                        sx: {
                            px: 2,
                            py: 1.5
                        },
                        children: sections.map((section, index)=>/*#__PURE__*/ jsx_runtime_.jsx(TopNavSection, {
                                items: section.items,
                                pathname: pathname,
                                subheader: section.subheader
                            }, index))
                    })
                })
            })
        ]
    });
};
TopNav.propTypes = {
    color: prop_types_default().oneOf([
        "blend-in",
        "discrete",
        "evident"
    ]),
    onMobileNav: (prop_types_default()).func,
    sections: (prop_types_default()).array
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/horizontal-layout/use-mobile-nav.ts


const useMobileNav = ()=>{
    const pathname = (0,use_pathname/* usePathname */.j)();
    const [open, setOpen] = (0,react_.useState)(false);
    const handlePathnameChange = (0,react_.useCallback)(()=>{
        if (open) {
            setOpen(false);
        }
    }, [
        open
    ]);
    (0,react_.useEffect)(()=>{
        handlePathnameChange();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        pathname
    ]);
    const handleOpen = (0,react_.useCallback)(()=>{
        setOpen(true);
    }, []);
    const handleClose = (0,react_.useCallback)(()=>{
        setOpen(false);
    }, []);
    return {
        handleOpen,
        handleClose,
        open
    };
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/horizontal-layout/horizontal-layout.tsx







const HorizontalLayoutRoot = (0,styles.styled)("div")({
    display: "flex",
    flex: "1 1 auto",
    maxWidth: "100%"
});
const HorizontalLayoutContainer = (0,styles.styled)("div")({
    display: "flex",
    flex: "1 1 auto",
    flexDirection: "column",
    width: "100%"
});
const HorizontalLayout = (props)=>{
    const { children , navColor , sections  } = props;
    const lgUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("lg"));
    const mobileNav = useMobileNav();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(TopNav, {
                color: navColor,
                onMobileNav: mobileNav.handleOpen,
                sections: sections
            }),
            !lgUp && /*#__PURE__*/ jsx_runtime_.jsx(MobileNav, {
                color: navColor,
                onClose: mobileNav.handleClose,
                open: mobileNav.open,
                sections: sections
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(HorizontalLayoutRoot, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(HorizontalLayoutContainer, {
                    children: children
                })
            })
        ]
    });
};
HorizontalLayout.propTypes = {
    children: (prop_types_default()).node,
    navColor: prop_types_default().oneOf([
        "blend-in",
        "discrete",
        "evident"
    ]),
    sections: (prop_types_default()).array
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/horizontal-layout/index.ts


;// CONCATENATED MODULE: ./src/layouts/dashboard/vertical-layout/side-nav-item.tsx










const SideNavItem = (props)=>{
    const { active , children , depth =0 , disabled , external , icon , label , open: openProp , path , title  } = props;
    const [open, setOpen] = (0,react_.useState)(!!openProp);
    const handleToggle = (0,react_.useCallback)(()=>{
        setOpen((prevOpen)=>!prevOpen);
    }, []);
    // Icons can be defined at top level only, deep levels have bullets instead of actual icons.
    let startIcon;
    if (depth === 0) {
        startIcon = icon;
    } else {
        startIcon = /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
            sx: {
                alignItems: "center",
                display: "center",
                height: 20,
                justifyContent: "center",
                width: 20
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    backgroundColor: "var(--nav-item-icon-color)",
                    borderRadius: "50%",
                    height: 4,
                    opacity: 0,
                    width: 4,
                    ...active && {
                        backgroundColor: "var(--nav-item-icon-active-color)",
                        height: 6,
                        opacity: 1,
                        width: 6
                    }
                }
            })
        });
    }
    const offset = depth === 0 ? 0 : (depth - 1) * 16;
    // Branch
    if (children) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
                    disabled: disabled,
                    onClick: handleToggle,
                    sx: {
                        alignItems: "center",
                        borderRadius: 1,
                        display: "flex",
                        justifyContent: "flex-start",
                        pl: `${16 + offset}px`,
                        pr: "16px",
                        py: "6px",
                        textAlign: "left",
                        width: "100%",
                        ...active && {
                            ...depth === 0 && {
                                backgroundColor: "var(--nav-item-active-bg)"
                            }
                        },
                        "&:hover": {
                            backgroundColor: "var(--nav-item-hover-bg)"
                        }
                    },
                    children: [
                        startIcon && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            component: "span",
                            sx: {
                                alignItems: "center",
                                color: "var(--nav-item-icon-color)",
                                display: "inline-flex",
                                justifyContent: "center",
                                mr: 2,
                                ...active && {
                                    color: "var(--nav-item-icon-active-color)"
                                }
                            },
                            children: startIcon
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            component: "span",
                            sx: {
                                color: "var(--nav-item-color)",
                                flexGrow: 1,
                                fontFamily: (theme)=>theme.typography.fontFamily,
                                fontSize: depth > 0 ? 13 : 14,
                                fontWeight: depth > 0 ? 500 : 600,
                                lineHeight: "24px",
                                whiteSpace: "nowrap",
                                ...active && {
                                    color: "var(--nav-item-active-color)"
                                },
                                ...disabled && {
                                    color: "var(--nav-item-disabled-color)"
                                }
                            },
                            children: title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            sx: {
                                color: "var(--nav-item-chevron-color)",
                                fontSize: 16,
                                ml: 2
                            },
                            children: open ? /*#__PURE__*/ jsx_runtime_.jsx(ChevronDown/* default */.Z, {}) : /*#__PURE__*/ jsx_runtime_.jsx(ChevronRight/* default */.Z, {})
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Collapse_default()), {
                    in: open,
                    sx: {
                        mt: 0.5
                    },
                    children: children
                })
            ]
        });
    }
    // Leaf
    const linkProps = path ? external ? {
        component: "a",
        href: path,
        target: "_blank"
    } : {
        component: router_link/* RouterLink */.r,
        href: path
    } : {};
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
            disabled: disabled,
            sx: {
                alignItems: "center",
                borderRadius: 1,
                display: "flex",
                justifyContent: "flex-start",
                pl: `${16 + offset}px`,
                pr: "16px",
                py: "6px",
                textAlign: "left",
                width: "100%",
                ...active && {
                    ...depth === 0 && {
                        backgroundColor: "var(--nav-item-active-bg)"
                    }
                },
                "&:hover": {
                    backgroundColor: "var(--nav-item-hover-bg)"
                }
            },
            ...linkProps,
            children: [
                startIcon && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "span",
                    sx: {
                        alignItems: "center",
                        color: "var(--nav-item-icon-color)",
                        display: "inline-flex",
                        justifyContent: "center",
                        mr: 2,
                        ...active && {
                            color: "var(--nav-item-icon-active-color)"
                        }
                    },
                    children: startIcon
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "span",
                    sx: {
                        color: "var(--nav-item-color)",
                        flexGrow: 1,
                        fontFamily: (theme)=>theme.typography.fontFamily,
                        fontSize: depth > 0 ? 13 : 14,
                        fontWeight: depth > 0 ? 500 : 600,
                        lineHeight: "24px",
                        whiteSpace: "nowrap",
                        ...active && {
                            color: "var(--nav-item-active-color)"
                        },
                        ...disabled && {
                            color: "var(--nav-item-disabled-color)"
                        }
                    },
                    children: title
                }),
                label && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "span",
                    sx: {
                        ml: 2
                    },
                    children: label
                })
            ]
        })
    });
};
SideNavItem.propTypes = {
    active: (prop_types_default()).bool,
    children: (prop_types_default()).node,
    depth: (prop_types_default()).number,
    disabled: (prop_types_default()).bool,
    external: (prop_types_default()).bool,
    icon: (prop_types_default()).node,
    label: (prop_types_default()).node,
    open: (prop_types_default()).bool,
    path: (prop_types_default()).string,
    title: (prop_types_default()).string.isRequired
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/vertical-layout/side-nav-section.tsx





const side_nav_section_renderItems = ({ depth =0 , items , pathname  })=>items.reduce((acc, item)=>side_nav_section_reduceChildRoutes({
            acc,
            depth,
            item,
            pathname
        }), []);
const side_nav_section_reduceChildRoutes = ({ acc , depth , item , pathname  })=>{
    const checkPath = !!(item.path && pathname);
    const partialMatch = checkPath ? pathname.includes(item.path) : false;
    const exactMatch = checkPath ? pathname === item.path : false;
    if (item.items) {
        acc.push(/*#__PURE__*/ jsx_runtime_.jsx(SideNavItem, {
            active: partialMatch,
            depth: depth,
            disabled: item.disabled,
            icon: item.icon,
            label: item.label,
            open: partialMatch,
            title: item.title,
            children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                component: "ul",
                spacing: 0.5,
                sx: {
                    listStyle: "none",
                    m: 0,
                    p: 0
                },
                children: side_nav_section_renderItems({
                    depth: depth + 1,
                    items: item.items,
                    pathname
                })
            })
        }, item.title));
    } else {
        acc.push(/*#__PURE__*/ jsx_runtime_.jsx(SideNavItem, {
            active: exactMatch,
            depth: depth,
            disabled: item.disabled,
            external: item.external,
            icon: item.icon,
            label: item.label,
            path: item.path,
            title: item.title
        }, item.title));
    }
    return acc;
};
const SideNavSection = (props)=>{
    const { items =[] , pathname , subheader ="" , ...other } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        component: "ul",
        spacing: 0.5,
        sx: {
            listStyle: "none",
            m: 0,
            p: 0
        },
        ...other,
        children: [
            subheader && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "li",
                sx: {
                    color: "var(--nav-section-title-color)",
                    fontSize: 12,
                    fontWeight: 700,
                    lineHeight: 1.66,
                    mb: 1,
                    ml: 1,
                    textTransform: "uppercase"
                },
                children: subheader
            }),
            side_nav_section_renderItems({
                items,
                pathname
            })
        ]
    });
};
SideNavSection.propTypes = {
    items: (prop_types_default()).array,
    pathname: (prop_types_default()).string,
    subheader: (prop_types_default()).string
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/vertical-layout/side-nav.tsx














const SIDE_NAV_WIDTH = 280;
const side_nav_useCssVars = (color)=>{
    const theme = (0,styles.useTheme)();
    return (0,react_.useMemo)(()=>{
        switch(color){
            case "blend-in":
                if (theme.palette.mode === "dark") {
                    return {
                        "--nav-bg": theme.palette.background.default,
                        "--nav-color": theme.palette.neutral[100],
                        "--nav-border-color": theme.palette.neutral[700],
                        "--nav-logo-border": theme.palette.neutral[700],
                        "--nav-section-title-color": theme.palette.neutral[400],
                        "--nav-item-color": theme.palette.neutral[400],
                        "--nav-item-hover-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-color": theme.palette.text.primary,
                        "--nav-item-disabled-color": theme.palette.neutral[600],
                        "--nav-item-icon-color": theme.palette.neutral[500],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[700],
                        "--nav-item-chevron-color": theme.palette.neutral[700],
                        "--nav-scrollbar-color": theme.palette.neutral[400]
                    };
                } else {
                    return {
                        "--nav-bg": theme.palette.background.default,
                        "--nav-color": theme.palette.text.primary,
                        "--nav-border-color": theme.palette.neutral[100],
                        "--nav-logo-border": theme.palette.neutral[100],
                        "--nav-section-title-color": theme.palette.neutral[400],
                        "--nav-item-color": theme.palette.text.secondary,
                        "--nav-item-hover-bg": theme.palette.action.hover,
                        "--nav-item-active-bg": theme.palette.action.selected,
                        "--nav-item-active-color": theme.palette.text.primary,
                        "--nav-item-disabled-color": theme.palette.neutral[400],
                        "--nav-item-icon-color": theme.palette.neutral[400],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[400],
                        "--nav-item-chevron-color": theme.palette.neutral[400],
                        "--nav-scrollbar-color": theme.palette.neutral[900]
                    };
                }
            case "discrete":
                if (theme.palette.mode === "dark") {
                    return {
                        "--nav-bg": theme.palette.neutral[900],
                        "--nav-color": theme.palette.neutral[100],
                        "--nav-border-color": theme.palette.neutral[700],
                        "--nav-logo-border": theme.palette.neutral[700],
                        "--nav-section-title-color": theme.palette.neutral[400],
                        "--nav-item-color": theme.palette.neutral[400],
                        "--nav-item-hover-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-color": theme.palette.text.primary,
                        "--nav-item-disabled-color": theme.palette.neutral[600],
                        "--nav-item-icon-color": theme.palette.neutral[500],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[700],
                        "--nav-item-chevron-color": theme.palette.neutral[700],
                        "--nav-scrollbar-color": theme.palette.neutral[400]
                    };
                } else {
                    return {
                        "--nav-bg": theme.palette.neutral[50],
                        "--nav-color": theme.palette.text.primary,
                        "--nav-border-color": theme.palette.divider,
                        "--nav-logo-border": theme.palette.neutral[200],
                        "--nav-section-title-color": theme.palette.neutral[500],
                        "--nav-item-color": theme.palette.neutral[500],
                        "--nav-item-hover-bg": theme.palette.action.hover,
                        "--nav-item-active-bg": theme.palette.action.selected,
                        "--nav-item-active-color": theme.palette.text.primary,
                        "--nav-item-disabled-color": theme.palette.neutral[400],
                        "--nav-item-icon-color": theme.palette.neutral[400],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[400],
                        "--nav-item-chevron-color": theme.palette.neutral[400],
                        "--nav-scrollbar-color": theme.palette.neutral[900]
                    };
                }
            case "evident":
                if (theme.palette.mode === "dark") {
                    return {
                        "--nav-bg": theme.palette.neutral[800],
                        "--nav-color": theme.palette.common.white,
                        "--nav-border-color": "transparent",
                        "--nav-logo-border": theme.palette.neutral[700],
                        "--nav-section-title-color": theme.palette.neutral[400],
                        "--nav-item-color": theme.palette.neutral[400],
                        "--nav-item-hover-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-color": theme.palette.common.white,
                        "--nav-item-disabled-color": theme.palette.neutral[500],
                        "--nav-item-icon-color": theme.palette.neutral[400],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[500],
                        "--nav-item-chevron-color": theme.palette.neutral[600],
                        "--nav-scrollbar-color": theme.palette.neutral[400]
                    };
                } else {
                    return {
                        "--nav-bg": theme.palette.neutral[800],
                        "--nav-color": theme.palette.common.white,
                        "--nav-border-color": "transparent",
                        "--nav-logo-border": theme.palette.neutral[700],
                        "--nav-section-title-color": theme.palette.neutral[400],
                        "--nav-item-color": theme.palette.neutral[400],
                        "--nav-item-hover-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-bg": "rgba(255, 255, 255, 0.04)",
                        "--nav-item-active-color": theme.palette.common.white,
                        "--nav-item-disabled-color": theme.palette.neutral[500],
                        "--nav-item-icon-color": theme.palette.neutral[400],
                        "--nav-item-icon-active-color": theme.palette.primary.main,
                        "--nav-item-icon-disabled-color": theme.palette.neutral[500],
                        "--nav-item-chevron-color": theme.palette.neutral[600],
                        "--nav-scrollbar-color": theme.palette.neutral[400]
                    };
                }
            default:
                return {};
        }
    }, [
        theme,
        color
    ]);
};
const SideNav = (props)=>{
    const { color ="evident" , sections =[]  } = props;
    const pathname = (0,use_pathname/* usePathname */.j)();
    const cssVars = side_nav_useCssVars(color);
    return /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
        anchor: "left",
        open: true,
        PaperProps: {
            sx: {
                ...cssVars,
                backgroundColor: "var(--nav-bg)",
                borderRightColor: "var(--nav-border-color)",
                borderRightStyle: "solid",
                borderRightWidth: 1,
                color: "var(--nav-color)",
                width: SIDE_NAV_WIDTH
            }
        },
        variant: "permanent",
        children: /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
            sx: {
                height: "100%",
                "& .simplebar-content": {
                    height: "100%"
                },
                "& .simplebar-scrollbar:before": {
                    background: "var(--nav-scrollbar-color)"
                }
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                sx: {
                    height: "100%"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 2,
                        sx: {
                            p: 3
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            component: router_link/* RouterLink */.r,
                            href: paths/* paths.index */.H.index,
                            sx: {
                                display: "flex",
                                height: 40,
                                width: 150
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(logo/* Logo */.T, {
                                fillColor: "white"
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                        component: "nav",
                        spacing: 2,
                        sx: {
                            flexGrow: 1,
                            px: 2
                        },
                        children: sections.map((section, index)=>/*#__PURE__*/ jsx_runtime_.jsx(SideNavSection, {
                                items: section.items,
                                pathname: pathname,
                                subheader: section.subheader
                            }, index))
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            p: 3
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Logout, {})
                    })
                ]
            })
        })
    });
};
SideNav.propTypes = {
    color: prop_types_default().oneOf([
        "blend-in",
        "discrete",
        "evident"
    ]),
    sections: (prop_types_default()).array
};

// EXTERNAL MODULE: ./node_modules/@mui/system/colorManipulator.js
var colorManipulator = __webpack_require__(229551);
;// CONCATENATED MODULE: ./src/layouts/dashboard/vertical-layout/top-nav.tsx













const TOP_NAV_HEIGHT = 64;
const top_nav_SIDE_NAV_WIDTH = 280;
const top_nav_TopNav = (props)=>{
    const { onMobileNavOpen , ...other } = props;
    const [submitting, setSubmitting] = (0,react_.useState)(false);
    const lgUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("lg"));
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        component: "header",
        sx: {
            backdropFilter: "blur(6px)",
            backgroundColor: (theme)=>(0,colorManipulator.alpha)(theme.palette.background.default, 0.8),
            position: "sticky",
            left: {
                lg: `${top_nav_SIDE_NAV_WIDTH}px`
            },
            top: 0,
            width: {
                lg: `calc(100% - ${top_nav_SIDE_NAV_WIDTH}px)`
            },
            zIndex: (theme)=>theme.zIndex.appBar
        },
        ...other,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
            alignItems: "center",
            direction: "row",
            justifyContent: "space-between",
            spacing: 2,
            sx: {
                minHeight: TOP_NAV_HEIGHT,
                px: 2
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    spacing: 2,
                    children: [
                        !lgUp && /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            onClick: onMobileNavOpen,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Menu01/* default */.Z, {})
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(buttons_button/* Button */.z, {
                            startIcon: !submitting && /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* RefreshCcw01 */.eBU, {})
                            }),
                            variant: "contained",
                            disabled: submitting,
                            onClick: ()=>(setSubmitting(true), window.location.reload()),
                            children: "Refresh"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    spacing: 2,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(AccountButton, {})
                })
            ]
        })
    });
};
top_nav_TopNav.propTypes = {
    onMobileNavOpen: (prop_types_default()).func
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/vertical-layout/use-mobile-nav.ts


const use_mobile_nav_useMobileNav = ()=>{
    const pathname = (0,use_pathname/* usePathname */.j)();
    const [open, setOpen] = (0,react_.useState)(false);
    const handlePathnameChange = (0,react_.useCallback)(()=>{
        if (open) {
            setOpen(false);
        }
    }, [
        open
    ]);
    (0,react_.useEffect)(()=>{
        handlePathnameChange();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        pathname
    ]);
    const handleOpen = (0,react_.useCallback)(()=>{
        setOpen(true);
    }, []);
    const handleClose = (0,react_.useCallback)(()=>{
        setOpen(false);
    }, []);
    return {
        handleOpen,
        handleClose,
        open
    };
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/vertical-layout/vertical-layout.tsx








const vertical_layout_SIDE_NAV_WIDTH = 280;
const VerticalLayoutRoot = (0,styles.styled)("div")(({ theme  })=>({
        display: "flex",
        flex: "1 1 auto",
        maxWidth: "100%",
        [theme.breakpoints.up("lg")]: {
            paddingLeft: vertical_layout_SIDE_NAV_WIDTH
        }
    }));
const VerticalLayoutContainer = (0,styles.styled)("div")({
    display: "flex",
    flex: "1 1 auto",
    flexDirection: "column",
    width: "100%"
});
const VerticalLayout = (props)=>{
    const { children , sections , navColor  } = props;
    const lgUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("lg"));
    const mobileNav = use_mobile_nav_useMobileNav();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(top_nav_TopNav, {
                onMobileNavOpen: mobileNav.handleOpen
            }),
            lgUp && /*#__PURE__*/ jsx_runtime_.jsx(SideNav, {
                color: navColor,
                sections: sections
            }),
            !lgUp && /*#__PURE__*/ jsx_runtime_.jsx(MobileNav, {
                color: navColor,
                onClose: mobileNav.handleClose,
                open: mobileNav.open,
                sections: sections
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(VerticalLayoutRoot, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(VerticalLayoutContainer, {
                    children: children
                })
            })
        ]
    });
};
VerticalLayout.propTypes = {
    children: (prop_types_default()).node,
    navColor: prop_types_default().oneOf([
        "blend-in",
        "discrete",
        "evident"
    ]),
    sections: (prop_types_default()).array
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/vertical-layout/index.ts


;// CONCATENATED MODULE: ./src/layouts/dashboard/layout.tsx







const Layout = withAuthGuard((props)=>{
    const settings = (0,use_settings/* useSettings */.r)();
    const sections = useSections();
    if (settings.layout === "horizontal") {
        return /*#__PURE__*/ jsx_runtime_.jsx(HorizontalLayout, {
            sections: sections,
            navColor: settings.navColor,
            ...props
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(VerticalLayout, {
        sections: sections,
        navColor: settings.navColor,
        ...props
    });
});
Layout.propTypes = {
    children: (prop_types_default()).node
};

;// CONCATENATED MODULE: ./src/layouts/dashboard/index.ts


;// CONCATENATED MODULE: ./src/app/(dashboard)/layout.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


/***/ }),

/***/ 796372:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ useAuth)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_contexts_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(736169);


const useAuth = ()=>(0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(src_contexts_auth__WEBPACK_IMPORTED_MODULE_1__/* .AuthContext */ .Vo);


/***/ }),

/***/ 69281:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ usePopover)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function usePopover() {
    const anchorRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const handleOpen = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setOpen(true);
    }, []);
    const handleClose = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setOpen(false);
    }, []);
    const handleToggle = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setOpen((prevState)=>!prevState);
    }, []);
    return {
        anchorRef,
        handleClose,
        handleOpen,
        handleToggle,
        open
    };
}


/***/ }),

/***/ 840513:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.useRouter)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 633743:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ Button)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(898511);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(664085);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_2__);



// Define a generic type that extends ButtonHTMLAttributes
const Button = ({ children , ...props })=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_1___default()), {
        ...props,
        children: props.disabled ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_2__.CircularProgress, {
            size: 24,
            color: "inherit"
        }) // Show a spinner when disabled.
         : children
    });
};


/***/ }),

/***/ 361679:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(835985);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (proxy.default);


/***/ })

};
;