"use strict";
exports.id = 2851;
exports.ids = [2851];
exports.modules = {

/***/ 782851:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ useMockedUser)
/* harmony export */ });
const useMockedUser = ()=>{
    return {
        id: 2996,
        firstName: "Pratik",
        lastName: "Dhody",
        email: "pratikdhody@gmail.com",
        registeredDate: "2019-02-14T09:20:46.000Z",
        isPartner: 1,
        linkedPartnerId: "220",
        name: "Mt Derrimut Golf Club",
        status: "publish",
        facebookHandle: "mtderrimutgc",
        instagramHandle: "mtderrimutgc",
        teeTimes: [
            {
                records: [
                    {
                        userId: "2996",
                        teeTime: 2221823,
                        bookedOn: "1999-12-09 00:00:00"
                    },
                    {
                        userId: "1938",
                        teeTime: 2221820,
                        bookedOn: "1999-12-09 00:00:00"
                    },
                    {
                        userId: "",
                        teeTime: 2221821,
                        bookedOn: ""
                    },
                    {
                        userId: "",
                        teeTime: 2221822,
                        bookedOn: ""
                    }
                ],
                teeTime: "2023-12-01 07:00:00",
                courseName: "",
                eligibility: "The Addict"
            }
        ],
        vouchers: [
            {
                id: 1814451,
                userId: "2996",
                claimedDate: "2023-08-07 21:27:50.000000",
                voucherType: "3",
                userLastName: "Dhody",
                userGolfLink: "123",
                verifiedDate: "",
                voucherCode: "111111",
                userFirstName: "Pratik",
                partnerRating: 0,
                status: "1",
                numberOfRangeBallsReceived: "50"
            }
        ]
    };
};


/***/ })

};
;