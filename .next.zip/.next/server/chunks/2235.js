"use strict";
exports.id = 2235;
exports.ids = [2235];
exports.modules = {

/***/ 452235:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Y": () => (/* binding */ FileDropzone)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(869232);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var react_dropzone__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(505399);
/* harmony import */ var react_dropzone__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(react_dropzone__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _untitled_ui_icons_react_build_esm_Upload01__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(429771);
/* harmony import */ var _untitled_ui_icons_react_build_esm_X__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(180501);
/* harmony import */ var _mui_material_Avatar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(217296);
/* harmony import */ var _mui_material_Avatar__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Avatar__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(746661);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(898511);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(916816);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(854436);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_List__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_ListItem__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(790777);
/* harmony import */ var _mui_material_ListItem__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(126765);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(846517);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_material_Stack__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(705537);
/* harmony import */ var _mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(381394);
/* harmony import */ var _mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(556020);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(243360);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var src_components_file_icon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(994797);
/* harmony import */ var src_utils_bytes_to_size__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(98323);



















const FileDropzone = (props)=>{
    const { caption , files =[] , onRemove , onRemoveAll , onUpload , ...other } = props;
    const { getRootProps , getInputProps , isDragActive  } = (0,react_dropzone__WEBPACK_IMPORTED_MODULE_4__.useDropzone)(other);
    const hasAnyFiles = files.length > 0;
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material_Box__WEBPACK_IMPORTED_MODULE_5__["default"], {
                sx: {
                    alignItems: "center",
                    border: 1,
                    borderRadius: 1,
                    borderStyle: "dashed",
                    borderColor: "divider",
                    display: "flex",
                    flexWrap: "wrap",
                    justifyContent: "center",
                    outline: "none",
                    py: 3,
                    ...isDragActive && {
                        backgroundColor: "action.active",
                        opacity: 0.5
                    },
                    "&:hover": {
                        backgroundColor: "action.hover",
                        cursor: "pointer",
                        opacity: 0.5
                    }
                },
                ...getRootProps(),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                        ...getInputProps()
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6__["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Avatar__WEBPACK_IMPORTED_MODULE_7___default()), {
                                sx: {
                                    height: 64,
                                    width: 64
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_8___default()), {
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_untitled_ui_icons_react_build_esm_Upload01__WEBPACK_IMPORTED_MODULE_1__/* ["default"] */ .Z, {})
                                })
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                spacing: 1,
                                children: [
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_9___default()), {
                                        sx: {
                                            "& span": {
                                                textDecoration: "underline"
                                            }
                                        },
                                        variant: "h6",
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "Click to upload"
                                            }),
                                            " or drag and drop"
                                        ]
                                    }),
                                    caption && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_9___default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: caption
                                    })
                                ]
                            })
                        ]
                    })
                ]
            }),
            hasAnyFiles && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material_Box__WEBPACK_IMPORTED_MODULE_5__["default"], {
                sx: {
                    mt: 2
                },
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_List__WEBPACK_IMPORTED_MODULE_10___default()), {
                        children: files.map((file)=>{
                            const extension = file.name.split(".").pop();
                            return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItem__WEBPACK_IMPORTED_MODULE_11___default()), {
                                sx: {
                                    border: 1,
                                    borderColor: "divider",
                                    borderRadius: 1,
                                    "& + &": {
                                        mt: 1
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_12___default()), {
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_components_file_icon__WEBPACK_IMPORTED_MODULE_3__/* .FileIcon */ .a, {
                                            extension: extension
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_13___default()), {
                                        primary: file.name,
                                        primaryTypographyProps: {
                                            variant: "subtitle2"
                                        },
                                        secondary: (0,src_utils_bytes_to_size__WEBPACK_IMPORTED_MODULE_14__/* .bytesToSize */ .R)(file.size)
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        title: "Remove",
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_16___default()), {
                                            edge: "end",
                                            onClick: ()=>onRemove?.(file),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_8___default()), {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_untitled_ui_icons_react_build_esm_X__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                                            })
                                        })
                                    })
                                ]
                            }, file.path);
                        })
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material_Stack__WEBPACK_IMPORTED_MODULE_6__["default"], {
                        alignItems: "center",
                        direction: "row",
                        justifyContent: "flex-end",
                        spacing: 2,
                        sx: {
                            mt: 2
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_17___default()), {
                                color: "inherit",
                                onClick: onRemoveAll,
                                size: "small",
                                type: "button",
                                children: "Remove All"
                            }),
                            onUpload && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_17___default()), {
                                onClick: onUpload,
                                size: "small",
                                type: "button",
                                variant: "contained",
                                children: "Upload"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
FileDropzone.propTypes = {
    caption: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().string),
    files: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().array),
    onRemove: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().func),
    onRemoveAll: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().func),
    onUpload: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().func),
    // From Dropzone
    accept: prop_types__WEBPACK_IMPORTED_MODULE_18___default().objectOf(prop_types__WEBPACK_IMPORTED_MODULE_18___default().arrayOf((prop_types__WEBPACK_IMPORTED_MODULE_18___default().string.isRequired)).isRequired),
    disabled: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().bool),
    getFilesFromEvent: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().func),
    maxFiles: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().number),
    maxSize: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().number),
    minSize: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().number),
    noClick: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().bool),
    noDrag: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().bool),
    noDragEventsBubbling: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().bool),
    noKeyboard: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().bool),
    onDrop: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().func),
    onDropAccepted: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().func),
    onDropRejected: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().func),
    onFileDialogCancel: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().func),
    preventDropOnDocument: (prop_types__WEBPACK_IMPORTED_MODULE_18___default().bool)
};


/***/ }),

/***/ 994797:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ FileIcon)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(869232);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_1__);


const icons = {
    jpeg: "/assets/icons/icon-jpg.svg",
    jpg: "/assets/icons/icon-jpg.svg",
    mp4: "/assets/icons/icon-mp4.svg",
    pdf: "/assets/icons/icon-pdf.svg",
    png: "/assets/icons/icon-png.svg",
    svg: "/assets/icons/icon-svg.svg"
};
const FileIcon = (props)=>{
    const { extension  } = props;
    let icon;
    if (!extension) {
        icon = "/assets/icons/icon-other.svg";
    } else {
        icon = icons[extension] || "/assets/icons/icon-other.svg";
    }
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("img", {
        src: icon
    });
};
FileIcon.propTypes = {
    extension: (prop_types__WEBPACK_IMPORTED_MODULE_1___default().string)
};


/***/ }),

/***/ 98323:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ bytesToSize)
/* harmony export */ });
/* eslint-disable no-restricted-properties */ const bytesToSize = (bytes, decimals = 2)=>{
    if (bytes === 0) {
        return "0 Bytes";
    }
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = [
        "Bytes",
        "KB",
        "MB",
        "GB",
        "TB",
        "PB",
        "EB",
        "ZB",
        "YB"
    ];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
};


/***/ })

};
;