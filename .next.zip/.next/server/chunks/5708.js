"use strict";
exports.id = 5708;
exports.ids = [5708];
exports.modules = {

/***/ 15708:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ mainApi)
/* harmony export */ });
/* harmony import */ var src_utils_apply_pagination__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(789989);
/* harmony import */ var src_utils_apply_sort__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(391734);
/* harmony import */ var src_utils_deep_copy__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(846447);
/* harmony import */ var src_utils_jwt__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(205200);
/* harmony import */ var axios__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(740248);
/* harmony import */ var src_contexts_auth_auth_provider__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(465388);






class MainApi {
    async getVouchers(request, vouchers = []) {
        const { filters , page , rowsPerPage , sortBy , sortDir  } = request;
        let data = (0,src_utils_deep_copy__WEBPACK_IMPORTED_MODULE_1__/* .deepCopy */ .p)(vouchers);
        let count = data.length;
        if (typeof filters !== "undefined") {
            data = data.filter((voucher)=>{
                if (typeof filters.query !== "undefined" && filters.query !== "") {
                    let queryMatched = false;
                    const properties = [
                        "userFirstName",
                        "userLastName",
                        "voucherCode",
                        "userGolfLink"
                    ];
                    if (voucher) {
                        // Check if voucher is not null or undefined
                        properties.forEach((property)=>{
                            const propertyValue = voucher[property];
                            if (propertyValue && typeof propertyValue === "string") {
                                // Check if the property value is a non-null string
                                if (propertyValue.toLowerCase().includes(filters.query.toLowerCase())) {
                                    queryMatched = true;
                                }
                            }
                        });
                    }
                    if (!queryMatched) {
                        return false;
                    }
                }
                return true;
            });
            count = data.length;
        }
        if (typeof sortBy !== "undefined" && typeof sortDir !== "undefined") {
            data = (0,src_utils_apply_sort__WEBPACK_IMPORTED_MODULE_2__/* .applySort */ .v)(data, sortBy, sortDir);
        }
        if (typeof page !== "undefined" && typeof rowsPerPage !== "undefined") {
            data = (0,src_utils_apply_pagination__WEBPACK_IMPORTED_MODULE_3__/* .applyPagination */ .i)(data, page, rowsPerPage);
        }
        return Promise.resolve({
            data,
            count
        });
    }
    putVoucher(id, key, value) {
        const accessToken = window.localStorage.getItem(src_contexts_auth_auth_provider__WEBPACK_IMPORTED_MODULE_0__/* .STORAGE_KEY */ .U);
        return new Promise(async (resolve, reject)=>{
            try {
                // Decode access token
                const decodedToken = (0,src_utils_jwt__WEBPACK_IMPORTED_MODULE_4__/* .decode */ .Jx)(String(accessToken));
                try {
                    if (!decodedToken.token) {
                        reject(new Error("Invalid authorization token"));
                        return;
                    }
                    const requestData = {
                        id,
                        key,
                        value
                    };
                    // Make an HTTP POST request to the API
                    const response = await axios__WEBPACK_IMPORTED_MODULE_5__/* ["default"].put */ .Z.put("https://sit1api.futuregolf.com.au" + "/putPost", requestData, {
                        headers: {
                            Authorization: `Bearer ${decodedToken.token}`
                        }
                    });
                    resolve({
                        response
                    });
                } catch (err) {
                    reject(new Error("Please check your data request"));
                }
            } catch (err) {
                console.error("[Voucher Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    postPartnerFeedback(type, values, files) {
        //type 1 = member feedback
        //type 2 = marketing/other feedback
        const accessToken = window.localStorage.getItem(src_contexts_auth_auth_provider__WEBPACK_IMPORTED_MODULE_0__/* .STORAGE_KEY */ .U);
        return new Promise(async (resolve, reject)=>{
            try {
                // Decode access token
                const decodedToken = (0,src_utils_jwt__WEBPACK_IMPORTED_MODULE_4__/* .decode */ .Jx)(String(accessToken));
                try {
                    if (!decodedToken.token) {
                        reject(new Error("Invalid authorization token"));
                        return;
                    }
                    const postData = type === 1 ? {
                        type: type,
                        "wpcf-pmf-full-name": values.name,
                        "wpcf-pmf-feedback-date": Math.floor(values.feedbackDate.getTime() / 1000),
                        "wpcf-pmf-feedback": values.feedback,
                        "wpcf-pmf-user-id": "",
                        "partner-name": values.partnerName,
                        files: files
                    } : {
                        type: type,
                        partnerName: values.partnerName,
                        name: values.name,
                        email: values.email,
                        number: values.number,
                        enquiryType: values.enquiryType,
                        message: values.message
                    };
                    // Make an HTTP POST request to the API
                    const response = await axios__WEBPACK_IMPORTED_MODULE_5__/* ["default"].post */ .Z.post("https://sit1api.futuregolf.com.au" + "/postPartnerFeedback", postData, {
                        headers: {
                            Authorization: `Bearer ${decodedToken.token}`
                        }
                    });
                    resolve({
                        response
                    });
                } catch (err) {
                    reject(new Error("Please check your data request"));
                }
            } catch (err) {
                console.error("[Main Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
}
const mainApi = new MainApi();


/***/ })

};
;