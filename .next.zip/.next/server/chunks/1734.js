"use strict";
exports.id = 1734;
exports.ids = [1734];
exports.modules = {

/***/ 391734:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "v": () => (/* binding */ applySort)
/* harmony export */ });
function descendingComparator(a, b, sortBy) {
    // When compared to something undefined, always returns false.
    // This means that if a field does not exist from either element ('a' or 'b') the return will be 0.
    if (b[sortBy] < a[sortBy]) {
        return -1;
    }
    if (b[sortBy] > a[sortBy]) {
        return 1;
    }
    return 0;
}
function getComparator(sortDir, sortBy) {
    return sortDir === "desc" ? (a, b)=>descendingComparator(a, b, sortBy) : (a, b)=>-descendingComparator(a, b, sortBy);
}
function applySort(documents, sortBy, sortDir) {
    const comparator = getComparator(sortDir, sortBy);
    const stabilizedThis = documents.map((el, index)=>[
            el,
            index
        ]);
    stabilizedThis.sort((a, b)=>{
        // @ts-ignore
        const newOrder = comparator(a[0], b[0]);
        if (newOrder !== 0) {
            return newOrder;
        }
        // @ts-ignore
        return a[1] - b[1];
    });
    // @ts-ignore
    return stabilizedThis.map((el)=>el[0]);
}


/***/ })

};
;