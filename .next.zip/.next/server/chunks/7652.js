"use strict";
exports.id = 7652;
exports.ids = [7652];
exports.modules = {

/***/ 757652:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "t": () => (/* binding */ ContactForm)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(746661);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(380428);
/* harmony import */ var _mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(895157);
/* harmony import */ var _mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_Unstable_Grid2__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(377974);
/* harmony import */ var _mui_material_Unstable_Grid2__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Unstable_Grid2__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(662360);
/* harmony import */ var _mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(877829);
/* harmony import */ var _mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_Select__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(679006);
/* harmony import */ var _mui_material_Select__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Select__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(243360);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var src_hooks_use_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(796372);
/* harmony import */ var react_hot_toast__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(333518);
/* harmony import */ var yup__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(158952);
/* harmony import */ var formik__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(906135);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(664085);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var src_hooks_use_mounted__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(887408);
/* harmony import */ var src_api_main__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(15708);
/* harmony import */ var _components_buttons_button__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(633743);

















const ContactForm = (props)=>{
    const { enquiryType ="1"  } = props;
    const user = (0,src_hooks_use_auth__WEBPACK_IMPORTED_MODULE_1__/* .useAuth */ .a)();
    const isMounted = (0,src_hooks_use_mounted__WEBPACK_IMPORTED_MODULE_5__/* .useMounted */ .s)();
    const initialValues = {
        partnerName: user.user?.name || "",
        name: "",
        email: user.user?.email || "",
        number: "",
        enquiryType: enquiryType,
        message: "",
        submit: null
    };
    const validationSchema = yup__WEBPACK_IMPORTED_MODULE_3__/* .object */ .Ry({
        name: yup__WEBPACK_IMPORTED_MODULE_3__/* .string */ .Z_().max(255).required("Name is required"),
        email: yup__WEBPACK_IMPORTED_MODULE_3__/* .string */ .Z_().email("Must be a valid email").max(255).required("Email is required"),
        number: yup__WEBPACK_IMPORTED_MODULE_3__/* .string */ .Z_().max(12).required("Number is required"),
        enquiryType: yup__WEBPACK_IMPORTED_MODULE_3__/* .string */ .Z_().max(2).required("Enquiry type is required"),
        message: yup__WEBPACK_IMPORTED_MODULE_3__/* .string */ .Z_().min(100).required("Message is required & a must be a minimum or 100 characters")
    });
    function resetForm() {
        formik.resetForm();
    }
    const formik = (0,formik__WEBPACK_IMPORTED_MODULE_4__.useFormik)({
        initialValues,
        validationSchema,
        onSubmit: async (values, helpers)=>{
            try {
                const res = await src_api_main__WEBPACK_IMPORTED_MODULE_6__/* .mainApi.postPartnerFeedback */ .m.postPartnerFeedback(2, values);
                console.log("res", res);
                if (res.response.status === 200) {
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_2__/* ["default"].success */ .ZP.success("Your request has been submitted. We will be in touch with you shortly.");
                    resetForm();
                } else {
                    react_hot_toast__WEBPACK_IMPORTED_MODULE_2__/* ["default"].error */ .ZP.error(`Whoops, there was an error in submitting this request`);
                }
            } catch (err) {
                console.error(err);
                if (isMounted()) {
                    helpers.setStatus({
                        success: false
                    });
                    helpers.setErrors({
                        submit: err.message
                    });
                    helpers.setSubmitting(false);
                }
            }
        }
    });
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
        noValidate: true,
        onSubmit: formik.handleSubmit,
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Unstable_Grid2__WEBPACK_IMPORTED_MODULE_8___default()), {
                container: true,
                spacing: 3,
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Unstable_Grid2__WEBPACK_IMPORTED_MODULE_8___default()), {
                        xs: 12,
                        sm: 6,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9___default()), {
                            fullWidth: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    sx: {
                                        color: "text.primary",
                                        mb: 1
                                    },
                                    children: "Partner"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_11___default()), {
                                    error: !!(formik.touched.partnerName && formik.errors.partnerName),
                                    fullWidth: true,
                                    disabled: true,
                                    name: "partnerName",
                                    required: true,
                                    onBlur: formik.handleBlur,
                                    onChange: formik.handleChange,
                                    type: "text",
                                    value: formik.values.partnerName
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Unstable_Grid2__WEBPACK_IMPORTED_MODULE_8___default()), {
                        xs: 12,
                        sm: 6,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9___default()), {
                            fullWidth: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    sx: {
                                        color: "text.primary",
                                        mb: 1
                                    },
                                    children: "Your Name"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_11___default()), {
                                    error: !!(formik.touched.name && formik.errors.name),
                                    fullWidth: true,
                                    required: true,
                                    placeholder: "John Smith",
                                    name: "name",
                                    onBlur: formik.handleBlur,
                                    onChange: formik.handleChange,
                                    type: "text",
                                    value: formik.values.name
                                }),
                                !!(formik.touched.name && formik.errors.name) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                    sx: {
                                        mt: 2
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_13__.FormHelperText, {
                                        error: true,
                                        children: formik.errors.name
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Unstable_Grid2__WEBPACK_IMPORTED_MODULE_8___default()), {
                        xs: 12,
                        sm: 6,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9___default()), {
                            fullWidth: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    sx: {
                                        color: "text.primary",
                                        mb: 1
                                    },
                                    children: "Email"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_11___default()), {
                                    error: !!(formik.touched.email && formik.errors.email),
                                    fullWidth: true,
                                    name: "email",
                                    required: true,
                                    onBlur: formik.handleBlur,
                                    onChange: formik.handleChange,
                                    type: "text",
                                    value: formik.values.email
                                }),
                                !!(formik.touched.email && formik.errors.email) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                    sx: {
                                        mt: 2
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_13__.FormHelperText, {
                                        error: true,
                                        children: formik.errors.email
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Unstable_Grid2__WEBPACK_IMPORTED_MODULE_8___default()), {
                        xs: 12,
                        sm: 6,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9___default()), {
                            fullWidth: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    sx: {
                                        color: "text.primary",
                                        mb: 1
                                    },
                                    children: "Contact Number"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_11___default()), {
                                    error: !!(formik.touched.number && formik.errors.number),
                                    fullWidth: true,
                                    name: "number",
                                    required: true,
                                    onBlur: formik.handleBlur,
                                    onChange: formik.handleChange,
                                    type: "text",
                                    value: formik.values.number
                                }),
                                !!(formik.touched.number && formik.errors.number) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                    sx: {
                                        mt: 2
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_13__.FormHelperText, {
                                        error: true,
                                        children: formik.errors.number
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Unstable_Grid2__WEBPACK_IMPORTED_MODULE_8___default()), {
                        xs: 12,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9___default()), {
                            fullWidth: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    sx: {
                                        color: "text.primary",
                                        mb: 1
                                    },
                                    children: "Enquiry Type"
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Select__WEBPACK_IMPORTED_MODULE_14___default()), {
                                    error: !!(formik.touched.enquiryType && formik.errors.enquiryType),
                                    fullWidth: true,
                                    name: "enquiryType",
                                    required: true,
                                    onBlur: formik.handleBlur,
                                    onChange: formik.handleChange,
                                    type: "text",
                                    value: formik.values.enquiryType,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_15___default()), {
                                            value: "1",
                                            children: "Marketing"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_MenuItem__WEBPACK_IMPORTED_MODULE_15___default()), {
                                            value: "2",
                                            children: "Other"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Unstable_Grid2__WEBPACK_IMPORTED_MODULE_8___default()), {
                        xs: 12,
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_FormControl__WEBPACK_IMPORTED_MODULE_9___default()), {
                            fullWidth: true,
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_FormLabel__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    sx: {
                                        color: "text.primary",
                                        mb: 1
                                    },
                                    children: "Message"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_OutlinedInput__WEBPACK_IMPORTED_MODULE_11___default()), {
                                    error: !!(formik.touched.message && formik.errors.message),
                                    fullWidth: true,
                                    name: "message",
                                    required: true,
                                    multiline: true,
                                    rows: 6,
                                    onBlur: formik.handleBlur,
                                    onChange: formik.handleChange,
                                    type: "text",
                                    value: formik.values.message
                                }),
                                !!(formik.touched.message && formik.errors.message) && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_12__["default"], {
                                    sx: {
                                        mt: 2
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_13__.FormHelperText, {
                                        error: true,
                                        children: formik.errors.message
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material_Box__WEBPACK_IMPORTED_MODULE_12__["default"], {
                sx: {
                    display: "flex",
                    justifyContent: "center",
                    mt: 3
                },
                children: [
                    formik.errors.submit && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_13__.FormHelperText, {
                        error: true,
                        sx: {
                            mt: 3
                        },
                        children: formik.errors.submit
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_buttons_button__WEBPACK_IMPORTED_MODULE_7__/* .Button */ .z, {
                        disabled: formik.isSubmitting,
                        type: "submit",
                        fullWidth: true,
                        size: "large",
                        variant: "contained",
                        children: "Submit"
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_16___default()), {
                color: "text.secondary",
                sx: {
                    my: 1
                },
                variant: "body2",
                children: "An email will be sent with this request and we will be in touch with you shortly."
            })
        ]
    });
};


/***/ })

};
;