exports.id = 7680;
exports.ids = [7680];
exports.modules = {

/***/ 225009:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 189222, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 878301, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 883751, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 654765, 23));
Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 805192, 23))

/***/ }),

/***/ 534653:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 789638))

/***/ }),

/***/ 523200:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 337305))

/***/ }),

/***/ 337305:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(746661);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(898511);
/* harmony import */ var _mui_material_Button__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Button__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(963246);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Container__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(243360);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_useMediaQuery__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(975983);
/* harmony import */ var src_components_router_link__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(510079);
/* harmony import */ var src_components_seo__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(839566);
/* harmony import */ var src_hooks_use_page_view__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(846099);
/* harmony import */ var src_paths__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(287842);
/* __next_internal_client_entry_do_not_use__  auto */ 









const NotFound = ()=>{
    const mdUp = (0,_mui_material_useMediaQuery__WEBPACK_IMPORTED_MODULE_5__["default"])((theme)=>theme.breakpoints.down("md"));
    (0,src_hooks_use_page_view__WEBPACK_IMPORTED_MODULE_3__/* .usePageView */ .a)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_components_seo__WEBPACK_IMPORTED_MODULE_2__/* .Seo */ .p, {
                title: "Error: Not Found"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_6__["default"], {
                component: "main",
                sx: {
                    alignItems: "center",
                    display: "flex",
                    flexGrow: 1,
                    py: "80px"
                },
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Container__WEBPACK_IMPORTED_MODULE_7___default()), {
                    maxWidth: "lg",
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_6__["default"], {
                            sx: {
                                display: "flex",
                                justifyContent: "center",
                                mb: 6
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_6__["default"], {
                                alt: "Not found",
                                component: "img",
                                src: "/assets/errors/error-404.png",
                                sx: {
                                    height: "auto",
                                    maxWidth: "100%",
                                    width: 400
                                }
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                            align: "center",
                            variant: mdUp ? "h1" : "h4",
                            children: "404: The page you are looking for isn’t here"
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_8___default()), {
                            align: "center",
                            color: "text.secondary",
                            sx: {
                                mt: 0.5
                            },
                            children: "You either tried some shady route or you came here by mistake. Whichever it is, try using the navigation."
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_6__["default"], {
                            sx: {
                                display: "flex",
                                justifyContent: "center",
                                mt: 6
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Button__WEBPACK_IMPORTED_MODULE_9___default()), {
                                component: src_components_router_link__WEBPACK_IMPORTED_MODULE_1__/* .RouterLink */ .r,
                                href: src_paths__WEBPACK_IMPORTED_MODULE_4__/* .paths.index */ .H.index,
                                children: "Back to Home"
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (NotFound);


/***/ }),

/***/ 4286:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ Logo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(522166);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__);


const Logo = (props)=>{
    const { fillColor ="black" , variant ="primary"  } = props;
    const theme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_1__.useTheme)();
    return variant === "primary" ? /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("svg", {
        id: "Layer_1",
        "data-name": "Layer 1",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 600 80",
        fill: fillColor,
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
            d: "M184.67,48.79l-1.8,10A2,2,0,0,1,181,60.42H164.44c-2.95,0-4.09,1-4.67,4.1l-1.06,5.89h20.14a1.34,1.34,0,0,1,1.4,1.4v.24l-1.72,9.67a2,2,0,0,1-1.89,1.63H156.5l-4,22.77a2.09,2.09,0,0,1-2,1.64H137.17a1.24,1.24,0,0,1-1.31-1.31v-.33l7.29-41.6c2.86-16.63,13.26-18.43,24.24-18.43a108.55,108.55,0,0,1,15.89,1.07c.9.08,1.39.57,1.39,1.31Zm48.48,12.78c0-1-.9-1.47-1.88-1.47H219.56a2.14,2.14,0,0,0-2.21,1.8l-5.57,31.69a16.72,16.72,0,0,1-7,1.8c-2.62,0-3.85-.41-3.85-3.27a22.76,22.76,0,0,1,.57-4.1l4.59-26.12v-.33a1.39,1.39,0,0,0-1.39-1.47H192.45a2.28,2.28,0,0,0-2,1.8l-4.5,25.55a36.92,36.92,0,0,0-.66,6.55c0,8.19,3.44,14.5,12.86,14.5,2.87,0,7.37-.74,13.11-4.51l-.41,2.13v.25a1.33,1.33,0,0,0,1.39,1.39h11.22a2,2,0,0,0,1.88-1.64l7.86-44.22Zm36.37-.16a1.24,1.24,0,0,0-1.31-1.31H262l1.56-8.93v-.25a1.3,1.3,0,0,0-1.31-1.31H262l-12.53,2.13a2.38,2.38,0,0,0-2,1.72l-1.15,6.64h-5.41a2.18,2.18,0,0,0-2,1.72l-1.23,6.88v.24A1.59,1.59,0,0,0,239,70.5l5.24,1.22-3.85,21.87a28.38,28.38,0,0,0-.41,4.26c0,7.94,5.08,10.65,12.21,10.65a37.8,37.8,0,0,0,7.45-.74,2.33,2.33,0,0,0,2.05-1.64l1.31-7.7v-.24a1.34,1.34,0,0,0-1.48-1.31h-3.76c-1.48,0-2-.33-2-1.39a8.81,8.81,0,0,1,.24-1.73l3.94-22h6.22A2,2,0,0,0,268,70.09l1.48-8.36Zm49.14.16c0-1-.9-1.47-1.89-1.47H305.06a2.15,2.15,0,0,0-2.21,1.8l-5.57,31.69a16.63,16.63,0,0,1-7,1.8c-2.62,0-3.85-.41-3.85-3.27A23.71,23.71,0,0,1,287,88l4.59-26.12v-.33a1.39,1.39,0,0,0-1.39-1.47H278a2.25,2.25,0,0,0-2,1.8L271.4,87.45a36.88,36.88,0,0,0-.65,6.55c0,8.19,3.44,14.5,12.86,14.5,2.86,0,7.37-.74,13.1-4.51l-.41,2.13v.25a1.33,1.33,0,0,0,1.39,1.39h11.22a2,2,0,0,0,1.89-1.64l7.86-44.22Zm36-.74a1.33,1.33,0,0,0-1.39-1.39h-.9a14.74,14.74,0,0,0-11,4.26l.24-2v-.24a1.27,1.27,0,0,0-1.31-1.39H328.81a2.08,2.08,0,0,0-2,1.63L319.07,106v.24a1.55,1.55,0,0,0,1.47,1.56h12.29a2.17,2.17,0,0,0,2-1.8l5.57-31.78a22.12,22.12,0,0,1,9.75-1.88h1.14A2,2,0,0,0,353,70.66l1.72-9.58Zm24.17,10.73c3.68,0,5,2,5,4.83a16,16,0,0,1-.41,3.28H371.32c1-4.67,2.95-8.11,7.54-8.11m19.32,10.07a29.34,29.34,0,0,0,.41-4.66c0-9.75-5.57-17.61-17.44-17.61-13.68,0-23,6.06-25.72,22.27l-.9,5.41a25.81,25.81,0,0,0-.32,4.18c0,11.63,9,17.28,18.09,17.28A57.89,57.89,0,0,0,390.24,106a2.45,2.45,0,0,0,2.05-2.3l1.31-7.37V96c0-.74-.5-1.07-1.23-1.07H392c-3.11.33-11.38.66-15.72.66-4.1,0-6.72-.58-6.72-4.67a14.85,14.85,0,0,1,.25-2.54h25.47a2.09,2.09,0,0,0,2-1.8l.82-4.92m59.63-31.77a3.29,3.29,0,0,1,.08-.41c0-.74-.58-.9-1.39-1.15A63.89,63.89,0,0,0,439,46.09c-12,0-26.29,3.11-30.63,27l-1.55,8.59a37.21,37.21,0,0,0-.58,6.47c0,15.07,11.38,20.4,20.56,20.4a97,97,0,0,0,19.32-2c1.4-.25,1.81-.65,2.05-1.88L453,77.21V77a1.34,1.34,0,0,0-1.39-1.4H438.64a1.92,1.92,0,0,0-1.8,1.64L433.89,94a41.63,41.63,0,0,1-4.58.25c-3,0-6.15-1.07-6.15-7.38a32.45,32.45,0,0,1,.5-5.15L425.21,73c1.8-9.83,5.24-12.29,13.43-12.29,6.06,0,12.61.57,15.73.74h.24c.82,0,1.15-.33,1.31-1.31l1.89-10.32m24.73,22.68c3.2,0,4.59,1.23,4.59,4.84a30.44,30.44,0,0,1-.41,4.17l-.82,4.75c-1.23,7-3.28,9.09-7.37,9.09-3.11,0-4.75-1.14-4.75-5a28.09,28.09,0,0,1,.41-4.1l.82-4.75c1.14-6.47,3.36-9,7.53-9m19.82,9a42.52,42.52,0,0,0,.41-4.91c0-10.48-6.55-17.28-17.93-17.28-13.68,0-22.69,6-25.47,22.19l-.82,4.75a26.6,26.6,0,0,0-.41,5c0,10.32,6.22,17.2,18,17.2,14.25,0,22.69-6.31,25.39-22.2l.82-4.75m29.08-35.79a1.32,1.32,0,0,0-1.4-1.31H517.68a2.19,2.19,0,0,0-2,1.64L505.07,106v.24a1.54,1.54,0,0,0,1.47,1.56h12.37a2.25,2.25,0,0,0,2-1.8l10.57-59.87Zm35.87-.49c0-.73-.66-1.14-1.39-1.31a36.74,36.74,0,0,0-6.72-.82c-9.58,0-15.64,2.21-17.85,15.07L541,60.1h-5.57a1.91,1.91,0,0,0-2.05,1.72l-1.22,7.12v.41a1.48,1.48,0,0,0,1.39,1.56l5.4.82-6.22,35.7c-.57,3.28-1.31,3.52-4.1,3.52h-2.78a2,2,0,0,0-1.88,1.64l-1.31,7.54v.24c0,.74.65,1.15,1.39,1.31a36.53,36.53,0,0,0,6.71.82c9.5,0,15.48-2,17.77-15.07l6.31-35.7h6.06a1.8,1.8,0,0,0,2-1.72l1.47-8.19v-.41A1.23,1.23,0,0,0,563,60.1h-6.06l.32-1.89c.58-3.19,1.32-3.52,3.53-3.52H564a1.84,1.84,0,0,0,2-1.64l1.31-7.53Zm-449.13.8H60.81L56.47,65.7H85.22l-1.07,4.71C81.64,81.46,73.36,89.19,64,89.19H51.29l-4.24,18.72H69.74c20.5,0,37.63-13.54,42.05-33.23l6.4-28.58h0ZM109.3,2.5h-52C36.85,2.5,19.71,16,15.3,35.73L2.69,93.19c-1.65,7.37,4.36,14.72,12,14.72h8.54L38.46,40C41,29,49.24,21.22,58.59,21.22H95L92.66,31.71h28.48l2.59-11.55c2-8.84-5.23-17.66-14.43-17.66"
        })
    }) : /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("svg", {
        id: "Layer_1",
        "data-name": "Layer 1",
        xmlns: "http://www.w3.org/2000/svg",
        viewBox: "0 0 170 170",
        fill: fillColor,
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                d: "M3.9,85A81.1,81.1,0,1,1,85,166.1,81.1,81.1,0,0,1,3.9,85"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                fill: "white",
                d: "M122.17,78.27H83.36L80.42,91.54H99.87l-.73,3.19c-1.69,7.48-7.29,12.7-13.61,12.7H76.92L74.05,120.1H89.4a28.7,28.7,0,0,0,28.44-22.48l4.33-19.33h0Z"
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("path", {
                fill: "white",
                d: "M116.16,48.79H81A28.71,28.71,0,0,0,52.57,71.27L44,110.14a8.37,8.37,0,0,0,8.14,10H58L68.24,74.16c1.7-7.48,7.29-12.7,13.61-12.7h24.66l-1.61,7.09h19.27l1.75-7.81a10,10,0,0,0-9.76-12"
            })
        ]
    });
};


/***/ }),

/***/ 510079:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ RouterLink)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(331621);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);



/**
 * This is a wrapper over `next/link` component.
 * We use this to help us maintain consistency between Vite and Next.js
 */ const RouterLink = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_1__.forwardRef)(function RouterLink(props, ref) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
        ref: ref,
        ...props
    });
});


/***/ }),

/***/ 839566:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ Seo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(322424);
/* harmony import */ var next_head__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_head__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(869232);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);



const Seo = (props)=>{
    const { title  } = props;
    const fullTitle = title ? title + " | Future Golf" : "Future Golf";
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_head__WEBPACK_IMPORTED_MODULE_1___default()), {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("title", {
            children: fullTitle
        })
    });
};
Seo.propTypes = {
    title: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().string)
};


/***/ }),

/***/ 198103:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "HR": () => (/* binding */ enableDevTools),
/* harmony export */   "PG": () => (/* binding */ gtmConfig),
/* harmony export */   "jZ": () => (/* binding */ mapboxConfig)
/* harmony export */ });
const enableDevTools = process.env.NEXT_PUBLIC_ENABLE_REDUX_DEV_TOOLS === "true";
const gtmConfig = {
    containerId: process.env.NEXT_PUBLIC_GTM_CONTAINER_ID
};
const mapboxConfig = {
    apiKey: process.env.NEXT_PUBLIC_MAPBOX_API_KEY
};


/***/ }),

/***/ 378276:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "E": () => (/* binding */ initialState),
/* harmony export */   "V": () => (/* binding */ AuthContext)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_utils_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(85403);


const initialState = {
    isAuthenticated: false,
    isInitialized: false,
    user: null
};
const AuthContext = (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)({
    ...initialState,
    issuer: src_utils_auth__WEBPACK_IMPORTED_MODULE_1__/* .Issuer.JWT */ .M.JWT,
    signIn: ()=>Promise.resolve(),
    refresh: ()=>Promise.resolve(),
    signOut: ()=>Promise.resolve()
});


/***/ }),

/***/ 465388:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "H": () => (/* binding */ AuthProvider),
  "U": () => (/* binding */ auth_provider_STORAGE_KEY)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./src/utils/jwt.ts
var jwt = __webpack_require__(205200);
// EXTERNAL MODULE: ./node_modules/axios/lib/axios.js + 46 modules
var axios = __webpack_require__(740248);
;// CONCATENATED MODULE: ./src/api/auth/index.ts


const STORAGE_KEY = "users";
// NOTE: We use localStorage since memory storage is lost after page reload.
//  This should be replaced with a server call that returns DB persisted data.
const getPersistedUsers = ()=>{
    try {
        const data = localStorage.getItem(STORAGE_KEY);
        if (!data) {
            return [];
        }
        return JSON.parse(data);
    } catch (err) {
        console.error(err);
        return [];
    }
};
class AuthApi {
    async signIn(request) {
        const { email , password  } = request;
        return new Promise(async (resolve, reject)=>{
            try {
                try {
                    // Make an HTTP POST request to the API
                    const response = await axios/* default.post */.Z.post("https://sit1api.futuregolf.com.au" + "/getToken", {
                        grant_type: "password",
                        username: email,
                        password: password
                    });
                    // Create the access token
                    const accessToken = (0,jwt/* sign */.Xx)({
                        token: process.env.NEXT_PUBLIC_TMP_TOKEN ? process.env.NEXT_PUBLIC_TMP_TOKEN : response.data.message.access_token
                    }, jwt/* JWT_SECRET */.rf, {
                        expiresIn: jwt/* JWT_EXPIRES_IN */.R1
                    });
                    resolve({
                        accessToken
                    });
                } catch (err) {
                    reject(new Error("Please check your email and password"));
                }
            } catch (err) {
                console.error("[Auth Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    getPartner(request) {
        const { accessToken  } = request;
        return new Promise(async (resolve, reject)=>{
            try {
                // Decode access token
                const decodedToken = (0,jwt/* decode */.Jx)(String(accessToken));
                try {
                    if (!decodedToken.token) {
                        reject(new Error("Invalid authorization token"));
                        return;
                    }
                    // Make an HTTP POST request to the API
                    const response = await axios/* default.get */.Z.get("https://sit1api.futuregolf.com.au" + "/getPartner", {
                        headers: {
                            Authorization: `Bearer ${decodedToken.token}`
                        }
                    });
                    if (!response.data.isPartner) {
                        reject(new Error("Your account does not have access to use this portal. Please contact us at partnerships@futuregolf.com.au"));
                    }
                    resolve({
                        id: response.data.ID,
                        firstName: response.data.firstName,
                        lastName: response.data.lastName,
                        email: response.data.email,
                        registeredDate: response.data.registeredDate,
                        isPartner: response.data.isPartner,
                        linkedPartnerId: response.data.linkedPartnerId,
                        name: response.data.name,
                        status: response.data.status,
                        facebookHandle: response.data.facebookHandle,
                        instagramHandle: response.data.instagramHandle,
                        vouchers: response.data.vouchers
                    });
                } catch (err) {
                    reject(new Error("Please check your email and password"));
                }
            } catch (err) {
                console.error("[Auth Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
}
const authApi = new AuthApi();

// EXTERNAL MODULE: ./src/utils/auth.ts
var auth = __webpack_require__(85403);
// EXTERNAL MODULE: ./src/contexts/auth/auth-context.ts
var auth_context = __webpack_require__(378276);
;// CONCATENATED MODULE: ./src/contexts/auth/auth-provider.tsx






const auth_provider_STORAGE_KEY = "accessToken";
var ActionType;
(function(ActionType) {
    ActionType["INITIALIZE"] = "INITIALIZE";
    ActionType["SIGN_IN"] = "SIGN_IN";
    ActionType["SIGN_UP"] = "SIGN_UP";
    ActionType["SIGN_OUT"] = "SIGN_OUT";
    ActionType["REFRESH"] = "REFRESH";
})(ActionType || (ActionType = {}));
const handlers = {
    INITIALIZE: (state, action)=>{
        const { isAuthenticated , user  } = action.payload;
        return {
            ...state,
            isAuthenticated,
            isInitialized: true,
            user
        };
    },
    SIGN_IN: (state, action)=>{
        const { user  } = action.payload;
        return {
            ...state,
            isAuthenticated: true,
            user
        };
    },
    REFRESH: (state, action)=>{
        const { user  } = action.payload;
        return {
            ...state,
            isAuthenticated: true,
            user
        };
    },
    SIGN_UP: (state, action)=>{
        const { user  } = action.payload;
        return {
            ...state,
            isAuthenticated: true,
            user
        };
    },
    SIGN_OUT: (state)=>({
            ...state,
            isAuthenticated: false,
            user: null
        })
};
const reducer = (state, action)=>handlers[action.type] ? handlers[action.type](state, action) : state;
const AuthProvider = (props)=>{
    const { children  } = props;
    const [state, dispatch] = (0,react_.useReducer)(reducer, auth_context/* initialState */.E);
    const initialize = (0,react_.useCallback)(async ()=>{
        try {
            const accessToken = window.localStorage.getItem(auth_provider_STORAGE_KEY);
            if (accessToken) {
                const user = await authApi.getPartner({
                    accessToken
                });
                dispatch({
                    type: ActionType.INITIALIZE,
                    payload: {
                        isAuthenticated: true,
                        user
                    }
                });
            } else {
                dispatch({
                    type: ActionType.INITIALIZE,
                    payload: {
                        isAuthenticated: false,
                        user: null
                    }
                });
            }
        } catch (err) {
            console.error(err);
            dispatch({
                type: ActionType.INITIALIZE,
                payload: {
                    isAuthenticated: false,
                    user: null
                }
            });
        }
    }, [
        dispatch
    ]);
    (0,react_.useEffect)(()=>{
        initialize();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []);
    const signIn = (0,react_.useCallback)(async (email, password)=>{
        const { accessToken  } = await authApi.signIn({
            email,
            password
        });
        localStorage.setItem(auth_provider_STORAGE_KEY, accessToken);
        const user = await authApi.getPartner({
            accessToken
        });
        dispatch({
            type: ActionType.SIGN_IN,
            payload: {
                user
            }
        });
    }, [
        dispatch
    ]);
    const signOut = (0,react_.useCallback)(async ()=>{
        localStorage.removeItem(auth_provider_STORAGE_KEY);
        dispatch({
            type: ActionType.SIGN_OUT
        });
    }, [
        dispatch
    ]);
    const refresh = (0,react_.useCallback)(async ()=>{
        console.log("Refreshing");
        const accessToken = window.localStorage.getItem(auth_provider_STORAGE_KEY);
        const user = await authApi.getPartner({
            accessToken
        });
        dispatch({
            type: ActionType.REFRESH,
            payload: {
                user
            }
        });
    }, [
        dispatch
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(auth_context/* AuthContext.Provider */.V.Provider, {
        value: {
            ...state,
            issuer: auth/* Issuer.JWT */.M.JWT,
            signIn,
            signOut,
            refresh
        },
        children: children
    });
};
AuthProvider.propTypes = {
    children: (prop_types_default()).node.isRequired
};


/***/ }),

/***/ 736169:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "he": () => (/* reexport */ AuthConsumer),
  "Vo": () => (/* reexport */ auth_context/* AuthContext */.V),
  "Ho": () => (/* reexport */ auth_provider/* AuthProvider */.H)
});

// EXTERNAL MODULE: ./src/contexts/auth/auth-context.ts
var auth_context = __webpack_require__(378276);
;// CONCATENATED MODULE: ./src/contexts/auth/auth-consumer.tsx

const AuthConsumer = auth_context/* AuthContext.Consumer */.V.Consumer;

// EXTERNAL MODULE: ./src/contexts/auth/auth-provider.tsx + 1 modules
var auth_provider = __webpack_require__(465388);
;// CONCATENATED MODULE: ./src/contexts/auth/index.ts





/***/ }),

/***/ 34383:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "ix": () => (/* reexport */ SettingsConsumer),
  "J6": () => (/* reexport */ SettingsContext),
  "mu": () => (/* reexport */ SettingsProvider)
});

// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./src/contexts/settings/settings-context.tsx

const defaultSettings = {
    colorPreset: "blue",
    contrast: "normal",
    direction: "ltr",
    layout: "vertical",
    navColor: "evident",
    paletteMode: "light",
    responsiveFontSizes: true,
    stretch: false
};
const initialState = {
    ...defaultSettings,
    isInitialized: false,
    openDrawer: false
};
const SettingsContext = /*#__PURE__*/ (0,react_.createContext)({
    ...defaultSettings,
    ...initialState,
    handleDrawerClose: ()=>{},
    handleDrawerOpen: ()=>{},
    handleReset: ()=>{},
    handleUpdate: ()=>{},
    isCustom: false
});

;// CONCATENATED MODULE: ./src/contexts/settings/settings-consumer.ts

const SettingsConsumer = SettingsContext.Consumer;

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/lodash.isequal/index.js
var lodash_isequal = __webpack_require__(642980);
var lodash_isequal_default = /*#__PURE__*/__webpack_require__.n(lodash_isequal);
;// CONCATENATED MODULE: ./src/contexts/settings/settings-provider.tsx





const SettingsProvider = (props)=>{
    const { children , onReset =()=>{} , onUpdate =()=>{} , settings: initialSettings  } = props;
    const [state, setState] = (0,react_.useState)(initialState);
    const settings = (0,react_.useMemo)(()=>{
        return {
            ...defaultSettings,
            ...initialSettings
        };
    }, [
        initialSettings
    ]);
    const handleUpdate = (0,react_.useCallback)((newSettings)=>{
        onUpdate({
            colorPreset: settings.colorPreset,
            contrast: settings.contrast,
            direction: settings.direction,
            layout: settings.layout,
            navColor: settings.navColor,
            paletteMode: settings.paletteMode,
            responsiveFontSizes: settings.responsiveFontSizes,
            stretch: settings.stretch,
            ...newSettings
        });
    }, [
        onUpdate,
        settings
    ]);
    const handleDrawerOpen = (0,react_.useCallback)(()=>{
        setState((prevState)=>({
                ...prevState,
                openDrawer: true
            }));
    }, []);
    const handleDrawerClose = (0,react_.useCallback)(()=>{
        setState((prevState)=>({
                ...prevState,
                openDrawer: false
            }));
    }, []);
    const isCustom = (0,react_.useMemo)(()=>{
        return !lodash_isequal_default()(defaultSettings, {
            colorPreset: settings.colorPreset,
            contrast: settings.contrast,
            direction: settings.direction,
            layout: settings.layout,
            navColor: settings.navColor,
            paletteMode: settings.paletteMode,
            responsiveFontSizes: settings.responsiveFontSizes,
            stretch: settings.stretch
        });
    }, [
        settings
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(SettingsContext.Provider, {
        value: {
            ...settings,
            ...state,
            handleDrawerClose,
            handleDrawerOpen,
            handleReset: onReset,
            handleUpdate,
            isCustom
        },
        children: children
    });
};
SettingsProvider.propTypes = {
    children: (prop_types_default()).node.isRequired
};

;// CONCATENATED MODULE: ./src/contexts/settings/index.ts





/***/ }),

/***/ 846099:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "a": () => (/* binding */ usePageView)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_libs_gtm__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(217022);


const usePageView = ()=>{
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        src_libs_gtm__WEBPACK_IMPORTED_MODULE_1__/* .gtm.push */ .w.push({
            event: "page_view"
        });
    }, []);
};


/***/ }),

/***/ 789638:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Layout": () => (/* binding */ Layout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/next/dist/client/components/noop-head.js
var noop_head = __webpack_require__(322424);
var noop_head_default = /*#__PURE__*/__webpack_require__.n(noop_head);
// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(801560);
// EXTERNAL MODULE: ./node_modules/tss-react/esm/next/appDir.js
var appDir = __webpack_require__(930270);
// EXTERNAL MODULE: ./node_modules/js-cookie/dist/js.cookie.mjs
var js_cookie = __webpack_require__(897270);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CssBaseline/index.js
var CssBaseline = __webpack_require__(457981);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
// EXTERNAL MODULE: ./node_modules/@mui/x-date-pickers/node/AdapterDateFns/index.js
var AdapterDateFns = __webpack_require__(887400);
// EXTERNAL MODULE: ./node_modules/@mui/x-date-pickers/node/LocalizationProvider/index.js
var LocalizationProvider = __webpack_require__(597057);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@emotion/cache/dist/emotion-cache.esm.js + 7 modules
var emotion_cache_esm = __webpack_require__(258471);
// EXTERNAL MODULE: ./node_modules/@emotion/react/dist/emotion-element-6bdfffb2.esm.js + 1 modules
var emotion_element_6bdfffb2_esm = __webpack_require__(319128);
// EXTERNAL MODULE: ./node_modules/stylis-plugin-rtl/dist/cjs/stylis-rtl.js
var stylis_rtl = __webpack_require__(585248);
var stylis_rtl_default = /*#__PURE__*/__webpack_require__.n(stylis_rtl);
;// CONCATENATED MODULE: ./src/components/rtl.tsx






const styleCache = ()=>(0,emotion_cache_esm["default"])({
        key: "rtl",
        prepend: true,
        // @ts-ignore
        stylisPlugins: [
            (stylis_rtl_default())
        ]
    });
const RTL = (props)=>{
    const { children , direction ="ltr"  } = props;
    (0,react_.useEffect)(()=>{
        document.dir = direction;
    }, [
        direction
    ]);
    if (direction === "rtl") {
        return /*#__PURE__*/ jsx_runtime_.jsx(emotion_element_6bdfffb2_esm.C, {
            value: styleCache(),
            children: children
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: children
    });
};
RTL.propTypes = {
    children: (prop_types_default()).node.isRequired,
    direction: prop_types_default().oneOf([
        "ltr",
        "rtl"
    ])
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./src/components/logo.tsx
var logo = __webpack_require__(4286);
;// CONCATENATED MODULE: ./src/components/splash-screen.tsx



const SplashScreen = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            alignItems: "center",
            backgroundColor: "background.paper",
            display: "flex",
            flexDirection: "column",
            height: "100vh",
            justifyContent: "center",
            left: 0,
            p: 3,
            position: "fixed",
            top: 0,
            width: "100vw",
            zIndex: 1400
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
            sx: {
                display: "inline-flex",
                height: 288,
                width: 288
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx(logo/* Logo */.T, {})
        })
    });

// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(333518);
// EXTERNAL MODULE: ./node_modules/@mui/system/colorManipulator.js
var colorManipulator = __webpack_require__(229551);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/index.js
var node = __webpack_require__(664085);
;// CONCATENATED MODULE: ./src/components/toaster.tsx





const Toaster = ({ onUndo  })=>{
    const theme = (0,styles.useTheme)();
    const handleUndo = (t)=>{
        onUndo?.();
        dist/* default.dismiss */.ZP.dismiss();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(dist/* Toaster */.x7, {
        position: "top-center",
        toastOptions: {
            style: {
                backdropFilter: "blur(6px)",
                background: (0,colorManipulator.alpha)(theme.palette.neutral[900], 0.8),
                color: theme.palette.common.white,
                boxShadow: theme.shadows[16],
                minWidth: "fit-content"
            }
        },
        children: (t)=>/*#__PURE__*/ jsx_runtime_.jsx(dist/* ToastBar */.$x, {
                toast: t,
                children: ({ icon , message  })=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            icon,
                            message,
                            t.type !== "loading" && onUndo && /*#__PURE__*/ jsx_runtime_.jsx(node.Button, {
                                color: "inherit",
                                onClick: ()=>handleUndo(t),
                                children: /*#__PURE__*/ jsx_runtime_.jsx(node.Typography, {
                                    color: "white",
                                    children: "Undo"
                                })
                            })
                        ]
                    })
            })
    });
};

// EXTERNAL MODULE: ./src/config.ts
var config = __webpack_require__(198103);
// EXTERNAL MODULE: ./src/contexts/auth/index.ts + 1 modules
var auth = __webpack_require__(736169);
// EXTERNAL MODULE: ./src/contexts/settings/index.ts + 3 modules
var contexts_settings = __webpack_require__(34383);
// EXTERNAL MODULE: ./src/libs/gtm.ts
var gtm = __webpack_require__(217022);
;// CONCATENATED MODULE: ./src/hooks/use-analytics.ts


function useAnalytics(config) {
    (0,react_.useEffect)(()=>{
        gtm/* gtm.initialize */.w.initialize(config);
    }, [
        config
    ]);
}

// EXTERNAL MODULE: ./node_modules/next/router.js
var router = __webpack_require__(500778);
var router_default = /*#__PURE__*/__webpack_require__.n(router);
// EXTERNAL MODULE: ./node_modules/nprogress/nprogress.js
var nprogress = __webpack_require__(472553);
var nprogress_default = /*#__PURE__*/__webpack_require__.n(nprogress);
;// CONCATENATED MODULE: ./src/hooks/use-nprogress.ts



function useNprogress() {
    (0,react_.useEffect)(()=>{
        router_default().events.on("routeChangeStart", (nprogress_default()).start);
        router_default().events.on("routeChangeError", (nprogress_default()).done);
        router_default().events.on("routeChangeComplete", (nprogress_default()).done);
        return ()=>{
            router_default().events.off("routeChangeStart", (nprogress_default()).start);
            router_default().events.off("routeChangeError", (nprogress_default()).done);
            router_default().events.off("routeChangeComplete", (nprogress_default()).done);
        };
    }, []);
}

// EXTERNAL MODULE: ./src/store/index.ts + 2 modules
var store = __webpack_require__(754835);
// EXTERNAL MODULE: ./src/theme/index.ts + 12 modules
var src_theme = __webpack_require__(188053);
// EXTERNAL MODULE: ./node_modules/i18next/dist/esm/i18next.js + 4 modules
var i18next = __webpack_require__(503134);
// EXTERNAL MODULE: ./node_modules/react-i18next/dist/es/index.js + 14 modules
var es = __webpack_require__(791148);
// EXTERNAL MODULE: ./src/locales/tokens.ts
var tokens = __webpack_require__(288411);
;// CONCATENATED MODULE: ./src/locales/translations/en.ts

const en = {
    [tokens/* tokens.common.languageChanged */.T.common.languageChanged]: "Language changed",
    [tokens/* tokens.nav.academy */.T.nav.academy]: "Academy",
    [tokens/* tokens.nav.account */.T.nav.account]: "Account",
    [tokens/* tokens.nav.analytics */.T.nav.analytics]: "Analytics",
    [tokens/* tokens.nav.auth */.T.nav.auth]: "Auth",
    [tokens/* tokens.nav.memberFeedback */.T.nav.memberFeedback]: "Member Feedback",
    [tokens/* tokens.nav.browse */.T.nav.browse]: "Browse",
    [tokens/* tokens.nav.calendar */.T.nav.calendar]: "Calendar",
    [tokens/* tokens.nav.chat */.T.nav.chat]: "Chat",
    [tokens/* tokens.nav.checkout */.T.nav.checkout]: "Checkout",
    [tokens/* tokens.nav.concepts */.T.nav.concepts]: "Concepts",
    [tokens/* tokens.nav.contact */.T.nav.contact]: "Contact",
    [tokens/* tokens.nav.marketing */.T.nav.marketing]: "Marketing Support",
    [tokens/* tokens.nav.course */.T.nav.course]: "Course",
    [tokens/* tokens.nav.create */.T.nav.create]: "Create",
    [tokens/* tokens.nav.vouchers */.T.nav.vouchers]: "Round Vouchers",
    [tokens/* tokens.nav.dashboard */.T.nav.dashboard]: "Dashboard",
    [tokens/* tokens.nav.details */.T.nav.details]: "Details",
    [tokens/* tokens.nav.edit */.T.nav.edit]: "Edit",
    [tokens/* tokens.nav.error */.T.nav.error]: "Error",
    [tokens/* tokens.nav.feed */.T.nav.feed]: "Feed",
    [tokens/* tokens.nav.fileManager */.T.nav.fileManager]: "File Manager",
    [tokens/* tokens.nav.finance */.T.nav.finance]: "Finance",
    [tokens/* tokens.nav.fleet */.T.nav.fleet]: "Fleet",
    [tokens/* tokens.nav.forgotPassword */.T.nav.forgotPassword]: "Forgot Password",
    [tokens/* tokens.nav.invoiceList */.T.nav.invoiceList]: "Invoices",
    [tokens/* tokens.nav.jobList */.T.nav.jobList]: "Job Listings",
    [tokens/* tokens.nav.kanban */.T.nav.kanban]: "Round Vouchers",
    [tokens/* tokens.nav.list */.T.nav.list]: "Dedicated Tee Times",
    [tokens/* tokens.nav.login */.T.nav.login]: "Login",
    [tokens/* tokens.nav.logistics */.T.nav.logistics]: "Logistics",
    [tokens/* tokens.nav.mail */.T.nav.mail]: "Mail",
    [tokens/* tokens.nav.management */.T.nav.management]: "Management",
    [tokens/* tokens.nav.orderList */.T.nav.orderList]: "Orders",
    [tokens/* tokens.nav.overview */.T.nav.overview]: "Round Vouchers",
    [tokens/* tokens.nav.pages */.T.nav.pages]: "Pages",
    [tokens/* tokens.nav.postCreate */.T.nav.postCreate]: "Post Create",
    [tokens/* tokens.nav.postDetails */.T.nav.postDetails]: "Post Details",
    [tokens/* tokens.nav.postList */.T.nav.postList]: "Post List",
    [tokens/* tokens.nav.pricing */.T.nav.pricing]: "Pricing",
    [tokens/* tokens.nav.profile */.T.nav.profile]: "Profile",
    [tokens/* tokens.nav.register */.T.nav.register]: "Register",
    [tokens/* tokens.nav.resetPassword */.T.nav.resetPassword]: "Reset Password",
    [tokens/* tokens.nav.socialMedia */.T.nav.socialMedia]: "Social Media",
    [tokens/* tokens.nav.verifyCode */.T.nav.verifyCode]: "Verify Code"
};

;// CONCATENATED MODULE: ./src/locales/i18n.ts
/* eslint-disable import/no-named-as-default-member */ 


i18next/* default.use */.ZP.use(es/* initReactI18next */.Db).init({
    resources: {
        en: {
            translation: en
        }
    },
    lng: "en",
    fallbackLng: "en",
    interpolation: {
        escapeValue: false
    }
});

;// CONCATENATED MODULE: ./src/layouts/root/root.tsx
/* __next_internal_client_entry_do_not_use__ Layout auto */ 


















// Remove if locales are not used

const SETTINGS_STORAGE_KEY = "app.settings";
const resetSettings = ()=>{
    try {
        js_cookie/* default.remove */.Z.remove(SETTINGS_STORAGE_KEY);
        window.location.reload();
    } catch (err) {
        console.error(err);
    }
};
const updateSettings = (settings)=>{
    try {
        js_cookie/* default.set */.Z.set(SETTINGS_STORAGE_KEY, JSON.stringify(settings));
        window.location.reload();
    } catch (err) {
        console.error(err);
    }
};
const Layout = (props)=>{
    const { children , settings  } = props;
    useAnalytics(config/* gtmConfig */.PG);
    useNprogress();
    return /*#__PURE__*/ jsx_runtime_.jsx(appDir/* NextAppDirEmotionCacheProvider */.a, {
        options: {
            key: "css"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(lib.Provider, {
            store: store/* store */.h,
            children: /*#__PURE__*/ jsx_runtime_.jsx(LocalizationProvider.LocalizationProvider, {
                dateAdapter: AdapterDateFns/* AdapterDateFns */.H,
                children: /*#__PURE__*/ jsx_runtime_.jsx(auth/* AuthProvider */.Ho, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(auth/* AuthConsumer */.he, {
                        children: (auth)=>/*#__PURE__*/ jsx_runtime_.jsx(contexts_settings/* SettingsProvider */.mu, {
                                onReset: resetSettings,
                                onUpdate: updateSettings,
                                settings: settings,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(contexts_settings/* SettingsConsumer */.ix, {
                                    children: (settings)=>{
                                        const theme = (0,src_theme/* createTheme */.j)({
                                            colorPreset: settings.colorPreset,
                                            contrast: settings.contrast,
                                            direction: settings.direction,
                                            paletteMode: settings.paletteMode,
                                            responsiveFontSizes: settings.responsiveFontSizes
                                        });
                                        // Prevent guards from redirecting
                                        const showSlashScreen = !auth.isInitialized;
                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(styles.ThemeProvider, {
                                            theme: theme,
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((noop_head_default()), {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                                            name: "color-scheme",
                                                            content: settings.paletteMode
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                                                            name: "theme-color",
                                                            content: theme.palette.neutral[900]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(RTL, {
                                                    direction: settings.direction,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(CssBaseline["default"], {}),
                                                        showSlashScreen ? /*#__PURE__*/ jsx_runtime_.jsx(SplashScreen, {}) : /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                                            children: children
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Toaster, {
                                                            onUndo: ()=>console.log("funnnction")
                                                        })
                                                    ]
                                                })
                                            ]
                                        });
                                    }
                                })
                            })
                    })
                })
            })
        })
    });
};


/***/ }),

/***/ 217022:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "w": () => (/* binding */ gtm)
/* harmony export */ });
const warn = (...args)=>{
    if (process.env.ENV !== "development") {
        return;
    }
    console.warn(...args);
};
class GTM {
    configure(config) {
        if (!config.containerId) {
            warn("GTM requires a GTM ID to be loaded.");
            return;
        }
        this.CONTAINER_ID = config.containerId;
    }
    initialize(config) {
        if (this.initialized) {
            warn("GTM can only be initialized once.");
            return;
        }
        // Maybe you want to load events from server side (in NextJS apps for example),
        // those can be queued.
        // SSR queued events can be loaded in the initialize script.
        // For the moment we do not implement it, but in future we might add it.
        if (!document) {
            warn("GTM can be initialized only on client side.");
            return;
        }
        this.configure(config);
        if (!this.CONTAINER_ID) {
            return;
        }
        const script = document.createElement("script");
        const noscript = document.createElement("noscript");
        script.innerHTML = `
      (function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start':
        new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],
        j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src=
        'https://www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f);
      })(window,document,'script','dataLayer','${this.CONTAINER_ID}');
    `;
        noscript.innerHTML = `
      <iframe src="https://www.googletagmanager.com/ns.html?id=${this.CONTAINER_ID}" height="0" width="0" style="display:none;visibility:hidden"></iframe>
    `;
        document.head.insertBefore(script, document.head.childNodes[0]);
        document.body.insertBefore(noscript, document.body.childNodes[0]);
    }
    // eslint-disable-next-line class-methods-use-this
    push(...args) {
        if (!window) {
            warn("GTM push works only on client side.");
            return;
        }
        if (!window.dataLayer) {
            window.dataLayer = [];
        }
        window.dataLayer.push(...args);
    }
    constructor(){
        this.initialized = false;
    }
}
// Singleton
const gtm = new GTM();


/***/ }),

/***/ 288411:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "T": () => (/* binding */ tokens)
/* harmony export */ });
const tokens = {
    common: {
        languageChanged: "common.languageChanged"
    },
    nav: {
        academy: "nav.academy",
        account: "nav.account",
        analytics: "nav.analytics",
        auth: "nav.auth",
        memberFeedback: "nav.memberFeedback",
        browse: "nav.browse",
        calendar: "nav.calendar",
        chat: "nav.chat",
        checkout: "nav.checkout",
        concepts: "nav.concepts",
        contact: "nav.contact",
        marketing: "nav.marketing",
        course: "nav.course",
        create: "nav.create",
        vouchers: "nav.customers",
        dashboard: "nav.dashboard",
        details: "nav.details",
        edit: "nav.edit",
        error: "nav.error",
        feed: "nav.feed",
        fileManager: "nav.fileManager",
        files: "nav.files",
        finance: "nav.finance",
        fleet: "nav.fleet",
        forgotPassword: "nav.forgotPassword",
        invoiceList: "nav.invoices",
        jobList: "nav.jobList",
        kanban: "nav.kanban",
        list: "nav.list",
        login: "nav.login",
        logistics: "nav.logistics",
        mail: "nav.mail",
        management: "nav.management",
        orderList: "nav.orders",
        overview: "nav.overview",
        pages: "nav.pages",
        postCreate: "nav.postCreate",
        postDetails: "nav.postDetails",
        postList: "nav.postList",
        pricing: "nav.pricing",
        profile: "nav.profile",
        register: "nav.register",
        resetPassword: "nav.resetPassword",
        socialMedia: "nav.socialMedia",
        verifyCode: "nav.verifyCode"
    }
};


/***/ }),

/***/ 287842:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "H": () => (/* binding */ paths)
/* harmony export */ });
const paths = {
    index: "/",
    checkout: "/checkout",
    pricing: "/pricing",
    auth: {
        login: "/auth/login"
    },
    authDemo: {
        forgotPassword: {
            classic: "/auth-demo/forgot-password/classic",
            modern: "/auth-demo/forgot-password/modern"
        },
        login: {
            classic: "/auth-demo/login/classic",
            modern: "/auth-demo/login/modern"
        },
        register: {
            classic: "/auth-demo/register/classic",
            modern: "/auth-demo/register/modern"
        },
        resetPassword: {
            classic: "/auth-demo/reset-password/classic",
            modern: "/auth-demo/reset-password/modern"
        },
        verifyCode: {
            classic: "/auth-demo/verify-code/classic",
            modern: "/auth-demo/verify-code/modern"
        }
    },
    dashboard: {
        index: "/",
        academy: {
            index: "/academy",
            courseDetails: "/academy/courses/:courseId"
        },
        account: "/account",
        analytics: "/analytics",
        blank: "/blank",
        memberFeedback: "/member-feedback",
        marketingContact: "/marketing-contact",
        contact: "/contact",
        chat: "/chat",
        vouchers: {
            index: "/vouchers"
        },
        teeTimes: "/tee-times",
        fileManager: "/file-manager",
        invoices: {
            index: "/invoices",
            details: "/invoices/:orderId"
        },
        jobs: {
            index: "/jobs",
            create: "/jobs/create",
            companies: {
                details: "/jobs/companies/:companyId"
            }
        },
        kanban: "/kanban",
        logistics: {
            index: "/logistics",
            fleet: "/logistics/fleet"
        },
        mail: "/mail",
        social: {
            index: "/social",
            profile: "/social/profile",
            feed: "/social/feed"
        }
    },
    components: {
        index: "/components",
        dataDisplay: {
            detailLists: "/components/data-display/detail-lists",
            tables: "/components/data-display/tables",
            quickStats: "/components/data-display/quick-stats"
        },
        lists: {
            groupedLists: "/components/lists/grouped-lists",
            gridLists: "/components/lists/grid-lists"
        },
        forms: "/components/forms",
        modals: "/components/modals",
        charts: "/components/charts",
        buttons: "/components/buttons",
        typography: "/components/typography",
        colors: "/components/colors",
        inputs: "/components/inputs"
    },
    docs: "https://support.futuregolf.com.au",
    notAuthorized: "/errors/401",
    notFound: "/errors/404",
    serverError: "/errors/500"
};


/***/ }),

/***/ 16638:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ reducer),
/* harmony export */   "t": () => (/* binding */ slice)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(610668);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var src_utils_obj_from_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(701726);


const initialState = {
    contacts: {
        byId: {},
        allIds: []
    },
    currentThreadId: undefined,
    threads: {
        byId: {},
        allIds: []
    }
};
const reducers = {
    getContacts (state, action) {
        const contacts = action.payload;
        state.contacts.byId = (0,src_utils_obj_from_array__WEBPACK_IMPORTED_MODULE_0__/* .objFromArray */ .y)(contacts);
        state.contacts.allIds = Object.keys(state.contacts.byId);
    },
    getThreads (state, action) {
        const threads = action.payload;
        state.threads.byId = (0,src_utils_obj_from_array__WEBPACK_IMPORTED_MODULE_0__/* .objFromArray */ .y)(threads);
        state.threads.allIds = Object.keys(state.threads.byId);
    },
    getThread (state, action) {
        const thread = action.payload;
        if (thread) {
            state.threads.byId[thread.id] = thread;
            if (!state.threads.allIds.includes(thread.id)) {
                state.threads.allIds.unshift(thread.id);
            }
        }
    },
    markThreadAsSeen (state, action) {
        const threadId = action.payload;
        const thread = state.threads.byId[threadId];
        if (thread) {
            thread.unreadCount = 0;
        }
    },
    setCurrentThread (state, action) {
        state.currentThreadId = action.payload;
    },
    addMessage (state, action) {
        const { threadId , message  } = action.payload;
        const thread = state.threads.byId[threadId];
        if (thread) {
            thread.messages.push(message);
        }
    }
};
const slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
    name: "chat",
    initialState,
    reducers
});
const { reducer  } = slice;


/***/ }),

/***/ 424198:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ reducer),
/* harmony export */   "t": () => (/* binding */ slice)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(610668);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var src_utils_obj_from_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(701726);


const initialState = {
    isLoaded: false,
    columns: {
        byId: {},
        allIds: []
    },
    tasks: {
        byId: {},
        allIds: []
    },
    members: {
        byId: {},
        allIds: []
    }
};
const reducers = {
    getBoard (state, action) {
        const board = action.payload;
        state.columns.byId = (0,src_utils_obj_from_array__WEBPACK_IMPORTED_MODULE_0__/* .objFromArray */ .y)(board.columns);
        state.columns.allIds = Object.keys(state.columns.byId);
        state.tasks.byId = (0,src_utils_obj_from_array__WEBPACK_IMPORTED_MODULE_0__/* .objFromArray */ .y)(board.tasks);
        state.tasks.allIds = Object.keys(state.tasks.byId);
        state.members.byId = (0,src_utils_obj_from_array__WEBPACK_IMPORTED_MODULE_0__/* .objFromArray */ .y)(board.members);
        state.members.allIds = Object.keys(state.members.byId);
        state.isLoaded = true;
    },
    createColumn (state, action) {
        const column = action.payload;
        state.columns.byId[column.id] = column;
        state.columns.allIds.push(column.id);
    },
    updateColumn (state, action) {
        const column = action.payload;
        state.columns.byId[column.id] = column;
    },
    clearColumn (state, action) {
        const columnId = action.payload;
        // taskIds to be removed
        const { taskIds  } = state.columns.byId[columnId];
        // Delete the taskIds references from the column
        state.columns.byId[columnId].taskIds = [];
        // Delete the tasks from state
        taskIds.forEach((taskId)=>{
            delete state.tasks.byId[taskId];
        });
        state.tasks.allIds = state.tasks.allIds.filter((taskId)=>taskIds.includes(taskId));
    },
    deleteColumn (state, action) {
        const columnId = action.payload;
        delete state.columns.byId[columnId];
        state.columns.allIds = state.columns.allIds.filter((_columnId)=>_columnId !== columnId);
    },
    createTask (state, action) {
        const task = action.payload;
        state.tasks.byId[task.id] = task;
        state.tasks.allIds.push(task.id);
        // Add the taskId reference to the column
        state.columns.byId[task.columnId].taskIds.push(task.id);
    },
    updateTask (state, action) {
        const task = action.payload;
        Object.assign(state.tasks.byId[task.id], task);
    },
    moveTask (state, action) {
        const { taskId , position , columnId  } = action.payload;
        const sourceColumnId = state.tasks.byId[taskId].columnId;
        // Remove task from source column
        state.columns.byId[sourceColumnId].taskIds = state.columns.byId[sourceColumnId].taskIds.filter((_taskId)=>_taskId !== taskId);
        // If columnId exists, it means that we have to add the task to the new column
        if (columnId) {
            // Change task's columnId reference
            state.tasks.byId[taskId].columnId = columnId;
            // Push the taskId to the specified position
            state.columns.byId[columnId].taskIds.splice(position, 0, taskId);
        } else {
            // Push the taskId to the specified position
            state.columns.byId[sourceColumnId].taskIds.splice(position, 0, taskId);
        }
    },
    deleteTask (state, action) {
        const taskId = action.payload;
        const { columnId  } = state.tasks.byId[taskId];
        delete state.tasks.byId[taskId];
        state.tasks.allIds = state.tasks.allIds.filter((_taskId)=>_taskId !== taskId);
        state.columns.byId[columnId].taskIds = state.columns.byId[columnId].taskIds.filter((_taskId)=>_taskId !== taskId);
    },
    addComment (state, action) {
        const { taskId , comment  } = action.payload;
        const task = state.tasks.byId[taskId];
        task.comments.push(comment);
    },
    addChecklist (state, action) {
        const { taskId , checklist  } = action.payload;
        const task = state.tasks.byId[taskId];
        task.checklists.push(checklist);
    },
    updateChecklist (state, action) {
        const { taskId , checklist  } = action.payload;
        const task = state.tasks.byId[taskId];
        task.checklists = task.checklists.map((_checklist)=>{
            if (_checklist.id === checklist.id) {
                return checklist;
            }
            return _checklist;
        });
    },
    deleteChecklist (state, action) {
        const { taskId , checklistId  } = action.payload;
        const task = state.tasks.byId[taskId];
        task.checklists = task.checklists.filter((checklist)=>checklist.id !== checklistId);
    },
    addCheckItem (state, action) {
        const { taskId , checklistId , checkItem  } = action.payload;
        const task = state.tasks.byId[taskId];
        const checklist = task.checklists.find((checklist)=>checklist.id === checklistId);
        if (!checklist) {
            return;
        }
        checklist.checkItems.push(checkItem);
    },
    updateCheckItem (state, action) {
        const { taskId , checklistId , checkItem  } = action.payload;
        const task = state.tasks.byId[taskId];
        const checklist = task.checklists.find((checklist)=>checklist.id === checklistId);
        if (!checklist) {
            return;
        }
        checklist.checkItems = checklist.checkItems.map((_checkItem)=>{
            if (_checkItem.id === checkItem.id) {
                return checkItem;
            }
            return _checkItem;
        });
    },
    deleteCheckItem (state, action) {
        const { taskId , checklistId , checkItemId  } = action.payload;
        const task = state.tasks.byId[taskId];
        const checklist = task.checklists.find((_checklist)=>_checklist.id === checklistId);
        if (!checklist) {
            return;
        }
        checklist.checkItems = checklist.checkItems.filter((checkItem)=>checkItem.id !== checkItemId);
    }
};
const slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
    name: "kanban",
    initialState,
    reducers
});
const { reducer  } = slice;


/***/ }),

/***/ 162154:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ reducer),
/* harmony export */   "t": () => (/* binding */ slice)
/* harmony export */ });
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(610668);
/* harmony import */ var _reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var src_utils_obj_from_array__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(701726);


const initialState = {
    emails: {
        byId: {},
        allIds: []
    },
    labels: []
};
const reducers = {
    getLabels (state, action) {
        state.labels = action.payload;
    },
    getEmails (state, action) {
        const emails = action.payload;
        state.emails.byId = (0,src_utils_obj_from_array__WEBPACK_IMPORTED_MODULE_0__/* .objFromArray */ .y)(emails);
        state.emails.allIds = Object.keys(state.emails.byId);
    },
    getEmail (state, action) {
        const email = action.payload;
        state.emails.byId[email.id] = email;
        if (!state.emails.allIds.includes(email.id)) {
            state.emails.allIds.push(email.id);
        }
    }
};
const slice = (0,_reduxjs_toolkit__WEBPACK_IMPORTED_MODULE_1__.createSlice)({
    name: "mail",
    initialState,
    reducers
});
const { reducer  } = slice;


/***/ }),

/***/ 754835:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "h": () => (/* binding */ store),
  "I0": () => (/* binding */ useDispatch),
  "v9": () => (/* binding */ useSelector)
});

// EXTERNAL MODULE: ./node_modules/react-redux/lib/index.js
var lib = __webpack_require__(801560);
// EXTERNAL MODULE: ./node_modules/@reduxjs/toolkit/dist/redux-toolkit.cjs.production.min.js
var redux_toolkit_cjs_production_min = __webpack_require__(610668);
// EXTERNAL MODULE: ./src/config.ts
var config = __webpack_require__(198103);
// EXTERNAL MODULE: ./src/slices/chat.ts
var chat = __webpack_require__(16638);
// EXTERNAL MODULE: ./src/slices/kanban.ts
var kanban = __webpack_require__(424198);
// EXTERNAL MODULE: ./src/slices/mail.ts
var mail = __webpack_require__(162154);
;// CONCATENATED MODULE: ./src/slices/voucher.ts

const initialState = {
    vouchers: []
};
const reducers = {
    getVouchers (state, action) {
        state.vouchers = action.payload;
    },
    updateEvent (state, action) {
        const event = action.payload;
        state.vouchers = state.vouchers.map((_event)=>{
            if (_event.id === event.id) {
                return event;
            }
            return _event;
        });
    }
};
const slice = (0,redux_toolkit_cjs_production_min.createSlice)({
    name: "vouchers",
    initialState,
    reducers
});
const { reducer  } = slice;

;// CONCATENATED MODULE: ./src/store/root-reducer.ts





const rootReducer = (0,redux_toolkit_cjs_production_min.combineReducers)({
    chat: chat/* reducer */.I,
    kanban: kanban/* reducer */.I,
    mail: mail/* reducer */.I,
    voucher: reducer
});

;// CONCATENATED MODULE: ./src/store/index.ts




const store = (0,redux_toolkit_cjs_production_min.configureStore)({
    reducer: rootReducer,
    devTools: config/* enableDevTools */.HR
});
const useSelector = lib.useSelector;
const useDispatch = ()=>(0,lib.useDispatch)();


/***/ }),

/***/ 399807:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kp": () => (/* binding */ warning),
/* harmony export */   "QN": () => (/* binding */ indigo),
/* harmony export */   "Vp": () => (/* binding */ success),
/* harmony export */   "ek": () => (/* binding */ green),
/* harmony export */   "iN": () => (/* binding */ blue),
/* harmony export */   "jk": () => (/* binding */ purple),
/* harmony export */   "n$": () => (/* binding */ neutral),
/* harmony export */   "um": () => (/* binding */ info),
/* harmony export */   "vU": () => (/* binding */ error)
/* harmony export */ });
/* harmony import */ var _mui_system_colorManipulator__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(229551);

const withAlphas = (color)=>{
    return {
        ...color,
        alpha4: (0,_mui_system_colorManipulator__WEBPACK_IMPORTED_MODULE_0__.alpha)(color.main, 0.04),
        alpha8: (0,_mui_system_colorManipulator__WEBPACK_IMPORTED_MODULE_0__.alpha)(color.main, 0.08),
        alpha12: (0,_mui_system_colorManipulator__WEBPACK_IMPORTED_MODULE_0__.alpha)(color.main, 0.12),
        alpha30: (0,_mui_system_colorManipulator__WEBPACK_IMPORTED_MODULE_0__.alpha)(color.main, 0.3),
        alpha50: (0,_mui_system_colorManipulator__WEBPACK_IMPORTED_MODULE_0__.alpha)(color.main, 0.5)
    };
};
const neutral = {
    50: "#F8F9FA",
    100: "#F3F4F6",
    200: "#E5E7EB",
    300: "#D2D6DB",
    400: "#9DA4AE",
    500: "#6C737F",
    600: "#4D5761",
    700: "#2F3746",
    800: "#1C2536",
    900: "#111927"
};
const blue = withAlphas({
    lightest: "#F5F8FF",
    light: "#EBEFFF",
    main: "#2970FF",
    dark: "#006caa",
    darkest: "#00359E",
    contrastText: "#FFFFFF"
});
const green = withAlphas({
    lightest: "#F6FEF9",
    light: "#EDFCF2",
    main: "#16B364",
    dark: "#087443",
    darkest: "#084C2E",
    contrastText: "#FFFFFF"
});
const indigo = withAlphas({
    lightest: "#F5F7FF",
    light: "#EBEEFE",
    main: "#000000",
    dark: "#4338CA",
    darkest: "#312E81",
    contrastText: "#FFFFFF"
});
const purple = withAlphas({
    lightest: "#F9F5FF",
    light: "#F4EBFF",
    main: "#9E77ED",
    dark: "#6941C6",
    darkest: "#42307D",
    contrastText: "#FFFFFF"
});
const success = withAlphas({
    lightest: "#F0FDF9",
    light: "#3FC79A",
    main: "#10B981",
    dark: "#0B815A",
    darkest: "#134E48",
    contrastText: "#FFFFFF"
});
const info = withAlphas({
    lightest: "#ECFDFF",
    light: "#CFF9FE",
    main: "#06AED4",
    dark: "#0E7090",
    darkest: "#164C63",
    contrastText: "#FFFFFF"
});
const warning = withAlphas({
    lightest: "#FFFAEB",
    light: "#FEF0C7",
    main: "#F79009",
    dark: "#B54708",
    darkest: "#7A2E0E",
    contrastText: "#FFFFFF"
});
const error = withAlphas({
    lightest: "#FEF3F2",
    light: "#FEE4E2",
    main: "#F04438",
    dark: "#B42318",
    darkest: "#7A271A",
    contrastText: "#FFFFFF"
});


/***/ }),

/***/ 188053:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "j": () => (/* binding */ createTheme)
});

// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
;// CONCATENATED MODULE: ./src/theme/base/create-typography.ts
const createTypography = ()=>{
    return {
        fontFamily: '"Inter", -apple-system, BlinkMacSystemFont, "Segoe UI", Helvetica, Arial, sans-serif, "Apple Color Emoji", "Segoe UI Emoji"',
        body1: {
            fontSize: "1rem",
            fontWeight: 400,
            lineHeight: 1.5
        },
        body2: {
            fontSize: "0.875rem",
            fontWeight: 400,
            lineHeight: 1.57
        },
        button: {
            fontWeight: 600
        },
        caption: {
            fontSize: "0.75rem",
            fontWeight: 500,
            lineHeight: 1.66
        },
        subtitle1: {
            fontSize: "1rem",
            fontWeight: 500,
            lineHeight: 1.57
        },
        subtitle2: {
            fontSize: "0.875rem",
            fontWeight: 500,
            lineHeight: 1.57
        },
        overline: {
            fontSize: "0.75rem",
            fontWeight: 600,
            letterSpacing: "0.5px",
            lineHeight: 2.5,
            textTransform: "uppercase"
        },
        h1: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            fontSize: "3.5rem",
            lineHeight: 1.2
        },
        h2: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            fontSize: "3rem",
            lineHeight: 1.2
        },
        h3: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            fontSize: "2.25rem",
            lineHeight: 1.2
        },
        h4: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            fontSize: "2rem",
            lineHeight: 1.2
        },
        h5: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            fontSize: "1.5rem",
            lineHeight: 1.2
        },
        h6: {
            fontFamily: "'Plus Jakarta Sans', sans-serif",
            fontWeight: 700,
            fontSize: "1.125rem",
            lineHeight: 1.2
        }
    };
};

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/InputLabel/index.js
var InputLabel = __webpack_require__(940575);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableCell/index.js
var TableCell = __webpack_require__(340514);
;// CONCATENATED MODULE: ./src/theme/base/create-components.tsx




// Used only to create transitions
const muiTheme = (0,styles.createTheme)();
const createComponents = ()=>{
    return {
        MuiAvatar: {
            styleOverrides: {
                root: {
                    fontSize: 14,
                    fontWeight: 600,
                    letterSpacing: 0
                }
            }
        },
        MuiButton: {
            styleOverrides: {
                root: {
                    borderRadius: "12px",
                    textTransform: "none"
                },
                sizeSmall: {
                    padding: "6px 16px"
                },
                sizeMedium: {
                    padding: "8px 20px"
                },
                sizeLarge: {
                    padding: "11px 24px"
                },
                textSizeSmall: {
                    padding: "7px 12px"
                },
                textSizeMedium: {
                    padding: "9px 16px"
                },
                textSizeLarge: {
                    padding: "12px 16px"
                }
            }
        },
        MuiCard: {
            styleOverrides: {
                root: {
                    borderRadius: 20
                }
            }
        },
        MuiCardContent: {
            styleOverrides: {
                root: {
                    padding: "32px 24px",
                    "&:last-child": {
                        paddingBottom: "32px"
                    }
                }
            }
        },
        MuiCardHeader: {
            defaultProps: {
                titleTypographyProps: {
                    variant: "h6"
                },
                subheaderTypographyProps: {
                    variant: "body2"
                }
            },
            styleOverrides: {
                root: {
                    padding: "32px 24px 16px"
                }
            }
        },
        MuiCheckbox: {
            defaultProps: {
                checkedIcon: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                    fill: "none",
                    height: "24",
                    viewBox: "0 0 24 24",
                    width: "24",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        clipRule: "evenodd",
                        d: "M9 3.5C5.68629 3.5 3 6.18629 3 9.5V15.5C3 18.8137 5.68629 21.5 9 21.5H15C18.3137 21.5 21 18.8137 21 15.5V9.5C21 6.18629 18.3137 3.5 15 3.5H9ZM16.7179 10.1961C17.1024 9.79966 17.0926 9.16657 16.6961 8.7821C16.2997 8.39763 15.6666 8.40737 15.2821 8.80385L10.6667 13.5635L8.7179 11.5539C8.33343 11.1574 7.70034 11.1476 7.30385 11.5321C6.90737 11.9166 6.89763 12.5497 7.2821 12.9461L9.94877 15.6961C10.1371 15.8904 10.3961 16 10.6667 16C10.9372 16 11.1962 15.8904 11.3846 15.6961L16.7179 10.1961Z",
                        fill: "currentColor",
                        fillRule: "evenodd"
                    })
                }),
                color: "primary",
                icon: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                    fill: "none",
                    height: "24",
                    viewBox: "0 0 24 24",
                    width: "24",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        height: "16",
                        rx: "5",
                        stroke: "currentColor",
                        strokeWidth: "2",
                        width: "16",
                        x: "4",
                        y: "4.5"
                    })
                }),
                indeterminateIcon: /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                    fill: "none",
                    height: "24",
                    viewBox: "0 0 24 24",
                    width: "24",
                    xmlns: "http://www.w3.org/2000/svg",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        clipRule: "evenodd",
                        d: "M9 5.5H15C17.2091 5.5 19 7.29086 19 9.5V15.5C19 17.7091 17.2091 19.5 15 19.5H9C6.79086 19.5 5 17.7091 5 15.5V9.5C5 7.29086 6.79086 5.5 9 5.5ZM3 9.5C3 6.18629 5.68629 3.5 9 3.5H15C18.3137 3.5 21 6.18629 21 9.5V15.5C21 18.8137 18.3137 21.5 15 21.5H9C5.68629 21.5 3 18.8137 3 15.5V9.5ZM8 11.5C7.44772 11.5 7 11.9477 7 12.5C7 13.0523 7.44772 13.5 8 13.5H16C16.5523 13.5 17 13.0523 17 12.5C17 11.9477 16.5523 11.5 16 11.5H8Z",
                        fill: "currentColor",
                        fillRule: "evenodd"
                    })
                })
            }
        },
        MuiChip: {
            styleOverrides: {
                root: {
                    fontWeight: 500
                }
            }
        },
        MuiCssBaseline: {
            styleOverrides: {
                "*": {
                    boxSizing: "border-box"
                },
                html: {
                    MozOsxFontSmoothing: "grayscale",
                    WebkitFontSmoothing: "antialiased",
                    display: "flex",
                    flexDirection: "column",
                    minHeight: "100%",
                    width: "100%"
                },
                body: {
                    display: "flex",
                    flex: "1 1 auto",
                    flexDirection: "column",
                    minHeight: "100%",
                    width: "100%"
                },
                "#root, #__next": {
                    display: "flex",
                    flex: "1 1 auto",
                    flexDirection: "column",
                    height: "100%",
                    width: "100%"
                },
                "#nprogress": {
                    pointerEvents: "none"
                },
                "#nprogress .bar": {
                    height: 3,
                    left: 0,
                    position: "fixed",
                    top: 0,
                    width: "100%",
                    zIndex: 2000
                }
            }
        },
        MuiIconButton: {
            styleOverrides: {
                sizeSmall: {
                    padding: 4
                }
            }
        },
        MuiInputBase: {
            styleOverrides: {
                input: {
                    "&::placeholder": {
                        opacity: 1
                    }
                }
            }
        },
        MuiInput: {
            styleOverrides: {
                input: {
                    fontSize: 14,
                    fontWeight: 500,
                    lineHeight: "24px"
                }
            }
        },
        MuiFilledInput: {
            styleOverrides: {
                root: {
                    backgroundColor: "transparent",
                    borderRadius: 8,
                    borderStyle: "solid",
                    borderWidth: 1,
                    overflow: "hidden",
                    transition: muiTheme.transitions.create([
                        "border-color",
                        "box-shadow"
                    ]),
                    "&:before": {
                        display: "none"
                    },
                    "&:after": {
                        display: "none"
                    }
                },
                input: {
                    fontSize: 14,
                    fontWeight: 500,
                    lineHeight: "24px"
                }
            }
        },
        MuiOutlinedInput: {
            styleOverrides: {
                input: {
                    fontSize: 14,
                    fontWeight: 500,
                    lineHeight: "24px"
                },
                notchedOutline: {
                    transition: muiTheme.transitions.create([
                        "border-color",
                        "box-shadow"
                    ])
                }
            }
        },
        MuiFormLabel: {
            styleOverrides: {
                root: {
                    fontSize: 14,
                    fontWeight: 500,
                    [`&.${InputLabel.inputLabelClasses.filled}`]: {
                        transform: "translate(12px, 18px) scale(1)"
                    },
                    [`&.${InputLabel.inputLabelClasses.shrink}`]: {
                        [`&.${InputLabel.inputLabelClasses.standard}`]: {
                            transform: "translate(0, -1.5px) scale(0.85)"
                        },
                        [`&.${InputLabel.inputLabelClasses.filled}`]: {
                            transform: "translate(12px, 6px) scale(0.85)"
                        },
                        [`&.${InputLabel.inputLabelClasses.outlined}`]: {
                            transform: "translate(14px, -9px) scale(0.85)"
                        }
                    }
                }
            }
        },
        MuiLinearProgress: {
            styleOverrides: {
                root: {
                    borderRadius: 3,
                    overflow: "hidden"
                }
            }
        },
        MuiLink: {
            defaultProps: {
                underline: "hover"
            }
        },
        MuiListItemIcon: {
            styleOverrides: {
                root: {
                    marginRight: "16px",
                    minWidth: "unset"
                }
            }
        },
        MuiPaper: {
            styleOverrides: {
                root: {
                    backgroundImage: "none"
                }
            }
        },
        MuiPopover: {
            defaultProps: {
                elevation: 16
            }
        },
        MuiRadio: {
            defaultProps: {
                color: "primary"
            }
        },
        MuiSwitch: {
            defaultProps: {
                color: "primary"
            }
        },
        MuiTab: {
            styleOverrides: {
                root: {
                    fontSize: 14,
                    fontWeight: 500,
                    lineHeight: 1.71,
                    minWidth: "auto",
                    paddingLeft: 0,
                    paddingRight: 0,
                    textTransform: "none",
                    "& + &": {
                        marginLeft: 24
                    }
                }
            }
        },
        MuiTableCell: {
            styleOverrides: {
                root: {
                    padding: "15px 16px"
                }
            }
        },
        MuiTableHead: {
            styleOverrides: {
                root: {
                    borderBottom: "none",
                    [`& .${TableCell.tableCellClasses.root}`]: {
                        borderBottom: "none",
                        fontSize: 12,
                        fontWeight: 600,
                        lineHeight: 1,
                        letterSpacing: 0.5,
                        textTransform: "uppercase"
                    },
                    [`& .${TableCell.tableCellClasses.paddingCheckbox}`]: {
                        paddingTop: 4,
                        paddingBottom: 4
                    }
                }
            }
        },
        MuiTextField: {
            defaultProps: {
                variant: "filled"
            }
        }
    };
};

;// CONCATENATED MODULE: ./src/theme/base/create-options.ts


// Here we do not modify the "palette" and "shadows" because "light" and "dark" mode
// may have different values.
const createOptions = (config)=>{
    const { direction ="ltr"  } = config;
    return {
        breakpoints: {
            values: {
                xs: 0,
                sm: 600,
                md: 900,
                lg: 1200,
                xl: 1440
            }
        },
        components: createComponents(),
        direction,
        shape: {
            borderRadius: 8
        },
        typography: createTypography()
    };
};

// EXTERNAL MODULE: ./node_modules/@mui/system/colorManipulator.js
var colorManipulator = __webpack_require__(229551);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Backdrop/index.js
var Backdrop = __webpack_require__(62788);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/FilledInput/index.js
var FilledInput = __webpack_require__(38634);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/OutlinedInput/index.js
var OutlinedInput = __webpack_require__(877829);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Paper/index.js
var Paper = __webpack_require__(427561);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/colors/index.js
var colors = __webpack_require__(983036);
;// CONCATENATED MODULE: ./src/theme/dark/create-components.ts







const create_components_createComponents = ({ palette  })=>{
    return {
        MuiAvatar: {
            styleOverrides: {
                root: {
                    backgroundColor: palette.neutral[300],
                    color: colors.common.black
                }
            }
        },
        MuiBackdrop: {
            styleOverrides: {
                root: {
                    [`&:not(.${Backdrop.backdropClasses.invisible})`]: {
                        backgroundColor: (0,colorManipulator.alpha)(colors.common.black, 0.50)
                    }
                }
            }
        },
        MuiCard: {
            styleOverrides: {
                root: {
                    [`&.${Paper.paperClasses.elevation1}`]: {
                        boxShadow: "0px 5px 22px rgba(0, 0, 0, 0.08), 0px 0px 0px 0.5px rgba(0, 0, 0, 0.06)"
                    }
                }
            }
        },
        MuiChip: {
            styleOverrides: {
                icon: {
                    color: palette.action.active
                },
                root: {
                    borderColor: palette.neutral[700]
                }
            }
        },
        MuiCssBaseline: {
            styleOverrides: {
                "#nprogress .bar": {
                    backgroundColor: palette.primary.main
                },
                ".slick-dots li button": {
                    "&:before": {
                        fontSize: 10,
                        color: palette.primary.main
                    }
                },
                ".slick-dots li.slick-active button": {
                    "&:before": {
                        color: palette.primary.main
                    }
                }
            }
        },
        MuiInputBase: {
            styleOverrides: {
                input: {
                    "&::placeholder": {
                        color: palette.text.secondary
                    }
                }
            }
        },
        MuiFilledInput: {
            styleOverrides: {
                root: {
                    borderColor: palette.divider,
                    "&:hover": {
                        backgroundColor: palette.action.hover
                    },
                    [`&.${FilledInput.filledInputClasses.disabled}`]: {
                        backgroundColor: "transparent"
                    },
                    [`&.${FilledInput.filledInputClasses.focused}`]: {
                        backgroundColor: "transparent",
                        borderColor: palette.primary.main,
                        boxShadow: `${palette.primary.main} 0 0 0 2px`
                    },
                    [`&.${FilledInput.filledInputClasses.error}`]: {
                        borderColor: palette.error.main,
                        boxShadow: `${palette.error.main} 0 0 0 2px`
                    }
                }
            }
        },
        MuiOutlinedInput: {
            styleOverrides: {
                root: {
                    "&:hover": {
                        backgroundColor: palette.action.hover,
                        [`& .${OutlinedInput.outlinedInputClasses.notchedOutline}`]: {
                            borderColor: palette.divider
                        }
                    },
                    [`&.${OutlinedInput.outlinedInputClasses.focused}`]: {
                        backgroundColor: "transparent",
                        [`& .${OutlinedInput.outlinedInputClasses.notchedOutline}`]: {
                            borderColor: palette.primary.main,
                            boxShadow: `${palette.primary.main} 0 0 0 2px`
                        }
                    },
                    [`&.${FilledInput.filledInputClasses.error}`]: {
                        [`& .${OutlinedInput.outlinedInputClasses.notchedOutline}`]: {
                            borderColor: palette.error.main,
                            boxShadow: `${palette.error.main} 0 0 0 2px`
                        }
                    }
                },
                notchedOutline: {
                    borderColor: palette.divider
                }
            }
        },
        MuiSwitch: {
            styleOverrides: {
                switchBase: {
                    color: palette.neutral[500]
                },
                track: {
                    backgroundColor: palette.neutral[400],
                    opacity: 1
                }
            }
        },
        MuiTableCell: {
            styleOverrides: {
                root: {
                    borderBottomColor: palette.divider
                }
            }
        },
        MuiTableHead: {
            styleOverrides: {
                root: {
                    [`& .${TableCell.tableCellClasses.root}`]: {
                        backgroundColor: palette.neutral[800],
                        color: palette.neutral[400]
                    }
                }
            }
        },
        // @ts-ignore
        MuiTimelineConnector: {
            styleOverrides: {
                root: {
                    backgroundColor: palette.divider
                }
            }
        },
        MuiTooltip: {
            styleOverrides: {
                tooltip: {
                    backdropFilter: "blur(6px)",
                    background: (0,colorManipulator.alpha)(palette.neutral[900], 0.8)
                }
            }
        }
    };
};

// EXTERNAL MODULE: ./src/theme/colors.ts
var theme_colors = __webpack_require__(399807);
;// CONCATENATED MODULE: ./src/theme/utils.ts

const getPrimary = (preset)=>{
    switch(preset){
        case "blue":
            return theme_colors/* blue */.iN;
        case "green":
            return theme_colors/* green */.ek;
        case "indigo":
            return theme_colors/* indigo */.QN;
        case "purple":
            return theme_colors/* purple */.jk;
        default:
            console.error('Invalid color preset, accepted values: "blue", "green", "indigo" or "purple"".');
            return theme_colors/* blue */.iN;
    }
};

;// CONCATENATED MODULE: ./src/theme/dark/create-palette.ts



const createPalette = (config)=>{
    const { colorPreset , contrast  } = config;
    return {
        action: {
            active: theme_colors/* neutral.500 */.n$[500],
            disabled: (0,colorManipulator.alpha)(theme_colors/* neutral.100 */.n$[100], 0.38),
            disabledBackground: (0,colorManipulator.alpha)(theme_colors/* neutral.100 */.n$[100], 0.12),
            focus: (0,colorManipulator.alpha)(theme_colors/* neutral.100 */.n$[100], 0.16),
            hover: (0,colorManipulator.alpha)(theme_colors/* neutral.100 */.n$[100], 0.04),
            selected: (0,colorManipulator.alpha)(theme_colors/* neutral.100 */.n$[100], 0.12)
        },
        background: {
            default: contrast === "high" ? "#0B0F19" : "#0E1320",
            paper: theme_colors/* neutral.900 */.n$[900]
        },
        divider: "#2D3748",
        error: theme_colors/* error */.vU,
        info: theme_colors/* info */.um,
        mode: "dark",
        neutral: theme_colors/* neutral */.n$,
        primary: getPrimary(colorPreset),
        success: theme_colors/* success */.Vp,
        text: {
            primary: "#EDF2F7",
            secondary: "#A0AEC0",
            disabled: "rgba(255, 255, 255, 0.48)"
        },
        warning: theme_colors/* warning */.Kp
    };
};

;// CONCATENATED MODULE: ./src/theme/dark/create-shadows.ts
const createShadows = ()=>{
    return [
        "none",
        "0px 1px 2px rgba(0, 0, 0, 0.24)",
        "0px 1px 2px rgba(0, 0, 0, 0.24)",
        "0px 1px 4px rgba(0, 0, 0, 0.24)",
        "0px 1px 5px rgba(0, 0, 0, 0.24)",
        "0px 1px 6px rgba(0, 0, 0, 0.24)",
        "0px 2px 6px rgba(0, 0, 0, 0.24)",
        "0px 3px 6px rgba(0, 0, 0, 0.24)",
        "0px 4px 6px rgba(0, 0, 0, 0.24)",
        "0px 5px 12px rgba(0, 0, 0, 0.24)",
        "0px 5px 14px rgba(0, 0, 0, 0.24)",
        "0px 5px 15px rgba(0, 0, 0, 0.24)",
        "0px 6px 15px rgba(0, 0, 0, 0.24)",
        "0px 7px 15px rgba(0, 0, 0, 0.24)",
        "0px 8px 15px rgba(0, 0, 0, 0.24)",
        "0px 9px 15px rgba(0, 0, 0, 0.24)",
        "0px 10px 15px rgba(0, 0, 0, 0.24)",
        "0px 12px 22px rgba(0, 0, 0, 0.24)",
        "0px 13px 22px rgba(0, 0, 0, 0.24)",
        "0px 14px 24px rgba(0, 0, 0, 0.24)",
        "0px 20px 25px rgba(0, 0, 0, 0.24)",
        "0px 25px 50px rgba(0, 0, 0, 0.24)",
        "0px 25px 50px rgba(0, 0, 0, 0.24)",
        "0px 25px 50px rgba(0, 0, 0, 0.24)",
        "0px 25px 50px rgba(0, 0, 0, 0.24)"
    ];
};

;// CONCATENATED MODULE: ./src/theme/dark/create-options.ts



const create_options_createOptions = (config)=>{
    const { colorPreset , contrast  } = config;
    const palette = createPalette({
        colorPreset,
        contrast
    });
    const components = create_components_createComponents({
        palette
    });
    const shadows = createShadows();
    return {
        components,
        palette,
        shadows
    };
};

;// CONCATENATED MODULE: ./src/theme/light/create-components.ts







const light_create_components_createComponents = ({ palette  })=>{
    return {
        MuiAvatar: {
            styleOverrides: {
                root: {
                    backgroundColor: palette.neutral[200],
                    color: colors.common.black
                }
            }
        },
        MuiBackdrop: {
            styleOverrides: {
                root: {
                    [`&:not(.${Backdrop.backdropClasses.invisible})`]: {
                        backgroundColor: (0,colorManipulator.alpha)(palette.neutral[900], 0.75)
                    }
                }
            }
        },
        MuiCard: {
            styleOverrides: {
                root: {
                    [`&.${Paper.paperClasses.elevation1}`]: {
                        boxShadow: "0px 5px 22px rgba(0, 0, 0, 0.04), 0px 0px 0px 0.5px rgba(0, 0, 0, 0.03)"
                    }
                }
            }
        },
        MuiChip: {
            styleOverrides: {
                icon: {
                    color: palette.action.active
                },
                root: {
                    borderColor: palette.neutral[200]
                }
            }
        },
        MuiCssBaseline: {
            styleOverrides: {
                "#nprogress .bar": {
                    backgroundColor: palette.primary.main
                },
                ".slick-dots li button": {
                    "&:before": {
                        fontSize: 10,
                        color: palette.primary.main
                    }
                },
                ".slick-dots li.slick-active button": {
                    "&:before": {
                        color: palette.primary.main
                    }
                }
            }
        },
        MuiInputBase: {
            styleOverrides: {
                input: {
                    "&::placeholder": {
                        color: palette.text.secondary
                    }
                }
            }
        },
        MuiFilledInput: {
            styleOverrides: {
                root: {
                    borderColor: palette.neutral[200],
                    "&:hover": {
                        backgroundColor: palette.action.hover
                    },
                    [`&.${FilledInput.filledInputClasses.disabled}`]: {
                        backgroundColor: "transparent"
                    },
                    [`&.${FilledInput.filledInputClasses.focused}`]: {
                        backgroundColor: "transparent",
                        borderColor: palette.primary.main,
                        boxShadow: `${palette.primary.main} 0 0 0 2px`
                    },
                    [`&.${FilledInput.filledInputClasses.error}`]: {
                        borderColor: palette.error.main,
                        boxShadow: `${palette.error.main} 0 0 0 2px`
                    }
                }
            }
        },
        MuiOutlinedInput: {
            styleOverrides: {
                root: {
                    "&:hover": {
                        backgroundColor: palette.action.hover,
                        [`& .${OutlinedInput.outlinedInputClasses.notchedOutline}`]: {
                            borderColor: palette.neutral[200]
                        }
                    },
                    [`&.${OutlinedInput.outlinedInputClasses.focused}`]: {
                        backgroundColor: "transparent",
                        [`& .${OutlinedInput.outlinedInputClasses.notchedOutline}`]: {
                            borderColor: palette.primary.main,
                            boxShadow: `${palette.primary.main} 0 0 0 2px`
                        }
                    },
                    [`&.${FilledInput.filledInputClasses.error}`]: {
                        [`& .${OutlinedInput.outlinedInputClasses.notchedOutline}`]: {
                            borderColor: palette.error.main,
                            boxShadow: `${palette.error.main} 0 0 0 2px`
                        }
                    }
                },
                notchedOutline: {
                    borderColor: palette.neutral[200]
                }
            }
        },
        MuiSwitch: {
            styleOverrides: {
                switchBase: {
                    color: palette.neutral[500]
                },
                track: {
                    backgroundColor: palette.neutral[400],
                    opacity: 1
                }
            }
        },
        MuiTableCell: {
            styleOverrides: {
                root: {
                    borderBottomColor: palette.divider
                }
            }
        },
        MuiTableHead: {
            styleOverrides: {
                root: {
                    [`& .${TableCell.tableCellClasses.root}`]: {
                        backgroundColor: palette.neutral[50],
                        color: palette.neutral[700]
                    }
                }
            }
        },
        // @ts-ignore
        MuiTimelineConnector: {
            styleOverrides: {
                root: {
                    backgroundColor: palette.divider
                }
            }
        },
        MuiTooltip: {
            styleOverrides: {
                tooltip: {
                    backdropFilter: "blur(6px)",
                    background: (0,colorManipulator.alpha)(palette.neutral[900], 0.8)
                }
            }
        }
    };
};

;// CONCATENATED MODULE: ./src/theme/light/create-palette.ts




const create_palette_createPalette = (config)=>{
    const { colorPreset , contrast  } = config;
    return {
        action: {
            active: theme_colors/* neutral.500 */.n$[500],
            disabled: (0,colorManipulator.alpha)(theme_colors/* neutral.900 */.n$[900], 0.38),
            disabledBackground: (0,colorManipulator.alpha)(theme_colors/* neutral.900 */.n$[900], 0.12),
            focus: (0,colorManipulator.alpha)(theme_colors/* neutral.900 */.n$[900], 0.16),
            hover: (0,colorManipulator.alpha)(theme_colors/* neutral.900 */.n$[900], 0.04),
            selected: (0,colorManipulator.alpha)(theme_colors/* neutral.900 */.n$[900], 0.12)
        },
        background: {
            default: contrast === "high" ? theme_colors/* neutral.50 */.n$[50] : colors.common.white,
            paper: colors.common.white
        },
        divider: "#F2F4F7",
        error: theme_colors/* error */.vU,
        info: theme_colors/* info */.um,
        mode: "light",
        neutral: theme_colors/* neutral */.n$,
        primary: getPrimary(colorPreset),
        success: theme_colors/* success */.Vp,
        text: {
            primary: theme_colors/* neutral.900 */.n$[900],
            secondary: theme_colors/* neutral.500 */.n$[500],
            disabled: (0,colorManipulator.alpha)(theme_colors/* neutral.900 */.n$[900], 0.38)
        },
        warning: theme_colors/* warning */.Kp
    };
};

;// CONCATENATED MODULE: ./src/theme/light/create-shadows.ts
const create_shadows_createShadows = ()=>{
    return [
        "none",
        "0px 1px 2px rgba(0, 0, 0, 0.08)",
        "0px 1px 5px rgba(0, 0, 0, 0.08)",
        "0px 1px 8px rgba(0, 0, 0, 0.08)",
        "0px 1px 10px rgba(0, 0, 0, 0.08)",
        "0px 1px 14px rgba(0, 0, 0, 0.08)",
        "0px 1px 18px rgba(0, 0, 0, 0.08)",
        "0px 2px 16px rgba(0, 0, 0, 0.08)",
        "0px 3px 14px rgba(0, 0, 0, 0.08)",
        "0px 3px 16px rgba(0, 0, 0, 0.08)",
        "0px 4px 18px rgba(0, 0, 0, 0.08)",
        "0px 4px 20px rgba(0, 0, 0, 0.08)",
        "0px 5px 22px rgba(0, 0, 0, 0.08)",
        "0px 5px 24px rgba(0, 0, 0, 0.08)",
        "0px 5px 26px rgba(0, 0, 0, 0.08)",
        "0px 6px 28px rgba(0, 0, 0, 0.08)",
        "0px 6px 30px rgba(0, 0, 0, 0.08)",
        "0px 6px 32px rgba(0, 0, 0, 0.08)",
        "0px 7px 34px rgba(0, 0, 0, 0.08)",
        "0px 7px 36px rgba(0, 0, 0, 0.08)",
        "0px 8px 38px rgba(0, 0, 0, 0.08)",
        "0px 8px 40px rgba(0, 0, 0, 0.08)",
        "0px 8px 42px rgba(0, 0, 0, 0.08)",
        "0px 9px 44px rgba(0, 0, 0, 0.08)",
        "0px 9px 46px rgba(0, 0, 0, 0.08)"
    ];
};

;// CONCATENATED MODULE: ./src/theme/light/create-options.ts



const light_create_options_createOptions = ({ colorPreset , contrast  })=>{
    const palette = create_palette_createPalette({
        colorPreset,
        contrast
    });
    const components = light_create_components_createComponents({
        palette
    });
    const shadows = create_shadows_createShadows();
    return {
        components,
        palette,
        shadows
    };
};

;// CONCATENATED MODULE: ./src/theme/index.ts




const createTheme = (config)=>{
    let theme = (0,styles.createTheme)(// Base options available for both dark and light palette modes
    createOptions({
        direction: config.direction
    }), // Options based on selected palette mode, color preset and contrast
    config.paletteMode === "dark" ? create_options_createOptions({
        colorPreset: config.colorPreset,
        contrast: config.contrast
    }) : light_create_options_createOptions({
        colorPreset: config.colorPreset,
        contrast: config.contrast
    }));
    if (config.responsiveFontSizes) {
        theme = (0,styles.responsiveFontSizes)(theme);
    }
    return theme;
};


/***/ }),

/***/ 85403:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "M": () => (/* binding */ Issuer)
/* harmony export */ });
var Issuer;
(function(Issuer) {
    Issuer["JWT"] = "JWT";
})(Issuer || (Issuer = {}));


/***/ }),

/***/ 205200:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Jx": () => (/* binding */ decode),
/* harmony export */   "R1": () => (/* binding */ JWT_EXPIRES_IN),
/* harmony export */   "Xx": () => (/* binding */ sign),
/* harmony export */   "rf": () => (/* binding */ JWT_SECRET)
/* harmony export */ });
/* unused harmony export verify */
const JWT_SECRET = "fg-captivity-dictate-promptly";
const JWT_EXPIRES_IN = 3600 * 24 * 2; // 2 days
function bufferToBase64(buffer) {
    let binary = "";
    for(let i = 0; i < buffer.length; i++){
        binary += String.fromCharCode(buffer[i]);
    }
    return Buffer.from(binary, "binary").toString("base64");
}
function base64ToBuffer(base64String) {
    const binaryString = Buffer.from(base64String, "base64").toString("binary");
    const buffer = new Uint8Array(binaryString.length);
    for(let i = 0; i < binaryString.length; i++){
        buffer[i] = binaryString.charCodeAt(i);
    }
    return buffer;
}
const sign = (payload, privateKey, header)=>{
    const now = new Date();
    header.expiresIn = new Date(now.getTime() + header.expiresIn);
    const encoder = new TextEncoder();
    const encodedHeader = encoder.encode(JSON.stringify(header));
    const encodedPayload = encoder.encode(JSON.stringify(payload));
    // Convert the binary data to base64
    const encodedHeaderBase64 = bufferToBase64(encodedHeader);
    const encodedPayloadBase64 = bufferToBase64(encodedPayload);
    const signature = Array.from(encodedPayload).map((item, key)=>String.fromCharCode(item ^ privateKey.charCodeAt(key % privateKey.length))).join("");
    return `${encodedHeaderBase64}.${encodedPayloadBase64}.${Buffer.from(signature, "binary").toString("base64")}`;
};
const decode = (token)=>{
    const [encodedHeader, encodedPayload, signature] = token.split(".");
    if (token !== null && token !== "null") {
        const decoder = new TextDecoder("utf-8");
        const header = JSON.parse(decoder.decode(base64ToBuffer(encodedHeader)));
        const payload = JSON.parse(decoder.decode(base64ToBuffer(encodedPayload)));
        const now = new Date();
        if (now < header.expiresIn) {
            throw new Error("Expired token");
        }
        const verifiedSignature = Buffer.from(Array.from(decoder.decode(base64ToBuffer(encodedPayload))).map((item, key)=>String.fromCharCode(item.charCodeAt(0) ^ JWT_SECRET[key % JWT_SECRET.length].charCodeAt(0))).join(""), "binary").toString("base64");
        if (verifiedSignature !== signature) {
            throw new Error("Invalid signature");
        }
        return payload;
    }
};
const verify = (token, privateKey)=>{
    const [encodedHeader, encodedPayload, signature] = token.split(".");
    const decoder = new TextDecoder("utf-8");
    const header = JSON.parse(decoder.decode(base64ToBuffer(encodedHeader)));
    const payload = JSON.parse(decoder.decode(base64ToBuffer(encodedPayload)));
    const now = new Date();
    if (now < header.expiresIn) {
        throw new Error("Expired token");
    }
    const verifiedSignature = Buffer.from(Array.from(decoder.decode(base64ToBuffer(encodedPayload))).map((item, key)=>String.fromCharCode(item.charCodeAt(0) ^ privateKey.charCodeAt(key % privateKey.length))).join(""), "binary").toString("base64");
    if (verifiedSignature !== signature) {
        throw new Error("Invalid signature");
    }
    return payload;
};


/***/ }),

/***/ 701726:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "y": () => (/* binding */ objFromArray)
/* harmony export */ });
const objFromArray = (arr, key = "id")=>arr.reduce((accumulator, current)=>{
        accumulator[current[key]] = current;
        return accumulator;
    }, {});


/***/ }),

/***/ 948550:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ layout),
  "dynamic": () => (/* binding */ dynamic)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/react-quill/dist/quill.snow.css
var quill_snow = __webpack_require__(410144);
// EXTERNAL MODULE: ./node_modules/react-draft-wysiwyg/dist/react-draft-wysiwyg.css
var react_draft_wysiwyg = __webpack_require__(202591);
// EXTERNAL MODULE: ./node_modules/simplebar-react/dist/simplebar.min.css
var simplebar_min = __webpack_require__(11752);
// EXTERNAL MODULE: ./node_modules/mapbox-gl/dist/mapbox-gl.css
var mapbox_gl = __webpack_require__(844270);
// EXTERNAL MODULE: ./node_modules/next/headers.js
var headers = __webpack_require__(268558);
// EXTERNAL MODULE: ./node_modules/next/dist/build/webpack/loaders/next-flight-loader/module-proxy.js
var module_proxy = __webpack_require__(835985);
;// CONCATENATED MODULE: ./src/layouts/root/root.tsx

const proxy = (0,module_proxy.createProxy)(String.raw`/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/layouts/root/root.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* harmony default export */ const root = (proxy.default);

const e0 = proxy["Layout"];

;// CONCATENATED MODULE: ./src/layouts/root/index.ts


;// CONCATENATED MODULE: ./src/app/layout.tsx
// Remove if react-quill is not used


// Remove if react-draft-wysiwyg is not used

// Remove if simplebar is not used

// Remove if mapbox is not used



// Force-Dynamic is required otherwise all pages are marked as client-side
// due to the usage of the "cookies" function.
const dynamic = "force-dynamic";
const Favicon = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "apple-touch-icon",
                sizes: "180x180",
                href: "/apple-touch-icon.png"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "icon",
                href: "/favicon.ico"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "icon",
                type: "image/png",
                sizes: "32x32",
                href: "/favicon-32x32.png"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "icon",
                type: "image/png",
                sizes: "16x16",
                href: "/favicon-16x16.png"
            })
        ]
    });
const Fonts = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "preconnect",
                href: "https://fonts.googleapis.com"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "preconnect",
                href: "https://fonts.gstatic.com"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "stylesheet",
                href: "https://fonts.googleapis.com/css2?family=Inter:wght@100;200;300;400;500;600;700;800;900&display=swap"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "stylesheet",
                href: "https://fonts.googleapis.com/css2?family=Roboto+Mono:wght@300;400&display=swap"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "stylesheet",
                href: "https://fonts.googleapis.com/css2?family=Plus+Jakarta+Sans:wght@600;700&display=swap"
            })
        ]
    });
const Vendors = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "stylesheet",
                href: "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick.min.css"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("link", {
                rel: "stylesheet",
                href: "https://cdnjs.cloudflare.com/ajax/libs/slick-carousel/1.6.0/slick-theme.min.css"
            })
        ]
    });
const SETTINGS_STORAGE_KEY = "app.settings";
const restoreSettings = ()=>{
    const cookieList = cookies();
    let value;
    if (cookieList.has(SETTINGS_STORAGE_KEY)) {
        try {
            const restored = cookieList.get(SETTINGS_STORAGE_KEY);
            if (restored) {
                value = JSON.parse(restored.value);
            }
        } catch (err) {
            console.error(err);
        // If stored data is not a strigified JSON this will fail,
        // that's why we catch the error
        }
    }
    return value;
};
const Layout = (props)=>{
    const { children  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("html", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("head", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Future Golf"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "viewport",
                        content: "initial-scale=1, width=device-width"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Favicon, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Fonts, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(Vendors, {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("body", {
                children: /*#__PURE__*/ jsx_runtime_.jsx(e0, {
                    children: children
                })
            })
        ]
    });
};
/* harmony default export */ const layout = (Layout);


/***/ }),

/***/ 789499:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx");


/***/ })

};
;