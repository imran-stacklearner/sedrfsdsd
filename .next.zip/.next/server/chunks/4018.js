exports.id = 4018;
exports.ids = [4018];
exports.modules = {

/***/ 895185:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 742008))

/***/ }),

/***/ 742008:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* reexport */ Layout)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/useMediaQuery/index.js
var useMediaQuery = __webpack_require__(975983);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/components/logo.tsx
var logo = __webpack_require__(4286);
// EXTERNAL MODULE: ./src/components/router-link.tsx
var router_link = __webpack_require__(510079);
// EXTERNAL MODULE: ./src/paths.ts
var paths = __webpack_require__(287842);
;// CONCATENATED MODULE: ./src/layouts/marketing/footer.tsx











const sections = [
    {
        title: "Menu",
        items: [
            {
                title: "Browse Components",
                path: paths/* paths.components.index */.H.components.index
            },
            {
                title: "Documentation",
                external: true,
                path: paths/* paths.docs */.H.docs
            }
        ]
    },
    {
        title: "Legal",
        items: [
            {
                title: "Terms & Conditions",
                path: "#"
            },
            {
                title: "License",
                path: "#"
            },
            {
                title: "Contact",
                path: "#"
            }
        ]
    },
    {
        title: "Social",
        items: [
            {
                title: "Instagram",
                path: "#"
            },
            {
                title: "LinkedIn",
                path: "#"
            }
        ]
    }
];
const Footer = (props)=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.50",
            borderTopColor: "divider",
            borderTopStyle: "solid",
            borderTopWidth: 1,
            pb: 6,
            pt: {
                md: 15,
                xs: 6
            }
        },
        ...props,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
            maxWidth: "lg",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                    container: true,
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            sm: 4,
                            md: 3,
                            sx: {
                                order: {
                                    xs: 4,
                                    md: 1
                                }
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                spacing: 1,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                        alignItems: "center",
                                        component: router_link/* RouterLink */.r,
                                        direction: "row",
                                        display: "inline-flex",
                                        href: paths/* paths.index */.H.index,
                                        spacing: 1,
                                        sx: {
                                            textDecoration: "none"
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                sx: {
                                                    display: "inline-flex",
                                                    height: 24,
                                                    width: 24
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(logo/* Logo */.T, {})
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                                sx: {
                                                    color: "text.primary",
                                                    fontFamily: "'Plus Jakarta Sans', sans-serif",
                                                    fontSize: 14,
                                                    fontWeight: 800,
                                                    letterSpacing: "0.3px",
                                                    lineHeight: 2.5,
                                                    "& span": {
                                                        color: "primary.main"
                                                    }
                                                },
                                                children: [
                                                    "Devias Kit ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                        children: "PRO"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "caption",
                                        children: "\xa9 2022 Devias IO"
                                    })
                                ]
                            })
                        }),
                        sections.map((section, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 4,
                                md: 3,
                                sx: {
                                    order: {
                                        md: index + 2,
                                        xs: index + 1
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "overline",
                                        children: section.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                        component: "ul",
                                        spacing: 1,
                                        sx: {
                                            listStyle: "none",
                                            m: 0,
                                            p: 0
                                        },
                                        children: section.items.map((item)=>{
                                            const linkProps = item.path ? item.external ? {
                                                component: "a",
                                                href: item.path,
                                                target: "_blank"
                                            } : {
                                                component: router_link/* RouterLink */.r,
                                                href: item.path
                                            } : {};
                                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                alignItems: "center",
                                                direction: "row",
                                                spacing: 2,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                        sx: {
                                                            backgroundColor: "primary.main",
                                                            height: 2,
                                                            width: 12
                                                        }
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        color: "text.primary",
                                                        variant: "subtitle2",
                                                        ...linkProps,
                                                        children: item.title
                                                    })
                                                ]
                                            }, item.title);
                                        })
                                    })
                                ]
                            }, section.title))
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                    sx: {
                        my: 6
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    variant: "caption",
                    children: "All Rights Reserved."
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@mui/material/node/ButtonBase/index.js
var ButtonBase = __webpack_require__(269860);
var ButtonBase_default = /*#__PURE__*/__webpack_require__.n(ButtonBase);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Drawer/index.js
var Drawer = __webpack_require__(379499);
var Drawer_default = /*#__PURE__*/__webpack_require__.n(Drawer);
// EXTERNAL MODULE: ./src/hooks/use-pathname.ts
var use_pathname = __webpack_require__(903268);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronDown.js
var ChevronDown = __webpack_require__(870261);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronRight.js
var ChevronRight = __webpack_require__(492382);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Collapse/index.js
var Collapse = __webpack_require__(836136);
var Collapse_default = /*#__PURE__*/__webpack_require__.n(Collapse);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
;// CONCATENATED MODULE: ./src/layouts/marketing/side-nav-item.tsx










const SideNavItem = (props)=>{
    const { active , children , disabled , external , open: openProp , path , title  } = props;
    const [open, setOpen] = (0,react_.useState)(!!openProp);
    const handleToggle = (0,react_.useCallback)(()=>{
        setOpen((prevOpen)=>!prevOpen);
    }, []);
    // Branch
    if (children) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
                    disabled: disabled,
                    onClick: handleToggle,
                    sx: {
                        alignItems: "center",
                        borderRadius: 1,
                        display: "flex",
                        justifyContent: "flex-start",
                        px: "12px",
                        py: "6px",
                        textAlign: "left",
                        width: "100%",
                        ...active && {
                            backgroundColor: "action.hover"
                        },
                        "&:hover": {
                            backgroundColor: "action.hover"
                        }
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            component: "span",
                            sx: {
                                flexGrow: 1,
                                fontFamily: (theme)=>theme.typography.fontFamily,
                                fontSize: 14,
                                fontWeight: 500,
                                lineHeight: "24px",
                                whiteSpace: "nowrap",
                                ...active && {
                                    color: "primary.main"
                                }
                            },
                            children: title
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            sx: {
                                color: "action.active",
                                fontSize: 16,
                                ml: 2
                            },
                            children: open ? /*#__PURE__*/ jsx_runtime_.jsx(ChevronDown/* default */.Z, {}) : /*#__PURE__*/ jsx_runtime_.jsx(ChevronRight/* default */.Z, {})
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Collapse_default()), {
                    in: open,
                    sx: {
                        mt: 0.5
                    },
                    children: children
                })
            ]
        });
    }
    // Leaf
    const linkProps = path ? external ? {
        component: "a",
        href: path,
        target: "_blank"
    } : {
        component: router_link/* RouterLink */.r,
        href: path
    } : {};
    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
        children: /*#__PURE__*/ jsx_runtime_.jsx((ButtonBase_default()), {
            sx: {
                alignItems: "center",
                borderRadius: 1,
                display: "flex",
                justifyContent: "flex-start",
                px: "12px",
                py: "6px",
                textAlign: "left",
                width: "100%",
                ...active && {
                    backgroundColor: "action.hover"
                },
                "&:hover": {
                    backgroundColor: "action.hover"
                }
            },
            ...linkProps,
            children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "span",
                sx: {
                    flexGrow: 1,
                    fontFamily: (theme)=>theme.typography.fontFamily,
                    fontSize: 14,
                    fontWeight: 500,
                    lineHeight: "24px",
                    whiteSpace: "nowrap",
                    ...active && {
                        color: "primary.main"
                    }
                },
                children: title
            })
        })
    });
};
SideNavItem.propTypes = {
    active: (prop_types_default()).bool,
    children: (prop_types_default()).any,
    depth: (prop_types_default()).number,
    disabled: (prop_types_default()).bool,
    external: (prop_types_default()).bool,
    open: (prop_types_default()).bool,
    path: (prop_types_default()).string,
    title: (prop_types_default()).string.isRequired
};

;// CONCATENATED MODULE: ./src/layouts/marketing/side-nav.tsx











const items = [
    {
        title: "Components",
        path: paths/* paths.components.index */.H.components.index
    },
    {
        title: "Pages",
        children: [
            {
                subheader: "Dashboard",
                items: [
                    {
                        title: "Overview",
                        path: paths/* paths.dashboard.index */.H.dashboard.index
                    },
                    {
                        title: "Vouchers",
                        path: paths/* paths.dashboard.vouchers.index */.H.dashboard.vouchers.index
                    },
                    {
                        title: "Logistics",
                        path: paths/* paths.dashboard.logistics.index */.H.dashboard.logistics.index
                    },
                    {
                        title: "File Manager",
                        path: paths/* paths.dashboard.fileManager */.H.dashboard.fileManager
                    },
                    {
                        title: "Academy",
                        path: paths/* paths.dashboard.academy.index */.H.dashboard.academy.index
                    }
                ]
            },
            {
                subheader: "Other",
                items: [
                    {
                        title: "Pricing",
                        path: paths/* paths.pricing */.H.pricing
                    },
                    {
                        title: "Checkout",
                        path: paths/* paths.checkout */.H.checkout
                    },
                    {
                        title: "Error",
                        path: paths/* paths.notFound */.H.notFound
                    }
                ]
            }
        ]
    },
    {
        title: "Docs",
        path: paths/* paths.docs */.H.docs,
        external: true
    }
];
const renderItems = ({ depth =0 , items , pathname  })=>items.reduce((acc, item)=>reduceChildRoutes({
            acc,
            depth,
            item,
            pathname
        }), []);
const reduceChildRoutes = ({ acc , depth , item , pathname  })=>{
    const checkPath = !!(item.path && pathname);
    const partialMatch = checkPath ? pathname.includes(item.path) : false;
    const exactMatch = checkPath ? pathname === item.path : false;
    if (item.children) {
        acc.push(/*#__PURE__*/ jsx_runtime_.jsx(SideNavItem, {
            active: partialMatch,
            depth: depth,
            disabled: item.disabled,
            open: partialMatch,
            title: item.title,
            children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                spacing: 2,
                children: item.children.map((child, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        component: "ul",
                        spacing: 0.5,
                        sx: {
                            listStyle: "none",
                            m: 0,
                            p: 0
                        },
                        children: [
                            child.subheader && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                component: "li",
                                sx: {
                                    color: "text.secondary",
                                    fontSize: 12,
                                    fontWeight: 500,
                                    lineHeight: 1.66,
                                    mb: 1,
                                    pl: "24px",
                                    textTransform: "uppercase"
                                },
                                children: child.subheader
                            }),
                            child.items.map((item)=>{
                                const checkPath = !!(item.path && pathname);
                                const active = checkPath ? pathname === item.path : false;
                                const linkProps = item.path ? item.external ? {
                                    component: "a",
                                    href: item.path,
                                    target: "_blank"
                                } : {
                                    component: router_link/* RouterLink */.r,
                                    href: item.path
                                } : {};
                                return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
                                        sx: {
                                            alignItems: "center",
                                            borderRadius: 1,
                                            display: "flex",
                                            justifyContent: "flex-start",
                                            pl: "24px",
                                            pr: "16px",
                                            py: "8px",
                                            textAlign: "left",
                                            "&:hover": {
                                                backgroundColor: "action.hover"
                                            },
                                            ...active && {
                                                color: "primary.main"
                                            }
                                        },
                                        ...linkProps,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                component: "span",
                                                sx: {
                                                    height: 6,
                                                    mr: 2,
                                                    width: 6
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                    sx: {
                                                        backgroundColor: "neutral.400",
                                                        borderRadius: "50%",
                                                        height: 4,
                                                        opacity: 0,
                                                        width: 4,
                                                        ...active && {
                                                            backgroundColor: "primary.main",
                                                            height: 6,
                                                            opacity: 1,
                                                            width: 6
                                                        }
                                                    }
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                component: "span",
                                                sx: {
                                                    flexGrow: 1,
                                                    fontFamily: (theme)=>theme.typography.fontFamily,
                                                    fontSize: 13,
                                                    fontWeight: 500,
                                                    lineHeight: "24px",
                                                    whiteSpace: "nowrap"
                                                },
                                                children: item.title
                                            })
                                        ]
                                    })
                                }, item.title);
                            })
                        ]
                    }, index))
            })
        }, item.title));
    } else {
        acc.push(/*#__PURE__*/ jsx_runtime_.jsx(SideNavItem, {
            active: exactMatch,
            depth: depth,
            disabled: item.disabled,
            external: item.external,
            path: item.path,
            title: item.title
        }, item.title));
    }
    return acc;
};
const SideNav = (props)=>{
    const { onClose , open =false  } = props;
    const pathname = (0,use_pathname/* usePathname */.j)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Drawer_default()), {
        anchor: "right",
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                maxWidth: "100%",
                width: 300
            }
        },
        variant: "temporary",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    pt: 2,
                    px: 2
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    component: router_link/* RouterLink */.r,
                    direction: "row",
                    display: "inline-flex",
                    href: paths/* paths.index */.H.index,
                    spacing: 1,
                    sx: {
                        textDecoration: "none"
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                display: "inline-flex",
                                height: 24,
                                width: 24
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(logo/* Logo */.T, {})
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                color: "text.primary",
                                fontFamily: "'Plus Jakarta Sans', sans-serif",
                                fontSize: 14,
                                fontWeight: 800,
                                letterSpacing: "0.3px",
                                lineHeight: 2.5,
                                "& span": {
                                    color: "primary.main"
                                }
                            },
                            children: [
                                "Devias Kit ",
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: "PRO"
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "nav",
                sx: {
                    p: 2
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                    component: "ul",
                    spacing: 1,
                    sx: {
                        listStyle: "none",
                        m: 0,
                        p: 0
                    },
                    children: renderItems({
                        items,
                        pathname
                    })
                })
            })
        ]
    });
};
SideNav.propTypes = {
    onClose: (prop_types_default()).func,
    open: (prop_types_default()).bool
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Menu01.js
var Menu01 = __webpack_require__(913629);
// EXTERNAL MODULE: ./node_modules/@mui/system/colorManipulator.js
var colorManipulator = __webpack_require__(229551);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Chip/index.js
var Chip = __webpack_require__(829553);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/lodash/throttle.js
var throttle = __webpack_require__(325006);
var throttle_default = /*#__PURE__*/__webpack_require__.n(throttle);
;// CONCATENATED MODULE: ./src/hooks/use-window-scroll.ts


const useWindowScroll = (config)=>{
    (0,react_.useEffect)(()=>{
        const { handler , delay  } = config;
        const withThrottle = throttle_default()(handler, delay);
        window.addEventListener("scroll", withThrottle);
        return ()=>{
            window.removeEventListener("scroll", withThrottle);
        };
    }, [
        config
    ]);
};

;// CONCATENATED MODULE: ./src/icons/untitled-ui/duocolor/credit-card-01.tsx

const CreditCard01 = (props)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 24,
        height: 24,
        fill: "none",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                fill: "currentColor",
                d: "M2 8.2V10h20V8.2c0-1.1201 0-1.6802-.218-2.108a1.9998 1.9998 0 0 0-.874-.874C20.4802 5 19.9201 5 18.8 5H5.2c-1.1201 0-1.6802 0-2.108.218a2 2 0 0 0-.874.874C2 6.5198 2 7.08 2 8.2Z",
                opacity: 0.12
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M22 10H2m0-1.8v7.6c0 1.1201 0 1.6802.218 2.108.1917.3763.4977.6823.874.874C3.5198 19 4.08 19 5.2 19h13.6c1.1201 0 1.6802 0 2.108-.218a1.9996 1.9996 0 0 0 .874-.874C22 17.4802 22 16.9201 22 15.8V8.2c0-1.1201 0-1.6802-.218-2.108a1.9998 1.9998 0 0 0-.874-.874C20.4802 5 19.9201 5 18.8 5H5.2c-1.1201 0-1.6802 0-2.108.218a2 2 0 0 0-.874.874C2 6.5198 2 7.08 2 8.2Z"
            })
        ]
    });
/* harmony default export */ const credit_card_01 = (CreditCard01);

;// CONCATENATED MODULE: ./src/icons/untitled-ui/duocolor/home-smile.tsx

const HomeSmile = (props)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 24,
        height: 24,
        fill: "none",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                fill: "currentColor",
                d: "M3 10.5651c0-.5744 0-.8616.074-1.126a1.9998 1.9998 0 0 1 .318-.6502c.1633-.2208.39-.3971.8434-.7498l6.7823-5.2751c.3513-.2732.527-.4099.721-.4624a.9996.9996 0 0 1 .5226 0c.194.0525.3697.1891.721.4624l6.7823 5.2751c.4534.3527.6801.529.8434.7498.1446.1955.2524.4159.318.6502.074.2644.074.5516.074 1.126V17.8c0 1.1201 0 1.6801-.218 2.108a1.9996 1.9996 0 0 1-.874.874C19.4802 21 18.9201 21 17.8 21H6.2c-1.1201 0-1.6802 0-2.108-.218a1.9997 1.9997 0 0 1-.874-.874C3 19.4801 3 18.9201 3 17.8v-7.2349Z",
                opacity: 0.12
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "M8.126 14c.444 1.7252 2.0102 3 3.874 3s3.4299-1.2748 3.874-3M11.0177 2.764 4.2354 8.0391c-.4534.3527-.68.529-.8434.7498a1.9998 1.9998 0 0 0-.318.6502C3 9.7035 3 9.9907 3 10.565V17.8c0 1.1201 0 1.6801.218 2.108.1917.3763.4977.6823.874.874C4.5198 21 5.08 21 6.2 21h11.6c1.1201 0 1.6802 0 2.108-.218a1.9996 1.9996 0 0 0 .874-.874C21 19.4801 21 18.9201 21 17.8v-7.2349c0-.5744 0-.8616-.074-1.126a2.0016 2.0016 0 0 0-.318-.6502c-.1633-.2208-.39-.3971-.8434-.7498L12.9823 2.764c-.3513-.2732-.527-.4099-.721-.4624a.9996.9996 0 0 0-.5226 0c-.194.0525-.3697.1891-.721.4624Z"
            })
        ]
    });
/* harmony default export */ const home_smile = (HomeSmile);

;// CONCATENATED MODULE: ./src/icons/untitled-ui/duocolor/log-out-01.tsx

const LogOut01 = (props)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 24,
        height: 24,
        fill: "none",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                fill: "currentColor",
                d: "M3 21V3h6v18H3Z",
                opacity: 0.12
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "m16 17 5-5m0 0-5-5m5 5H9m0-9H7.8c-1.6802 0-2.5202 0-3.162.327a3 3 0 0 0-1.311 1.311C3 5.2798 3 6.1198 3 7.8v8.4c0 1.6802 0 2.5202.327 3.162a2.9997 2.9997 0 0 0 1.311 1.311C5.2798 21 6.1198 21 7.8 21H9"
            })
        ]
    });
/* harmony default export */ const log_out_01 = (LogOut01);

;// CONCATENATED MODULE: ./src/icons/untitled-ui/duocolor/x-square.tsx

const XSquare = (props)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        xmlns: "http://www.w3.org/2000/svg",
        width: 24,
        height: 24,
        fill: "none",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                fill: "currentColor",
                d: "M3 7.8c0-1.6802 0-2.5202.327-3.162a3 3 0 0 1 1.311-1.311C5.2798 3 6.1198 3 7.8 3h8.4c1.6802 0 2.5202 0 3.162.327a2.9997 2.9997 0 0 1 1.311 1.311C21 5.2798 21 6.1198 21 7.8v8.4c0 1.6802 0 2.5202-.327 3.162a2.9994 2.9994 0 0 1-1.311 1.311C18.7202 21 17.8802 21 16.2 21H7.8c-1.6802 0-2.5202 0-3.162-.327a2.9997 2.9997 0 0 1-1.311-1.311C3 18.7202 3 17.8802 3 16.2V7.8Z",
                opacity: 0.12
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("path", {
                stroke: "currentColor",
                strokeLinecap: "round",
                strokeLinejoin: "round",
                strokeWidth: 2,
                d: "m9 9 6 6m0-6-6 6m-1.2 6h8.4c1.6802 0 2.5202 0 3.162-.327a2.9994 2.9994 0 0 0 1.311-1.311C21 18.7202 21 17.8802 21 16.2V7.8c0-1.6802 0-2.5202-.327-3.162a2.9997 2.9997 0 0 0-1.311-1.311C18.7202 3 17.8802 3 16.2 3H7.8c-1.6802 0-2.5202 0-3.162.327a3 3 0 0 0-1.311 1.311C3 5.2798 3 6.1198 3 7.8v8.4c0 1.6802 0 2.5202.327 3.162a2.9997 2.9997 0 0 0 1.311 1.311C5.2798 21 6.1198 21 7.8 21Z"
            })
        ]
    });
/* harmony default export */ const x_square = (XSquare);

;// CONCATENATED MODULE: ./src/layouts/marketing/pages-popover.tsx











const pages_popover_sections = [
    {
        items: [
            {
                title: "Dashboard",
                path: "/dashboard",
                icon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                    fontSize: "small",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(home_smile, {})
                }),
                caption: "40+ screens",
                children: [
                    {
                        title: "Overview",
                        path: paths/* paths.dashboard.index */.H.dashboard.index
                    },
                    {
                        title: "Vouchers",
                        path: paths/* paths.dashboard.vouchers.index */.H.dashboard.vouchers.index
                    },
                    {
                        title: "Logistics",
                        path: paths/* paths.dashboard.logistics.index */.H.dashboard.logistics.index
                    },
                    {
                        title: "File Manager",
                        path: paths/* paths.dashboard.fileManager */.H.dashboard.fileManager
                    },
                    {
                        title: "Academy",
                        path: paths/* paths.dashboard.academy.index */.H.dashboard.academy.index
                    }
                ]
            }
        ]
    },
    {
        items: [
            {
                title: "Pricing",
                path: paths/* paths.pricing */.H.pricing,
                icon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                    fontSize: "small",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(credit_card_01, {})
                })
            },
            {
                title: "Checkout",
                path: paths/* paths.checkout */.H.checkout,
                icon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                    fontSize: "small",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(log_out_01, {})
                })
            },
            {
                title: "Error",
                path: paths/* paths.notFound */.H.notFound,
                icon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                    fontSize: "small",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(x_square, {})
                })
            }
        ]
    }
];
const PagesPopover = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            display: "grid",
            gap: 3,
            gridTemplateColumns: "repeat(2, 1fr)",
            p: 3
        },
        children: pages_popover_sections.map((section, index)=>{
            return /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                component: "ul",
                spacing: 0.5,
                sx: {
                    listStyle: "none",
                    m: 0,
                    p: 0
                },
                children: section.items.map((item)=>{
                    const linkProps = item.path ? item.external ? {
                        component: "a",
                        href: item.path,
                        target: "_blank"
                    } : {
                        component: router_link/* RouterLink */.r,
                        href: item.path
                    } : {};
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
                                sx: {
                                    alignItems: "center",
                                    borderRadius: 1,
                                    display: "flex",
                                    justifyContent: "flex-start",
                                    px: "12px",
                                    py: "6px",
                                    textAlign: "left",
                                    width: "100%",
                                    "&:hover": {
                                        backgroundColor: "action.hover"
                                    }
                                },
                                ...linkProps,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                        component: "span",
                                        sx: {
                                            alignItems: "center",
                                            color: "action.active",
                                            display: "inline-flex",
                                            justifyContent: "center",
                                            mr: 2,
                                            width: 20
                                        },
                                        children: item.icon
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                        component: "span",
                                        sx: {
                                            flexGrow: 1
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                component: "span",
                                                sx: {
                                                    display: "block",
                                                    fontFamily: (theme)=>theme.typography.fontFamily,
                                                    fontSize: 14,
                                                    fontWeight: 500,
                                                    lineHeight: "24px",
                                                    whiteSpace: "nowrap"
                                                },
                                                children: item.title
                                            }),
                                            item.caption && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                component: "span",
                                                sx: {
                                                    color: "text.secondary",
                                                    display: "block",
                                                    fontFamily: (theme)=>theme.typography.fontFamily,
                                                    fontSize: 12,
                                                    fontWeight: 400,
                                                    lineHeight: "18px",
                                                    whiteSpace: "nowrap"
                                                },
                                                children: item.caption
                                            })
                                        ]
                                    })
                                ]
                            }),
                            item.children && /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                component: "ul",
                                spacing: 0.5,
                                sx: {
                                    listStyle: "none",
                                    m: 0,
                                    p: 0,
                                    pl: 20 + 16 + "px"
                                },
                                children: item.children.map((child)=>{
                                    const linkProps = child.path ? child.external ? {
                                        component: "a",
                                        href: child.path,
                                        target: "_blank"
                                    } : {
                                        component: router_link/* RouterLink */.r,
                                        href: child.path
                                    } : {};
                                    return /*#__PURE__*/ jsx_runtime_.jsx("li", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((ButtonBase_default()), {
                                            sx: {
                                                alignItems: "center",
                                                borderRadius: 1,
                                                display: "flex",
                                                justifyContent: "flex-start",
                                                px: "12px",
                                                py: "6px",
                                                textAlign: "left",
                                                width: "100%",
                                                "&:hover": {
                                                    backgroundColor: "action.hover"
                                                }
                                            },
                                            ...linkProps,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                component: "span",
                                                sx: {
                                                    color: "text.secondary",
                                                    display: "block",
                                                    fontFamily: (theme)=>theme.typography.fontFamily,
                                                    fontSize: 14,
                                                    fontWeight: 500,
                                                    lineHeight: "24px",
                                                    whiteSpace: "nowrap"
                                                },
                                                children: child.title
                                            })
                                        })
                                    }, child.title);
                                })
                            })
                        ]
                    }, item.title);
                })
            }, index);
        })
    });

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Paper/index.js
var Paper = __webpack_require__(427561);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Portal/index.js
var Portal = __webpack_require__(257636);
;// CONCATENATED MODULE: ./src/layouts/marketing/top-nav-item.tsx












const TOP_NAV_HEIGHT = 64;
const TOP_NAV_SPACE = 16;
const OFFSET = 16;
const TopNavItem = (props)=>{
    const { active , external , path , popover , title  } = props;
    const [open, setOpen] = (0,react_.useState)(false);
    const handleMouseEnter = (0,react_.useCallback)(()=>{
        setOpen(true);
    }, []);
    const handleMouseLeave = (0,react_.useCallback)(()=>{
        setOpen(false);
    }, []);
    // With mega-menu
    if (popover) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "li",
                    sx: {
                        display: "flex",
                        alignItems: "center",
                        height: "100%"
                    },
                    onMouseEnter: handleMouseEnter,
                    onMouseLeave: handleMouseLeave,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
                        disableRipple: true,
                        sx: {
                            alignItems: "center",
                            borderRadius: 1,
                            display: "flex",
                            justifyContent: "flex-start",
                            px: "16px",
                            py: "8px",
                            textAlign: "left",
                            "&:hover": {
                                backgroundColor: "action.hover"
                            },
                            ...active && {
                                color: "primary.main"
                            }
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                component: "span",
                                variant: "subtitle2",
                                children: title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                sx: {
                                    fontSize: 16,
                                    ml: 1
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronDown/* default */.Z, {})
                            })
                        ]
                    })
                }),
                open && /*#__PURE__*/ jsx_runtime_.jsx(Portal["default"], {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        onMouseEnter: handleMouseEnter,
                        onMouseLeave: handleMouseLeave,
                        sx: {
                            left: 0,
                            position: "fixed",
                            pt: OFFSET + "px",
                            right: 0,
                            top: TOP_NAV_HEIGHT + TOP_NAV_SPACE,
                            zIndex: (theme)=>theme.zIndex.appBar + 100
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Paper_default()), {
                            elevation: 16,
                            sx: {
                                backgroundColor: (theme)=>(0,colorManipulator.alpha)(theme.palette.background.paper, 0.90),
                                backdropFilter: "blur(6px)",
                                mx: "auto",
                                width: (theme)=>theme.breakpoints.values.md
                            },
                            children: popover
                        })
                    })
                })
            ]
        });
    }
    // Simple
    const linkProps = path ? external ? {
        component: "a",
        href: path,
        target: "_blank"
    } : {
        component: router_link/* RouterLink */.r,
        href: path
    } : {};
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        component: "li",
        sx: {
            display: "flex",
            alignItems: "center",
            height: "100%"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((ButtonBase_default()), {
            disableRipple: true,
            sx: {
                alignItems: "center",
                borderRadius: 1,
                display: "flex",
                justifyContent: "flex-start",
                px: "16px",
                py: "8px",
                textAlign: "left",
                "&:hover": {
                    backgroundColor: "action.hover"
                },
                ...active && {
                    color: "primary.main"
                }
            },
            ...linkProps,
            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                component: "span",
                variant: "subtitle2",
                children: title
            })
        })
    });
};
TopNavItem.propTypes = {
    active: (prop_types_default()).bool,
    external: (prop_types_default()).bool,
    path: (prop_types_default()).string,
    popover: (prop_types_default()).any,
    title: (prop_types_default()).string.isRequired
};

;// CONCATENATED MODULE: ./src/layouts/marketing/top-nav.tsx




















const top_nav_items = [
    {
        title: "Components",
        path: paths/* paths.components.index */.H.components.index
    },
    {
        title: "Pages",
        popover: /*#__PURE__*/ jsx_runtime_.jsx(PagesPopover, {})
    },
    {
        title: "Docs",
        path: paths/* paths.docs */.H.docs,
        external: true
    }
];
const top_nav_TOP_NAV_HEIGHT = 64;
const TopNav = (props)=>{
    const { onMobileNavOpen  } = props;
    const pathname = (0,use_pathname/* usePathname */.j)();
    const mdUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("md"));
    const [elevate, setElevate] = (0,react_.useState)(false);
    const offset = 64;
    const delay = 100;
    const handleWindowScroll = (0,react_.useCallback)(()=>{
        if (window.scrollY > offset) {
            setElevate(true);
        } else {
            setElevate(false);
        }
    }, []);
    useWindowScroll({
        handler: handleWindowScroll,
        delay
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        component: "header",
        sx: {
            left: 0,
            position: "fixed",
            right: 0,
            top: 0,
            pt: 2,
            zIndex: (theme)=>theme.zIndex.appBar
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "lg",
            sx: {
                backdropFilter: "blur(6px)",
                backgroundColor: "transparent",
                borderRadius: 2.5,
                boxShadow: "none",
                transition: (theme)=>theme.transitions.create("box-shadow, background-color", {
                        easing: theme.transitions.easing.easeInOut,
                        duration: 200
                    }),
                ...elevate && {
                    backgroundColor: (theme)=>(0,colorManipulator.alpha)(theme.palette.background.paper, 0.9),
                    boxShadow: 8
                }
            },
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                direction: "row",
                spacing: 2,
                sx: {
                    height: top_nav_TOP_NAV_HEIGHT
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 1,
                        sx: {
                            flexGrow: 1
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                alignItems: "center",
                                component: router_link/* RouterLink */.r,
                                direction: "row",
                                display: "inline-flex",
                                href: paths/* paths.index */.H.index,
                                spacing: 1,
                                sx: {
                                    textDecoration: "none"
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                        sx: {
                                            display: "inline-flex",
                                            height: 24,
                                            width: 24
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(logo/* Logo */.T, {})
                                    }),
                                    mdUp && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                        sx: {
                                            color: "text.primary",
                                            fontFamily: "'Plus Jakarta Sans', sans-serif",
                                            fontSize: 14,
                                            fontWeight: 800,
                                            letterSpacing: "0.3px",
                                            lineHeight: 2.5,
                                            "& span": {
                                                color: "primary.main"
                                            }
                                        },
                                        children: [
                                            "Devias Kit ",
                                            /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                                children: "PRO"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                                label: "v6.4.0",
                                size: "small"
                            })
                        ]
                    }),
                    mdUp && /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 2,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            component: "nav",
                            sx: {
                                height: "100%"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                component: "ul",
                                alignItems: "center",
                                justifyContent: "center",
                                direction: "row",
                                spacing: 1,
                                sx: {
                                    height: "100%",
                                    listStyle: "none",
                                    m: 0,
                                    p: 0
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                    children: top_nav_items.map((item)=>{
                                        const checkPath = !!(item.path && pathname);
                                        const partialMatch = checkPath ? pathname.includes(item.path) : false;
                                        const exactMatch = checkPath ? pathname === item.path : false;
                                        const active = item.popover ? partialMatch : exactMatch;
                                        return /*#__PURE__*/ jsx_runtime_.jsx(TopNavItem, {
                                            active: active,
                                            external: item.external,
                                            path: item.path,
                                            popover: item.popover,
                                            title: item.title
                                        }, item.title);
                                    })
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        justifyContent: "flex-end",
                        spacing: 2,
                        sx: {
                            flexGrow: 1
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                component: "a",
                                size: mdUp ? "medium" : "small",
                                href: "https://mui.com/store/items/devias-kit-pro",
                                target: "_blank",
                                variant: "contained",
                                children: "Purchase Now"
                            }),
                            !mdUp && /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: onMobileNavOpen,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    fontSize: "small",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Menu01/* default */.Z, {})
                                })
                            })
                        ]
                    })
                ]
            })
        })
    });
};
TopNav.propTypes = {
    onMobileNavOpen: (prop_types_default()).func
};

;// CONCATENATED MODULE: ./src/layouts/marketing/use-mobile-nav.ts


const useMobileNav = ()=>{
    const pathname = (0,use_pathname/* usePathname */.j)();
    const [open, setOpen] = (0,react_.useState)(false);
    const handlePathnameChange = (0,react_.useCallback)(()=>{
        if (open) {
            setOpen(false);
        }
    }, [
        open
    ]);
    (0,react_.useEffect)(()=>{
        handlePathnameChange();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        pathname
    ]);
    const handleOpen = (0,react_.useCallback)(()=>{
        setOpen(true);
    }, []);
    const handleClose = (0,react_.useCallback)(()=>{
        setOpen(false);
    }, []);
    return {
        handleOpen,
        handleClose,
        open
    };
};

;// CONCATENATED MODULE: ./src/layouts/marketing/layout.tsx








const LayoutRoot = (0,styles.styled)("div")(({ theme  })=>({
        backgroundColor: theme.palette.background.default,
        height: "100%"
    }));
const Layout = (props)=>{
    const { children  } = props;
    const lgUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("lg"));
    const mobileNav = useMobileNav();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(TopNav, {
                onMobileNavOpen: mobileNav.handleOpen
            }),
            !lgUp && /*#__PURE__*/ jsx_runtime_.jsx(SideNav, {
                onClose: mobileNav.handleClose,
                open: mobileNav.open
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(LayoutRoot, {
                children: [
                    children,
                    /*#__PURE__*/ jsx_runtime_.jsx(Footer, {})
                ]
            })
        ]
    });
};
Layout.propTypes = {
    children: (prop_types_default()).node
};

;// CONCATENATED MODULE: ./src/layouts/marketing/index.ts


;// CONCATENATED MODULE: ./src/app/marketing/layout.tsx
/* __next_internal_client_entry_do_not_use__ default auto */ 


/***/ }),

/***/ 586068:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$$typeof": () => (/* binding */ $$typeof),
/* harmony export */   "__esModule": () => (/* binding */ __esModule),
/* harmony export */   "default": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(835985);

const proxy = (0,next_dist_build_webpack_loaders_next_flight_loader_module_proxy__WEBPACK_IMPORTED_MODULE_0__.createProxy)(String.raw`/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/layout.tsx`)

// Accessing the __esModule property and exporting $$typeof are required here.
// The __esModule getter forces the proxy target to create the default export
// and the $$typeof value is for rendering logic to determine if the module
// is a client boundary.
const { __esModule, $$typeof } = proxy;
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (proxy.default);


/***/ })

};
;