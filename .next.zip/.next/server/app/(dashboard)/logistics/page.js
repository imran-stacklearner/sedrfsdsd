(() => {
var exports = {};
exports.id = 333;
exports.ids = [333];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 876168:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'logistics',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 716794, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/logistics/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/logistics/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/logistics/page"
  

/***/ }),

/***/ 429048:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 55636))

/***/ }),

/***/ 55636:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Plus.js
var Plus = __webpack_require__(959309);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/hooks/use-settings.ts
var use_settings = __webpack_require__(488141);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/AlertCircle.js
var AlertCircle = __webpack_require__(142885);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-deviated-vehicles.tsx








const LogisticsDeviatedVehicles = (props)=>{
    const { amount  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
            spacing: 1,
            sx: {
                p: 3
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                            variant: "rounded",
                            sx: {
                                backgroundColor: "warning.alpha12",
                                color: "warning.main"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(AlertCircle/* default */.Z, {})
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "h5",
                            children: amount
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    variant: "body2",
                    children: "Vehicles deviated from route"
                })
            ]
        })
    });
};
LogisticsDeviatedVehicles.propTypes = {
    amount: (prop_types_default()).number.isRequired
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/AlertTriangle.js
var AlertTriangle = __webpack_require__(568537);
;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-error-vehicles.tsx








const LogisticsErrorVehicles = (props)=>{
    const { amount  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
            spacing: 1,
            sx: {
                p: 3
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                            variant: "rounded",
                            sx: {
                                backgroundColor: "error.alpha12",
                                color: "error.main"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(AlertTriangle/* default */.Z, {})
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "h5",
                            children: amount
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    variant: "body2",
                    children: "Vehicles with errors"
                })
            ]
        })
    });
};
LogisticsErrorVehicles.propTypes = {
    amount: (prop_types_default()).number.isRequired
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Clock.js
var Clock = __webpack_require__(477159);
;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-late-vehicles.tsx








const LogisticsLateVehicles = (props)=>{
    const { amount  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
            spacing: 1,
            sx: {
                p: 3
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                            variant: "rounded",
                            sx: {
                                backgroundColor: "primary.alpha12",
                                color: "primary.main"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Clock/* default */.Z, {})
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "h5",
                            children: amount
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    variant: "body2",
                    children: "Late vehicles"
                })
            ]
        })
    });
};
LogisticsLateVehicles.propTypes = {
    amount: (prop_types_default()).number.isRequired
};

// EXTERNAL MODULE: ./node_modules/@mui/system/colorManipulator.js
var colorManipulator = __webpack_require__(229551);
;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-route-vehicles.tsx








const LogisticsRouteVehicles = (props)=>{
    const { amount  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
            spacing: 1,
            sx: {
                p: 3
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                            sx: {
                                backgroundColor: "transparent"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    animation: "pulse ease 750ms infinite",
                                    borderRadius: "50%",
                                    p: 0.5,
                                    "@keyframes pulse": {
                                        "0%": {
                                            boxShadow: "none"
                                        },
                                        "100%": {
                                            boxShadow: (theme)=>`0px 0px 0px 6px ${(0,colorManipulator.alpha)(theme.palette.error.main, 0.1)}`
                                        }
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                    sx: {
                                        backgroundColor: "error.main",
                                        borderRadius: "50%",
                                        height: 18,
                                        width: 18
                                    }
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "h5",
                            children: amount
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    variant: "body2",
                    children: "On route vehicles"
                })
            ]
        })
    });
};
LogisticsRouteVehicles.propTypes = {
    amount: (prop_types_default()).number.isRequired
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
// EXTERNAL MODULE: ./src/components/chart.tsx
var chart = __webpack_require__(400929);
;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-vehicles-condition.tsx










const categories = [
    {
        id: "excellent",
        title: "Very good",
        description: "Excellent"
    },
    {
        id: "good",
        title: "Good",
        description: "Good condition"
    },
    {
        id: "bad",
        title: "Bad",
        description: "Needs attention"
    }
];
const createChartOptions = (theme, color)=>{
    return {
        chart: {
            background: "transparent"
        },
        colors: [
            color
        ],
        labels: [
            "Health"
        ],
        plotOptions: {
            radialBar: {
                dataLabels: {
                    name: {
                        show: true,
                        color: theme.palette.text.secondary,
                        fontSize: "12px",
                        fontWeight: 400,
                        offsetY: 20
                    },
                    value: {
                        color: theme.palette.text.primary,
                        fontSize: "18px",
                        fontWeight: 600,
                        offsetY: -20
                    }
                },
                hollow: {
                    size: "50%"
                },
                track: {
                    background: (0,colorManipulator.alpha)(color, 0.12)
                }
            }
        },
        states: {
            active: {
                filter: {
                    type: "none"
                }
            },
            hover: {
                filter: {
                    type: "none"
                }
            }
        },
        theme: {
            mode: theme.palette.mode
        }
    };
};
const LogisticsVehiclesCondition = (props)=>{
    const { bad , excellent , good  } = props;
    const theme = (0,styles.useTheme)();
    const total = excellent + good + bad;
    const colorsMap = {
        excellent: theme.palette.primary.main,
        good: theme.palette.warning.main,
        bad: theme.palette.error.main
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                title: "Vehicles Condition"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    p: 1
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    container: true,
                    spacing: 3,
                    children: categories.map((category)=>{
                        const color = colorsMap[category.id];
                        const chartOptions = createChartOptions(theme, color);
                        const amount = props[category.id] || 0;
                        const progress = Math.round(amount / total * 100);
                        const chartSeries = [
                            progress
                        ];
                        return /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 4,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    alignItems: "center",
                                    backgroundColor: (0,colorManipulator.alpha)(color, 0.04),
                                    borderRadius: 3,
                                    display: "flex",
                                    flexDirection: "column",
                                    p: 2
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        sx: {
                                            color
                                        },
                                        variant: "h6",
                                        children: category.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                                        height: 200,
                                        options: chartOptions,
                                        series: chartSeries,
                                        type: "radialBar"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "h6",
                                        children: amount
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: category.description
                                    })
                                ]
                            })
                        }, category.title);
                    })
                })
            })
        ]
    });
};
LogisticsVehiclesCondition.propTypes = {
    bad: (prop_types_default()).number.isRequired,
    excellent: (prop_types_default()).number.isRequired,
    good: (prop_types_default()).number.isRequired
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Truck02.js
var Truck02 = __webpack_require__(779115);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/LinearProgress/index.js
var LinearProgress = __webpack_require__(154003);
var LinearProgress_default = /*#__PURE__*/__webpack_require__.n(LinearProgress);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Table/index.js
var Table = __webpack_require__(620390);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableBody/index.js
var TableBody = __webpack_require__(843606);
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableCell/index.js
var TableCell = __webpack_require__(340514);
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableHead/index.js
var TableHead = __webpack_require__(30092);
var TableHead_default = /*#__PURE__*/__webpack_require__.n(TableHead);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableRow/index.js
var TableRow = __webpack_require__(893761);
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow);
// EXTERNAL MODULE: ./src/components/scrollbar.tsx
var scrollbar = __webpack_require__(851716);
// EXTERNAL MODULE: ./src/components/severity-pill.tsx
var severity_pill = __webpack_require__(594368);
;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-vehicles-list.tsx

















const LogisticsVehiclesList = (props)=>{
    const { vehicles  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                title: "On Route Vehicles",
                subheader: "Condition and temperature"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        minWidth: 1200
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((TableHead_default()), {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: "Location"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: "Ending Route"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: "Starting Route"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: "Warnings"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: "Refrigerator Temperature"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                                children: vehicles.map((vehicle)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                        sx: {
                                            "&:last-child td, &:last-child th": {
                                                border: 0
                                            }
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                                    sx: {
                                                        alignItems: "center",
                                                        display: "flex"
                                                    },
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                            sx: {
                                                                mr: 2
                                                            },
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Truck02/* default */.Z, {})
                                                            })
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            variant: "subtitle2",
                                                            children: vehicle.id
                                                        })
                                                    ]
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "body2",
                                                    children: vehicle.endingRoute
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "body2",
                                                    children: vehicle.startingRoute
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(severity_pill/* SeverityPill */.I, {
                                                    color: vehicle.status,
                                                    children: vehicle.warning || "No warnings"
                                                })
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((LinearProgress_default()), {
                                                        value: vehicle.temperature,
                                                        variant: "determinate"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                                        sx: {
                                                            alignItems: "center",
                                                            display: "flex",
                                                            mt: 2
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                color: "inherit",
                                                                variant: "inherit",
                                                                children: vehicle.temperatureLabel
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                                sx: {
                                                                    flexGrow: 1
                                                                }
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                                color: "text.secondary",
                                                                variant: "inherit",
                                                                children: [
                                                                    vehicle.temperature,
                                                                    "\xb0C"
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    }, vehicle.id))
                            })
                        ]
                    })
                })
            })
        ]
    });
};
LogisticsVehiclesList.propTypes = {
    vehicles: (prop_types_default()).array.isRequired
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/List/index.js
var List = __webpack_require__(854436);
var List_default = /*#__PURE__*/__webpack_require__.n(List);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItem/index.js
var ListItem = __webpack_require__(790777);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem);
;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-vehicles-overview.tsx












const useChartOptions = (labels)=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent"
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.warning.main,
            theme.palette.info.main
        ],
        labels,
        plotOptions: {
            radialBar: {
                track: {
                    background: theme.palette.mode === "dark" ? theme.palette.neutral[800] : theme.palette.neutral[100]
                },
                dataLabels: {
                    name: {
                        color: theme.palette.text.primary
                    },
                    value: {
                        color: theme.palette.text.primary
                    }
                }
            }
        },
        states: {
            active: {
                filter: {
                    type: "none"
                }
            },
            hover: {
                filter: {
                    type: "none"
                }
            }
        },
        theme: {
            mode: theme.palette.mode
        }
    };
};
const LogisticsVehiclesOverview = (props)=>{
    const { chartSeries , labels  } = props;
    const chartOptions = useChartOptions(labels);
    const total = chartSeries.reduce((acc, item)=>acc += item, 0);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                title: "Vehicles Overview"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    p: 3
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                    alignItems: "center",
                    container: true,
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                                height: 300,
                                options: chartOptions,
                                series: chartSeries,
                                type: "radialBar"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                spacing: 3,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "body2",
                                                children: "Total"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "h5",
                                                children: total
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                                        disablePadding: true,
                                        children: chartSeries.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                                disableGutters: true,
                                                sx: {
                                                    display: "flex"
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                        sx: {
                                                            backgroundColor: chartOptions.colors[index],
                                                            borderRadius: "4px",
                                                            height: 16,
                                                            mr: 1,
                                                            width: 16
                                                        }
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        color: "text.secondary",
                                                        variant: "body2",
                                                        children: labels[index]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                        sx: {
                                                            flexGrow: 1
                                                        }
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "subtitle2",
                                                        children: item
                                                    })
                                                ]
                                            }, index))
                                    })
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};
LogisticsVehiclesOverview.propTypes = {
    chartSeries: (prop_types_default()).array.isRequired,
    labels: (prop_types_default()).array.isRequired
};

;// CONCATENATED MODULE: ./src/app/(dashboard)/logistics/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 


















const Page = ()=>{
    const settings = (0,use_settings/* useSettings */.r)();
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: Logistics Dashboard"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "main",
                sx: {
                    flexGrow: 1,
                    py: 8
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                    maxWidth: settings.stretch ? false : "xl",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                        container: true,
                        spacing: {
                            xs: 3,
                            lg: 4
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    direction: "row",
                                    justifyContent: "space-between",
                                    spacing: 4,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "h4",
                                                children: "Logistics"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                                direction: "row",
                                                spacing: 4,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                    startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                                                    }),
                                                    variant: "contained",
                                                    children: "Add Vehicle"
                                                })
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 3,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(LogisticsRouteVehicles, {
                                    amount: 38
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 3,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(LogisticsErrorVehicles, {
                                    amount: 2
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 3,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(LogisticsDeviatedVehicles, {
                                    amount: 1
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 3,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(LogisticsLateVehicles, {
                                    amount: 2
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                lg: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(LogisticsVehiclesOverview, {
                                    chartSeries: [
                                        38,
                                        50,
                                        12
                                    ],
                                    labels: [
                                        "Available",
                                        "Out of service",
                                        "On route"
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                lg: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(LogisticsVehiclesCondition, {
                                    bad: 12,
                                    excellent: 181,
                                    good: 24
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(LogisticsVehiclesList, {
                                    vehicles: [
                                        {
                                            id: "VOL-653CD1",
                                            endingRoute: "Cleveland, Ohio, USA",
                                            startingRoute: "Cleveland, Ohio, USA",
                                            status: "success",
                                            temperature: 8,
                                            temperatureLabel: "Very Good"
                                        },
                                        {
                                            id: "VOL-653CD2",
                                            endingRoute: "Cleveland, Ohio, USA",
                                            startingRoute: "Cleveland, Ohio, USA",
                                            status: "warning",
                                            temperature: 8,
                                            temperatureLabel: "Very Good",
                                            warning: "Temperature not optimal"
                                        },
                                        {
                                            id: "VOL-653CD3",
                                            endingRoute: "Cleveland, Ohio, USA",
                                            startingRoute: "Cleveland, Ohio, USA",
                                            status: "error",
                                            temperature: 8,
                                            temperatureLabel: "Very Good",
                                            warning: "ECU not responding"
                                        },
                                        {
                                            id: "VOL-653CD4",
                                            endingRoute: "Cleveland, Ohio, USA",
                                            startingRoute: "Cleveland, Ohio, USA",
                                            status: "success",
                                            temperature: 8,
                                            temperatureLabel: "Very Good"
                                        }
                                    ]
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 716794:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/logistics/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,9535,9115,8537,1547,7680,95,9494,2302,4368,929], () => (__webpack_exec__(876168)));
module.exports = __webpack_exports__;

})();