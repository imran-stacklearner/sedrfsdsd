(() => {
var exports = {};
exports.id = 3139;
exports.ids = [3139];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 418302:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'logistics',
        {
        children: [
        'fleet',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 74374, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/logistics/fleet/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/logistics/fleet/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/logistics/fleet/page"
  

/***/ }),

/***/ 526341:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 982819))

/***/ }),

/***/ 982819:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/useMediaQuery/index.js
var useMediaQuery = __webpack_require__(975983);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/X.js
var X = __webpack_require__(180501);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Drawer/index.js
var Drawer = __webpack_require__(379499);
var Drawer_default = /*#__PURE__*/__webpack_require__.n(Drawer);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-fleet-drawer.tsx








const LogisticsFleetDrawer = (props)=>{
    const { children , container , open , onClose  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Drawer_default()), {
        anchor: "left",
        hideBackdrop: true,
        ModalProps: {
            container,
            sx: {
                pointerEvents: "none",
                position: "absolute"
            }
        },
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                pointerEvents: "auto",
                position: "absolute"
            }
        },
        SlideProps: {
            container
        },
        variant: "temporary",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "flex-center",
                direction: "row",
                justifyContent: "space-between",
                sx: {
                    p: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "h5",
                        children: "Fleet"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        onClick: onClose,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(X/* default */.Z, {})
                        })
                    })
                ]
            }),
            children
        ]
    });
};
LogisticsFleetDrawer.propTypes = {
    children: (prop_types_default()).node,
    container: (prop_types_default()).any,
    onClose: (prop_types_default()).func,
    open: (prop_types_default()).bool
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Truck02.js
var Truck02 = __webpack_require__(779115);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ButtonBase/index.js
var ButtonBase = __webpack_require__(269860);
var ButtonBase_default = /*#__PURE__*/__webpack_require__.n(ButtonBase);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Collapse/index.js
var Collapse = __webpack_require__(836136);
var Collapse_default = /*#__PURE__*/__webpack_require__.n(Collapse);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/LinearProgress/index.js
var LinearProgress = __webpack_require__(154003);
var LinearProgress_default = /*#__PURE__*/__webpack_require__.n(LinearProgress);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/Timeline/index.js
var Timeline = __webpack_require__(34029);
var Timeline_default = /*#__PURE__*/__webpack_require__.n(Timeline);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/TimelineConnector/index.js
var TimelineConnector = __webpack_require__(292635);
var TimelineConnector_default = /*#__PURE__*/__webpack_require__.n(TimelineConnector);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/TimelineContent/index.js
var TimelineContent = __webpack_require__(357189);
var TimelineContent_default = /*#__PURE__*/__webpack_require__.n(TimelineContent);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/TimelineDot/index.js
var TimelineDot = __webpack_require__(254977);
var TimelineDot_default = /*#__PURE__*/__webpack_require__.n(TimelineDot);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/TimelineItem/index.js
var TimelineItem = __webpack_require__(375076);
var TimelineItem_default = /*#__PURE__*/__webpack_require__.n(TimelineItem);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/TimelineSeparator/index.js
var TimelineSeparator = __webpack_require__(63909);
var TimelineSeparator_default = /*#__PURE__*/__webpack_require__.n(TimelineSeparator);
;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-fleet-vehicle.tsx



















const LogisticsFleetVehicle = (props)=>{
    const { onDeselect , onSelect , selected , vehicle  } = props;
    const handleToggle = (0,react_.useCallback)(()=>{
        if (!selected) {
            onSelect?.(vehicle.id);
        } else {
            onDeselect?.();
        }
    }, [
        onDeselect,
        onSelect,
        selected,
        vehicle
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        component: "li",
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
                sx: {
                    alignItems: "center",
                    justifyContent: "flex-start",
                    p: 2,
                    textAlign: "left",
                    width: "100%"
                },
                onClick: handleToggle,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                        sx: {
                            mr: 2
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Truck02/* default */.Z, {})
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                children: vehicle.id
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.secondary",
                                variant: "body2",
                                children: vehicle.location
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Collapse_default()), {
                in: selected,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                        sx: {
                            p: 2
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                spacing: 1,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "caption",
                                        children: "Temperature (good)"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                        alignItems: "center",
                                        direction: "row",
                                        spacing: 2,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((LinearProgress_default()), {
                                                value: 8,
                                                sx: {
                                                    flexGrow: 1
                                                },
                                                variant: "determinate"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "body2",
                                                children: vehicle.temp
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Timeline_default()), {
                                position: "right",
                                sx: {
                                    px: 3,
                                    [`& .${TimelineItem.timelineItemClasses.root}:before`]: {
                                        flex: 0,
                                        padding: 0
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TimelineItem_default()), {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TimelineSeparator_default()), {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((TimelineDot_default()), {
                                                        color: "primary"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((TimelineConnector_default()), {})
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TimelineContent_default()), {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            variant: "body2",
                                                            children: "Tracking Number Created"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            color: "text.secondary",
                                                            variant: "caption",
                                                            children: vehicle.startedAt
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TimelineItem_default()), {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TimelineSeparator_default()), {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((TimelineDot_default()), {
                                                        color: "primary"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((TimelineConnector_default()), {})
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TimelineContent_default()), {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            variant: "body2",
                                                            children: "Out for Delivery"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            color: "text.secondary",
                                                            variant: "caption",
                                                            children: vehicle.departedAt
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TimelineItem_default()), {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((TimelineSeparator_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((TimelineDot_default()), {
                                                    color: "primary"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TimelineContent_default()), {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            variant: "body2",
                                                            children: "Arrived"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            color: "text.secondary",
                                                            variant: "caption",
                                                            children: vehicle.arrivedAt
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
LogisticsFleetVehicle.propTypes = {
    onDeselect: (prop_types_default()).func,
    onSelect: (prop_types_default()).func,
    selected: (prop_types_default()).bool,
    // @ts-ignore
    vehicle: (prop_types_default()).object.isRequired
};

;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-fleet-list.tsx





const LogisticsFleetList = (props)=>{
    const { onVehicleDeselect , onVehicleSelect , currentVehicleId , vehicles =[]  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
        component: "ul",
        divider: /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
        sx: {
            borderBottomColor: "divider",
            borderBottomStyle: "solid",
            borderBottomWidth: 1,
            listStyle: "none",
            m: 0,
            p: 0
        },
        children: vehicles.map((vehicle)=>{
            const selected = currentVehicleId ? currentVehicleId === vehicle.id : false;
            return /*#__PURE__*/ jsx_runtime_.jsx(LogisticsFleetVehicle, {
                onDeselect: onVehicleDeselect,
                onSelect: onVehicleSelect,
                selected: selected,
                vehicle: vehicle
            }, vehicle.id);
        })
    });
};
LogisticsFleetList.propTypes = {
    currentVehicleId: (prop_types_default()).string,
    onVehicleDeselect: (prop_types_default()).func,
    onVehicleSelect: (prop_types_default()).func,
    vehicles: (prop_types_default()).array
};

// EXTERNAL MODULE: ./node_modules/react-map-gl/dist/es5/index.js
var es5 = __webpack_require__(717028);
var es5_default = /*#__PURE__*/__webpack_require__.n(es5);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
// EXTERNAL MODULE: ./src/config.ts
var config = __webpack_require__(198103);
;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-fleet-map.tsx








// Map default view state
const VIEW_STATE = {
    latitude: 40.74281576586265,
    longitude: -73.99277240443942,
    zoom: 11
};
const LogisticsFleetMap = (props)=>{
    const { onVehicleSelect , currentVehicleId , vehicles =[]  } = props;
    const theme = (0,styles.useTheme)();
    const mapRef = (0,react_.useRef)(null);
    const [viewState] = (0,react_.useState)(()=>{
        if (!currentVehicleId) {
            return VIEW_STATE;
        } else {
            const vehicle = vehicles.find((vehicle)=>vehicle.id === currentVehicleId);
            if (!vehicle) {
                return VIEW_STATE;
            } else {
                return {
                    latitude: vehicle.latitude,
                    longitude: vehicle.longitude,
                    zoom: 13
                };
            }
        }
    });
    const handleRecenter = (0,react_.useCallback)(()=>{
        const map = mapRef.current;
        if (!map) {
            return;
        }
        let flyOptions;
        const vehicle = vehicles.find((vehicle)=>vehicle.id === currentVehicleId);
        if (!vehicle) {
            flyOptions = {
                center: [
                    VIEW_STATE.longitude,
                    VIEW_STATE.latitude
                ]
            };
        } else {
            flyOptions = {
                center: [
                    vehicle.longitude,
                    vehicle.latitude
                ]
            };
        }
        map.flyTo(flyOptions);
    }, [
        vehicles,
        currentVehicleId
    ]);
    // Recenter if vehicles or current vehicle change
    (0,react_.useEffect)(()=>{
        handleRecenter();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        vehicles,
        currentVehicleId
    ]);
    const mapStyle = theme.palette.mode === "dark" ? "mapbox://styles/mapbox/dark-v9" : "mapbox://styles/mapbox/light-v9";
    if (!config/* mapboxConfig.apiKey */.jZ.apiKey) {
        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
            sx: {
                alignItems: "center",
                display: "flex",
                flexDirection: "column",
                height: "100%",
                justifyContent: "center"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        mb: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        component: "img",
                        src: "/assets/errors/error-404.png",
                        sx: {
                            width: 200,
                            maxWidth: "100%"
                        }
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "h5",
                    sx: {
                        mb: 1
                    },
                    children: "Map cannot be loaded"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    variant: "subtitle2",
                    children: "Mapbox API Key is not configured."
                })
            ]
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx((es5_default()), {
        attributionControl: false,
        initialViewState: viewState,
        mapStyle: mapStyle,
        mapboxAccessToken: config/* mapboxConfig.apiKey */.jZ.apiKey,
        ref: mapRef,
        maxZoom: 20,
        minZoom: 11,
        children: vehicles.map((vehicle)=>/*#__PURE__*/ jsx_runtime_.jsx(es5.Marker, {
                latitude: vehicle.latitude,
                longitude: vehicle.longitude,
                onClick: ()=>onVehicleSelect?.(vehicle.id),
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        height: 50,
                        width: 50,
                        ...vehicle.id === currentVehicleId && {
                            filter: (theme)=>`drop-shadow(0px 0px 8px ${theme.palette.primary.main})`
                        },
                        "& img": {
                            height: "100%"
                        }
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                        src: "/assets/car-marker.png"
                    })
                })
            }, vehicle.id))
    });
};
LogisticsFleetMap.propTypes = {
    currentVehicleId: (prop_types_default()).string,
    onVehicleSelect: (prop_types_default()).func,
    vehicles: (prop_types_default()).array
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Menu01.js
var Menu01 = __webpack_require__(913629);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
;// CONCATENATED MODULE: ./src/sections/dashboard/logistics/logistics-fleet-toolbar.tsx







const LogisticsFleetToolbar = (props)=>{
    const { onDrawerOpen  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            left: 0,
            p: 2,
            pointerEvents: "none",
            position: "absolute",
            top: 0,
            width: "100%",
            zIndex: 10
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
            sx: {
                p: 2,
                pointerEvents: "auto"
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                onClick: onDrawerOpen,
                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Menu01/* default */.Z, {})
                })
            })
        })
    });
};
LogisticsFleetToolbar.propTypes = {
    onDrawerOpen: (prop_types_default()).func
};

;// CONCATENATED MODULE: ./src/app/(dashboard)/logistics/fleet/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 










const useVehicles = ()=>{
    return [
        {
            id: "VOL-653CD2",
            location: "New York, NY, USA",
            latitude: 40.74759625348667,
            longitude: -74.00422032706065,
            temp: "8\xb0C",
            startedAt: "Sep 01, 7:53 AM",
            departedAt: "Sep 01, 8:02 AM",
            arrivedAt: "Sep 01, 8:18 AM"
        },
        {
            id: "VOL-653CD3",
            location: "New York, NY, USA",
            latitude: 40.75374208987527,
            longitude: -74.02878378307403,
            temp: "6\xb0C",
            startedAt: "Sep 01, 8:21 AM",
            departedAt: "Sep 01, 8:36 AM",
            arrivedAt: "Sep 01, 9:54 AM"
        },
        {
            id: "VOL-653CD4",
            location: "New York, NY, USA",
            latitude: 40.765281069832085,
            longitude: -73.96392724511145,
            temp: "8\xb0C",
            startedAt: "Sep 01, 6:34 AM",
            departedAt: "Sep 01, 7:41 AM",
            arrivedAt: "Sep 01, 9:20 AM"
        }
    ];
};
const Page = ()=>{
    const rootRef = (0,react_.useRef)(null);
    const mdUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("md"));
    const vehicles = useVehicles();
    const [openDrawer, setOpenDrawer] = (0,react_.useState)(false);
    const [currentVehicleId, setCurrentVehicleId] = (0,react_.useState)(vehicles[0]?.id);
    const handleVehicleSelect = (0,react_.useCallback)((vehicleId)=>{
        setCurrentVehicleId(vehicleId);
    }, []);
    const handleVehicleDeselect = (0,react_.useCallback)(()=>{
        setCurrentVehicleId(undefined);
    }, []);
    const handleDrawerOpen = (0,react_.useCallback)(()=>{
        setOpenDrawer(true);
    }, []);
    const handleDrawerClose = (0,react_.useCallback)(()=>{
        setOpenDrawer(false);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: Logistics Fleet"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                component: "main",
                ref: rootRef,
                sx: {
                    display: "flex",
                    flex: "1 1 auto",
                    overflow: "hidden",
                    position: "relative"
                },
                children: [
                    mdUp && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                        sx: {
                            borderRightColor: "divider",
                            borderRightStyle: "solid",
                            borderRightWidth: 1,
                            flex: "0 0 400px"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    p: 2
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h5",
                                    children: "Fleet"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(LogisticsFleetList, {
                                currentVehicleId: currentVehicleId,
                                onVehicleDeselect: handleVehicleDeselect,
                                onVehicleSelect: handleVehicleSelect,
                                vehicles: vehicles
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                        sx: {
                            flex: "1 1 auto",
                            overflow: "hidden",
                            position: "relative"
                        },
                        children: [
                            !mdUp && /*#__PURE__*/ jsx_runtime_.jsx(LogisticsFleetToolbar, {
                                onDrawerOpen: handleDrawerOpen
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(LogisticsFleetMap, {
                                currentVehicleId: currentVehicleId,
                                onVehicleSelect: handleVehicleSelect,
                                vehicles: vehicles
                            })
                        ]
                    })
                ]
            }),
            !mdUp && /*#__PURE__*/ jsx_runtime_.jsx(LogisticsFleetDrawer, {
                container: rootRef.current,
                onClose: handleDrawerClose,
                open: openDrawer,
                children: /*#__PURE__*/ jsx_runtime_.jsx(LogisticsFleetList, {
                    currentVehicleId: currentVehicleId,
                    onVehicleDeselect: handleVehicleDeselect,
                    onVehicleSelect: handleVehicleSelect,
                    vehicles: vehicles
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 74374:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/logistics/fleet/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,3580,3171,9115,7028,7680,95,9494,2302], () => (__webpack_exec__(418302)));
module.exports = __webpack_exports__;

})();