(() => {
var exports = {};
exports.id = 552;
exports.ids = [552];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 188792:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'kanban',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 150227, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/kanban/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/kanban/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/kanban/page"
  

/***/ }),

/***/ 980628:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 683236))

/***/ }),

/***/ 683236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/react-beautiful-dnd/dist/react-beautiful-dnd.cjs.js
var react_beautiful_dnd_cjs = __webpack_require__(85926);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(333518);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
// EXTERNAL MODULE: ./node_modules/lodash.debounce/index.js
var lodash_debounce = __webpack_require__(261043);
var lodash_debounce_default = /*#__PURE__*/__webpack_require__.n(lodash_debounce);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Archive.js
var Archive = __webpack_require__(952097);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Eye.js
var Eye = __webpack_require__(800408);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/EyeOff.js
var EyeOff = __webpack_require__(134746);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Plus.js
var Plus = __webpack_require__(959309);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/X.js
var X = __webpack_require__(180501);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/AvatarGroup/index.js
var AvatarGroup = __webpack_require__(792438);
var AvatarGroup_default = /*#__PURE__*/__webpack_require__.n(AvatarGroup);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Chip/index.js
var Chip = __webpack_require__(829553);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Drawer/index.js
var Drawer = __webpack_require__(379499);
var Drawer_default = /*#__PURE__*/__webpack_require__.n(Drawer);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Input/index.js
var Input = __webpack_require__(378382);
var Input_default = /*#__PURE__*/__webpack_require__.n(Input);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tab/index.js
var Tab = __webpack_require__(189733);
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tabs/index.js
var Tabs = __webpack_require__(790206);
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/useMediaQuery/index.js
var useMediaQuery = __webpack_require__(975983);
// EXTERNAL MODULE: ./src/hooks/use-mocked-user.ts
var use_mocked_user = __webpack_require__(782851);
// EXTERNAL MODULE: ./src/store/index.ts + 2 modules
var store = __webpack_require__(754835);
// EXTERNAL MODULE: ./src/utils/create-resource-id.ts
var create_resource_id = __webpack_require__(17911);
// EXTERNAL MODULE: ./src/utils/deep-copy.ts
var deep_copy = __webpack_require__(846447);
;// CONCATENATED MODULE: ./src/api/kanban/data.ts

const now = new Date();
const board = {
    members: [
        {
            id: "5e86809283e28b96d2d38537",
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        {
            id: "5e887a62195cc5aef7e8ca5d",
            avatar: "/assets/avatars/avatar-marcus-finn.png",
            name: "Marcus Finn"
        },
        {
            id: "5e887ac47eed253091be10cb",
            avatar: "/assets/avatars/avatar-carson-darrin.png",
            name: "Carson Darrin"
        },
        {
            id: "5e887b209c28ac3dd97f6db5",
            avatar: "/assets/avatars/avatar-fran-perez.png",
            name: "Fran Perez"
        },
        {
            id: "5e887b7602bdbc4dbb234b27",
            avatar: "/assets/avatars/avatar-jie-yan-song.png",
            name: "Jie Yan Song"
        }
    ],
    columns: [
        {
            id: "5e849c39325dc5ef58e5a5db",
            taskIds: [
                "5e849c8708bd72683b454747",
                "5e849c90fabe1f1f4b3557f6",
                "5e849c977ef6265938bfd90b",
                "5e849c9e34ee93bc7255c599"
            ],
            name: "Todo"
        },
        {
            id: "5e849c2b38d238c33e516755",
            taskIds: [
                "5e849ca7d063dc3830d4b49c",
                "5e849cb5d0c6e8894451fdfa"
            ],
            name: "Progress"
        },
        {
            id: "5e849c2b38d238c33e5146755",
            taskIds: [],
            name: "Done"
        }
    ],
    tasks: [
        {
            id: "5e849c8708bd72683b454747",
            assigneesIds: [
                "5e887a62195cc5aef7e8ca5d"
            ],
            attachments: [
                {
                    id: "7191325744eca06bc6ad2219",
                    type: "image",
                    url: "/assets/covers/abstract-1-4x3-small.png"
                }
            ],
            authorId: "5e86809283e28b96d2d38537",
            checklists: [
                {
                    id: "5e84a8175c48d3f5b1d01972",
                    name: "Update overview page",
                    checkItems: [
                        {
                            id: "5e85af37da584c5e4bd8a06c",
                            name: "Prepare sketch",
                            state: "complete"
                        }
                    ]
                }
            ],
            comments: [
                {
                    id: "15e849c5a35d4dff4f88ebff6",
                    authorId: "5e887ac47eed253091be10cb",
                    createdAt: (0,date_fns.subDays)(now, 5).getTime(),
                    message: "This is a comment"
                }
            ],
            columnId: "5e849c39325dc5ef58e5a5db",
            description: "Duis condimentum lacus finibus felis pellentesque, ac auctor nibh fermentum. Duis sed dui ante. Phasellus id eros tincidunt, dictum lorem vitae, pellentesque sem. Aenean eu enim sit amet mauris rhoncus mollis. Sed enim turpis, porta a felis et, luctus faucibus nisi. Phasellus et metus fermentum, ultrices arcu aliquam, facilisis justo. Cras nunc nunc, elementum sed euismod ut, maximus eget nibh. Phasellus condimentum lorem neque. Vestibulum ante ipsum primis in faucibus orci luctus et ultrices posuere cubilia Curae; Fusce sagittis pharetra eleifend. Suspendisse potenti.",
            due: (0,date_fns.addDays)(now, 7).getTime(),
            isSubscribed: false,
            labels: [
                "Business",
                "Design"
            ],
            name: "Call with sales of HubSpot"
        },
        {
            id: "5e849c90fabe1f1f4b3557f6",
            assigneesIds: [
                "5e887b209c28ac3dd97f6db5",
                "5e887a62195cc5aef7e8ca5d"
            ],
            attachments: [],
            authorId: "5e887b209c28ac3dd97f6db5",
            checklists: [],
            columnId: "5e849c39325dc5ef58e5a5db",
            comments: [],
            description: "We are looking for vue experience and of course node js strong knowledge",
            due: (0,date_fns.addDays)(now, 6).getTime(),
            isSubscribed: true,
            labels: [],
            name: "Interview for the Asis. Sales Manager"
        },
        {
            id: "5e849c977ef6265938bfd90b",
            assigneesIds: [],
            attachments: [],
            authorId: "5e887b7602bdbc4dbb234b27",
            checklists: [],
            columnId: "5e849c39325dc5ef58e5a5db",
            comments: [],
            description: "We need to make it aggressive with pricing because it’s in their interest to acquire us",
            due: null,
            isSubscribed: false,
            labels: [],
            name: "Change the height of the top bar because it looks too chunky"
        },
        {
            id: "5e849c9e34ee93bc7255c599",
            assigneesIds: [
                "5e887ac47eed253091be10cb",
                "5e86809283e28b96d2d38537"
            ],
            attachments: [],
            authorId: "5e887a62195cc5aef7e8ca5d",
            checklists: [],
            columnId: "5e849c39325dc5ef58e5a5db",
            comments: [],
            description: "We need to make it aggressive with pricing because it’s in their interest to acquire us",
            due: null,
            isSubscribed: false,
            labels: [],
            name: "Integrate Stripe API"
        },
        {
            id: "5e849ca7d063dc3830d4b49c",
            assigneesIds: [
                "5e887a62195cc5aef7e8ca5d"
            ],
            attachments: [],
            authorId: "5e887ac47eed253091be10cb",
            checklists: [],
            columnId: "5e849c2b38d238c33e516755",
            comments: [],
            description: "We need to make it aggressive with pricing because it’s in their interest to acquire us",
            due: null,
            isSubscribed: true,
            labels: [],
            name: "Update the customer API for payments"
        },
        {
            id: "5e849cb5d0c6e8894451fdfa",
            assigneesIds: [],
            attachments: [],
            authorId: "5e887ac47eed253091be10cb",
            checklists: [],
            columnId: "5e849c2b38d238c33e516755",
            comments: [],
            description: "We need to make it aggressive with pricing because it’s in their interest to acquire us",
            due: null,
            isSubscribed: true,
            labels: [],
            name: "Redesign the landing page"
        }
    ]
};
const data = {
    board
};

;// CONCATENATED MODULE: ./src/api/kanban/index.ts



// On server get current identity (user) from the request
const user = {
    id: "5e86809283e28b96d2d38537",
    avatar: "/assets/avatars/avatar-anika-visser.png",
    name: "Anika Visser"
};
class KanbanApi {
    getBoard(request = {}) {
        return Promise.resolve((0,deep_copy/* deepCopy */.p)(data.board));
    }
    createColumn(request) {
        const { name  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Create the new column
                const column = {
                    id: (0,create_resource_id/* createResourceId */.h)(),
                    name,
                    taskIds: []
                };
                clonedBoard.columns.push(column);
                // Save changes
                data.board = clonedBoard;
                resolve((0,deep_copy/* deepCopy */.p)(column));
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    updateColumn(request) {
        const { columnId , update  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the column to clear
                const column = clonedBoard.columns.find((column)=>column.id === columnId);
                if (!column) {
                    reject(new Error("Column not found"));
                    return;
                }
                // Update the column
                Object.assign(column, update);
                // Save changes
                data.board = clonedBoard;
                resolve((0,deep_copy/* deepCopy */.p)(column));
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    clearColumn(request) {
        const { columnId  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the column to clear
                const column = clonedBoard.columns.find((column)=>column.id === columnId);
                if (!column) {
                    reject(new Error("Column not found"));
                    return;
                }
                // Remove the tasks with columnId reference
                clonedBoard.tasks = clonedBoard.tasks.filter((task)=>task.columnId !== columnId);
                // Remove all taskIds from the column
                column.taskIds = [];
                // Save changes
                data.board = clonedBoard;
                resolve(true);
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    deleteColumn(request) {
        const { columnId  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the column to remove
                const column = clonedBoard.columns.find((column)=>column.id === columnId);
                if (!column) {
                    reject(new Error("Column not found"));
                    return;
                }
                // Remove the tasks with columnId reference
                clonedBoard.tasks = clonedBoard.tasks.filter((task)=>task.columnId !== columnId);
                // Remove the column from the board
                clonedBoard.columns = clonedBoard.columns.filter((column)=>column.id !== columnId);
                // Save changes
                data.board = clonedBoard;
                resolve(true);
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    createTask(request) {
        const { columnId , name  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the column where the new task will be added
                const column = clonedBoard.columns.find((column)=>column.id === columnId);
                if (!column) {
                    reject(new Error("Column not found"));
                    return;
                }
                // Create the new task
                const task = {
                    id: (0,create_resource_id/* createResourceId */.h)(),
                    assigneesIds: [],
                    attachments: [],
                    authorId: user.id,
                    checklists: [],
                    columnId,
                    comments: [],
                    description: null,
                    due: null,
                    isSubscribed: false,
                    labels: [],
                    name
                };
                // Add the new task
                clonedBoard.tasks.push(task);
                // Add the taskId reference to the column
                column.taskIds.push(task.id);
                // Save changes
                data.board = clonedBoard;
                resolve((0,deep_copy/* deepCopy */.p)(task));
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    updateTask(request) {
        const { taskId , update  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the task that will be updated
                const task = clonedBoard.tasks.find((task)=>task.id === taskId);
                if (!task) {
                    reject(new Error("Task not found"));
                    return;
                }
                // Update the task
                Object.assign(task, update);
                // Save changes
                data.board = clonedBoard;
                resolve((0,deep_copy/* deepCopy */.p)(task));
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    moveTask(request) {
        const { taskId , position , columnId  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the task that will be moved
                const task = clonedBoard.tasks.find((task)=>task.id === taskId);
                if (!task) {
                    reject(new Error("Task not found"));
                    return;
                }
                // Find the source column of the task
                const sourceColumn = clonedBoard.columns.find((column)=>column.id === task.columnId);
                if (!sourceColumn) {
                    reject(new Error("Column not found"));
                    return;
                }
                // Remove the taskId reference from the source list
                sourceColumn.taskIds = sourceColumn.taskIds.filter((id)=>taskId !== id);
                if (!columnId) {
                    // If columnId is not provided, it means that we move the task in the same list
                    sourceColumn.taskIds.splice(position, 0, task.id);
                } else {
                    // Find the destination column for the task
                    const destinationColumn = clonedBoard.columns.find((column)=>column.id === columnId);
                    if (!destinationColumn) {
                        reject(new Error("Column not found"));
                        return;
                    }
                    // Add the taskId reference to the destination list
                    destinationColumn.taskIds.splice(position, 0, task.id);
                    // Store the new columnId reference
                    task.columnId = destinationColumn.id;
                }
                // Save changes
                data.board = clonedBoard;
                resolve(true);
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    deleteTask(request) {
        const { taskId  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the task that will be removed
                const task = clonedBoard.tasks.find((task)=>task.id === taskId);
                if (!task) {
                    reject(new Error("Task not found"));
                    return;
                }
                // Remove the task from board
                clonedBoard.tasks = clonedBoard.tasks.filter((task)=>task.id !== taskId);
                // Find the column using the columnId reference
                const column = clonedBoard.columns.find((column)=>column.id === task.columnId);
                // If for some reason it does not exist, there's no problem. Maybe something broke before.
                if (column) {
                    column.taskIds = column.taskIds.filter((_taskId)=>_taskId !== taskId);
                }
                // Save changes
                data.board = clonedBoard;
                resolve(true);
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    addComment(request) {
        const { taskId , message  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the task where the comment will be added
                const task = clonedBoard.tasks.find((task)=>task.id === taskId);
                if (!task) {
                    reject(new Error("Task not found"));
                    return;
                }
                // Create the new comment
                const comment = {
                    id: (0,create_resource_id/* createResourceId */.h)(),
                    authorId: user.id,
                    createdAt: new Date().getTime(),
                    message
                };
                // Add the new comment to task
                task.comments.push(comment);
                // Save changes
                data.board = clonedBoard;
                resolve((0,deep_copy/* deepCopy */.p)(comment));
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    addChecklist(request) {
        const { taskId , name  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the task where the checklist will be added
                const task = clonedBoard.tasks.find((task)=>task.id === taskId);
                if (!task) {
                    reject(new Error("Task not found"));
                    return;
                }
                // Create the new checklist
                const checklist = {
                    id: (0,create_resource_id/* createResourceId */.h)(),
                    name,
                    checkItems: []
                };
                // Add the new checklist to task
                task.checklists.push(checklist);
                // Save changes
                data.board = clonedBoard;
                resolve((0,deep_copy/* deepCopy */.p)(checklist));
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    updateChecklist(request) {
        const { taskId , checklistId , update  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the task that contains the checklist that will be updated
                const task = clonedBoard.tasks.find((task)=>task.id === taskId);
                if (!task) {
                    reject(new Error("Task not found"));
                    return;
                }
                // Find the checklist that will be updated
                const checklist = task.checklists.find((checklist)=>checklist.id === checklistId);
                if (!checklist) {
                    reject(new Error("Checklist not found"));
                    return;
                }
                // Update the checklist
                Object.assign(checklist, update);
                // Save changes
                data.board = clonedBoard;
                resolve((0,deep_copy/* deepCopy */.p)(checklist));
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    deleteChecklist(request) {
        const { taskId , checklistId  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the task that contains the checklist that will be removed
                const task = clonedBoard.tasks.find((task)=>task.id === taskId);
                if (!task) {
                    reject(new Error("Task not found"));
                    return;
                }
                // Remove the checklist from the task
                task.checklists = task.checklists.filter((checklists)=>checklists.id !== checklistId);
                // Save changes
                data.board = clonedBoard;
                resolve(true);
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    addCheckItem(request) {
        const { taskId , checklistId , name  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the task where the checklist will be added
                const task = clonedBoard.tasks.find((task)=>task.id === taskId);
                if (!task) {
                    reject(new Error("Task not found"));
                    return;
                }
                // Find the checklist where the check item will be added
                const checklist = task.checklists.find((checklist)=>checklist.id === checklistId);
                if (!checklist) {
                    reject(new Error("Checklist not found"));
                    return;
                }
                // Create the new check item
                const checkItem = {
                    id: (0,create_resource_id/* createResourceId */.h)(),
                    name,
                    state: "incomplete"
                };
                // Add the check item to the checklist
                checklist.checkItems.push(checkItem);
                // Save changes
                data.board = clonedBoard;
                resolve((0,deep_copy/* deepCopy */.p)(checkItem));
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    updateCheckItem(request) {
        const { taskId , checklistId , checkItemId , update  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the task where the checklist will be added
                const task = clonedBoard.tasks.find((task)=>task.id === taskId);
                if (!task) {
                    reject(new Error("Task not found"));
                    return;
                }
                // Find the checklist where the check item will be updated
                const checklist = task.checklists.find((checklist)=>checklist.id === checklistId);
                if (!checklist) {
                    reject(new Error("Checklist not found"));
                    return;
                }
                // Find the checklist where the check item will be updated
                const checkItem = checklist.checkItems.find((checkItem)=>checkItem.id === checkItemId);
                if (!checkItem) {
                    reject(new Error("Check item not found"));
                    return;
                }
                // Update the check item
                Object.assign(checkItem, update);
                // Save changes
                data.board = clonedBoard;
                resolve((0,deep_copy/* deepCopy */.p)(checkItem));
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    deleteCheckItem(request) {
        const { taskId , checklistId , checkItemId  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Make a deep copy
                const clonedBoard = (0,deep_copy/* deepCopy */.p)(data.board);
                // Find the task that contains the checklist that contains the check item that will be removed
                const task = clonedBoard.tasks.find((task)=>task.id === taskId);
                if (!task) {
                    reject(new Error("Task not found"));
                    return;
                }
                // Find the checklist where the check item will be updated
                const checklist = task.checklists.find((checklist)=>checklist.id === checklistId);
                if (!checklist) {
                    reject(new Error("Checklist not found"));
                    return;
                }
                // Remove the check item from the checklist
                checklist.checkItems = checklist.checkItems.filter((checkItem)=>checkItem.id !== checkItemId);
                // Save changes
                data.board = clonedBoard;
                resolve(true);
            } catch (err) {
                console.error("[Kanban Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
}
const kanbanApi = new KanbanApi();

// EXTERNAL MODULE: ./src/slices/kanban.ts
var kanban = __webpack_require__(424198);
;// CONCATENATED MODULE: ./src/thunks/kanban.ts


const getBoard = ()=>async (dispatch)=>{
        const data = await kanbanApi.getBoard();
        dispatch(kanban/* slice.actions.getBoard */.t.actions.getBoard(data));
    };
const createColumn = (params)=>async (dispatch)=>{
        const response = await kanbanApi.createColumn(params);
        dispatch(kanban/* slice.actions.createColumn */.t.actions.createColumn(response));
    };
const updateColumn = (params)=>async (dispatch)=>{
        const response = await kanbanApi.updateColumn(params);
        dispatch(kanban/* slice.actions.updateColumn */.t.actions.updateColumn(response));
    };
const clearColumn = (params)=>async (dispatch)=>{
        await kanbanApi.clearColumn(params);
        dispatch(kanban/* slice.actions.clearColumn */.t.actions.clearColumn(params.columnId));
    };
const deleteColumn = (params)=>async (dispatch)=>{
        await kanbanApi.deleteColumn(params);
        dispatch(kanban/* slice.actions.deleteColumn */.t.actions.deleteColumn(params.columnId));
    };
const createTask = (params)=>async (dispatch)=>{
        const response = await kanbanApi.createTask(params);
        dispatch(kanban/* slice.actions.createTask */.t.actions.createTask(response));
    };
const updateTask = (params)=>async (dispatch)=>{
        const response = await kanbanApi.updateTask(params);
        dispatch(kanban/* slice.actions.updateTask */.t.actions.updateTask(response));
    };
const moveTask = (params)=>async (dispatch)=>{
        await kanbanApi.moveTask(params);
        dispatch(kanban/* slice.actions.moveTask */.t.actions.moveTask(params));
    };
const deleteTask = (params)=>async (dispatch)=>{
        await kanbanApi.deleteTask(params);
        dispatch(kanban/* slice.actions.deleteTask */.t.actions.deleteTask(params.taskId));
    };
const addComment = (params)=>async (dispatch)=>{
        const response = await kanbanApi.addComment(params);
        dispatch(kanban/* slice.actions.addComment */.t.actions.addComment({
            taskId: params.taskId,
            comment: response
        }));
    };
const addChecklist = (params)=>async (dispatch)=>{
        const response = await kanbanApi.addChecklist(params);
        dispatch(kanban/* slice.actions.addChecklist */.t.actions.addChecklist({
            taskId: params.taskId,
            checklist: response
        }));
    };
const updateChecklist = (params)=>async (dispatch)=>{
        const response = await kanbanApi.updateChecklist(params);
        dispatch(kanban/* slice.actions.updateChecklist */.t.actions.updateChecklist({
            taskId: params.taskId,
            checklist: response
        }));
    };
const deleteChecklist = (params)=>async (dispatch)=>{
        await kanbanApi.deleteChecklist(params);
        dispatch(kanban/* slice.actions.deleteChecklist */.t.actions.deleteChecklist(params));
    };
const addCheckItem = (params)=>async (dispatch)=>{
        const response = await kanbanApi.addCheckItem(params);
        dispatch(kanban/* slice.actions.addCheckItem */.t.actions.addCheckItem({
            taskId: params.taskId,
            checklistId: params.checklistId,
            checkItem: response
        }));
    };
const updateCheckItem = (params)=>async (dispatch)=>{
        const response = await kanbanApi.updateCheckItem(params);
        dispatch(kanban/* slice.actions.updateCheckItem */.t.actions.updateCheckItem({
            taskId: params.taskId,
            checklistId: params.checklistId,
            checkItem: response
        }));
    };
const deleteCheckItem = (params)=>async (dispatch)=>{
        await kanbanApi.deleteCheckItem(params);
        dispatch(kanban/* slice.actions.deleteCheckItem */.t.actions.deleteCheckItem(params));
    };
const thunks = {
    addCheckItem,
    addChecklist,
    addComment,
    clearColumn,
    createColumn,
    createTask,
    deleteCheckItem,
    deleteChecklist,
    deleteColumn,
    deleteTask,
    getBoard,
    moveTask,
    updateCheckItem,
    updateChecklist,
    updateColumn,
    updateTask
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Trash02.js
var Trash02 = __webpack_require__(459074);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/LinearProgress/index.js
var LinearProgress = __webpack_require__(154003);
var LinearProgress_default = /*#__PURE__*/__webpack_require__.n(LinearProgress);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Checkbox/index.js
var Checkbox = __webpack_require__(63754);
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox);
;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/task-modal/task-check-item.tsx










const TaskCheckItem = (props)=>{
    const { checkItem , isRenaming =false , onCheck , onDelete , onRenameCancel , onRenameComplete , onRenameInit , onUncheck , ...other } = props;
    const [nameCopy, setNameCopy] = (0,react_.useState)(checkItem.name);
    const handleNameReset = (0,react_.useCallback)(()=>{
        setNameCopy(checkItem.name);
    }, [
        checkItem
    ]);
    (0,react_.useEffect)(()=>{
        handleNameReset();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        checkItem
    ]);
    const handleCheckChange = (0,react_.useCallback)((event)=>{
        if (event.target.checked) {
            onCheck?.();
        } else {
            onUncheck?.();
        }
    }, [
        onCheck,
        onUncheck
    ]);
    const handleNameChange = (0,react_.useCallback)((event)=>{
        setNameCopy(event.target.value);
    }, []);
    const handleRenameCancel = (0,react_.useCallback)(()=>{
        setNameCopy(checkItem.name);
        onRenameCancel?.();
    }, [
        checkItem,
        onRenameCancel
    ]);
    const handleRenameComplete = (0,react_.useCallback)(async ()=>{
        onRenameComplete?.(nameCopy);
    }, [
        nameCopy,
        onRenameComplete
    ]);
    const isChecked = checkItem.state === "complete";
    const isDashed = !isRenaming && isChecked;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        alignItems: "center",
        direction: "row",
        spacing: 1,
        sx: {
            px: 3,
            py: 1
        },
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                edge: "start",
                checked: isChecked,
                onChange: handleCheckChange
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                spacing: 2,
                sx: {
                    flexGrow: 1
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                        disableUnderline: true,
                        fullWidth: true,
                        onChange: handleNameChange,
                        onClick: onRenameInit,
                        sx: {
                            ...isDashed && {
                                textDecoration: "line-through"
                            },
                            "& .MuiInputBase-input": {
                                borderRadius: 1.5,
                                fontWeight: 500,
                                overflow: "hidden",
                                px: 2,
                                py: 1,
                                textOverflow: "ellipsis",
                                wordWrap: "break-word",
                                "&:hover, &:focus": {
                                    backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
                                    borderRadius: 1
                                }
                            }
                        },
                        value: nameCopy
                    }),
                    isRenaming ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                onClick: handleRenameComplete,
                                size: "small",
                                variant: "contained",
                                children: "Update"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                color: "inherit",
                                onClick: handleRenameCancel,
                                size: "small",
                                children: "Cancel"
                            })
                        ]
                    }) : /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        onClick: onDelete,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            fontSize: "small",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Trash02/* default */.Z, {})
                        })
                    })
                ]
            })
        ]
    });
};
TaskCheckItem.propTypes = {
    // @ts-ignore
    checkItem: (prop_types_default()).object.isRequired,
    isRenaming: (prop_types_default()).bool,
    onCheck: (prop_types_default()).func,
    onDelete: (prop_types_default()).func,
    onRenameCancel: (prop_types_default()).func,
    onRenameComplete: (prop_types_default()).func,
    onRenameInit: (prop_types_default()).func,
    onUncheck: (prop_types_default()).func
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/OutlinedInput/index.js
var OutlinedInput = __webpack_require__(877829);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput);
;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/task-modal/task-check-item-add.tsx








const TaskCheckItemAdd = (props)=>{
    const { onAdd , ...other } = props;
    const [isAdding, setIsAdding] = (0,react_.useState)(false);
    const [name, setName] = (0,react_.useState)("");
    const handleAdd = (0,react_.useCallback)(()=>{
        setIsAdding(true);
    }, []);
    const handleCancel = (0,react_.useCallback)(()=>{
        setIsAdding(false);
        setName("");
    }, []);
    const handleChange = (0,react_.useCallback)((event)=>{
        setName(event.target.value);
    }, []);
    const handleSave = (0,react_.useCallback)(async ()=>{
        if (!name) {
            return;
        }
        onAdd?.(name);
        setIsAdding(false);
        setName("");
    }, [
        name,
        onAdd
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        ...other,
        children: isAdding ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
            alignItems: "center",
            direction: "row",
            spacing: 2,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                    onChange: handleChange,
                    placeholder: "Add an item",
                    value: name,
                    sx: {
                        flexGrow: 1,
                        "& .MuiInputBase-input": {
                            px: 2,
                            py: 1
                        }
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                    onClick: handleSave,
                    size: "small",
                    variant: "contained",
                    children: "Add"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                    color: "inherit",
                    onClick: handleCancel,
                    size: "small",
                    children: "Cancel"
                })
            ]
        }) : /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
            color: "inherit",
            onClick: handleAdd,
            size: "small",
            startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
            }),
            children: "Add Item"
        })
    });
};
TaskCheckItemAdd.propTypes = {
    onAdd: (prop_types_default()).func
};

;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/task-modal/task-checklist.tsx
















const calculateProgress = (checkItems)=>{
    const totalCheckItems = checkItems.length;
    const completedCheckItems = checkItems.filter((checkItem)=>checkItem.state === "complete").length;
    const progress = totalCheckItems === 0 ? 100 : completedCheckItems / totalCheckItems * 100;
    return Math.round(progress);
};
const TaskChecklist = (props)=>{
    const { checklist , onCheckItemAdd , onCheckItemDelete , onCheckItemCheck , onCheckItemUncheck , onCheckItemRename , onDelete , onRename , ...other } = props;
    const [nameCopy, setNameCopy] = (0,react_.useState)(checklist.name);
    const [isRenaming, setIsRenaming] = (0,react_.useState)(false);
    // The current check item that is being renamed
    const [checkItemId, setCheckItemId] = (0,react_.useState)(null);
    const handleNameReset = (0,react_.useCallback)(()=>{
        setNameCopy(checklist.name);
    }, [
        checklist
    ]);
    (0,react_.useEffect)(()=>{
        handleNameReset();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        checklist
    ]);
    const handleNameChange = (0,react_.useCallback)((event)=>{
        setNameCopy(event.target.value);
    }, []);
    const handleRenameInit = (0,react_.useCallback)(()=>{
        setIsRenaming(true);
    }, []);
    const handleRenameCancel = (0,react_.useCallback)(()=>{
        setIsRenaming(false);
        setNameCopy(checklist.name);
    }, [
        checklist
    ]);
    const handleRenameComplete = (0,react_.useCallback)(async ()=>{
        if (!nameCopy || nameCopy === checklist.name) {
            setIsRenaming(false);
            setNameCopy(checklist.name);
            return;
        }
        setIsRenaming(false);
        onRename?.(nameCopy);
    }, [
        checklist,
        nameCopy,
        onRename
    ]);
    const handleCheckItemRenameInit = (0,react_.useCallback)((checkItemId)=>{
        setCheckItemId(checkItemId);
    }, []);
    const handleCheckItemRenameCancel = (0,react_.useCallback)(()=>{
        setCheckItemId(null);
    }, []);
    const handleCheckItemRenameComplete = (0,react_.useCallback)((checkItemId, name)=>{
        setCheckItemId(null);
        onCheckItemRename?.(checkItemId, name);
    }, [
        onCheckItemRename
    ]);
    // Maybe use memo to calculate the progress
    const progress = calculateProgress(checklist.checkItems);
    const hasCheckItems = checklist.checkItems.length > 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        variant: "outlined",
        ...other,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                spacing: 2,
                sx: {
                    p: 1
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                        disableUnderline: true,
                        fullWidth: true,
                        onChange: handleNameChange,
                        onClick: handleRenameInit,
                        sx: {
                            "& .MuiInputBase-input": {
                                borderRadius: 1.5,
                                fontWeight: 500,
                                overflow: "hidden",
                                px: 2,
                                py: 1,
                                textOverflow: "ellipsis",
                                wordWrap: "break-word",
                                "&:hover, &:focus": {
                                    backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
                                    borderRadius: 1
                                }
                            }
                        },
                        value: nameCopy
                    }),
                    isRenaming ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                onClick: handleRenameComplete,
                                size: "small",
                                variant: "contained",
                                children: "Save"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                color: "inherit",
                                onClick: handleRenameCancel,
                                size: "small",
                                children: "Cancel"
                            })
                        ]
                    }) : /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        onClick: onDelete,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            fontSize: "small",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Trash02/* default */.Z, {})
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                spacing: 2,
                sx: {
                    pb: 3,
                    pt: 2,
                    px: 3
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((LinearProgress_default()), {
                        color: "primary",
                        sx: {
                            borderRadius: 1,
                            flexGrow: 1,
                            height: 8,
                            [`& .${LinearProgress.linearProgressClasses.bar}`]: {
                                borderRadius: "inherit"
                            }
                        },
                        value: progress,
                        variant: "determinate"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                        color: "text.secondary",
                        variant: "body2",
                        children: [
                            progress,
                            "%"
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            hasCheckItems && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                        divider: /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                        spacing: 1,
                        children: checklist.checkItems.map((checkItem)=>{
                            const isRenaming = checkItemId === checkItem.id;
                            return /*#__PURE__*/ jsx_runtime_.jsx(TaskCheckItem, {
                                checkItem: checkItem,
                                onCheck: ()=>onCheckItemCheck?.(checkItem.id),
                                onDelete: ()=>onCheckItemDelete?.(checkItem.id),
                                onRenameCancel: handleCheckItemRenameCancel,
                                onRenameComplete: (name)=>handleCheckItemRenameComplete(checkItem.id, name),
                                onRenameInit: ()=>handleCheckItemRenameInit(checkItem.id),
                                onUncheck: ()=>onCheckItemUncheck?.(checkItem.id),
                                isRenaming: isRenaming
                            }, checkItem.id);
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {})
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    p: 1
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(TaskCheckItemAdd, {
                    onAdd: onCheckItemAdd
                })
            })
        ]
    });
};
TaskChecklist.propTypes = {
    // @ts-ignore
    checklist: (prop_types_default()).object.isRequired,
    onCheckItemAdd: (prop_types_default()).func,
    onCheckItemDelete: (prop_types_default()).func,
    onCheckItemCheck: (prop_types_default()).func,
    onCheckItemUncheck: (prop_types_default()).func,
    onCheckItemRename: (prop_types_default()).func,
    onDelete: (prop_types_default()).func,
    onRename: (prop_types_default()).func
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Paper/index.js
var Paper = __webpack_require__(427561);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper);
;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/task-modal/task-comment.tsx








const useAuthor = (authorId)=>{
    return (0,store/* useSelector */.v9)((state)=>{
        const { members  } = state.kanban;
        return members.byId[authorId] || null;
    });
};
const TaskComment = (props)=>{
    const { comment , ...other } = props;
    const author = useAuthor(comment.authorId);
    const avatar = author?.avatar || undefined;
    const createdAt = (0,date_fns.format)(comment.createdAt, "MMM dd, yyyy 'at' hh:mm a");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        alignItems: "flex-start",
        direction: "row",
        spacing: 2,
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                src: avatar
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                spacing: 1,
                sx: {
                    flexGrow: 1
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "subtitle2",
                        children: author?.name
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Paper_default()), {
                        sx: {
                            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.50",
                            p: 2
                        },
                        variant: "outlined",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "body2",
                            children: comment.message
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        color: "text.secondary",
                        component: "p",
                        variant: "caption",
                        children: createdAt
                    })
                ]
            })
        ]
    });
};
TaskComment.propTypes = {
    // @ts-ignore
    comment: prop_types_default().objectOf((prop_types_default()).any).isRequired
};

;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/task-modal/task-comment-add.tsx








const TaskCommentAdd = (props)=>{
    const { avatar , onAdd , ...other } = props;
    const [message, setMessage] = (0,react_.useState)("");
    const handleMessageChange = (0,react_.useCallback)((event)=>{
        setMessage(event.target.value);
    }, []);
    const handleSubmit = (0,react_.useCallback)(async (event)=>{
        event.preventDefault();
        if (!message) {
            return;
        }
        onAdd?.(message);
        setMessage("");
    }, [
        message,
        onAdd
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        alignItems: "flex-start",
        direction: "row",
        spacing: 2,
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                src: avatar
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                component: "form",
                onSubmit: handleSubmit,
                sx: {
                    flexGrow: 1
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                        fullWidth: true,
                        multiline: true,
                        onChange: handleMessageChange,
                        placeholder: "Write a comment...",
                        rows: 3,
                        size: "small",
                        value: message
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            display: "flex",
                            justifyContent: "flex-end",
                            mt: 3
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            size: "small",
                            type: "submit",
                            variant: "contained",
                            children: "Comment"
                        })
                    })
                ]
            })
        ]
    });
};
TaskCommentAdd.propTypes = {
    avatar: (prop_types_default()).string.isRequired,
    onAdd: (prop_types_default()).func
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Menu/index.js
var Menu = __webpack_require__(576650);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/MenuItem/index.js
var MenuItem = __webpack_require__(662360);
var MenuItem_default = /*#__PURE__*/__webpack_require__.n(MenuItem);
// EXTERNAL MODULE: ./src/hooks/use-popover.ts
var use_popover = __webpack_require__(69281);
;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/task-modal/task-labels.tsx











const options = [
    "Business",
    "Planning",
    "Frontend",
    "Design"
];
const TaskLabels = (props)=>{
    const { labels =[] , onChange  } = props;
    const popover = (0,use_popover/* usePopover */.S)();
    const availableOptions = (0,react_.useMemo)(()=>{
        return options.filter((option)=>!labels.includes(option));
    }, [
        labels
    ]);
    const handleDelete = (0,react_.useCallback)((label)=>{
        const newLabels = labels.filter((item)=>item !== label);
        onChange?.(newLabels);
    }, [
        labels,
        onChange
    ]);
    const handleToggle = (0,react_.useCallback)((label)=>{
        let newLabels;
        const found = labels.find((item)=>item === label);
        if (found) {
            newLabels = labels.filter((item)=>item !== label);
        } else {
            newLabels = [
                ...labels,
                label
            ];
        }
        popover.handleClose();
        onChange?.(newLabels);
    }, [
        labels,
        popover,
        onChange
    ]);
    const canAdd = availableOptions.length > 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                flexWrap: "wrap",
                gap: 1,
                children: [
                    labels.map((label)=>/*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                            label: label,
                            onDelete: ()=>handleDelete(label),
                            size: "small"
                        }, label)),
                    /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        onClick: popover.handleOpen,
                        ref: popover.anchorRef,
                        disabled: !canAdd,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            fontSize: "small",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Menu_default()), {
                anchorEl: popover.anchorRef.current,
                anchorOrigin: {
                    horizontal: "right",
                    vertical: "bottom"
                },
                onClose: popover.handleClose,
                open: popover.open,
                transformOrigin: {
                    horizontal: "right",
                    vertical: "top"
                },
                children: availableOptions.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                        onClick: ()=>handleToggle(option),
                        children: option
                    }, option))
            })
        ]
    });
};
TaskLabels.propTypes = {
    labels: prop_types_default().arrayOf((prop_types_default()).string.isRequired),
    onChange: (prop_types_default()).func
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronDown.js
var ChevronDown = __webpack_require__(870261);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ButtonGroup/index.js
var ButtonGroup = __webpack_require__(732105);
var ButtonGroup_default = /*#__PURE__*/__webpack_require__.n(ButtonGroup);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Popover/index.js
var Popover = __webpack_require__(980798);
var Popover_default = /*#__PURE__*/__webpack_require__.n(Popover);
;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/task-modal/task-status.tsx









const TaskStatus = (props)=>{
    const { onChange , options =[] , value  } = props;
    const popover = (0,use_popover/* usePopover */.S)();
    const [currentOption, setCurrentOption] = (0,react_.useState)(()=>{
        return options.find((option)=>option.value === value);
    });
    (0,react_.useEffect)(()=>{
        const option = options.find((option)=>option.value === value);
        setCurrentOption(option);
    }, [
        options,
        value
    ]);
    const handleOptionConfirm = (0,react_.useCallback)(()=>{
        if (!currentOption) {
            return;
        }
        onChange?.(currentOption.value);
    }, [
        currentOption,
        onChange
    ]);
    const handleOptionSelect = (0,react_.useCallback)((value)=>{
        const option = options.find((option)=>option.value === value);
        popover.handleClose();
        setCurrentOption(option);
    }, [
        options,
        popover
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonGroup_default()), {
                ref: popover.anchorRef,
                variant: "contained",
                size: "small",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Button_default()), {
                        onClick: handleOptionConfirm,
                        children: [
                            "Submit as ",
                            currentOption?.label
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        size: "small",
                        onClick: popover.handleToggle,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronDown/* default */.Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Popover_default()), {
                anchorEl: popover.anchorRef.current,
                disableScrollLock: true,
                onClose: popover.handleClose,
                open: popover.open,
                anchorOrigin: {
                    horizontal: "right",
                    vertical: "bottom"
                },
                transformOrigin: {
                    horizontal: "right",
                    vertical: "top"
                },
                children: options.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                        selected: option.value === value,
                        onClick: ()=>handleOptionSelect(option.value),
                        children: option.label
                    }, option.value))
            })
        ]
    });
};
TaskStatus.propTypes = {
    onChange: (prop_types_default()).func,
    options: (prop_types_default()).array,
    value: (prop_types_default()).string.isRequired
};

;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/task-modal/task-modal.tsx



































const useColumns = ()=>{
    return (0,store/* useSelector */.v9)((state)=>{
        const { columns  } = state.kanban;
        return Object.values(columns.byId);
    });
};
const useTask = (taskId)=>{
    return (0,store/* useSelector */.v9)((state)=>{
        const { tasks  } = state.kanban;
        if (!taskId) {
            return null;
        }
        return tasks.byId[taskId] || null;
    });
};
const useColumn = (columnId)=>{
    return (0,store/* useSelector */.v9)((state)=>{
        const { columns  } = state.kanban;
        if (!columnId) {
            return null;
        }
        return columns.byId[columnId] || null;
    });
};
const task_modal_useAuthor = (authorId)=>{
    return (0,store/* useSelector */.v9)((state)=>{
        const { members  } = state.kanban;
        if (!authorId) {
            return null;
        }
        return members.byId[authorId] || null;
    });
};
const useAssignees = (assigneesIds)=>{
    return (0,store/* useSelector */.v9)((state)=>{
        const { members  } = state.kanban;
        if (!assigneesIds) {
            return [];
        }
        return assigneesIds.map((assigneeId)=>members.byId[assigneeId]).filter((assignee)=>!!assignee);
    });
};
const TaskModal = (props)=>{
    const { taskId , onClose , open =false , ...other } = props;
    const user = (0,use_mocked_user/* useMockedUser */.I)();
    const dispatch = (0,store/* useDispatch */.I0)();
    const columns = useColumns();
    const task = useTask(taskId);
    const column = useColumn(task?.columnId);
    const author = task_modal_useAuthor(task?.authorId);
    const assignees = useAssignees(task?.assigneesIds);
    const mdUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("md"));
    const [currentTab, setCurrentTab] = (0,react_.useState)("overview");
    const [nameCopy, setNameCopy] = (0,react_.useState)(task?.name || "");
    const debounceMs = 500;
    const handleTabsReset = (0,react_.useCallback)(()=>{
        setCurrentTab("overview");
    }, []);
    // Reset tab on task change
    (0,react_.useEffect)(()=>{
        handleTabsReset();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        taskId
    ]);
    const handleNameReset = (0,react_.useCallback)(()=>{
        setNameCopy(task?.name || "");
    }, [
        task
    ]);
    // Reset task name copy
    (0,react_.useEffect)(()=>{
        handleNameReset();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        task
    ]);
    const handleTabsChange = (0,react_.useCallback)((event, value)=>{
        setCurrentTab(value);
    }, []);
    const handleMove = (0,react_.useCallback)(async (columnId)=>{
        try {
            await dispatch(thunks.moveTask({
                taskId: task.id,
                position: 0,
                columnId
            }));
            onClose?.();
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task,
        onClose
    ]);
    const handleDelete = (0,react_.useCallback)(async ()=>{
        try {
            await dispatch(thunks.deleteTask({
                taskId: task.id
            }));
            onClose?.();
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task,
        onClose
    ]);
    const handleNameUpdate = (0,react_.useCallback)(async (name)=>{
        try {
            await dispatch(thunks.updateTask({
                taskId: task.id,
                update: {
                    name
                }
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleNameBlur = (0,react_.useCallback)(()=>{
        if (!nameCopy) {
            setNameCopy(task.name);
            return;
        }
        if (nameCopy === task.name) {
            return;
        }
        handleNameUpdate(nameCopy);
    }, [
        task,
        nameCopy,
        handleNameUpdate
    ]);
    const handleNameChange = (0,react_.useCallback)((event)=>{
        setNameCopy(event.target.value);
    }, []);
    const handleNameKeyUp = (0,react_.useCallback)((event)=>{
        if (event.code === "Enter") {
            if (nameCopy && nameCopy !== task.name) {
                handleNameUpdate(nameCopy);
            }
        }
    }, [
        task,
        nameCopy,
        handleNameUpdate
    ]);
    const handleDescriptionUpdate = (0,react_.useMemo)(()=>lodash_debounce_default()(async (description)=>{
            try {
                await dispatch(thunks.updateTask({
                    taskId: task.id,
                    update: {
                        description
                    }
                }));
            } catch (err) {
                console.error(err);
                dist/* default.error */.ZP.error("Something went wrong!");
            }
        }, debounceMs), [
        dispatch,
        task
    ]);
    const handleDescriptionChange = (0,react_.useCallback)((event)=>{
        handleDescriptionUpdate(event.target.value);
    }, [
        handleDescriptionUpdate
    ]);
    const handleSubscribe = (0,react_.useCallback)(async ()=>{
        try {
            await dispatch(thunks.updateTask({
                taskId: task.id,
                update: {
                    isSubscribed: true
                }
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleUnsubscribe = (0,react_.useCallback)(async ()=>{
        try {
            await dispatch(thunks.updateTask({
                taskId: task.id,
                update: {
                    isSubscribed: false
                }
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleLabelsChange = (0,react_.useCallback)(async (labels)=>{
        try {
            await dispatch(thunks.updateTask({
                taskId: task.id,
                update: {
                    labels
                }
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleChecklistAdd = (0,react_.useCallback)(async ()=>{
        try {
            await dispatch(thunks.addChecklist({
                taskId: task.id,
                name: "Untitled Checklist"
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleChecklistRename = (0,react_.useCallback)(async (checklistId, name)=>{
        try {
            await dispatch(thunks.updateChecklist({
                taskId: task.id,
                checklistId,
                update: {
                    name
                }
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleChecklistDelete = (0,react_.useCallback)(async (checklistId)=>{
        try {
            await dispatch(thunks.deleteChecklist({
                taskId: task.id,
                checklistId
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleCheckItemAdd = (0,react_.useCallback)(async (checklistId, name)=>{
        try {
            await dispatch(thunks.addCheckItem({
                taskId: task.id,
                checklistId,
                name
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleCheckItemDelete = (0,react_.useCallback)(async (checklistId, checkItemId)=>{
        try {
            await dispatch(thunks.deleteCheckItem({
                taskId: task.id,
                checklistId,
                checkItemId
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleCheckItemCheck = (0,react_.useCallback)(async (checklistId, checkItemId)=>{
        try {
            await dispatch(thunks.updateCheckItem({
                taskId: task.id,
                checklistId,
                checkItemId,
                update: {
                    state: "complete"
                }
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleCheckItemUncheck = (0,react_.useCallback)(async (checklistId, checkItemId)=>{
        try {
            await dispatch(thunks.updateCheckItem({
                taskId: task.id,
                checklistId,
                checkItemId,
                update: {
                    state: "incomplete"
                }
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleCheckItemRename = (0,react_.useCallback)(async (checklistId, checkItemId, name)=>{
        try {
            await dispatch(thunks.updateCheckItem({
                taskId: task.id,
                checklistId,
                checkItemId,
                update: {
                    name
                }
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const handleCommentAdd = (0,react_.useCallback)(async (message)=>{
        try {
            await dispatch(thunks.addComment({
                taskId: task.id,
                message
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch,
        task
    ]);
    const statusOptions = (0,react_.useMemo)(()=>{
        return columns.map((column)=>{
            return {
                label: column.name,
                value: column.id
            };
        });
    }, [
        columns
    ]);
    const content = task && column ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: {
                    sm: "center"
                },
                direction: {
                    xs: "column-reverse",
                    sm: "row"
                },
                justifyContent: {
                    sm: "space-between"
                },
                spacing: 1,
                sx: {
                    p: 3
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(TaskStatus, {
                            onChange: (columnId)=>handleMove(columnId),
                            options: statusOptions,
                            value: column.id
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        justifyContent: "flex-end",
                        alignItems: "center",
                        direction: "row",
                        spacing: 1,
                        children: [
                            task.isSubscribed ? /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: handleUnsubscribe,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(EyeOff/* default */.Z, {})
                                })
                            }) : /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: handleSubscribe,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Eye/* default */.Z, {})
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: handleDelete,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Archive/* default */.Z, {})
                                })
                            }),
                            !mdUp && /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: onClose,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(X/* default */.Z, {})
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    px: 1
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                    disableUnderline: true,
                    fullWidth: true,
                    onBlur: handleNameBlur,
                    onChange: handleNameChange,
                    onKeyUp: handleNameKeyUp,
                    placeholder: "Task name",
                    sx: (theme)=>({
                            ...theme.typography.h6,
                            "& .MuiInputBase-input": {
                                borderRadius: 1.5,
                                overflow: "hidden",
                                px: 2,
                                py: 1,
                                textOverflow: "ellipsis",
                                wordWrap: "break-word",
                                "&:hover, &:focus": {
                                    backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100"
                                }
                            }
                        }),
                    value: nameCopy
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Tabs_default()), {
                onChange: handleTabsChange,
                sx: {
                    px: 3
                },
                value: currentTab,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                        value: "overview",
                        label: "Overview"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                        value: "checklists",
                        label: "Checklists"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                        value: "comments",
                        label: "Comments"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                sx: {
                    p: 3
                },
                children: [
                    currentTab === "overview" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                        container: true,
                        spacing: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "caption",
                                    children: "Created by"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 8,
                                children: author && /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                    src: author.avatar || undefined
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "caption",
                                    children: "Assigned to"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 8,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    flexWrap: "wrap",
                                    spacing: 1,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((AvatarGroup_default()), {
                                            max: 5,
                                            children: assignees.map((assignee)=>/*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                    src: assignee.avatar || undefined
                                                }, assignee.id))
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                            disabled: true,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                fontSize: "small",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "caption",
                                    children: "Attachments"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 8,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    flexWrap: "wrap",
                                    spacing: 1,
                                    children: [
                                        task.attachments.map((attachment)=>/*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                src: attachment.url || undefined,
                                                sx: {
                                                    height: 64,
                                                    width: 64
                                                },
                                                variant: "rounded"
                                            }, attachment.id)),
                                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                            disabled: true,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                fontSize: "small",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "caption",
                                    children: "Due date"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 8,
                                children: task.due && /*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                                    size: "small",
                                    label: (0,date_fns.format)(task.due, "MMM dd, yyyy")
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "caption",
                                    children: "Labels"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 8,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(TaskLabels, {
                                    labels: task.labels,
                                    onChange: handleLabelsChange
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "caption",
                                    children: "Description"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 8,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                                    defaultValue: task.description,
                                    fullWidth: true,
                                    multiline: true,
                                    disableUnderline: true,
                                    onChange: handleDescriptionChange,
                                    placeholder: "Leave a message",
                                    rows: 6,
                                    sx: {
                                        borderColor: "divider",
                                        borderRadius: 1,
                                        borderStyle: "solid",
                                        borderWidth: 1,
                                        p: 1
                                    }
                                })
                            })
                        ]
                    }),
                    currentTab === "checklists" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        spacing: 2,
                        children: [
                            task.checklists.map((checklist)=>/*#__PURE__*/ jsx_runtime_.jsx(TaskChecklist, {
                                    checklist: checklist,
                                    onCheckItemAdd: (name)=>handleCheckItemAdd(checklist.id, name),
                                    onCheckItemDelete: (checkItemId)=>handleCheckItemDelete(checklist.id, checkItemId),
                                    onCheckItemCheck: (checkItemId)=>handleCheckItemCheck(checklist.id, checkItemId),
                                    onCheckItemUncheck: (checkItemId)=>handleCheckItemUncheck(checklist.id, checkItemId),
                                    onCheckItemRename: (checkItemId, name)=>handleCheckItemRename(checklist.id, checkItemId, name),
                                    onDelete: ()=>handleChecklistDelete(checklist.id),
                                    onRename: (name)=>handleChecklistRename(checklist.id, name)
                                }, checklist.id)),
                            /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                                }),
                                onClick: handleChecklistAdd,
                                variant: "contained",
                                children: "Add"
                            })
                        ]
                    }),
                    currentTab === "comments" && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        spacing: 2,
                        children: [
                            task.comments.map((comment)=>/*#__PURE__*/ jsx_runtime_.jsx(TaskComment, {
                                    comment: comment
                                }, comment.id)),
                            /*#__PURE__*/ jsx_runtime_.jsx(TaskCommentAdd, {
                                avatar: user.avatar,
                                onAdd: handleCommentAdd
                            })
                        ]
                    })
                ]
            })
        ]
    }) : null;
    return /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
        anchor: "right",
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                width: "100%",
                maxWidth: 500
            }
        },
        ...other,
        children: content
    });
};
TaskModal.propTypes = {
    onClose: (prop_types_default()).func,
    open: (prop_types_default()).bool,
    taskId: (prop_types_default()).string
};

;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/task-modal/index.ts


;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/task-add.tsx











const TaskAdd = (props)=>{
    const { onAdd , ...other } = props;
    const [isAdding, setIsAdding] = (0,react_.useState)(false);
    const [name, setName] = (0,react_.useState)("");
    const handleNameChange = (0,react_.useCallback)((event)=>{
        setName(event.target.value);
    }, []);
    const handleAddInit = (0,react_.useCallback)(()=>{
        setIsAdding(true);
    }, []);
    const handleAddCancel = (0,react_.useCallback)(()=>{
        setIsAdding(false);
        setName("");
    }, []);
    const handleAddConfirm = (0,react_.useCallback)(async ()=>{
        onAdd?.(name);
        setIsAdding(false);
        setName("");
    }, [
        name,
        onAdd
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "background.paper"
        },
        ...other,
        children: isAdding ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
            sx: {
                p: 2
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                    autoFocus: true,
                    fullWidth: true,
                    placeholder: "My new task",
                    name: "name",
                    onChange: handleNameChange,
                    sx: {
                        "& .MuiInputBase-input": {
                            px: 2,
                            py: 1
                        }
                    },
                    value: name
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    spacing: 2,
                    sx: {
                        mt: 2
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            onClick: handleAddConfirm,
                            size: "small",
                            startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                            }),
                            variant: "contained",
                            children: "Add Task"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            onClick: handleAddCancel,
                            size: "small",
                            children: "Cancel"
                        })
                    ]
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
            alignItems: "center",
            direction: "row",
            onClick: handleAddInit,
            spacing: 1,
            sx: {
                cursor: "pointer",
                p: 2,
                userSelect: "none"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                    color: "action",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    variant: "subtitle1",
                    children: "Add Task"
                })
            ]
        })
    });
};
TaskAdd.propTypes = {
    onAdd: (prop_types_default()).func
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/FileCheck03.js
var FileCheck03 = __webpack_require__(429283);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/List.js
var List = __webpack_require__(455978);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/MessageDotsCircle.js
var MessageDotsCircle = __webpack_require__(807421);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardMedia/index.js
var CardMedia = __webpack_require__(823359);
var CardMedia_default = /*#__PURE__*/__webpack_require__.n(CardMedia);
;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/task-card.tsx

















const task_card_useTask = (taskId)=>{
    return (0,store/* useSelector */.v9)((state)=>{
        const { tasks  } = state.kanban;
        return tasks.byId[taskId];
    });
};
const task_card_useAssignees = (assigneesIds)=>{
    return (0,store/* useSelector */.v9)((state)=>{
        const { members  } = state.kanban;
        if (!assigneesIds) {
            return [];
        }
        return assigneesIds.map((assigneeId)=>members.byId[assigneeId]).filter((assignee)=>!!assignee);
    });
};
const TaskCard = /*#__PURE__*/ (0,react_.forwardRef)(function TaskCard(props, ref) {
    const { taskId , dragging =false , onOpen , ...other } = props;
    const task = task_card_useTask(taskId);
    const assignees = task_card_useAssignees(task?.assigneesIds);
    if (!task) {
        return null;
    }
    const hasAssignees = task.assigneesIds.length > 0;
    const hasAttachments = task.attachments.length > 0;
    const hasChecklists = task.checklists.length > 0;
    const hasComments = task.comments.length > 0;
    const hasLabels = task.labels.length > 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        elevation: dragging ? 8 : 1,
        onClick: onOpen,
        ref: ref,
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "background.paper",
            ...dragging && {
                backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "background.paper"
            },
            p: 3,
            userSelect: "none",
            "&:hover": {
                backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.700" : "neutral.50"
            },
            "&.MuiPaper-elevation1": {
                boxShadow: 1
            }
        },
        ...other,
        children: [
            hasAttachments && /*#__PURE__*/ jsx_runtime_.jsx((CardMedia_default()), {
                image: task.attachments[0].url,
                sx: {
                    borderRadius: 1.5,
                    height: 120,
                    mb: 1
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                variant: "subtitle1",
                children: task.name
            }),
            hasLabels && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    alignItems: "center",
                    display: "flex",
                    flexWrap: "wrap",
                    m: -1,
                    mt: 1
                },
                children: task.labels.map((label)=>/*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                        label: label,
                        size: "small",
                        sx: {
                            m: 1
                        }
                    }, label))
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                justifyContent: "space-between",
                spacing: 2,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 2,
                        sx: {
                            mt: 2
                        },
                        children: [
                            task.isSubscribed && /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                color: "action",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Eye/* default */.Z, {})
                            }),
                            hasAttachments && /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                color: "action",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(FileCheck03/* default */.Z, {})
                            }),
                            hasChecklists && /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                color: "action",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(List/* default */.Z, {})
                            }),
                            hasComments && /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                color: "action",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(MessageDotsCircle/* default */.Z, {})
                            })
                        ]
                    }),
                    hasAssignees && /*#__PURE__*/ jsx_runtime_.jsx((AvatarGroup_default()), {
                        max: 3,
                        children: assignees.map((assignee)=>/*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                src: assignee.avatar || undefined
                            }, assignee.id))
                    })
                ]
            })
        ]
    });
});
TaskCard.propTypes = {
    taskId: (prop_types_default()).string.isRequired,
    dragging: (prop_types_default()).bool,
    onOpen: (prop_types_default()).func
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/DotsHorizontal.js
var DotsHorizontal = __webpack_require__(66519);
;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/column-card/column-header.tsx












const ColumnHeader = (props)=>{
    const { tasksCount , name , onClear , onDelete , onRename  } = props;
    const popover = (0,use_popover/* usePopover */.S)();
    const [nameCopy, setNameCopy] = (0,react_.useState)(name);
    const handleNameReset = (0,react_.useCallback)(()=>{
        setNameCopy(name);
    }, [
        name
    ]);
    (0,react_.useEffect)(()=>{
        handleNameReset();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        name
    ]);
    const handleNameBlur = (0,react_.useCallback)(()=>{
        if (!nameCopy) {
            setNameCopy(name);
            return;
        }
        if (nameCopy === name) {
            return;
        }
        onRename?.(nameCopy);
    }, [
        nameCopy,
        name,
        onRename
    ]);
    const handleNameChange = (0,react_.useCallback)((event)=>{
        setNameCopy(event.target.value);
    }, []);
    const handleNameKeyUp = (0,react_.useCallback)((event)=>{
        if (event.code === "Enter") {
            if (nameCopy && nameCopy !== name) {
                onRename?.(nameCopy);
            }
        }
    }, [
        nameCopy,
        name,
        onRename
    ]);
    const handleClear = (0,react_.useCallback)(()=>{
        popover.handleClose();
        onClear?.();
    }, [
        popover,
        onClear
    ]);
    const handleDelete = (0,react_.useCallback)(()=>{
        popover.handleClose();
        onDelete?.();
    }, [
        popover,
        onDelete
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                justifyContent: "space-between",
                spacing: 2,
                sx: {
                    pr: 2,
                    py: 1
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                        disableUnderline: true,
                        fullWidth: true,
                        onBlur: handleNameBlur,
                        onChange: handleNameChange,
                        onKeyUp: handleNameKeyUp,
                        placeholder: "Column Name",
                        sx: {
                            "& .MuiInputBase-input": {
                                borderRadius: 1.5,
                                fontWeight: 500,
                                overflow: "hidden",
                                px: 2,
                                py: 1,
                                textOverflow: "ellipsis",
                                wordWrap: "break-word",
                                "&:hover, &:focus": {
                                    backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100"
                                }
                            }
                        },
                        value: nameCopy
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                                label: tasksCount
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                edge: "end",
                                onClick: popover.handleOpen,
                                ref: popover.anchorRef,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Menu_default()), {
                anchorEl: popover.anchorRef.current,
                anchorOrigin: {
                    horizontal: "center",
                    vertical: "bottom"
                },
                keepMounted: true,
                onClose: popover.handleClose,
                open: popover.open,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                        onClick: handleClear,
                        children: "Clear"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                        onClick: handleDelete,
                        children: "Delete"
                    })
                ]
            })
        ]
    });
};
ColumnHeader.propTypes = {
    tasksCount: (prop_types_default()).number.isRequired,
    name: (prop_types_default()).string.isRequired,
    onClear: (prop_types_default()).func,
    onDelete: (prop_types_default()).func,
    onRename: (prop_types_default()).func
};

;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/column-card/column-card.tsx








const column_card_useColumn = (columnId)=>{
    return (0,store/* useSelector */.v9)((state)=>{
        const { columns  } = state.kanban;
        return columns.byId[columnId];
    });
};
const ColumnCard = (props)=>{
    const { columnId , onTaskAdd , onTaskOpen , onClear , onDelete , onRename , ...other } = props;
    const column = column_card_useColumn(columnId);
    if (!column) {
        return null;
    }
    const tasksCount = column.taskIds.length;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
        sx: {
            display: "flex",
            flexDirection: "column",
            maxHeight: "100%",
            overflowX: "hidden",
            overflowY: "hidden",
            width: {
                xs: 300,
                sm: 380
            }
        },
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ColumnHeader, {
                name: column.name,
                onClear: onClear,
                onDelete: onDelete,
                onRename: onRename,
                tasksCount: tasksCount
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                sx: {
                    backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.900" : "neutral.100",
                    borderRadius: 2.5
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(react_beautiful_dnd_cjs/* Droppable */.bK, {
                        droppableId: column.id,
                        type: "task",
                        children: (droppableProvider)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                ref: droppableProvider.innerRef,
                                sx: {
                                    flexGrow: 1,
                                    minHeight: 80,
                                    overflowY: "auto",
                                    px: 3,
                                    pt: 1.5
                                },
                                children: [
                                    column?.taskIds.map((taskId, index)=>/*#__PURE__*/ jsx_runtime_.jsx(react_beautiful_dnd_cjs/* Draggable */._l, {
                                            draggableId: taskId,
                                            index: index,
                                            children: (draggableProvided, snapshot)=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                    ref: draggableProvided.innerRef,
                                                    style: {
                                                        ...draggableProvided.draggableProps.style
                                                    },
                                                    sx: {
                                                        outline: "none",
                                                        py: 1.5
                                                    },
                                                    ...draggableProvided.draggableProps,
                                                    ...draggableProvided.dragHandleProps,
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(TaskCard, {
                                                        dragging: snapshot.isDragging,
                                                        onOpen: ()=>onTaskOpen?.(taskId),
                                                        taskId: taskId
                                                    }, taskId)
                                                })
                                        }, taskId)),
                                    droppableProvider.placeholder
                                ]
                            })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            pt: 1.5,
                            pb: 3,
                            px: 3
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(TaskAdd, {
                            onAdd: onTaskAdd
                        })
                    })
                ]
            })
        ]
    });
};
ColumnCard.propTypes = {
    columnId: (prop_types_default()).string.isRequired,
    onClear: (prop_types_default()).func,
    onDelete: (prop_types_default()).func,
    onRename: (prop_types_default()).func,
    onTaskAdd: (prop_types_default()).func,
    onTaskOpen: (prop_types_default()).func
};

;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/column-card/index.ts


;// CONCATENATED MODULE: ./src/sections/dashboard/kanban/column-add.tsx










const ColumnAdd = (props)=>{
    const { onAdd , ...other } = props;
    const [isAdding, setIsAdding] = (0,react_.useState)(false);
    const [name, setName] = (0,react_.useState)("");
    const handleChange = (0,react_.useCallback)((event)=>{
        setName(event.target.value);
    }, []);
    const handleAddInit = (0,react_.useCallback)(()=>{
        setIsAdding(true);
    }, []);
    const handleAddCancel = (0,react_.useCallback)(()=>{
        setIsAdding(false);
        setName("");
    }, []);
    const handleAddConfirm = (0,react_.useCallback)(async ()=>{
        onAdd?.(name);
        setIsAdding(false);
        setName("");
    }, [
        name,
        onAdd
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            borderRadius: 2.5,
            mt: 7,
            mx: 1,
            width: {
                sm: 380,
                xs: 300
            }
        },
        ...other,
        children: isAdding ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
            sx: {
                p: 2
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                    autoFocus: true,
                    fullWidth: true,
                    placeholder: "My new column",
                    name: "name",
                    onChange: handleChange,
                    value: name,
                    sx: {
                        "& .MuiInputBase-input": {
                            px: 2,
                            py: 1
                        }
                    }
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                    sx: {
                        alignItems: "center",
                        display: "flex",
                        mt: 2
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            onClick: handleAddConfirm,
                            size: "small",
                            startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                            }),
                            variant: "contained",
                            children: "Add Column"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            onClick: handleAddCancel,
                            size: "small",
                            sx: {
                                ml: 2
                            },
                            children: "Cancel"
                        })
                    ]
                })
            ]
        }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
            alignItems: "center",
            direction: "row",
            onClick: handleAddInit,
            spacing: 1,
            sx: {
                cursor: "pointer",
                p: 2,
                userSelect: "none"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                    color: "action",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    variant: "subtitle1",
                    children: "Add Column"
                })
            ]
        })
    });
};
ColumnAdd.propTypes = {
    onAdd: (prop_types_default()).func
};

;// CONCATENATED MODULE: ./src/app/(dashboard)/kanban/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 













const useColumnsIds = ()=>{
    const { columns  } = (0,store/* useSelector */.v9)((state)=>state.kanban);
    return columns.allIds;
};
const useBoard = ()=>{
    const dispatch = (0,store/* useDispatch */.I0)();
    const handleBoardGet = (0,react_.useCallback)(()=>{
        dispatch(thunks.getBoard());
    }, [
        dispatch
    ]);
    (0,react_.useEffect)(()=>{
        handleBoardGet();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []);
};
const Page = ()=>{
    const dispatch = (0,store/* useDispatch */.I0)();
    const columnsIds = useColumnsIds();
    const [currentTaskId, setCurrentTaskId] = (0,react_.useState)(null);
    (0,use_page_view/* usePageView */.a)();
    useBoard();
    const handleDragEnd = (0,react_.useCallback)(async ({ source , destination , draggableId  })=>{
        try {
            // Dropped outside the column
            if (!destination) {
                return;
            }
            // Task has not been moved
            if (source.droppableId === destination.droppableId && source.index === destination.index) {
                return;
            }
            if (source.droppableId === destination.droppableId) {
                // Moved to the same column on different position
                await dispatch(thunks.moveTask({
                    taskId: draggableId,
                    position: destination.index
                }));
            } else {
                // Moved to another column
                await dispatch(thunks.moveTask({
                    taskId: draggableId,
                    position: destination.index,
                    columnId: destination.droppableId
                }));
            }
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch
    ]);
    const handleColumnAdd = (0,react_.useCallback)(async (name)=>{
        try {
            await dispatch(thunks.createColumn({
                name: name || "Untitled Column"
            }));
            dist/* default.success */.ZP.success("Column created");
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch
    ]);
    const handleColumnClear = (0,react_.useCallback)(async (columnId)=>{
        try {
            await dispatch(thunks.clearColumn({
                columnId
            }));
            dist/* default.success */.ZP.success("Column cleared");
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch
    ]);
    const handleColumnDelete = (0,react_.useCallback)(async (columnId)=>{
        try {
            await dispatch(thunks.deleteColumn({
                columnId
            }));
            dist/* default.success */.ZP.success("Column deleted");
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch
    ]);
    const handleColumnRename = (0,react_.useCallback)(async (columnId, name)=>{
        try {
            await dispatch(thunks.updateColumn({
                columnId,
                update: {
                    name
                }
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch
    ]);
    const handleTaskAdd = (0,react_.useCallback)(async (columnId, name)=>{
        try {
            await dispatch(thunks.createTask({
                columnId,
                name: name || "Untitled Task"
            }));
        } catch (err) {
            console.error(err);
            dist/* default.error */.ZP.error("Something went wrong!");
        }
    }, [
        dispatch
    ]);
    const handleTaskOpen = (0,react_.useCallback)((taskId)=>{
        setCurrentTaskId(taskId);
    }, []);
    const handleTaskClose = (0,react_.useCallback)(()=>{
        setCurrentTaskId(null);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: Kanban"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                component: "main",
                sx: {
                    display: "flex",
                    flexDirection: "column",
                    flexGrow: 1,
                    overflow: "hidden",
                    pt: 8
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            px: 3
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "h4",
                            children: "Kanban"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(react_beautiful_dnd_cjs/* DragDropContext */.Z5, {
                        onDragEnd: handleDragEnd,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                display: "flex",
                                flexGrow: 1,
                                flexShrink: 1,
                                overflowX: "auto",
                                overflowY: "hidden",
                                px: 3,
                                py: 3
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                alignItems: "flex-start",
                                direction: "row",
                                spacing: 3,
                                children: [
                                    columnsIds.map((columnId)=>/*#__PURE__*/ jsx_runtime_.jsx(ColumnCard, {
                                            columnId: columnId,
                                            onClear: ()=>handleColumnClear(columnId),
                                            onDelete: ()=>handleColumnDelete(columnId),
                                            onRename: (name)=>handleColumnRename(columnId, name),
                                            onTaskAdd: (name)=>handleTaskAdd(columnId, name),
                                            onTaskOpen: handleTaskOpen
                                        }, columnId)),
                                    /*#__PURE__*/ jsx_runtime_.jsx(ColumnAdd, {
                                        onAdd: handleColumnAdd
                                    })
                                ]
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(TaskModal, {
                onClose: handleTaskClose,
                open: !!currentTaskId,
                taskId: currentTaskId || undefined
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 17911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ createResourceId)
/* harmony export */ });
const createResourceId = ()=>{
    const arr = new Uint8Array(12);
    window.crypto.getRandomValues(arr);
    return Array.from(arr, (v)=>v.toString(16).padStart(2, "0")).join("");
};


/***/ }),

/***/ 846447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ deepCopy)
/* harmony export */ });
// eslint-disable-next-line consistent-return
function deepCopy(obj) {
    if (typeof obj !== "object" || obj === null) {
        return obj;
    }
    if (obj instanceof Date) {
        return new Date(obj.getTime());
    }
    if (obj instanceof Array) {
        return obj.reduce((arr, item, index)=>{
            arr[index] = deepCopy(item);
            return arr;
        }, []);
    }
    if (obj instanceof Object) {
        return Object.keys(obj).reduce((newObj, key)=>{
            newObj[key] = deepCopy(obj[key]);
            return newObj;
        }, {});
    }
}


/***/ }),

/***/ 150227:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/kanban/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,6519,9074,408,9283,5978,4440,7680,95,9494,2302,2851], () => (__webpack_exec__(188792)));
module.exports = __webpack_exports__;

})();