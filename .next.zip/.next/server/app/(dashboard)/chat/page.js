(() => {
var exports = {};
exports.id = 7640;
exports.ids = [7640];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 444140:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'chat',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 797668, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/chat/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/chat/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/chat/page"
  

/***/ }),

/***/ 111569:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 26903))

/***/ }),

/***/ 26903:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Menu01.js
var Menu01 = __webpack_require__(913629);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/useMediaQuery/index.js
var useMediaQuery = __webpack_require__(975983);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/hooks/use-search-params.ts
var use_search_params = __webpack_require__(82365);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
;// CONCATENATED MODULE: ./src/sections/dashboard/chat/chat-blank.tsx



const ChatBlank = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
        sx: {
            alignItems: "center",
            display: "flex",
            flexGrow: 1,
            flexDirection: "column",
            justifyContent: "center",
            overflow: "hidden"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "img",
                src: "/assets/errors/error-404.png",
                sx: {
                    height: "auto",
                    maxWidth: 120
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                color: "text.secondary",
                sx: {
                    mt: 2
                },
                variant: "subtitle1",
                children: "Start meaningful conversations!"
            })
        ]
    });

// EXTERNAL MODULE: ./src/hooks/use-router.ts
var use_router = __webpack_require__(840513);
// EXTERNAL MODULE: ./src/paths.ts
var paths = __webpack_require__(287842);
// EXTERNAL MODULE: ./src/store/index.ts + 2 modules
var store = __webpack_require__(754835);
// EXTERNAL MODULE: ./src/utils/create-resource-id.ts
var create_resource_id = __webpack_require__(17911);
// EXTERNAL MODULE: ./src/utils/deep-copy.ts
var deep_copy = __webpack_require__(846447);
// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
;// CONCATENATED MODULE: ./src/api/chat/data.ts

const now = new Date();
const contacts = [
    {
        id: "5e8891ab188cd2855e6029b7",
        avatar: "/assets/avatars/avatar-alcides-antonio.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Alcides Antonio"
    },
    {
        id: "5e887a62195cc5aef7e8ca5d",
        avatar: "/assets/avatars/avatar-marcus-finn.png",
        isActive: false,
        lastActivity: (0,date_fns.subHours)(now, 2).getTime(),
        name: "Marcus Finn"
    },
    {
        id: "5e887ac47eed253091be10cb",
        avatar: "/assets/avatars/avatar-carson-darrin.png",
        isActive: false,
        lastActivity: (0,date_fns.subMinutes)(now, 15).getTime(),
        name: "Carson Darrin"
    },
    {
        id: "5e887b209c28ac3dd97f6db5",
        avatar: "/assets/avatars/avatar-fran-perez.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Fran Perez"
    },
    {
        id: "5e887b7602bdbc4dbb234b27",
        avatar: "/assets/avatars/avatar-jie-yan-song.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Jie Yan Song"
    },
    {
        id: "5e86805e2bafd54f66cc95c3",
        avatar: "/assets/avatars/avatar-miron-vitold.png",
        isActive: false,
        lastActivity: (0,date_fns.subHours)(now, 1).getTime(),
        name: "Miron Vitold"
    },
    {
        id: "5e887a1fbefd7938eea9c981",
        avatar: "/assets/avatars/avatar-penjani-inyene.png",
        isActive: false,
        lastActivity: (0,date_fns.subHours)(now, 6).getTime(),
        name: "Penjani Inyene"
    },
    {
        id: "5e887d0b3d090c1b8f162003",
        avatar: "/assets/avatars/avatar-omar-darboe.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Omar Darobe"
    },
    {
        id: "5e88792be2d4cfb4bf0971d9",
        avatar: "/assets/avatars/avatar-siegbert-gottfried.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Siegbert Gottfried"
    },
    {
        id: "5e8877da9a65442b11551975",
        avatar: "/assets/avatars/avatar-iulia-albu.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Iulia Albu"
    },
    {
        id: "5e8680e60cba5019c5ca6fda",
        avatar: "/assets/avatars/avatar-nasimiyu-danai.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Nasimiyu Danai"
    }
];
const threads = [
    {
        id: "5e867eb9de721aecaccf4f7b",
        messages: [
            {
                id: "5e867f0a5bc0ff2bfa07bfa6",
                attachments: [],
                body: "Hey, nice projects! I really liked the one in react. What's your quote on kinda similar project?",
                contentType: "text",
                createdAt: (0,date_fns.subDays)((0,date_fns.subHours)(now, 10), 4).getTime(),
                authorId: "5e86805e2bafd54f66cc95c3"
            },
            {
                id: "5e867f167d5f78109ae9f2a4",
                attachments: [],
                body: "I would need to know more details, but my hourly rate stats at $35/hour. Thanks!",
                contentType: "text",
                createdAt: (0,date_fns.subDays)((0,date_fns.subHours)(now, 2), 4).getTime(),
                authorId: "5e86809283e28b96d2d38537"
            },
            {
                id: "5e867f1c9ca72084693528f4",
                attachments: [],
                body: "Well it's a really easy one, I'm sure we can make it half of the price.",
                contentType: "text",
                createdAt: (0,date_fns.subHours)(now, 5).getTime(),
                authorId: "5e86805e2bafd54f66cc95c3"
            },
            {
                id: "5e867f22fd2e27a09849b4db",
                attachments: [],
                body: "Then why don't you make it if it's that easy? Sorry I'm not interetes, have fantastic day Adam!",
                contentType: "text",
                createdAt: (0,date_fns.subHours)(now, 3).getTime(),
                authorId: "5e86809283e28b96d2d38537"
            },
            {
                id: "5e867f28a34d45ac6eb5c41f",
                attachments: [],
                body: "Last offer, $25 per hour",
                contentType: "text",
                createdAt: (0,date_fns.subHours)(now, 2).getTime(),
                authorId: "5e86805e2bafd54f66cc95c3"
            },
            {
                id: "5e867f2dba984a3f78b33526",
                attachments: [],
                body: "/assets/covers/minimal-1-4x3-small.png",
                contentType: "image",
                createdAt: (0,date_fns.subHours)(now, 1).getTime(),
                authorId: "5e86805e2bafd54f66cc95c3"
            }
        ],
        participantIds: [
            "5e86809283e28b96d2d38537",
            "5e86805e2bafd54f66cc95c3"
        ],
        type: "ONE_TO_ONE",
        unreadCount: 2
    },
    {
        id: "5e867fa7082c3c5921403a26",
        messages: [
            {
                id: "5e867fc180837d901bd9bca1",
                attachments: [],
                body: "Hey, would you like to collaborate?",
                contentType: "text",
                createdAt: (0,date_fns.subDays)((0,date_fns.subMinutes)(now, 6), 3).getTime(),
                authorId: "5e8680e60cba5019c5ca6fda"
            },
            {
                id: "5e8d6fb695df7971237fc173",
                attachments: [],
                body: "Hi, Merrile!",
                contentType: "text",
                createdAt: (0,date_fns.subDays)((0,date_fns.subMinutes)(now, 5), 3).getTime(),
                authorId: "5e86809283e28b96d2d38537"
            },
            {
                id: "58825a290eb4d4271a54f188",
                attachments: [],
                body: "Hello everyone \uD83D\uDE00",
                contentType: "text",
                createdAt: (0,date_fns.subDays)((0,date_fns.subMinutes)(now, 2), 1).getTime(),
                authorId: "5e8891ab188cd2855e6029b7"
            }
        ],
        participantIds: [
            "5e86809283e28b96d2d38537",
            "5e8680e60cba5019c5ca6fda",
            "5e8891ab188cd2855e6029b7"
        ],
        type: "GROUP",
        unreadCount: 0
    }
];

;// CONCATENATED MODULE: ./src/api/chat/index.ts



// On server get current identity (user) from the request
const user = {
    id: "5e86809283e28b96d2d38537",
    avatar: "/assets/avatars/avatar-anika-visser.png",
    name: "Anika Visser"
};
const findThreadById = (threadId)=>{
    return threads.find((thread)=>thread.id === threadId);
};
const findThreadByParticipantIds = (participantIds)=>{
    return threads.find((thread)=>{
        if (thread.participantIds.length !== participantIds.length) {
            return false;
        }
        const foundParticipantIds = new Set();
        thread.participantIds.forEach((participantId)=>{
            if (participantIds.includes(participantId)) {
                foundParticipantIds.add(participantId);
            }
        });
        return foundParticipantIds.size === participantIds.length;
    });
};
class ChatApi {
    getContacts(request = {}) {
        const { query  } = request;
        return new Promise((resolve, reject)=>{
            try {
                let foundContacts = contacts;
                if (query) {
                    const cleanQuery = query.toLowerCase().trim();
                    foundContacts = foundContacts.filter((contact)=>contact.name.toLowerCase().includes(cleanQuery));
                }
                resolve((0,deep_copy/* deepCopy */.p)(foundContacts));
            } catch (err) {
                console.error("[Chat Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    getThreads(request = {}) {
        const expandedThreads = threads.map((thread)=>{
            const participants = [
                user
            ];
            contacts.forEach((contact)=>{
                if (thread.participantIds.includes(contact.id)) {
                    participants.push({
                        id: contact.id,
                        avatar: contact.avatar,
                        lastActivity: contact.lastActivity,
                        name: contact.name
                    });
                }
            });
            return {
                ...thread,
                participants
            };
        });
        return Promise.resolve((0,deep_copy/* deepCopy */.p)(expandedThreads));
    }
    getThread(request) {
        const { threadKey  } = request;
        return new Promise((resolve, reject)=>{
            if (!threadKey) {
                reject(new Error("Thread key is required"));
                return;
            }
            try {
                let thread;
                // Thread key might be a contact ID
                const contact = contacts.find((contact)=>contact.id === threadKey);
                if (contact) {
                    thread = findThreadByParticipantIds([
                        user.id,
                        contact.id
                    ]);
                }
                // Thread key might be a thread ID
                if (!thread) {
                    thread = findThreadById(threadKey);
                }
                // If reached this point and thread does not exist this could mean:
                // b) The thread key is a contact ID, but no thread found
                // a) The thread key is a thread ID and is invalid
                if (!thread) {
                    return resolve(null);
                }
                const participants = [
                    user
                ];
                contacts.forEach((contact)=>{
                    if (thread.participantIds.includes(contact.id)) {
                        participants.push({
                            id: contact.id,
                            avatar: contact.avatar,
                            lastActivity: contact.lastActivity,
                            name: contact.name
                        });
                    }
                });
                const expandedThread = {
                    ...thread,
                    participants
                };
                resolve((0,deep_copy/* deepCopy */.p)(expandedThread));
            } catch (err) {
                console.error("[Chat Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    markThreadAsSeen(request) {
        const { threadId  } = request;
        return new Promise((resolve, reject)=>{
            try {
                const thread = threads.find((thread)=>thread.id === threadId);
                if (thread) {
                    thread.unreadCount = 0;
                }
                resolve(true);
            } catch (err) {
                console.error("[Chat Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    getParticipants(request) {
        const { threadKey  } = request;
        return new Promise((resolve, reject)=>{
            try {
                const participants = [
                    user
                ];
                // Thread key might be a thread ID
                const thread = findThreadById(threadKey);
                if (thread) {
                    contacts.forEach((contact)=>{
                        if (thread.participantIds.includes(contact.id)) {
                            participants.push({
                                id: contact.id,
                                avatar: contact.avatar,
                                lastActivity: contact.lastActivity,
                                name: contact.name
                            });
                        }
                    });
                } else {
                    const contact = contacts.find((contact)=>contact.id === threadKey);
                    // If no contact found, the user is trying a shady route
                    if (!contact) {
                        reject(new Error("Unable to find the contact"));
                        return;
                    }
                    participants.push({
                        id: contact.id,
                        avatar: contact.avatar,
                        lastActivity: contact.lastActivity,
                        name: contact.name
                    });
                }
                return resolve(participants);
            } catch (err) {
                console.error("[Chat Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    addMessage(request) {
        const { threadId , recipientIds , body  } = request;
        return new Promise((resolve, reject)=>{
            try {
                if (!(threadId || recipientIds)) {
                    reject(new Error("Thread ID or recipient IDs has to be provided"));
                    return;
                }
                let thread;
                // Try to find the thread
                if (threadId) {
                    thread = findThreadById(threadId);
                    // If thread ID provided the thread has to exist.
                    if (!thread) {
                        reject(new Error("Invalid thread id"));
                        return;
                    }
                } else {
                    const participantIds = [
                        user.id,
                        ...recipientIds || []
                    ];
                    thread = findThreadByParticipantIds(participantIds);
                }
                // If reached this point, thread will exist if thread ID provided
                // For recipient Ids it may or may not exist. If it doesn't, create a new one.
                if (!thread) {
                    const participantIds = [
                        user.id,
                        ...recipientIds || []
                    ];
                    thread = {
                        id: (0,create_resource_id/* createResourceId */.h)(),
                        messages: [],
                        participantIds,
                        type: participantIds.length === 2 ? "ONE_TO_ONE" : "GROUP",
                        unreadCount: 0
                    };
                    // Add the new thread to the DB
                    threads.push(thread);
                }
                const message = {
                    id: (0,create_resource_id/* createResourceId */.h)(),
                    attachments: [],
                    body,
                    contentType: "text",
                    createdAt: new Date().getTime(),
                    authorId: user.id
                };
                thread.messages.push(message);
                resolve({
                    threadId: thread.id,
                    message
                });
            } catch (err) {
                console.error("[Chat Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
}
const chatApi = new ChatApi();

// EXTERNAL MODULE: ./src/slices/chat.ts
var chat = __webpack_require__(16638);
;// CONCATENATED MODULE: ./src/thunks/chat.ts


const getContacts = ()=>async (dispatch)=>{
        const response = await chatApi.getContacts({});
        dispatch(chat/* slice.actions.getContacts */.t.actions.getContacts(response));
    };
const getThreads = ()=>async (dispatch)=>{
        const response = await chatApi.getThreads();
        dispatch(chat/* slice.actions.getThreads */.t.actions.getThreads(response));
    };
const getThread = (params)=>async (dispatch)=>{
        const response = await chatApi.getThread(params);
        dispatch(chat/* slice.actions.getThread */.t.actions.getThread(response));
        return response?.id;
    };
const markThreadAsSeen = (params)=>async (dispatch)=>{
        await chatApi.markThreadAsSeen(params);
        dispatch(chat/* slice.actions.markThreadAsSeen */.t.actions.markThreadAsSeen(params.threadId));
    };
const setCurrentThread = (params)=>(dispatch)=>{
        dispatch(chat/* slice.actions.setCurrentThread */.t.actions.setCurrentThread(params.threadId));
    };
const addMessage = (params)=>async (dispatch)=>{
        const response = await chatApi.addMessage(params);
        dispatch(chat/* slice.actions.addMessage */.t.actions.addMessage(response));
        return response.threadId;
    };
const thunks = {
    addMessage,
    getContacts,
    getThread,
    getThreads,
    markThreadAsSeen,
    setCurrentThread
};

// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/SearchMd.js
var SearchMd = __webpack_require__(219057);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Chip/index.js
var Chip = __webpack_require__(829553);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ClickAwayListener/index.js
var ClickAwayListener = __webpack_require__(78960);
var ClickAwayListener_default = /*#__PURE__*/__webpack_require__.n(ClickAwayListener);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/InputAdornment/index.js
var InputAdornment = __webpack_require__(79150);
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/List/index.js
var List = __webpack_require__(854436);
var List_default = /*#__PURE__*/__webpack_require__.n(List);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemAvatar/index.js
var ListItemAvatar = __webpack_require__(372355);
var ListItemAvatar_default = /*#__PURE__*/__webpack_require__.n(ListItemAvatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemButton/index.js
var ListItemButton = __webpack_require__(729234);
var ListItemButton_default = /*#__PURE__*/__webpack_require__.n(ListItemButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemText/index.js
var ListItemText = __webpack_require__(846517);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/OutlinedInput/index.js
var OutlinedInput = __webpack_require__(877829);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Paper/index.js
var Paper = __webpack_require__(427561);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Popper/index.js
var Popper = __webpack_require__(956262);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./src/components/scrollbar.tsx
var scrollbar = __webpack_require__(851716);
;// CONCATENATED MODULE: ./src/sections/dashboard/chat/chat-composer-recipients.tsx





















const ChatComposerRecipients = (props)=>{
    const { onRecipientAdd , onRecipientRemove , recipients =[] , ...other } = props;
    const searchRef = (0,react_.useRef)(null);
    const [searchFocused, setSearchFocused] = (0,react_.useState)(false);
    const [searchQuery, setSearchQuery] = (0,react_.useState)("");
    const [searchResults, setSearchResults] = (0,react_.useState)([]);
    const showSearchResults = !!(searchFocused && searchQuery);
    const hasSearchResults = searchResults.length > 0;
    const handleSearchChange = (0,react_.useCallback)(async (event)=>{
        const query = event.target.value;
        setSearchQuery(query);
        if (!query) {
            setSearchResults([]);
            return;
        }
        try {
            const contacts = await chatApi.getContacts({
                query
            });
            // Filter already picked recipients
            const recipientIds = recipients.map((recipient)=>recipient.id);
            const filtered = contacts.filter((contact)=>!recipientIds.includes(contact.id));
            setSearchResults(filtered);
        } catch (err) {
            console.error(err);
        }
    }, [
        recipients
    ]);
    const handleSearchClickAway = (0,react_.useCallback)(()=>{
        if (showSearchResults) {
            setSearchFocused(false);
        }
    }, [
        showSearchResults
    ]);
    const handleSearchFocus = (0,react_.useCallback)(()=>{
        setSearchFocused(true);
    }, []);
    const handleSearchSelect = (0,react_.useCallback)((contact)=>{
        setSearchQuery("");
        onRecipientAdd?.(contact);
    }, [
        onRecipientAdd
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
            ...other,
            children: /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                    sx: {
                        alignItems: "center",
                        display: "flex",
                        p: 2
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((ClickAwayListener_default()), {
                            onClickAway: handleSearchClickAway,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    mr: 1
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                        fullWidth: true,
                                        onChange: handleSearchChange,
                                        onFocus: handleSearchFocus,
                                        placeholder: "Search contacts",
                                        ref: searchRef,
                                        startAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                            position: "start",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(SearchMd/* default */.Z, {})
                                            })
                                        }),
                                        sx: {
                                            "&.MuiInputBase-root": {
                                                height: 40,
                                                minWidth: 260
                                            }
                                        },
                                        value: searchQuery
                                    }),
                                    showSearchResults && /*#__PURE__*/ jsx_runtime_.jsx(Popper["default"], {
                                        anchorEl: searchRef.current,
                                        open: searchFocused,
                                        placement: "bottom-start",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Paper_default()), {
                                            elevation: 16,
                                            sx: {
                                                borderColor: "divider",
                                                borderStyle: "solid",
                                                borderWidth: 1,
                                                maxWidth: "100%",
                                                mt: 1,
                                                width: 320
                                            },
                                            children: hasSearchResults ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                        sx: {
                                                            px: 2,
                                                            pt: 2
                                                        },
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            color: "text.secondary",
                                                            variant: "subtitle2",
                                                            children: "Contacts"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                                                        children: searchResults.map((contact)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItemButton_default()), {
                                                                onClick: ()=>handleSearchSelect(contact),
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                            src: contact.avatar
                                                                        })
                                                                    }),
                                                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                                        primary: contact.name,
                                                                        primaryTypographyProps: {
                                                                            noWrap: true,
                                                                            variant: "subtitle2"
                                                                        }
                                                                    })
                                                                ]
                                                            }, contact.id))
                                                    })
                                                ]
                                            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                                sx: {
                                                    p: 2,
                                                    textAlign: "center"
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        gutterBottom: true,
                                                        variant: "h6",
                                                        children: "Nothing Found"
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                        color: "text.secondary",
                                                        variant: "body2",
                                                        children: [
                                                            "We couldn't find any matches for \"",
                                                            searchQuery,
                                                            '". Try checking for typos or using complete words.'
                                                        ]
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            color: "text.secondary",
                            sx: {
                                mr: 2
                            },
                            variant: "body2",
                            children: "To:"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            spacing: 2,
                            children: recipients.map((recipient)=>/*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                                    avatar: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                        src: recipient.avatar
                                    }),
                                    label: recipient.name,
                                    onDelete: ()=>onRecipientRemove?.(recipient.id)
                                }, recipient.id))
                        })
                    ]
                })
            })
        })
    });
};
ChatComposerRecipients.propTypes = {
    onRecipientAdd: (prop_types_default()).func,
    onRecipientRemove: (prop_types_default()).func,
    recipients: (prop_types_default()).array
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Attachment01.js
var Attachment01 = __webpack_require__(517163);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Camera01.js
var Camera01 = __webpack_require__(739624);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Send01.js
var Send01 = __webpack_require__(376131);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tooltip/index.js
var Tooltip = __webpack_require__(556020);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip);
// EXTERNAL MODULE: ./src/hooks/use-mocked-user.ts
var use_mocked_user = __webpack_require__(782851);
;// CONCATENATED MODULE: ./src/sections/dashboard/chat/chat-message-add.tsx














const ChatMessageAdd = (props)=>{
    const { disabled =false , onSend , ...other } = props;
    const user = (0,use_mocked_user/* useMockedUser */.I)();
    const fileInputRef = (0,react_.useRef)(null);
    const [body, setBody] = (0,react_.useState)("");
    const handleAttach = (0,react_.useCallback)(()=>{
        fileInputRef.current?.click();
    }, []);
    const handleChange = (0,react_.useCallback)((event)=>{
        setBody(event.target.value);
    }, []);
    const handleSend = (0,react_.useCallback)(()=>{
        if (!body) {
            return;
        }
        onSend?.(body);
        setBody("");
    }, [
        body,
        onSend
    ]);
    const handleKeyUp = (0,react_.useCallback)((event)=>{
        if (event.code === "Enter") {
            handleSend();
        }
    }, [
        handleSend
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        alignItems: "center",
        direction: "row",
        spacing: 2,
        sx: {
            px: 3,
            py: 1
        },
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                sx: {
                    display: {
                        xs: "none",
                        sm: "inline"
                    }
                },
                src: user.avatar
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                disabled: disabled,
                fullWidth: true,
                onChange: handleChange,
                onKeyUp: handleKeyUp,
                placeholder: "Leave a message",
                size: "small",
                value: body
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                sx: {
                    alignItems: "center",
                    display: "flex",
                    m: -2,
                    ml: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                        title: "Send",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                m: 1
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                color: "primary",
                                disabled: !body || disabled,
                                sx: {
                                    backgroundColor: "primary.main",
                                    color: "primary.contrastText",
                                    "&:hover": {
                                        backgroundColor: "primary.dark"
                                    }
                                },
                                onClick: handleSend,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Send01/* default */.Z, {})
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                        title: "Attach photo",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                display: {
                                    xs: "none",
                                    sm: "inline-flex"
                                },
                                m: 1
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                disabled: disabled,
                                edge: "end",
                                onClick: handleAttach,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Camera01/* default */.Z, {})
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                        title: "Attach file",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                display: {
                                    xs: "none",
                                    sm: "inline-flex"
                                },
                                m: 1
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                disabled: disabled,
                                edge: "end",
                                onClick: handleAttach,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Attachment01/* default */.Z, {})
                                })
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                hidden: true,
                ref: fileInputRef,
                type: "file"
            })
        ]
    });
};
ChatMessageAdd.propTypes = {
    disabled: (prop_types_default()).bool,
    onSend: (prop_types_default()).func
};

;// CONCATENATED MODULE: ./src/sections/dashboard/chat/chat-composer.tsx










const useRecipients = ()=>{
    const [recipients, setRecipients] = (0,react_.useState)([]);
    const handleRecipientAdd = (0,react_.useCallback)((recipient)=>{
        setRecipients((prevState)=>{
            const found = prevState.find((_recipient)=>_recipient.id === recipient.id);
            if (found) {
                return prevState;
            }
            return [
                ...prevState,
                recipient
            ];
        });
    }, []);
    const handleRecipientRemove = (0,react_.useCallback)((recipientId)=>{
        setRecipients((prevState)=>{
            return prevState.filter((recipient)=>recipient.id !== recipientId);
        });
    }, []);
    return {
        handleRecipientAdd,
        handleRecipientRemove,
        recipients
    };
};
const ChatComposer = (props)=>{
    const dispatch = (0,store/* useDispatch */.I0)();
    const router = (0,use_router/* useRouter */.t)();
    const { handleRecipientAdd , handleRecipientRemove , recipients  } = useRecipients();
    const handleSend = (0,react_.useCallback)(async (body)=>{
        const recipientIds = recipients.map((recipient)=>recipient.id);
        let threadId;
        try {
            // Handle send message and redirect to the new thread
            threadId = await dispatch(thunks.addMessage({
                recipientIds,
                body
            }));
        } catch (err) {
            console.error(err);
            return;
        }
        router.push(paths/* paths.dashboard.chat */.H.dashboard.chat + `?threadKey=${threadId}`);
    }, [
        dispatch,
        router,
        recipients
    ]);
    const canAddMessage = recipients.length > 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
        sx: {
            display: "flex",
            flexDirection: "column",
            flexGrow: 1
        },
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(ChatComposerRecipients, {
                onRecipientAdd: handleRecipientAdd,
                onRecipientRemove: handleRecipientRemove,
                recipients: recipients
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    flexGrow: 1
                }
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx(ChatMessageAdd, {
                disabled: !canAddMessage,
                onSend: handleSend
            })
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
;// CONCATENATED MODULE: ./src/sections/dashboard/chat/chat-container.tsx

const ChatContainer = (0,styles.styled)("div", {
    shouldForwardProp: (prop)=>prop !== "open"
})(({ theme , open  })=>({
        display: "flex",
        flexDirection: "column",
        flexGrow: 1,
        overflow: "hidden",
        [theme.breakpoints.up("md")]: {
            marginLeft: -380
        },
        transition: theme.transitions.create("margin", {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        }),
        ...open && {
            [theme.breakpoints.up("md")]: {
                marginLeft: 0
            },
            transition: theme.transitions.create("margin", {
                easing: theme.transitions.easing.easeOut,
                duration: theme.transitions.duration.enteringScreen
            })
        }
    }));

;// CONCATENATED MODULE: ./src/app/(dashboard)/chat/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 















/**
 * NOTE:
 * In our case there two possible routes
 * one that contains /chat and one with a chat?threadKey={{threadKey}}
 * if threadKey does not exist, it means that the chat is in compose mode
 */ const useThreads = ()=>{
    const dispatch = (0,store/* useDispatch */.I0)();
    const handleThreadsGet = (0,react_.useCallback)(()=>{
        dispatch(thunks.getThreads());
    }, [
        dispatch
    ]);
    (0,react_.useEffect)(()=>{
        handleThreadsGet();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []);
};
const useSidebar = ()=>{
    const searchParams = (0,use_search_params/* useSearchParams */.l)();
    const mdUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("md"));
    const [open, setOpen] = (0,react_.useState)(mdUp);
    const handleScreenResize = (0,react_.useCallback)(()=>{
        if (!mdUp) {
            setOpen(false);
        } else {
            setOpen(true);
        }
    }, [
        mdUp
    ]);
    (0,react_.useEffect)(()=>{
        handleScreenResize();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        mdUp
    ]);
    const handeParamsUpdate = (0,react_.useCallback)(()=>{
        if (!mdUp) {
            setOpen(false);
        }
    }, [
        mdUp
    ]);
    (0,react_.useEffect)(()=>{
        handeParamsUpdate();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        searchParams
    ]);
    const handleToggle = (0,react_.useCallback)(()=>{
        setOpen((prevState)=>!prevState);
    }, []);
    const handleClose = (0,react_.useCallback)(()=>{
        setOpen(false);
    }, []);
    return {
        handleToggle,
        handleClose,
        open
    };
};
const Page = ()=>{
    const rootRef = (0,react_.useRef)(null);
    const searchParams = (0,use_search_params/* useSearchParams */.l)();
    const compose = searchParams.get("compose") === "true";
    const threadKey = searchParams.get("threadKey") || undefined;
    const sidebar = useSidebar();
    (0,use_page_view/* usePageView */.a)();
    useThreads();
    const view = threadKey ? "thread" : compose ? "compose" : "blank";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: Chat"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "main",
                sx: {
                    backgroundColor: "background.paper",
                    flex: "1 1 auto",
                    overflow: "hidden",
                    position: "relative"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    ref: rootRef,
                    sx: {
                        bottom: 0,
                        display: "flex",
                        left: 0,
                        position: "absolute",
                        right: 0,
                        top: 0
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(ChatContainer, {
                        open: sidebar.open,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    p: 2
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    onClick: sidebar.handleToggle,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Menu01/* default */.Z, {})
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                            view === "compose" && /*#__PURE__*/ jsx_runtime_.jsx(ChatComposer, {}),
                            view === "blank" && /*#__PURE__*/ jsx_runtime_.jsx(ChatBlank, {})
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 82365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.useSearchParams)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 17911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ createResourceId)
/* harmony export */ });
const createResourceId = ()=>{
    const arr = new Uint8Array(12);
    window.crypto.getRandomValues(arr);
    return Array.from(arr, (v)=>v.toString(16).padStart(2, "0")).join("");
};


/***/ }),

/***/ 846447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ deepCopy)
/* harmony export */ });
// eslint-disable-next-line consistent-return
function deepCopy(obj) {
    if (typeof obj !== "object" || obj === null) {
        return obj;
    }
    if (obj instanceof Date) {
        return new Date(obj.getTime());
    }
    if (obj instanceof Array) {
        return obj.reduce((arr, item, index)=>{
            arr[index] = deepCopy(item);
            return arr;
        }, []);
    }
    if (obj instanceof Object) {
        return Object.keys(obj).reduce((newObj, key)=>{
            newObj[key] = deepCopy(obj[key]);
            return newObj;
        }, {});
    }
}


/***/ }),

/***/ 797668:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/chat/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,6131,9624,4363,7680,95,9494,2302,2851], () => (__webpack_exec__(444140)));
module.exports = __webpack_exports__;

})();