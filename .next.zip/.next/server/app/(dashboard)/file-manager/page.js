(() => {
var exports = {};
exports.id = 7001;
exports.ids = [7001];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 754911:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'file-manager',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 333324, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/file-manager/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/file-manager/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/file-manager/page"
  

/***/ }),

/***/ 814090:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 185038))

/***/ }),

/***/ 185038:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Upload01.js
var Upload01 = __webpack_require__(429771);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/utils/apply-pagination.ts
var apply_pagination = __webpack_require__(789989);
// EXTERNAL MODULE: ./src/utils/apply-sort.ts
var apply_sort = __webpack_require__(391734);
// EXTERNAL MODULE: ./src/utils/deep-copy.ts
var deep_copy = __webpack_require__(846447);
// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
;// CONCATENATED MODULE: ./src/api/file-manager/data.ts

const now = new Date();
const items = [
    {
        id: "719a07ce8e46dee2388d411c",
        author: {
            avatar: "/assets/avatars/avatar-alcides-antonio.png",
            name: "Alcides Antonio"
        },
        createdAt: (0,date_fns.subMinutes)(now, 15).getTime(),
        isFavorite: false,
        isPublic: false,
        items: [],
        itemsCount: 12,
        name: "AWS Credentials",
        shared: [
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                name: "Anika Visser"
            },
            {
                avatar: "/assets/avatars/avatar-miron-vitold.png",
                name: "Miron Vitold"
            }
        ],
        size: 528381242,
        tags: [
            "Business",
            "Work",
            "Homework",
            "Cats",
            "Holiday",
            "Friends"
        ],
        type: "folder",
        updatedAt: null
    },
    {
        id: "ed41ba8be80fac27d08efe3a",
        author: {
            avatar: "/assets/avatars/avatar-fran-perez.png",
            name: "Fran Perez"
        },
        createdAt: (0,date_fns.subMinutes)(now, 23).getTime(),
        isFavorite: true,
        isPublic: true,
        items: [],
        itemsCount: 5,
        name: "dev 2022",
        shared: [],
        size: 519090127,
        tags: [
            "Friends",
            "Business",
            "Homework",
            "Personal"
        ],
        type: "folder",
        updatedAt: (0,date_fns.subMinutes)(now, 2).getTime()
    },
    {
        id: "b8bb82b90aedf81d57ccdb4d",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subHours)((0,date_fns.subMinutes)(now, 3), 4).getTime(),
        isFavorite: false,
        isPublic: false,
        items: [],
        itemsCount: 3,
        name: "AI Resources",
        shared: [
            {
                avatar: "/assets/avatars/avatar-miron-vitold.png",
                name: "Miron Vitold"
            },
            {
                avatar: "/assets/avatars/avatar-alcides-antonio.png",
                name: "Alcides Antonio"
            },
            {
                avatar: "/assets/avatars/avatar-nasimiyu-danai.png",
                name: "Nasimiyu Danai"
            }
        ],
        size: 194220900,
        tags: [
            "Homework",
            "Holiday",
            "Important",
            "Work",
            "Friends",
            "Personal"
        ],
        type: "folder",
        updatedAt: null
    },
    {
        id: "b33fe3f9ced7e4fa7efcbd9a",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subHours)((0,date_fns.subMinutes)(now, 16), 20).getTime(),
        isFavorite: true,
        isPublic: false,
        itemsCount: 17,
        name: "invoices",
        shared: [],
        size: 731214568,
        tags: [
            "Personal",
            "Important",
            "Invoices"
        ],
        type: "folder",
        updatedAt: null
    },
    {
        id: "dffb38de19c7e9ce0dc690cf",
        author: {
            avatar: "/assets/avatars/avatar-carson-darrin.png",
            name: "Carson Darrin"
        },
        createdAt: (0,date_fns.subHours)((0,date_fns.subMinutes)(now, 23), 26).getTime(),
        isFavorite: true,
        isPublic: true,
        items: [],
        itemsCount: 12,
        name: "assets",
        shared: [],
        size: 103885109,
        tags: [
            "Invoices",
            "Personal",
            "Holiday",
            "Homework",
            "Cats",
            "Work"
        ],
        type: "folder",
        updatedAt: null
    },
    {
        id: "c23e85a978a79a5cb53c0b0a",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 41), 6), 2).getTime(),
        extension: "pdf",
        isFavorite: true,
        isPublic: false,
        name: "Personal-cv.pdf",
        shared: [
            {
                avatar: "/assets/avatars/avatar-alcides-antonio.png",
                name: "Alcides Antonio"
            }
        ],
        size: 472262466,
        tags: [
            "Invoices",
            "Work"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "b3acfe9aa417c1f9e1cda220",
        author: {
            avatar: "/assets/avatars/avatar-siegbert-gottfried.png",
            name: "Siegbert Gottfried"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 41), 6), 2).getTime(),
        extension: "svg",
        isFavorite: true,
        isPublic: false,
        name: "company-logo-white.svg",
        shared: [
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                name: "Anika Visser"
            },
            {
                avatar: "/assets/avatars/avatar-nasimiyu-danai.png",
                name: "Nasimiyu Danai"
            }
        ],
        size: 762152011,
        tags: [
            "Homework"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "afa0412fe4cdb39b3c8b9ad2",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 41), 6), 2).getTime(),
        extension: "jpeg",
        isFavorite: true,
        isPublic: false,
        name: "landing_cover1.jpeg",
        shared: [
            {
                avatar: "/assets/avatars/avatar-iulia-albu.png",
                name: "Iulia Albu"
            }
        ],
        size: 746826456,
        tags: [
            "Important",
            "Personal",
            "Invoices",
            "Homework",
            "Business",
            "Cats",
            "Holiday"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "f90e02aaa5f7f9f87ae14ad8",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 41), 6), 2).getTime(),
        extension: "svg",
        isFavorite: false,
        isPublic: false,
        name: "About-Hero_shape-xl.svg",
        shared: [
            {
                avatar: "/assets/avatars/avatar-nasimiyu-danai.png",
                name: "Nasimiyu Danai"
            },
            {
                avatar: "/assets/avatars/avatar-iulia-albu.png",
                name: "Iulia Albu"
            }
        ],
        size: 374404524,
        tags: [],
        type: "file",
        updatedAt: null
    },
    {
        id: "b74e2b767d284d4a94de5e3a",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 41), 6), 2).getTime(),
        extension: "log",
        isFavorite: true,
        isPublic: false,
        name: "api-out.log",
        shared: [],
        size: 54765975,
        tags: [
            "Cats"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "b929bf2753254c05d45bc9fa",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 41), 6), 2).getTime(),
        extension: "ico",
        isFavorite: true,
        isPublic: false,
        name: "investor_optical_tactics.ico",
        shared: [
            {
                avatar: "/assets/avatars/avatar-carson-darrin.png",
                name: "Carson Darrin"
            }
        ],
        size: 674580489,
        tags: [
            "Homework",
            "Cats",
            "Business",
            "Personal",
            "Friends"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "fdbadfb4cbbd5b3ea44b1823",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 3), 14), 6).getTime(),
        extension: "dmg",
        isFavorite: true,
        isPublic: false,
        name: "rustic_driver_pike.dmg",
        shared: [
            {
                avatar: "/assets/avatars/avatar-siegbert-gottfried.png",
                name: "Siegbert Gottfried"
            },
            {
                avatar: "/assets/avatars/avatar-carson-darrin.png",
                name: "Carson Darrin"
            }
        ],
        size: 211681809,
        tags: [
            "Work",
            "Personal",
            "Invoices",
            "Homework"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "edc8f7a0420fef23bfeaafed",
        author: {
            avatar: "/assets/avatars/avatar-siegbert-gottfried.png",
            name: "Siegbert Gottfried"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 21), 4), 9).getTime(),
        extension: "7z",
        isFavorite: false,
        isPublic: false,
        name: "strategist-auto_royce.7z",
        shared: [],
        size: 928256606,
        tags: [],
        type: "file",
        updatedAt: null
    },
    {
        id: "28becedd58a2fb7be2d05cf5",
        author: {
            avatar: "/assets/avatars/avatar-marcus-finn.png",
            name: "Marcus Finn"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 45), 11), 9).getTime(),
        extension: "msi",
        isFavorite: false,
        isPublic: true,
        name: "Graphic Driver 1.11.msi",
        shared: [],
        size: 436081098,
        tags: [
            "Homework",
            "Holiday",
            "Cats",
            "Invoices",
            "Important",
            "Work",
            "Friends"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "5affd9c3af627afb1fdc7657",
        author: {
            avatar: "/assets/avatars/avatar-marcus-finn.png",
            name: "Marcus Finn"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 23), 3), 10).getTime(),
        extension: "svg",
        isFavorite: false,
        isPublic: true,
        name: "icon-arrow-right.svg",
        shared: [],
        size: 6273,
        tags: [
            "Personal"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "3bc08f0082b7dd2bd52fee6e",
        author: {
            avatar: "/assets/avatars/avatar-omar-darboe.png",
            name: "Omar Darobe"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 4), 2), 11).getTime(),
        extension: "rar",
        isFavorite: false,
        isPublic: false,
        name: "animation-ai-model.py",
        shared: [
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                name: "Anika Visser"
            }
        ],
        size: 785187212,
        tags: [
            "Work",
            "Cats",
            "Invoices"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "100bcfa1faeba4c36c7b5ad3",
        author: {
            avatar: "/assets/avatars/avatar-penjani-inyene.png",
            name: "Penjani Inyene"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 31), 6), 11).getTime(),
        extension: "png",
        isFavorite: true,
        isPublic: false,
        name: "hybrid_vw-2023.png",
        shared: [
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                name: "Anika Visser"
            }
        ],
        size: 442600692,
        tags: [
            "Important",
            "Business",
            "Holiday",
            "Friends",
            "Invoices",
            "Personal"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "6e638cfc6ab9bd1c78a28f73",
        author: {
            avatar: "/assets/avatars/avatar-jie-yan-song.png",
            name: "Jie Yan Song"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 11), 12), 11).getTime(),
        extension: "png",
        isFavorite: true,
        isPublic: true,
        name: "diesel_electric.png",
        shared: [],
        size: 363777187,
        tags: [
            "Important",
            "Homework"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "45fb900df5e07ac0c5aeedfa",
        author: {
            avatar: "/assets/avatars/avatar-alcides-antonio.png",
            name: "Alcides Antonio"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 4), 15), 15).getTime(),
        extension: "mp4",
        isFavorite: false,
        isPublic: false,
        name: "christmas carols.mp4",
        shared: [
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                name: "Anika Visser"
            }
        ],
        size: 841133109,
        tags: [
            "Personal",
            "Important",
            "Invoices"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "5e9b61b7caec888a9fb53fa5",
        author: {
            avatar: "/assets/avatars/avatar-siegbert-gottfried.png",
            name: "Siegbert Gottfried"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 31), 5), 17).getTime(),
        extension: "dmg",
        isFavorite: false,
        isPublic: false,
        name: "Bandwidth_traffic-analyzer.dmg",
        shared: [
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                name: "Anika Visser"
            }
        ],
        size: 258621281,
        tags: [
            "Homework",
            "Work",
            "Personal",
            "Important"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "ec4754671acbd7ad74afffa6",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 11), 16), 18).getTime(),
        extension: "pkg",
        isFavorite: true,
        isPublic: false,
        name: "devias-kit.fig",
        shared: [
            {
                avatar: "/assets/avatars/avatar-neha-punita.png",
                name: "Neha Punita"
            }
        ],
        size: 528228820,
        tags: [
            "Work",
            "Holiday",
            "Friends"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "97c43cc1e0ad50cbbf14b6ce",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 1), 3), 37).getTime(),
        extension: "exe",
        isFavorite: true,
        isPublic: false,
        name: "not_a_virus.exe",
        shared: [
            {
                avatar: "/assets/avatars/avatar-cao-yu.png",
                name: "Cao Yu"
            },
            {
                avatar: "/assets/avatars/avatar-siegbert-gottfried.png",
                name: "Siegbert Gottfried"
            }
        ],
        size: 600779531,
        tags: [
            "Important",
            "Friends"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "7cfdb3fed0bac18d77b555ba",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 12), 11), 40).getTime(),
        extension: "psd",
        isFavorite: true,
        isPublic: false,
        name: "website-hero-illustration.psd",
        shared: [
            {
                avatar: "/assets/avatars/avatar-cao-yu.png",
                name: "Cao Yu"
            }
        ],
        size: 333130679,
        tags: [
            "Cats",
            "Personal",
            "Work",
            "Important",
            "Friends"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "e23ee9ae093bb6e25cce9f85",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 15), 23), 41).getTime(),
        extension: "tar",
        isFavorite: true,
        isPublic: false,
        name: "ssl-certs.tar",
        shared: [
            {
                avatar: "/assets/avatars/avatar-neha-punita.png",
                name: "Neha Punita"
            }
        ],
        size: 516488635,
        tags: [
            "Cats",
            "Friends",
            "Important",
            "Homework",
            "Work",
            "Personal",
            "Business"
        ],
        type: "file",
        updatedAt: null
    },
    {
        id: "22fae356b5b7c5d13c4b4ba8",
        author: {
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 40), 11), 62).getTime(),
        extension: "deb",
        isFavorite: true,
        isPublic: false,
        name: "tablet-driver-adapter.deb",
        shared: [],
        size: 761277264,
        tags: [
            "Cats",
            "Homework",
            "Business",
            "Personal"
        ],
        type: "file",
        updatedAt: null
    }
];

;// CONCATENATED MODULE: ./src/api/file-manager/index.ts




class FileManagerApi {
    getItems(request = {}) {
        const { filters , page , rowsPerPage , sortBy , sortDir  } = request;
        let data = (0,deep_copy/* deepCopy */.p)(items);
        let count = data.length;
        if (typeof filters !== "undefined") {
            data = data.filter((file)=>{
                if (typeof filters.query !== "undefined" && filters.query !== "") {
                    const matched = file.name.toLowerCase().includes(filters.query.toLowerCase());
                    if (!matched) {
                        return false;
                    }
                }
                return true;
            });
            count = data.length;
        }
        if (typeof sortBy !== "undefined" && typeof sortDir !== "undefined") {
            data = (0,apply_sort/* applySort */.v)(data, sortBy, sortDir);
        }
        if (typeof page !== "undefined" && typeof rowsPerPage !== "undefined") {
            data = (0,apply_pagination/* applyPagination */.i)(data, page, rowsPerPage);
        }
        return Promise.resolve({
            data,
            count
        });
    }
}
const fileManagerApi = new FileManagerApi();

// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-dialog.ts
var use_dialog = __webpack_require__(756964);
// EXTERNAL MODULE: ./src/hooks/use-mounted.ts
var use_mounted = __webpack_require__(887408);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/hooks/use-settings.ts
var use_settings = __webpack_require__(488141);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/X.js
var X = __webpack_require__(180501);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Dialog/index.js
var Dialog = __webpack_require__(933429);
var Dialog_default = /*#__PURE__*/__webpack_require__.n(Dialog);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/DialogContent/index.js
var DialogContent = __webpack_require__(515381);
var DialogContent_default = /*#__PURE__*/__webpack_require__.n(DialogContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./src/components/file-dropzone.tsx
var file_dropzone = __webpack_require__(452235);
;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/file-uploader.tsx











const FileUploader = (props)=>{
    const { onClose , open =false  } = props;
    const [files, setFiles] = (0,react_.useState)([]);
    (0,react_.useEffect)(()=>{
        setFiles([]);
    }, [
        open
    ]);
    const handleDrop = (0,react_.useCallback)((newFiles)=>{
        setFiles((prevFiles)=>{
            return [
                ...prevFiles,
                ...newFiles
            ];
        });
    }, []);
    const handleRemove = (0,react_.useCallback)((file)=>{
        setFiles((prevFiles)=>{
            return prevFiles.filter((_file)=>_file.path !== file.path);
        });
    }, []);
    const handleRemoveAll = (0,react_.useCallback)(()=>{
        setFiles([]);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Dialog_default()), {
        fullWidth: true,
        maxWidth: "sm",
        open: open,
        onClose: onClose,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                justifyContent: "space-between",
                spacing: 3,
                sx: {
                    px: 3,
                    py: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "h6",
                        children: "Upload Files"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        color: "inherit",
                        onClick: onClose,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(X/* default */.Z, {})
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((DialogContent_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx(file_dropzone/* FileDropzone */.Y, {
                    accept: {
                        "*/*": []
                    },
                    caption: "Max file size is 3 MB",
                    files: files,
                    onDrop: handleDrop,
                    onRemove: handleRemove,
                    onRemoveAll: handleRemoveAll,
                    onUpload: onClose
                })
            })
        ]
    });
};
FileUploader.propTypes = {
    onClose: (prop_types_default()).func,
    open: (prop_types_default()).bool
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Edit02.js
var Edit02 = __webpack_require__(956461);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Star01.js
var Star01 = __webpack_require__(796756);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Trash02.js
var Trash02 = __webpack_require__(459074);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Backdrop/index.js
var Backdrop = __webpack_require__(62788);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Drawer/index.js
var Drawer = __webpack_require__(379499);
var Drawer_default = /*#__PURE__*/__webpack_require__.n(Drawer);
// EXTERNAL MODULE: ./src/utils/bytes-to-size.ts
var bytes_to_size = __webpack_require__(98323);
// EXTERNAL MODULE: ./src/components/file-icon.tsx
var file_icon = __webpack_require__(994797);
;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/item-icon.tsx



const ItemIcon = (props)=>{
    const { type , extension  } = props;
    return type === "folder" ? /*#__PURE__*/ jsx_runtime_.jsx("img", {
        src: "/assets/icons/icon-folder.svg"
    }) : /*#__PURE__*/ jsx_runtime_.jsx(file_icon/* FileIcon */.a, {
        extension: extension
    });
};
ItemIcon.propTypes = {
    extension: (prop_types_default()).string,
    type: prop_types_default().oneOf([
        "file",
        "folder"
    ]).isRequired
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Plus.js
var Plus = __webpack_require__(959309);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Chip/index.js
var Chip = __webpack_require__(829553);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Menu/index.js
var Menu = __webpack_require__(576650);
var Menu_default = /*#__PURE__*/__webpack_require__.n(Menu);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/MenuItem/index.js
var MenuItem = __webpack_require__(662360);
var MenuItem_default = /*#__PURE__*/__webpack_require__.n(MenuItem);
// EXTERNAL MODULE: ./src/hooks/use-popover.ts
var use_popover = __webpack_require__(69281);
;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/item-drawer/item-tags.tsx











const options = [
    "Invoices",
    "Work",
    "Business",
    "Planning",
    "Frontend",
    "Design"
];
const ItemTags = (props)=>{
    const { onChange , tags =[]  } = props;
    const popover = (0,use_popover/* usePopover */.S)();
    const availableOptions = (0,react_.useMemo)(()=>{
        return options.filter((option)=>!tags.includes(option));
    }, [
        tags
    ]);
    const handleDelete = (0,react_.useCallback)((label)=>{
        const newLabels = tags.filter((item)=>item !== label);
        onChange?.(newLabels);
    }, [
        tags,
        onChange
    ]);
    const handleToggle = (0,react_.useCallback)((label)=>{
        let newLabels;
        const found = tags.find((item)=>item === label);
        if (found) {
            newLabels = tags.filter((item)=>item !== label);
        } else {
            newLabels = [
                ...tags,
                label
            ];
        }
        popover.handleClose();
        onChange?.(newLabels);
    }, [
        tags,
        popover,
        onChange
    ]);
    const canAdd = availableOptions.length > 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                flexWrap: "wrap",
                gap: 1,
                children: [
                    tags.map((label)=>/*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                            label: label,
                            onDelete: ()=>handleDelete(label),
                            size: "small"
                        }, label)),
                    /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        onClick: popover.handleOpen,
                        ref: popover.anchorRef,
                        disabled: !canAdd,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            fontSize: "small",
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Menu_default()), {
                anchorEl: popover.anchorRef.current,
                anchorOrigin: {
                    horizontal: "right",
                    vertical: "bottom"
                },
                onClose: popover.handleClose,
                open: popover.open,
                transformOrigin: {
                    horizontal: "right",
                    vertical: "top"
                },
                children: availableOptions.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                        onClick: ()=>handleToggle(option),
                        children: option
                    }, option))
            })
        ]
    });
};
ItemTags.propTypes = {
    onChange: (prop_types_default()).func,
    tags: prop_types_default().arrayOf((prop_types_default()).string.isRequired)
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Globe03.js
var Globe03 = __webpack_require__(826882);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/AvatarGroup/index.js
var AvatarGroup = __webpack_require__(792438);
var AvatarGroup_default = /*#__PURE__*/__webpack_require__.n(AvatarGroup);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tooltip/index.js
var Tooltip = __webpack_require__(556020);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip);
;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/item-drawer/item-shared.tsx










const ItemShared = (props)=>{
    const { isPublic , shared  } = props;
    const showShared = !isPublic && (shared || []).length > 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        alignItems: "center",
        direction: "row",
        spacing: 1,
        children: [
            isPublic && /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                title: "Public",
                children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                    sx: {
                        height: 32,
                        width: 32
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        fontSize: "small",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Globe03/* default */.Z, {})
                    })
                })
            }),
            showShared && /*#__PURE__*/ jsx_runtime_.jsx((AvatarGroup_default()), {
                max: 3,
                children: shared?.map((person)=>/*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                        src: person.avatar,
                        sx: {
                            height: 32,
                            width: 32
                        }
                    }, person.name))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                    fontSize: "small",
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                })
            })
        ]
    });
};
ItemShared.propTypes = {
    isPublic: (prop_types_default()).bool,
    shared: (prop_types_default()).array
};

;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/item-drawer/item-drawer.tsx





















const ItemDrawer = (props)=>{
    const { item , onClose , onDelete , onFavorite , onTagsChange , open =false  } = props;
    let content = null;
    if (item) {
        const size = (0,bytes_to_size/* bytesToSize */.R)(item.size);
        const createdAt = item.createdAt && (0,date_fns.format)(item.createdAt, "MMM dd, yyyy HH:mm");
        const updatedAt = item.updatedAt && (0,date_fns.format)(item.updatedAt, "MMM dd, yyyy HH:mm");
        content = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    justifyContent: "flex-end",
                    spacing: 2,
                    sx: {
                        p: 3
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            onClick: ()=>onFavorite?.(item.id, !item.isFavorite),
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                fontSize: "small",
                                sx: {
                                    color: item.isFavorite ? "warning.main" : "action.active"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Star01/* default */.Z, {})
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            onClick: onClose,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                fontSize: "small",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(X/* default */.Z, {})
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                    sx: {
                        px: 3,
                        py: 2
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.50",
                                borderColor: (theme)=>theme.palette.mode === "dark" ? "neutral.500" : "neutral.300",
                                borderRadius: 1,
                                borderStyle: "dashed",
                                borderWidth: 1,
                                display: "flex",
                                justifyContent: "center",
                                mb: 2,
                                p: 3
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ItemIcon, {
                                type: item.type,
                                extension: item.extension
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            justifyContent: "space-between",
                            spacing: 2,
                            sx: {
                                mb: 2
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h6",
                                    children: item.name
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        fontSize: "small",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Edit02/* default */.Z, {})
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                            container: true,
                            spacing: 3,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 4,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "caption",
                                        children: "Created by"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 8,
                                    children: item.author && /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                        src: item.author.avatar || undefined
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 4,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "caption",
                                        children: "Size"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 8,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "body2",
                                        children: size
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 4,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "caption",
                                        children: "Created At"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 8,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "body2",
                                        children: createdAt
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 4,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "caption",
                                        children: "Modified At"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 8,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "body2",
                                        children: updatedAt
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 4,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "caption",
                                        children: "Tags"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 8,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ItemTags, {
                                        tags: item.tags,
                                        onChange: (tags)=>onTagsChange?.(item.id, tags)
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 4,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "caption",
                                        children: "Shared with"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 8,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ItemShared, {
                                        isPublic: item.isPublic,
                                        shared: item.shared
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 4,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "caption",
                                        children: "Actions"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 8,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                        onClick: ()=>onDelete?.(item.id),
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            fontSize: "small",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Trash02/* default */.Z, {})
                                        })
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
        anchor: "right",
        ModalProps: {
            sx: {
                [`& .${Backdrop.backdropClasses.root}`]: {
                    background: "transparent !important"
                }
            }
        },
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                maxWidth: "100%",
                width: 400
            }
        },
        children: content
    });
};
ItemDrawer.propTypes = {
    // @ts-ignore
    item: (prop_types_default()).object,
    onClose: (prop_types_default()).func,
    onDelete: (prop_types_default()).func,
    onFavorite: (prop_types_default()).func,
    onTagsChange: (prop_types_default()).func,
    open: (prop_types_default()).bool
};

;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/item-drawer/index.ts


// EXTERNAL MODULE: ./node_modules/@mui/material/node/Table/index.js
var Table = __webpack_require__(620390);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableBody/index.js
var TableBody = __webpack_require__(843606);
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TablePagination/index.js
var TablePagination = __webpack_require__(47651);
var TablePagination_default = /*#__PURE__*/__webpack_require__.n(TablePagination);
// EXTERNAL MODULE: ./src/components/scrollbar.tsx
var scrollbar = __webpack_require__(851716);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/DotsVertical.js
var DotsVertical = __webpack_require__(131563);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Link01.js
var Link01 = __webpack_require__(921695);
;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/item-menu.tsx







const ItemMenu = (props)=>{
    const { anchorEl , onClose , onDelete , open =false  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Menu_default()), {
        anchorEl: anchorEl,
        anchorOrigin: {
            horizontal: "right",
            vertical: "bottom"
        },
        onClose: onClose,
        open: open,
        sx: {
            [`& .${MenuItem.menuItemClasses.root}`]: {
                fontSize: 14,
                "& svg": {
                    mr: 1
                }
            }
        },
        transformOrigin: {
            horizontal: "right",
            vertical: "top"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                onClick: onClose,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        fontSize: "small",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Link01/* default */.Z, {})
                    }),
                    "Copy Link"
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                onClick: onDelete,
                sx: {
                    color: "error.main"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        fontSize: "small",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Trash02/* default */.Z, {})
                    }),
                    "Delete"
                ]
            })
        ]
    });
};
ItemMenu.propTypes = {
    anchorEl: (prop_types_default()).any,
    onClose: (prop_types_default()).func,
    onDelete: (prop_types_default()).func,
    open: (prop_types_default()).bool
};

;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/item-list-card.tsx





















const ItemListCard = (props)=>{
    const { item , onDelete , onFavorite , onOpen  } = props;
    const popover = (0,use_popover/* usePopover */.S)();
    const handleDelete = (0,react_.useCallback)(()=>{
        popover.handleClose();
        onDelete?.(item.id);
    }, [
        item,
        popover,
        onDelete
    ]);
    let size = (0,bytes_to_size/* bytesToSize */.R)(item.size);
    if (item.type === "folder") {
        size += `• ${item.itemsCount} items`;
    }
    const createdAt = item.createdAt && (0,date_fns.format)(item.createdAt, "MMM dd, yyyy");
    const showShared = !item.isPublic && (item.shared || []).length > 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                sx: {
                    backgroundColor: "transparent",
                    boxShadow: 0,
                    transition: (theme)=>theme.transitions.create([
                            "background-color, box-shadow"
                        ], {
                            easing: theme.transitions.easing.easeInOut,
                            duration: 200
                        }),
                    "&:hover": {
                        backgroundColor: "background.paper",
                        boxShadow: 16
                    }
                },
                variant: "outlined",
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        justifyContent: "space-between",
                        spacing: 3,
                        sx: {
                            pt: 2,
                            px: 2
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: ()=>onFavorite?.(item.id, !item.isFavorite),
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    fontSize: "small",
                                    sx: {
                                        color: item.isFavorite ? "warning.main" : "action.active"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Star01/* default */.Z, {})
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: popover.handleOpen,
                                ref: popover.anchorRef,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    fontSize: "small",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(DotsVertical/* default */.Z, {})
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                        sx: {
                            p: 2
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    display: "flex",
                                    mb: 1
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                    onClick: ()=>onOpen?.(item.id),
                                    sx: {
                                        display: "inline-flex",
                                        cursor: "pointer"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ItemIcon, {
                                        type: item.type,
                                        extension: item.extension
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                onClick: ()=>onOpen?.(item.id),
                                sx: {
                                    cursor: "pointer"
                                },
                                variant: "subtitle2",
                                children: item.name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                                sx: {
                                    my: 1
                                }
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                alignItems: "center",
                                direction: "row",
                                justifyContent: "space-between",
                                spacing: 1,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: size
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            item.isPublic && /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                                title: "Public",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                    sx: {
                                                        height: 32,
                                                        width: 32
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                        fontSize: "small",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Globe03/* default */.Z, {})
                                                    })
                                                })
                                            }),
                                            showShared && /*#__PURE__*/ jsx_runtime_.jsx((AvatarGroup_default()), {
                                                max: 3,
                                                children: item.shared?.map((person)=>/*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                        src: person.avatar,
                                                        sx: {
                                                            height: 32,
                                                            width: 32
                                                        }
                                                    }, person.name))
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                color: "text.secondary",
                                variant: "caption",
                                children: [
                                    "Created at ",
                                    createdAt
                                ]
                            })
                        ]
                    })
                ]
            }, item.id),
            /*#__PURE__*/ jsx_runtime_.jsx(ItemMenu, {
                anchorEl: popover.anchorRef.current,
                onClose: popover.handleClose,
                onDelete: handleDelete,
                open: popover.open
            })
        ]
    });
};
ItemListCard.propTypes = {
    // @ts-ignore
    item: (prop_types_default()).object.isRequired,
    onDelete: (prop_types_default()).func,
    onFavorite: (prop_types_default()).func,
    onOpen: (prop_types_default()).func
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableCell/index.js
var TableCell = __webpack_require__(340514);
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableRow/index.js
var TableRow = __webpack_require__(893761);
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow);
;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/item-list-row.tsx





















const ItemListRow = (props)=>{
    const { item , onDelete , onFavorite , onOpen  } = props;
    const popover = (0,use_popover/* usePopover */.S)();
    const handleDelete = (0,react_.useCallback)(()=>{
        popover.handleClose();
        onDelete?.(item.id);
    }, [
        item,
        popover,
        onDelete
    ]);
    let size = (0,bytes_to_size/* bytesToSize */.R)(item.size);
    if (item.type === "folder") {
        size += `• ${item.itemsCount} items`;
    }
    const createdAt = item.createdAt && (0,date_fns.format)(item.createdAt, "MMM dd, yyyy");
    const showShared = !item.isPublic && (item.shared || []).length > 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                sx: {
                    backgroundColor: "transparent",
                    borderRadius: 1.5,
                    boxShadow: 0,
                    transition: (theme)=>theme.transitions.create([
                            "background-color",
                            "box-shadow"
                        ], {
                            easing: theme.transitions.easing.easeInOut,
                            duration: 200
                        }),
                    "&:hover": {
                        backgroundColor: "background.paper",
                        boxShadow: 16
                    },
                    [`& .${TableCell.tableCellClasses.root}`]: {
                        borderBottomWidth: 1,
                        borderBottomColor: "divider",
                        borderBottomStyle: "solid",
                        borderTopWidth: 1,
                        borderTopColor: "divider",
                        borderTopStyle: "solid",
                        "&:first-of-type": {
                            borderTopLeftRadius: (theme)=>theme.shape.borderRadius * 1.5,
                            borderBottomLeftRadius: (theme)=>theme.shape.borderRadius * 1.5,
                            borderLeftWidth: 1,
                            borderLeftColor: "divider",
                            borderLeftStyle: "solid"
                        },
                        "&:last-of-type": {
                            borderTopRightRadius: (theme)=>theme.shape.borderRadius * 1.5,
                            borderBottomRightRadius: (theme)=>theme.shape.borderRadius * 1.5,
                            borderRightWidth: 1,
                            borderRightColor: "divider",
                            borderRightStyle: "solid"
                        }
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                    onClick: ()=>onOpen?.(item.id),
                                    sx: {
                                        cursor: "pointer"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ItemIcon, {
                                        type: item.type,
                                        extension: item.extension
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            noWrap: true,
                                            onClick: ()=>onOpen?.(item.id),
                                            sx: {
                                                cursor: "pointer"
                                            },
                                            variant: "subtitle2",
                                            children: item.name
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            noWrap: true,
                                            variant: "body2",
                                            children: size
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                noWrap: true,
                                variant: "subtitle2",
                                children: "Created at"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.secondary",
                                noWrap: true,
                                variant: "body2",
                                children: createdAt
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                display: "flex"
                            },
                            children: [
                                item.isPublic && /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                    title: "Public",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                        sx: {
                                            height: 32,
                                            width: 32
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            fontSize: "small",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Globe03/* default */.Z, {})
                                        })
                                    })
                                }),
                                showShared && /*#__PURE__*/ jsx_runtime_.jsx((AvatarGroup_default()), {
                                    max: 3,
                                    children: item.shared?.map((person)=>/*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                            src: person.avatar,
                                            sx: {
                                                height: 32,
                                                width: 32
                                            }
                                        }, person.name))
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                        align: "right",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            onClick: ()=>onFavorite?.(item.id, !item.isFavorite),
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                fontSize: "small",
                                sx: {
                                    color: item.isFavorite ? "warning.main" : "action.active"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Star01/* default */.Z, {})
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                        align: "right",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            onClick: popover.handleOpen,
                            ref: popover.anchorRef,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                fontSize: "small",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(DotsVertical/* default */.Z, {})
                            })
                        })
                    })
                ]
            }, item.id),
            /*#__PURE__*/ jsx_runtime_.jsx(ItemMenu, {
                anchorEl: popover.anchorRef.current,
                onClose: popover.handleClose,
                onDelete: handleDelete,
                open: popover.open
            })
        ]
    });
};
ItemListRow.propTypes = {
    // @ts-ignore
    item: (prop_types_default()).object.isRequired,
    onDelete: (prop_types_default()).func,
    onFavorite: (prop_types_default()).func,
    onOpen: (prop_types_default()).func
};

;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/item-list.tsx










const ItemList = (props)=>{
    const { count =0 , items =[] , onDelete , onFavorite , onOpen , onPageChange =()=>{} , onRowsPerPageChange , page =0 , rowsPerPage =0 , view ="grid"  } = props;
    let content;
    if (view === "grid") {
        content = /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
            sx: {
                display: "grid",
                gap: 3,
                gridTemplateColumns: "repeat(3, 1fr)"
            },
            children: items.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(ItemListCard, {
                    item: item,
                    onDelete: onDelete,
                    onFavorite: onFavorite,
                    onOpen: onOpen
                }, item.id))
        });
    } else {
        // Negative margin is a fix for the box shadow. The virtual scrollbar cuts it.
        content = /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
            sx: {
                m: -3
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        p: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Table_default()), {
                        sx: {
                            minWidth: 600,
                            borderCollapse: "separate",
                            borderSpacing: "0 8px"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                            children: items.map((item)=>/*#__PURE__*/ jsx_runtime_.jsx(ItemListRow, {
                                    item: item,
                                    onDelete: onDelete,
                                    onFavorite: onFavorite,
                                    onOpen: onOpen
                                }, item.id))
                        })
                    })
                })
            })
        });
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 4,
        children: [
            content,
            /*#__PURE__*/ jsx_runtime_.jsx((TablePagination_default()), {
                component: "div",
                count: count,
                onPageChange: onPageChange,
                onRowsPerPageChange: onRowsPerPageChange,
                page: page,
                rowsPerPage: rowsPerPage,
                rowsPerPageOptions: [
                    9,
                    18
                ]
            })
        ]
    });
};
ItemList.propTypes = {
    items: (prop_types_default()).array,
    count: (prop_types_default()).number,
    onDelete: (prop_types_default()).func,
    onFavorite: (prop_types_default()).func,
    onOpen: (prop_types_default()).func,
    onPageChange: (prop_types_default()).func,
    onRowsPerPageChange: (prop_types_default()).func,
    page: (prop_types_default()).number,
    rowsPerPage: (prop_types_default()).number,
    view: prop_types_default().oneOf([
        "grid",
        "list"
    ])
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Grid01.js
var Grid01 = __webpack_require__(706806);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/List.js
var List = __webpack_require__(455978);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/SearchMd.js
var SearchMd = __webpack_require__(219057);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/InputAdornment/index.js
var InputAdornment = __webpack_require__(79150);
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/OutlinedInput/index.js
var OutlinedInput = __webpack_require__(877829);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TextField/index.js
var TextField = __webpack_require__(28379);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ToggleButton/index.js
var ToggleButton = __webpack_require__(642002);
var ToggleButton_default = /*#__PURE__*/__webpack_require__.n(ToggleButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ToggleButtonGroup/index.js
var ToggleButtonGroup = __webpack_require__(753844);
var ToggleButtonGroup_default = /*#__PURE__*/__webpack_require__.n(ToggleButtonGroup);
;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/item-search.tsx















const sortOptions = [
    {
        label: "Latest",
        value: "desc"
    },
    {
        label: "Oldest",
        value: "asc"
    }
];
const ItemSearch = (props)=>{
    const { onFiltersChange , onSortChange , onViewChange , view ="grid" , // sortBy = 'createdAt',
    sortDir ="asc"  } = props;
    const queryRef = (0,react_.useRef)(null);
    const handleQueryChange = (0,react_.useCallback)((event)=>{
        event.preventDefault();
        const query = queryRef.current?.value || "";
        onFiltersChange?.({
            query
        });
    }, [
        onFiltersChange
    ]);
    const handleSortChange = (0,react_.useCallback)((event)=>{
        const sortDir = event.target.value;
        onSortChange?.(sortDir);
    }, [
        onSortChange
    ]);
    const handleViewChange = (0,react_.useCallback)((event, value)=>{
        onViewChange?.(value);
    }, [
        onViewChange
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
            alignItems: "center",
            direction: "row",
            gap: 2,
            sx: {
                p: 2
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "form",
                    onSubmit: handleQueryChange,
                    sx: {
                        flexGrow: 1
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                        defaultValue: "",
                        fullWidth: true,
                        inputProps: {
                            ref: queryRef
                        },
                        name: "itemName",
                        placeholder: "Search",
                        startAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                            position: "start",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(SearchMd/* default */.Z, {})
                            })
                        })
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ToggleButtonGroup_default()), {
                    exclusive: true,
                    onChange: handleViewChange,
                    sx: {
                        borderWidth: 1,
                        borderColor: "divider",
                        borderStyle: "solid",
                        [`& .${ToggleButtonGroup.toggleButtonGroupClasses.grouped}`]: {
                            margin: 0.5,
                            border: 0,
                            "&:not(:first-of-type)": {
                                borderRadius: 1
                            },
                            "&:first-of-type": {
                                borderRadius: 1
                            }
                        }
                    },
                    value: view,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((ToggleButton_default()), {
                            value: "grid",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                fontSize: "small",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Grid01/* default */.Z, {})
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((ToggleButton_default()), {
                            value: "list",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                fontSize: "small",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(List/* default */.Z, {})
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                    label: "Sort By",
                    name: "sort",
                    onChange: handleSortChange,
                    select: true,
                    SelectProps: {
                        native: true
                    },
                    value: sortDir,
                    children: sortOptions.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                            value: option.value,
                            children: option.label
                        }, option.value))
                })
            ]
        })
    });
};
ItemSearch.propTypes = {
    onFiltersChange: (prop_types_default()).func,
    onSortChange: (prop_types_default()).func,
    onViewChange: (prop_types_default()).func,
    sortBy: (prop_types_default()).string,
    sortDir: prop_types_default().oneOf([
        "asc",
        "desc"
    ]),
    view: prop_types_default().oneOf([
        "grid",
        "list"
    ])
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Lightning01.js
var Lightning01 = __webpack_require__(259079);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardActions/index.js
var CardActions = __webpack_require__(640362);
var CardActions_default = /*#__PURE__*/__webpack_require__.n(CardActions);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/List/index.js
var node_List = __webpack_require__(854436);
var List_default = /*#__PURE__*/__webpack_require__.n(node_List);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItem/index.js
var ListItem = __webpack_require__(790777);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemIcon/index.js
var ListItemIcon = __webpack_require__(126765);
var ListItemIcon_default = /*#__PURE__*/__webpack_require__.n(ListItemIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemText/index.js
var ListItemText = __webpack_require__(846517);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
// EXTERNAL MODULE: ./src/components/chart.tsx
var chart = __webpack_require__(400929);
;// CONCATENATED MODULE: ./src/sections/dashboard/file-manager/storage-stats.tsx




















const useChartOptions = (usage)=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            redrawOnParentResize: false,
            redrawOnWindowResize: false
        },
        colors: [
            theme.palette.primary.main
        ],
        fill: {
            opacity: 1,
            type: "solid"
        },
        grid: {
            padding: {
                bottom: 0,
                left: 0,
                right: 0,
                top: 0
            }
        },
        labels: [
            usage
        ],
        plotOptions: {
            radialBar: {
                dataLabels: {
                    name: {
                        color: theme.palette.text.primary,
                        fontSize: "24px",
                        fontWeight: 500,
                        show: true,
                        offsetY: -15
                    },
                    value: {
                        show: false
                    }
                },
                endAngle: 90,
                hollow: {
                    size: "60%"
                },
                startAngle: -90,
                track: {
                    background: theme.palette.mode === "dark" ? theme.palette.primary.dark : theme.palette.primary.light,
                    strokeWidth: "100%"
                }
            }
        },
        states: {
            active: {
                filter: {
                    type: "none"
                }
            },
            hover: {
                filter: {
                    type: "none"
                }
            }
        },
        stroke: {
            lineCap: "round"
        },
        theme: {
            mode: theme.palette.mode
        }
    };
};
const totals = [
    {
        extension: "mp4",
        itemsCount: 25,
        label: "MP4",
        size: 24431234531
    },
    {
        extension: "png",
        itemsCount: 591,
        label: "PNG",
        size: 58723843923
    },
    {
        extension: "pdf",
        itemsCount: 95,
        label: "PDF",
        size: 432424040
    },
    {
        extension: null,
        itemsCount: 210,
        label: "Other",
        size: 274128437
    }
];
const StorageStats = ()=>{
    const currentUsage = "75 GB";
    const currentUsagePercentage = 75;
    const chartOptions = useChartOptions(currentUsage);
    const chartSeries = [
        currentUsagePercentage
    ];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                title: "Storage",
                subheader: "Upgrade before reaching it"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    height: 260,
                                    mt: "-48px",
                                    mb: "-100px"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                                    width: 260,
                                    height: 260,
                                    options: chartOptions,
                                    series: chartSeries,
                                    type: "radialBar"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "h6",
                                sx: {
                                    mb: 1
                                },
                                children: "You’ve almost reached your limit"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                color: "text.secondary",
                                variant: "body2",
                                children: [
                                    "You have used ",
                                    currentUsagePercentage,
                                    "% of your available storage."
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                        disablePadding: true,
                        sx: {
                            mt: 2
                        },
                        children: totals.map((total)=>{
                            const size = (0,bytes_to_size/* bytesToSize */.R)(total.size);
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                disableGutters: true,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                            sx: {
                                                color: "primary.main"
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(file_icon/* FileIcon */.a, {
                                                extension: total.extension
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                        primary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "caption",
                                            children: total.label
                                        }),
                                        secondary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: [
                                                size,
                                                " • ",
                                                total.itemsCount,
                                                " items"
                                            ]
                                        })
                                    })
                                ]
                            }, total.extension);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                sx: {
                    justifyContent: "flex-end"
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                    endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        fontSize: "small",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Lightning01/* default */.Z, {})
                    }),
                    size: "small",
                    variant: "contained",
                    children: "Upgrade Plan"
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/app/(dashboard)/file-manager/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 




















const useItemsSearch = ()=>{
    const [state, setState] = (0,react_.useState)({
        filters: {
            query: undefined
        },
        page: 0,
        rowsPerPage: 9,
        sortBy: "createdAt",
        sortDir: "desc"
    });
    const handleFiltersChange = (0,react_.useCallback)((filters)=>{
        setState((prevState)=>({
                ...prevState,
                filters
            }));
    }, []);
    const handleSortChange = (0,react_.useCallback)((sortDir)=>{
        setState((prevState)=>({
                ...prevState,
                sortDir
            }));
    }, []);
    const handlePageChange = (0,react_.useCallback)((event, page)=>{
        setState((prevState)=>({
                ...prevState,
                page
            }));
    }, []);
    const handleRowsPerPageChange = (0,react_.useCallback)((event)=>{
        setState((prevState)=>({
                ...prevState,
                rowsPerPage: parseInt(event.target.value, 10)
            }));
    }, []);
    return {
        handleFiltersChange,
        handleSortChange,
        handlePageChange,
        handleRowsPerPageChange,
        state
    };
};
const useItemsStore = (searchState)=>{
    const isMounted = (0,use_mounted/* useMounted */.s)();
    const [state, setState] = (0,react_.useState)({
        items: [],
        itemsCount: 0
    });
    const handleItemsGet = (0,react_.useCallback)(async ()=>{
        try {
            const response = await fileManagerApi.getItems(searchState);
            if (isMounted()) {
                setState({
                    items: response.data,
                    itemsCount: response.count
                });
            }
        } catch (err) {
            console.error(err);
        }
    }, [
        searchState,
        isMounted
    ]);
    (0,react_.useEffect)(()=>{
        handleItemsGet();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        searchState
    ]);
    const handleDelete = (0,react_.useCallback)((itemId)=>{
        // api call should be made here, then get the list again
        setState((prevState)=>{
            return {
                ...prevState,
                items: prevState.items.filter((item)=>item.id !== itemId)
            };
        });
    }, []);
    const handleFavorite = (0,react_.useCallback)((itemId, value)=>{
        setState((prevState)=>{
            return {
                ...prevState,
                items: prevState.items.map((item)=>{
                    if (item.id === itemId) {
                        return {
                            ...item,
                            isFavorite: value
                        };
                    }
                    return item;
                })
            };
        });
    }, []);
    return {
        handleDelete,
        handleFavorite,
        ...state
    };
};
const useCurrentItem = (items, itemId)=>{
    return (0,react_.useMemo)(()=>{
        if (!itemId) {
            return undefined;
        }
        return items.find((item)=>item.id === itemId);
    }, [
        items,
        itemId
    ]);
};
const Page = ()=>{
    const settings = (0,use_settings/* useSettings */.r)();
    const itemsSearch = useItemsSearch();
    const itemsStore = useItemsStore(itemsSearch.state);
    const [view, setView] = (0,react_.useState)("grid");
    const uploadDialog = (0,use_dialog/* useDialog */.R)();
    const detailsDialog = (0,use_dialog/* useDialog */.R)();
    const currentItem = useCurrentItem(itemsStore.items, detailsDialog.data);
    (0,use_page_view/* usePageView */.a)();
    const handleDelete = (0,react_.useCallback)((itemId)=>{
        // This can be triggered from multiple places, ensure drawer is closed.
        detailsDialog.handleClose();
        itemsStore.handleDelete(itemId);
    }, [
        detailsDialog,
        itemsStore
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: File Manager"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "main",
                sx: {
                    flexGrow: 1,
                    py: 8
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                    maxWidth: settings.stretch ? false : "xl",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                        container: true,
                        spacing: {
                            xs: 3,
                            lg: 4
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    direction: "row",
                                    justifyContent: "space-between",
                                    spacing: 4,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "h4",
                                                children: "File Manager"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                            alignItems: "center",
                                            direction: "row",
                                            spacing: 2,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                onClick: uploadDialog.handleOpen,
                                                startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Upload01/* default */.Z, {})
                                                }),
                                                variant: "contained",
                                                children: "Upload"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 8,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    spacing: {
                                        xs: 3,
                                        lg: 4
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(ItemSearch, {
                                            onFiltersChange: itemsSearch.handleFiltersChange,
                                            onSortChange: itemsSearch.handleSortChange,
                                            onViewChange: setView,
                                            sortBy: itemsSearch.state.sortBy,
                                            sortDir: itemsSearch.state.sortDir,
                                            view: view
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(ItemList, {
                                            count: itemsStore.itemsCount,
                                            items: itemsStore.items,
                                            onDelete: handleDelete,
                                            onFavorite: itemsStore.handleFavorite,
                                            onOpen: detailsDialog.handleOpen,
                                            onPageChange: itemsSearch.handlePageChange,
                                            onRowsPerPageChange: itemsSearch.handleRowsPerPageChange,
                                            page: itemsSearch.state.page,
                                            rowsPerPage: itemsSearch.state.rowsPerPage,
                                            view: view
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(StorageStats, {})
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(ItemDrawer, {
                item: currentItem,
                onClose: detailsDialog.handleClose,
                onDelete: handleDelete,
                onFavorite: itemsStore.handleFavorite,
                open: detailsDialog.open
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(FileUploader, {
                onClose: uploadDialog.handleClose,
                open: uploadDialog.open
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 756964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ useDialog)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useDialog() {
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        open: false,
        data: undefined
    });
    const handleOpen = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((data)=>{
        setState({
            open: true,
            data
        });
    }, []);
    const handleClose = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setState({
            open: false
        });
    }, []);
    return {
        data: state.data,
        handleClose,
        handleOpen,
        open: state.open
    };
}


/***/ }),

/***/ 333324:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/file-manager/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,9535,3194,9353,2765,9074,6461,5978,4286,7680,95,9494,2302,1734,717,929,2235], () => (__webpack_exec__(754911)));
module.exports = __webpack_exports__;

})();