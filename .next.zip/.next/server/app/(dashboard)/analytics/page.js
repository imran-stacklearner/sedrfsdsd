(() => {
var exports = {};
exports.id = 9302;
exports.ids = [9302];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 391650:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'analytics',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 348952, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/analytics/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/analytics/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/analytics/page"
  

/***/ }),

/***/ 224285:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 291848))

/***/ }),

/***/ 291848:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ArrowRight.js
var ArrowRight = __webpack_require__(394284);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Plus.js
var Plus = __webpack_require__(959309);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/hooks/use-settings.ts
var use_settings = __webpack_require__(488141);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardActions/index.js
var CardActions = __webpack_require__(640362);
var CardActions_default = /*#__PURE__*/__webpack_require__.n(CardActions);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
// EXTERNAL MODULE: ./src/components/chart.tsx
var chart = __webpack_require__(400929);
;// CONCATENATED MODULE: ./src/sections/dashboard/analytics/analytics-stats.tsx










const useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            toolbar: {
                show: false
            },
            zoom: {
                enabled: false
            }
        },
        colors: [
            theme.palette.primary.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            gradient: {
                opacityFrom: 0.5,
                opacityTo: 0,
                stops: [
                    0,
                    100
                ]
            },
            type: "gradient"
        },
        grid: {
            show: false,
            padding: {
                bottom: 0,
                left: 0,
                right: 0,
                top: 0
            }
        },
        stroke: {
            curve: "smooth",
            width: 3
        },
        theme: {
            mode: theme.palette.mode
        },
        tooltip: {
            enabled: false
        },
        xaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            },
            labels: {
                show: false
            }
        },
        yaxis: {
            show: false
        }
    };
};
const AnalyticsStats = (props)=>{
    const { action , chartSeries , value , title  } = props;
    const chartOptions = useChartOptions();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                justifyContent: "space-between",
                spacing: 2,
                sx: {
                    px: 3,
                    py: 2
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.secondary",
                                variant: "body2",
                                children: title
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mt: 1
                                },
                                variant: "h5",
                                children: value
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            width: 200
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                            height: 100,
                            options: chartOptions,
                            series: chartSeries,
                            type: "area"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                children: action
            })
        ]
    });
};
AnalyticsStats.propTypes = {
    action: (prop_types_default()).any.isRequired,
    chartSeries: (prop_types_default()).array.isRequired,
    title: (prop_types_default()).string.isRequired,
    value: (prop_types_default()).string.isRequired
};

// EXTERNAL MODULE: ./node_modules/numeral/numeral.js
var numeral = __webpack_require__(518470);
var numeral_default = /*#__PURE__*/__webpack_require__.n(numeral);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/InfoCircle.js
var InfoCircle = __webpack_require__(359825);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/LinkExternal01.js
var LinkExternal01 = __webpack_require__(890109);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Table/index.js
var Table = __webpack_require__(620390);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableBody/index.js
var TableBody = __webpack_require__(843606);
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableCell/index.js
var TableCell = __webpack_require__(340514);
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableHead/index.js
var TableHead = __webpack_require__(30092);
var TableHead_default = /*#__PURE__*/__webpack_require__.n(TableHead);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableRow/index.js
var TableRow = __webpack_require__(893761);
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tooltip/index.js
var Tooltip = __webpack_require__(556020);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip);
// EXTERNAL MODULE: ./src/components/scrollbar.tsx
var scrollbar = __webpack_require__(851716);
;// CONCATENATED MODULE: ./src/sections/dashboard/analytics/analytics-most-visited.tsx


















const AnalyticsMostVisited = (props)=>{
    const { pages  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                title: "Most Visited Pages",
                action: /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                    title: "Refresh rate is 24h",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        color: "action",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(InfoCircle/* default */.Z, {})
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                    sx: {
                        minWidth: 600
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((TableHead_default()), {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: "Page Name"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: "Visitors"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: "Unique page visits"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: "Bounce rate"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                            children: pages.map((page)=>{
                                const visitors = numeral_default()(page.visitors).format("0,0");
                                const uniqueVisitors = numeral_default()(page.uniqueVisits).format("0,0");
                                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                    sx: {
                                        "&:last-child td, &:last-child th": {
                                            border: 0
                                        }
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                color: "text.primary",
                                                href: "#",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                    alignItems: "center",
                                                    direction: "row",
                                                    spacing: 2,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                            fontSize: "small",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(LinkExternal01/* default */.Z, {})
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            variant: "body2",
                                                            children: page.url
                                                        })
                                                    ]
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: visitors
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: uniqueVisitors
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                            children: [
                                                page.bounceRate,
                                                "%"
                                            ]
                                        })
                                    ]
                                }, page.url);
                            })
                        })
                    ]
                })
            })
        ]
    });
};
AnalyticsMostVisited.propTypes = {
    pages: (prop_types_default()).array.isRequired
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
;// CONCATENATED MODULE: ./src/sections/dashboard/analytics/analytics-social-sources.tsx














const analytics_social_sources_useChartOptions = (labels)=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.warning.main,
            theme.palette.info.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        labels,
        legend: {
            show: false
        },
        plotOptions: {
            pie: {
                expandOnClick: false
            }
        },
        states: {
            active: {
                filter: {
                    type: "none"
                }
            },
            hover: {
                filter: {
                    type: "none"
                }
            }
        },
        stroke: {
            width: 0
        },
        theme: {
            mode: theme.palette.mode
        },
        tooltip: {
            fillSeriesColor: false
        }
    };
};
const AnalyticsSocialSources = (props)=>{
    const { chartSeries , labels  } = props;
    const chartOptions = analytics_social_sources_useChartOptions(labels);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                title: "Social Media Sources",
                action: /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                    title: "Refresh rate is 24h",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        color: "action",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(InfoCircle/* default */.Z, {})
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                        height: 200,
                        options: chartOptions,
                        series: chartSeries,
                        type: "donut"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        container: true,
                        spacing: 1,
                        children: chartSeries.map((item, index)=>/*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 6,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 1,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                            sx: {
                                                backgroundColor: chartOptions.colors[index],
                                                borderRadius: "50%",
                                                height: 8,
                                                width: 8
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: labels[index]
                                        })
                                    ]
                                })
                            }, index))
                    })
                ]
            })
        ]
    });
};
AnalyticsSocialSources.propTypes = {
    chartSeries: (prop_types_default()).any.isRequired,
    labels: (prop_types_default()).array.isRequired
};

;// CONCATENATED MODULE: ./src/sections/dashboard/analytics/analytics-traffic-sources.tsx







const analytics_traffic_sources_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: true,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.mode === "dark" ? theme.palette.primary.darkest : theme.palette.primary.light
        ],
        dataLabels: {
            enabled: false
        },
        legend: {
            show: false
        },
        grid: {
            borderColor: theme.palette.divider,
            padding: {
                bottom: 0,
                left: 0,
                right: 0,
                top: 0
            },
            strokeDashArray: 2
        },
        plotOptions: {
            bar: {
                borderRadius: 8,
                columnWidth: "32px",
                horizontal: true
            }
        },
        theme: {
            mode: theme.palette.mode
        },
        xaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            },
            categories: [
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
            ],
            labels: {
                style: {
                    colors: theme.palette.text.secondary
                }
            }
        },
        yaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            },
            labels: {
                show: false
            }
        }
    };
};
const AnalyticsTrafficSources = (props)=>{
    const { chartSeries  } = props;
    const chartOptions = analytics_traffic_sources_useChartOptions();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                sx: {
                    pb: 0
                },
                title: "Traffic Sources"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                sx: {
                    pt: 0
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                    height: 400,
                    options: chartOptions,
                    series: chartSeries,
                    type: "bar"
                })
            })
        ]
    });
};
AnalyticsTrafficSources.propTypes = {
    chartSeries: (prop_types_default()).any.isRequired
};

// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableSortLabel/index.js
var TableSortLabel = __webpack_require__(641426);
var TableSortLabel_default = /*#__PURE__*/__webpack_require__.n(TableSortLabel);
// EXTERNAL MODULE: ./src/utils/apply-sort.ts
var apply_sort = __webpack_require__(391734);
;// CONCATENATED MODULE: ./src/sections/dashboard/analytics/analytics-visits-by-country.tsx






















const flagMap = {
    ca: "/assets/flags/flag-ca.svg",
    de: "/assets/flags/flag-de.svg",
    es: "/assets/flags/flag-es.svg",
    ru: "/assets/flags/flag-ru.svg",
    uk: "/assets/flags/flag-uk.svg",
    us: "/assets/flags/flag-us.svg"
};
const AnalyticsVisitsByCountry = (props)=>{
    const { visits  } = props;
    const [sort, setSort] = (0,react_.useState)("desc");
    const sortedVisits = (0,react_.useMemo)(()=>{
        return (0,apply_sort/* applySort */.v)(visits, "value", sort);
    }, [
        visits,
        sort
    ]);
    const handleSort = (0,react_.useCallback)(()=>{
        setSort((prevState)=>{
            if (prevState === "asc") {
                return "desc";
            }
            return "asc";
        });
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                title: "Visits by Country",
                action: /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                    title: "Refresh rate is 24h",
                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        color: "action",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(InfoCircle/* default */.Z, {})
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((TableHead_default()), {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                    children: "Country"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                    sortDirection: sort,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((TableSortLabel_default()), {
                                        active: true,
                                        direction: sort,
                                        onClick: handleSort,
                                        children: "Value"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                    children: "SEO"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                        children: sortedVisits.map((visit)=>{
                            const visits = numeral_default()(visit.value).format("0,0");
                            const flag = flagMap[visit.id];
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                sx: {
                                    "&:last-child td, &:last-child th": {
                                        border: 0
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                            sx: {
                                                alignItems: "center",
                                                display: "flex"
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                    sx: {
                                                        height: 16,
                                                        width: 16,
                                                        "& img": {
                                                            height: 16,
                                                            width: 16
                                                        }
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                        alt: visit.name,
                                                        src: flag
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    sx: {
                                                        ml: 1
                                                    },
                                                    variant: "subtitle2",
                                                    children: visit.name
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: visits
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                        children: [
                                            visit.seoPercentage,
                                            "%"
                                        ]
                                    })
                                ]
                            }, visit.id);
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                    color: "inherit",
                    endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                    }),
                    size: "small",
                    children: "See more"
                })
            })
        ]
    });
};
AnalyticsVisitsByCountry.propTypes = {
    visits: (prop_types_default()).array.isRequired
};

;// CONCATENATED MODULE: ./src/app/(dashboard)/analytics/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 

















const Page = ()=>{
    const settings = (0,use_settings/* useSettings */.r)();
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: Analytics"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "main",
                sx: {
                    flexGrow: 1,
                    py: 8
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                    maxWidth: settings.stretch ? false : "xl",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                        container: true,
                        spacing: {
                            xs: 3,
                            lg: 4
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    direction: "row",
                                    justifyContent: "space-between",
                                    spacing: 4,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                            spacing: 1,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "h4",
                                                children: "Analytics"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                            alignItems: "center",
                                            direction: "row",
                                            spacing: 2,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                                                }),
                                                variant: "contained",
                                                children: "New Dashboard"
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(AnalyticsStats, {
                                    action: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                        color: "inherit",
                                        endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                                        }),
                                        size: "small",
                                        children: "See sources"
                                    }),
                                    chartSeries: [
                                        {
                                            data: [
                                                0,
                                                170,
                                                242,
                                                98,
                                                63,
                                                56,
                                                85,
                                                171,
                                                209,
                                                163,
                                                204,
                                                21,
                                                264,
                                                0
                                            ]
                                        }
                                    ],
                                    title: "Impressions",
                                    value: "36,6K"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(AnalyticsStats, {
                                    action: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                        color: "inherit",
                                        endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                                        }),
                                        size: "small",
                                        children: "See traffic"
                                    }),
                                    chartSeries: [
                                        {
                                            data: [
                                                0,
                                                245,
                                                290,
                                                187,
                                                172,
                                                106,
                                                15,
                                                210,
                                                202,
                                                19,
                                                18,
                                                3,
                                                212,
                                                0
                                            ]
                                        }
                                    ],
                                    title: "Engagements",
                                    value: "19K"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(AnalyticsStats, {
                                    action: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                        color: "inherit",
                                        endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                                        }),
                                        size: "small",
                                        children: "See campaigns"
                                    }),
                                    chartSeries: [
                                        {
                                            data: [
                                                0,
                                                277,
                                                191,
                                                93,
                                                92,
                                                85,
                                                166,
                                                240,
                                                63,
                                                4,
                                                296,
                                                144,
                                                166,
                                                0
                                            ]
                                        }
                                    ],
                                    title: "Spent",
                                    value: "$41.2K"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                lg: 8,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(AnalyticsTrafficSources, {
                                    chartSeries: [
                                        {
                                            name: "Organic",
                                            data: [
                                                45,
                                                40,
                                                37,
                                                41,
                                                42,
                                                45,
                                                42
                                            ]
                                        },
                                        {
                                            name: "Marketing",
                                            data: [
                                                19,
                                                26,
                                                22,
                                                19,
                                                22,
                                                24,
                                                28
                                            ]
                                        }
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                lg: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(AnalyticsVisitsByCountry, {
                                    visits: [
                                        {
                                            id: "us",
                                            name: "United States",
                                            seoPercentage: 40,
                                            value: 31200
                                        },
                                        {
                                            id: "uk",
                                            name: "United Kingdom",
                                            seoPercentage: 47,
                                            value: 12700
                                        },
                                        {
                                            id: "ru",
                                            name: "Russia",
                                            seoPercentage: 65,
                                            value: 10360
                                        },
                                        {
                                            id: "ca",
                                            name: "Canada",
                                            seoPercentage: 23,
                                            value: 5749
                                        },
                                        {
                                            id: "de",
                                            name: "Germany",
                                            seoPercentage: 45,
                                            value: 2932
                                        },
                                        {
                                            id: "es",
                                            name: "Spain",
                                            seoPercentage: 56,
                                            value: 200
                                        }
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                lg: 8,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(AnalyticsMostVisited, {
                                    pages: [
                                        {
                                            bounceRate: 16,
                                            uniqueVisits: 8584,
                                            url: "/",
                                            visitors: 95847
                                        },
                                        {
                                            bounceRate: 5,
                                            uniqueVisits: 648,
                                            url: "/auth/login",
                                            visitors: 7500
                                        },
                                        {
                                            bounceRate: 2,
                                            uniqueVisits: 568,
                                            url: "/dashboard",
                                            visitors: 85406
                                        },
                                        {
                                            bounceRate: 12,
                                            uniqueVisits: 12322,
                                            url: "/blog/top-5-react-frameworks",
                                            visitors: 75050
                                        },
                                        {
                                            bounceRate: 10,
                                            uniqueVisits: 11645,
                                            url: "/blog/understand-programming-principles",
                                            visitors: 68003
                                        },
                                        {
                                            bounceRate: 8,
                                            uniqueVisits: 10259,
                                            url: "/blog/design-patterns",
                                            visitors: 49510
                                        }
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                lg: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(AnalyticsSocialSources, {
                                    chartSeries: [
                                        10,
                                        10,
                                        20
                                    ],
                                    labels: [
                                        "Linkedin",
                                        "Facebook",
                                        "Instagram"
                                    ]
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 348952:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/analytics/page.tsx");


/***/ }),

/***/ 959309:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(369885);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(556786);



var Plus = function Plus(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "none"
  }, props, {
    children: /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: 2,
      d: "M12 5v14m-7-7h14"
    })
  }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Plus);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,8470,9535,9189,109,7680,95,9494,2302,1734,929], () => (__webpack_exec__(391650)));
module.exports = __webpack_exports__;

})();