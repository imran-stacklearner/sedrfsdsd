(() => {
var exports = {};
exports.id = 1470;
exports.ids = [1470];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 506478:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'account',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 347987, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/account/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/account/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/account/page"
  

/***/ }),

/***/ 75456:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 36531))

/***/ }),

/***/ 36531:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tab/index.js
var Tab = __webpack_require__(189733);
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tabs/index.js
var Tabs = __webpack_require__(790206);
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-mocked-user.ts
var use_mocked_user = __webpack_require__(782851);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/numeral/numeral.js
var numeral = __webpack_require__(518470);
var numeral_default = /*#__PURE__*/__webpack_require__.n(numeral);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Edit02.js
var Edit02 = __webpack_require__(956461);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Table/index.js
var Table = __webpack_require__(620390);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableBody/index.js
var TableBody = __webpack_require__(843606);
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableCell/index.js
var TableCell = __webpack_require__(340514);
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableHead/index.js
var TableHead = __webpack_require__(30092);
var TableHead_default = /*#__PURE__*/__webpack_require__.n(TableHead);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableRow/index.js
var TableRow = __webpack_require__(893761);
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow);
// EXTERNAL MODULE: ./src/components/property-list.tsx
var property_list = __webpack_require__(982009);
// EXTERNAL MODULE: ./src/components/property-list-item.tsx
var property_list_item = __webpack_require__(925115);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
;// CONCATENATED MODULE: ./src/sections/dashboard/account/account-plan-icon.tsx



const AccountPlanIcon = (props)=>{
    const { name  } = props;
    const theme = (0,styles.useTheme)();
    const fillColor = theme.palette.primary.main;
    switch(name){
        case "startup":
            return /*#__PURE__*/ jsx_runtime_.jsx("svg", {
                fill: "none",
                height: "33",
                viewBox: "0 0 24 33",
                width: "24",
                xmlns: "http://www.w3.org/2000/svg",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M13.7898 0.492981L23.0191 5.55771C23.2324 5.67468 23.4097 5.84498 23.5332 6.05102C23.6567 6.25713 23.7218 6.49154 23.7218 6.73031C23.7218 6.96907 23.6567 7.20348 23.5332 7.4096C23.4097 7.61564 23.2324 7.78594 23.0191 7.9029L13.7899 12.9679C13.2008 13.2911 12.5366 13.4609 11.861 13.4609C11.1852 13.4609 10.521 13.2911 9.93202 12.9679L0.702682 7.9029C0.489532 7.78594 0.312084 7.61564 0.188587 7.4096C0.0650921 7.20348 -9.53674e-06 6.96907 -9.53674e-06 6.73031C-9.53674e-06 6.49154 0.0650921 6.25713 0.188587 6.05102C0.312084 5.84498 0.489532 5.67468 0.702682 5.55771L9.93202 0.492981C10.521 0.169739 11.1852 -5.72205e-06 11.861 -5.72205e-06C12.5366 -5.72205e-06 13.2008 0.169739 13.7898 0.492981Z",
                    fill: fillColor
                })
            });
        case "standard":
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                fill: "none",
                height: "33",
                viewBox: "0 0 33 33",
                width: "33",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M18.4946 0.492981L27.7239 5.55771C27.9372 5.67468 28.1145 5.84498 28.238 6.05102C28.3615 6.25713 28.4266 6.49154 28.4266 6.73031C28.4266 6.96907 28.3615 7.20348 28.238 7.4096C28.1145 7.61564 27.9372 7.78594 27.7239 7.9029L18.4947 12.9679C17.9056 13.2911 17.2414 13.4609 16.5658 13.4609C15.89 13.4609 15.2258 13.2911 14.6368 12.9679L5.40749 7.9029C5.19434 7.78594 5.01689 7.61564 4.89339 7.4096C4.7699 7.20348 4.70479 6.96907 4.70479 6.73031C4.70479 6.49154 4.7699 6.25713 4.89339 6.05102C5.01689 5.84498 5.19434 5.67468 5.40749 5.55771L14.6368 0.492981C15.2258 0.169739 15.89 -5.72205e-06 16.5658 -5.72205e-06C17.2414 -5.72205e-06 17.9056 0.169739 18.4946 0.492981Z",
                        fill: fillColor
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M18.4448 5.2478L31.6626 12.5013C31.8758 12.6183 32.0532 12.7886 32.1767 12.9946C32.3002 13.2007 32.3653 13.4351 32.3653 13.6739C32.3653 13.9127 32.3002 14.1471 32.1767 14.3532C32.0532 14.5593 31.8758 14.7295 31.6626 14.8466L18.4448 22.1C17.8558 22.4231 17.1916 22.593 16.516 22.593C15.8403 22.593 15.1761 22.4231 14.5871 22.1L1.3693 14.8466C1.15615 14.7295 0.978699 14.5593 0.855202 14.3532C0.731705 14.1471 0.666607 13.9127 0.666607 13.6739C0.666607 13.4351 0.731705 13.2007 0.855202 12.9946C0.978699 12.7886 1.15615 12.6183 1.3693 12.5013L14.5871 5.2478C15.1761 4.92464 15.8403 4.75489 16.516 4.75489C17.1916 4.75489 17.8558 4.92464 18.4448 5.2478Z",
                        fill: fillColor,
                        opacity: "0.7"
                    })
                ]
            });
        case "business":
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
                fill: "none",
                height: "33",
                viewBox: "0 0 43 33",
                width: "43",
                xmlns: "http://www.w3.org/2000/svg",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M23.0075 0.49292L32.2369 5.55765C32.4501 5.67462 32.6275 5.84492 32.751 6.05096C32.8745 6.25707 32.9396 6.49148 32.9396 6.73025C32.9396 6.96901 32.8745 7.20342 32.751 7.40954C32.6275 7.61558 32.4501 7.78587 32.2369 7.90284L23.0076 12.9678C22.4186 13.2911 21.7543 13.4609 21.0787 13.4609C20.403 13.4609 19.7387 13.2911 19.1498 12.9678L9.92043 7.90284C9.70728 7.78587 9.52983 7.61558 9.40633 7.40954C9.28284 7.20342 9.21773 6.96901 9.21773 6.73025C9.21773 6.49148 9.28284 6.25707 9.40633 6.05096C9.52983 5.84492 9.70728 5.67462 9.92043 5.55765L19.1498 0.49292C19.7387 0.169678 20.403 -6.67572e-05 21.0787 -6.67572e-05C21.7543 -6.67572e-05 22.4186 0.169678 23.0075 0.49292Z",
                        fill: fillColor
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M22.9577 5.24774L36.1755 12.5012C36.3886 12.6182 36.5661 12.7885 36.6896 12.9945C36.8131 13.2007 36.8782 13.4351 36.8782 13.6738C36.8782 13.9126 36.8131 14.1471 36.6896 14.3531C36.5661 14.5592 36.3886 14.7295 36.1755 14.8465L22.9577 22.0999C22.3687 22.4231 21.7045 22.5929 21.0288 22.5929C20.3532 22.5929 19.6889 22.4231 19.1 22.0999L5.88218 14.8465C5.66903 14.7295 5.49158 14.5592 5.36808 14.3531C5.24458 14.1471 5.17949 13.9126 5.17949 13.6738C5.17949 13.4351 5.24458 13.2007 5.36808 12.9945C5.49158 12.7885 5.66903 12.6182 5.88218 12.5012L19.1 5.24774C19.6889 4.92458 20.3532 4.75483 21.0288 4.75483C21.7045 4.75483 22.3687 4.92458 22.9577 5.24774Z",
                        fill: fillColor,
                        opacity: "0.7"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M23.259 10.0018L41.6317 20.0843C41.8445 20.2012 42.0217 20.3711 42.145 20.5769C42.2683 20.7826 42.3333 21.0167 42.3333 21.2551C42.3333 21.4935 42.2683 21.7275 42.145 21.9333C42.0217 22.139 41.8445 22.309 41.6317 22.4258L23.2589 32.5081C22.6709 32.8307 22.0078 33.0002 21.3332 33.0002C20.6587 33.0002 19.9955 32.8307 19.4075 32.5081L1.03479 22.4258C0.821995 22.309 0.644833 22.139 0.521538 21.9333C0.398247 21.7275 0.333252 21.4935 0.333252 21.2551C0.333252 21.0167 0.398247 20.7826 0.521538 20.5769C0.644833 20.3711 0.821995 20.2012 1.03479 20.0843L19.4075 10.0018C19.9955 9.67921 20.6587 9.50966 21.3332 9.50966C22.0078 9.50966 22.6709 9.67921 23.259 10.0018Z",
                        fill: fillColor,
                        opacity: "0.4"
                    })
                ]
            });
        default:
            return null;
    }
};
AccountPlanIcon.propTypes = {
    name: prop_types_default().oneOf([
        "startup",
        "standard",
        "business"
    ]).isRequired
};

;// CONCATENATED MODULE: ./src/sections/dashboard/account/account-billing-settings.tsx

























const plans = [
    {
        id: "startup",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(AccountPlanIcon, {
            name: "startup"
        }),
        name: "Startup",
        price: 0
    },
    {
        id: "standard",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(AccountPlanIcon, {
            name: "standard"
        }),
        name: "Standard",
        price: 4.99
    },
    {
        id: "business",
        icon: /*#__PURE__*/ jsx_runtime_.jsx(AccountPlanIcon, {
            name: "business"
        }),
        name: "Business",
        price: 29.99
    }
];
const AccountBillingSettings = (props)=>{
    const { plan: currentPlan = "standard" , invoices =[]  } = props;
    const [selectedPlan, setSelectedPlan] = (0,react_.useState)(currentPlan);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 4,
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        title: "Change Plan",
                        subheader: "You can upgrade and downgrade whenever you want"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                        sx: {
                            pt: 0
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    container: true,
                                    spacing: 3,
                                    children: plans.map((plan)=>{
                                        const isSelected = plan.id === selectedPlan;
                                        const isCurrent = plan.id === currentPlan;
                                        const price = numeral_default()(plan.price).format("$0,0.00");
                                        return /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                            xs: 12,
                                            sm: 4,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                                                onClick: ()=>setSelectedPlan(plan.id),
                                                sx: {
                                                    cursor: "pointer",
                                                    ...isSelected && {
                                                        borderColor: "primary.main",
                                                        borderWidth: 2,
                                                        m: "-1px"
                                                    }
                                                },
                                                variant: "outlined",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                            sx: {
                                                                height: 52,
                                                                width: 52,
                                                                "& img": {
                                                                    height: "auto",
                                                                    width: "100%"
                                                                }
                                                            },
                                                            children: plan.icon
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                                            sx: {
                                                                display: "flex",
                                                                mb: 1,
                                                                mt: 1
                                                            },
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                    variant: "h5",
                                                                    children: price
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                    color: "text.secondary",
                                                                    sx: {
                                                                        mt: "auto",
                                                                        ml: "4px"
                                                                    },
                                                                    variant: "body2",
                                                                    children: "/mo"
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                            alignItems: "center",
                                                            direction: "row",
                                                            justifyContent: "space-between",
                                                            spacing: 3,
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                    variant: "overline",
                                                                    children: plan.name
                                                                }),
                                                                isCurrent && /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                    color: "primary.main",
                                                                    variant: "caption",
                                                                    children: "Using now"
                                                                })
                                                            ]
                                                        })
                                                    ]
                                                })
                                            })
                                        }, plan.id);
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                                sx: {
                                    my: 3
                                }
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    alignItems: "center",
                                    display: "flex",
                                    justifyContent: "space-between"
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "h6",
                                        children: "Billing details"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                        color: "inherit",
                                        startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Edit02/* default */.Z, {})
                                        }),
                                        children: "Edit"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    border: 1,
                                    borderColor: "divider",
                                    borderRadius: 1,
                                    mt: 3
                                },
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(property_list/* PropertyList */.c, {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(property_list_item/* PropertyListItem */.c, {
                                            align: "horizontal",
                                            divider: true,
                                            label: "Billing name",
                                            value: "John Doe"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(property_list_item/* PropertyListItem */.c, {
                                            align: "horizontal",
                                            divider: true,
                                            label: "Card number",
                                            value: "**** 1111"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(property_list_item/* PropertyListItem */.c, {
                                            align: "horizontal",
                                            divider: true,
                                            label: "Country",
                                            value: "Germany"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(property_list_item/* PropertyListItem */.c, {
                                            align: "horizontal",
                                            label: "Zip / Postal code",
                                            value: "667123"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                color: "text.secondary",
                                variant: "body2",
                                sx: {
                                    mt: 3
                                },
                                children: [
                                    "We cannot refund once you purchased a subscription, but you can always",
                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                        href: "#",
                                        sx: {
                                            ml: "4px"
                                        },
                                        underline: "none",
                                        variant: "body2",
                                        children: "Cancel"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    display: "flex",
                                    justifyContent: "flex-end",
                                    mt: 3
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    variant: "contained",
                                    children: "Upgrade Plan"
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        title: "Invoice history",
                        subheader: "You can view and download all your previous invoices here. If you’ve just made a payment, it may take a few hours for it to appear in the table below."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((TableHead_default()), {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: "Date"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: "Total (incl. tax)"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {})
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                                children: invoices.map((invoice)=>{
                                    const createdAt = (0,date_fns.format)(invoice.createdAt, "dd MMM yyyy");
                                    const amount = numeral_default()(invoice.amount).format("$0,0.00");
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                children: createdAt
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                children: amount
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                align: "right",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                    color: "inherit",
                                                    underline: "always",
                                                    href: "#",
                                                    children: "View Invoice"
                                                })
                                            })
                                        ]
                                    }, invoice.id);
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
AccountBillingSettings.propTypes = {
    plan: (prop_types_default()).string,
    invoices: (prop_types_default()).array
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Camera01.js
var Camera01 = __webpack_require__(739624);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/User01.js
var User01 = __webpack_require__(325055);
// EXTERNAL MODULE: ./node_modules/@mui/system/colorManipulator.js
var colorManipulator = __webpack_require__(229551);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Switch/index.js
var Switch = __webpack_require__(877876);
var Switch_default = /*#__PURE__*/__webpack_require__.n(Switch);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TextField/index.js
var TextField = __webpack_require__(28379);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField);
;// CONCATENATED MODULE: ./src/sections/dashboard/account/account-general-settings.tsx

















const AccountGeneralSettings = (props)=>{
    const { avatar , email , name  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 4,
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                        container: true,
                        spacing: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h6",
                                    children: "Basic details"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 8,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    spacing: 3,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "center",
                                            direction: "row",
                                            spacing: 2,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                    sx: {
                                                        borderColor: "neutral.300",
                                                        borderRadius: "50%",
                                                        borderStyle: "dashed",
                                                        borderWidth: 1,
                                                        p: "4px"
                                                    },
                                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                                        sx: {
                                                            borderRadius: "50%",
                                                            height: "100%",
                                                            width: "100%",
                                                            position: "relative"
                                                        },
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                                sx: {
                                                                    alignItems: "center",
                                                                    backgroundColor: (theme)=>(0,colorManipulator.alpha)(theme.palette.neutral[700], 0.5),
                                                                    borderRadius: "50%",
                                                                    color: "common.white",
                                                                    cursor: "pointer",
                                                                    display: "flex",
                                                                    height: "100%",
                                                                    justifyContent: "center",
                                                                    left: 0,
                                                                    opacity: 0,
                                                                    position: "absolute",
                                                                    top: 0,
                                                                    width: "100%",
                                                                    zIndex: 1,
                                                                    "&:hover": {
                                                                        opacity: 1
                                                                    }
                                                                },
                                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                                    alignItems: "center",
                                                                    direction: "row",
                                                                    spacing: 1,
                                                                    children: [
                                                                        /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                                            color: "inherit",
                                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Camera01/* default */.Z, {})
                                                                        }),
                                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                            color: "inherit",
                                                                            variant: "subtitle2",
                                                                            sx: {
                                                                                fontWeight: 700
                                                                            },
                                                                            children: "Select"
                                                                        })
                                                                    ]
                                                                })
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                                src: avatar,
                                                                sx: {
                                                                    height: 100,
                                                                    width: 100
                                                                },
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(User01/* default */.Z, {})
                                                                })
                                                            })
                                                        ]
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                    color: "inherit",
                                                    size: "small",
                                                    children: "Change"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "center",
                                            direction: "row",
                                            spacing: 2,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                    defaultValue: name,
                                                    label: "Full Name",
                                                    sx: {
                                                        flexGrow: 1
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                    color: "inherit",
                                                    size: "small",
                                                    children: "Save"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "center",
                                            direction: "row",
                                            spacing: 2,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                    defaultValue: email,
                                                    disabled: true,
                                                    label: "Email Address",
                                                    required: true,
                                                    sx: {
                                                        flexGrow: 1,
                                                        "& .MuiOutlinedInput-notchedOutline": {
                                                            borderStyle: "dashed"
                                                        }
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                    color: "inherit",
                                                    size: "small",
                                                    children: "Edit"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                        container: true,
                        spacing: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h6",
                                    children: "Public profile"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 12,
                                md: 8,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    divider: /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                                    spacing: 3,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "flex-start",
                                            direction: "row",
                                            justifyContent: "space-between",
                                            spacing: 3,
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                    spacing: 1,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            variant: "subtitle1",
                                                            children: "Make Contact Info Public"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            color: "text.secondary",
                                                            variant: "body2",
                                                            children: "Means that anyone viewing your profile will be able to see your contacts details."
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {})
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "flex-start",
                                            direction: "row",
                                            justifyContent: "space-between",
                                            spacing: 3,
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                    spacing: 1,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            variant: "subtitle1",
                                                            children: "Available to hire"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            color: "text.secondary",
                                                            variant: "body2",
                                                            children: "Toggling this will let your teammates know that you are available for acquiring new projects."
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                                    defaultChecked: true
                                                })
                                            ]
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                        container: true,
                        spacing: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h6",
                                    children: "Delete Account"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 8,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "flex-start",
                                    spacing: 3,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle1",
                                            children: "Delete your account and all of your source data. This is irreversible."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                            color: "error",
                                            variant: "outlined",
                                            children: "Delete account"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
AccountGeneralSettings.propTypes = {
    avatar: (prop_types_default()).string.isRequired,
    email: (prop_types_default()).string.isRequired,
    name: (prop_types_default()).string.isRequired
};

;// CONCATENATED MODULE: ./src/sections/dashboard/account/account-notifications-settings.tsx








const AccountNotificationsSettings = ()=>/*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                    container: true,
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 4,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "h6",
                                children: "Email"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            sm: 12,
                            md: 8,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                divider: /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                                spacing: 3,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                        alignItems: "flex-start",
                                        direction: "row",
                                        justifyContent: "space-between",
                                        spacing: 3,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                spacing: 1,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "subtitle1",
                                                        children: "Product updates"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        color: "text.secondary",
                                                        variant: "body2",
                                                        children: "News, announcements, and product updates."
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                                defaultChecked: true
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                        alignItems: "flex-start",
                                        direction: "row",
                                        justifyContent: "space-between",
                                        spacing: 3,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                spacing: 1,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "subtitle1",
                                                        children: "Security updates"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "body2",
                                                        color: "text.secondary",
                                                        children: "Important notifications about your account security."
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                                defaultChecked: true
                                            })
                                        ]
                                    })
                                ]
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                    sx: {
                        my: 3
                    }
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                    container: true,
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 4,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "h6",
                                children: "Phone notifications"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            sm: 12,
                            md: 8,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                divider: /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                                spacing: 3,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "flex-start",
                                    direction: "row",
                                    justifyContent: "space-between",
                                    spacing: 3,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            spacing: 1,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "subtitle1",
                                                    children: "Security updates"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    color: "text.secondary",
                                                    variant: "body2",
                                                    children: "Important notifications about your account security."
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {})
                                    ]
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/DotsHorizontal.js
var DotsHorizontal = __webpack_require__(66519);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Mail01.js
var Mail01 = __webpack_require__(871920);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/InputAdornment/index.js
var InputAdornment = __webpack_require__(79150);
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment);
// EXTERNAL MODULE: ./src/components/scrollbar.tsx
var scrollbar = __webpack_require__(851716);
// EXTERNAL MODULE: ./src/components/severity-pill.tsx
var severity_pill = __webpack_require__(594368);
;// CONCATENATED MODULE: ./src/sections/dashboard/account/account-team-settings.tsx























const AccountTeamSettings = (props)=>{
    const { members  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                    container: true,
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 4,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                spacing: 1,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "h6",
                                        children: "Invite members"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: "You currently pay for 2 Editor Seats."
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 8,
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                alignItems: "center",
                                direction: "row",
                                spacing: 3,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                        InputProps: {
                                            startAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                                position: "start",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Mail01/* default */.Z, {})
                                                })
                                            })
                                        },
                                        label: "Email address",
                                        name: "email",
                                        sx: {
                                            flexGrow: 1
                                        },
                                        type: "email"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                        variant: "contained",
                                        children: "Send Invite"
                                    })
                                ]
                            })
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                    sx: {
                        minWidth: 400
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((TableHead_default()), {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: "Member"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: "Role"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {})
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                            children: members.map((member, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                alignItems: "center",
                                                direction: "row",
                                                spacing: 1,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                        src: member.avatar,
                                                        sx: {
                                                            height: 40,
                                                            width: 40
                                                        },
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(User01/* default */.Z, {})
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                variant: "subtitle2",
                                                                children: member.name
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                color: "text.secondary",
                                                                variant: "body2",
                                                                children: member.email
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: member.role === "Owner" ? /*#__PURE__*/ jsx_runtime_.jsx(severity_pill/* SeverityPill */.I, {
                                                children: member.role
                                            }) : member.role
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            align: "right",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                                                })
                                            })
                                        })
                                    ]
                                }, index))
                        })
                    ]
                })
            })
        ]
    });
};
AccountTeamSettings.propTypes = {
    members: (prop_types_default()).array.isRequired
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ArrowRight.js
var ArrowRight = __webpack_require__(394284);
;// CONCATENATED MODULE: ./src/sections/dashboard/account/account-security-settings.tsx





















const AccountSecuritySettings = (props)=>{
    const { loginEvents  } = props;
    const [isEditing, setIsEditing] = (0,react_.useState)(false);
    const handleEdit = (0,react_.useCallback)(()=>{
        setIsEditing((prevState)=>!prevState);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 4,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                children: /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                        container: true,
                        spacing: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h6",
                                    children: "Change password"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 12,
                                md: 8,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 3,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                            disabled: !isEditing,
                                            label: "Password",
                                            type: "password",
                                            defaultValue: "Thebestpasswordever123#",
                                            sx: {
                                                flexGrow: 1,
                                                ...!isEditing && {
                                                    "& .MuiOutlinedInput-notchedOutline": {
                                                        borderStyle: "dotted"
                                                    }
                                                }
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                            onClick: handleEdit,
                                            children: isEditing ? "Save" : "Edit"
                                        })
                                    ]
                                })
                            })
                        ]
                    })
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        title: "Multi Factor Authentication"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                        sx: {
                            pt: 0
                        },
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                            container: true,
                            spacing: 4,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 6,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                                        sx: {
                                            height: "100%"
                                        },
                                        variant: "outlined",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                    sx: {
                                                        display: "block",
                                                        position: "relative"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                        sx: {
                                                            "&::before": {
                                                                backgroundColor: "error.main",
                                                                borderRadius: "50%",
                                                                content: '""',
                                                                display: "block",
                                                                height: 8,
                                                                left: 4,
                                                                position: "absolute",
                                                                top: 7,
                                                                width: 8,
                                                                zIndex: 1
                                                            }
                                                        },
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            color: "error",
                                                            sx: {
                                                                pl: 3
                                                            },
                                                            variant: "body2",
                                                            children: "Off"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    sx: {
                                                        mt: 1
                                                    },
                                                    variant: "subtitle2",
                                                    children: "Authenticator App"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    color: "text.secondary",
                                                    sx: {
                                                        mt: 1
                                                    },
                                                    variant: "body2",
                                                    children: "Use an authenticator app to generate one time security codes."
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                    sx: {
                                                        mt: 4
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                        endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                                                        }),
                                                        variant: "outlined",
                                                        children: "Set Up"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    sm: 6,
                                    xs: 12,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                                        sx: {
                                            height: "100%"
                                        },
                                        variant: "outlined",
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                    sx: {
                                                        position: "relative"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                        sx: {
                                                            "&::before": {
                                                                backgroundColor: "error.main",
                                                                borderRadius: "50%",
                                                                content: '""',
                                                                display: "block",
                                                                height: 8,
                                                                left: 4,
                                                                position: "absolute",
                                                                top: 7,
                                                                width: 8,
                                                                zIndex: 1
                                                            }
                                                        },
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            color: "error",
                                                            sx: {
                                                                pl: 3
                                                            },
                                                            variant: "body2",
                                                            children: "Off"
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    sx: {
                                                        mt: 1
                                                    },
                                                    variant: "subtitle2",
                                                    children: "Text Message"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    color: "text.secondary",
                                                    sx: {
                                                        mt: 1
                                                    },
                                                    variant: "body2",
                                                    children: "Use your mobile phone to receive security codes via SMS."
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                    sx: {
                                                        mt: 4
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                        endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                                                        }),
                                                        variant: "outlined",
                                                        children: "Set Up"
                                                    })
                                                })
                                            ]
                                        })
                                    })
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        title: "Login history",
                        subheader: "Your recent login activity"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                            sx: {
                                minWidth: 500
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((TableHead_default()), {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                children: "Login type"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                children: "IP Address"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                children: "Client"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                                    children: loginEvents.map((event)=>{
                                        const createdAt = (0,date_fns.format)(event.createdAt, "HH:mm a MM/dd/yyyy");
                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                            sx: {
                                                "&:last-child td, &:last-child th": {
                                                    border: 0
                                                }
                                            },
                                            children: [
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            variant: "subtitle2",
                                                            children: event.type
                                                        }),
                                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                            variant: "body2",
                                                            color: "body2",
                                                            children: [
                                                                "on ",
                                                                createdAt
                                                            ]
                                                        })
                                                    ]
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    children: event.ip
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    children: event.userAgent
                                                })
                                            ]
                                        }, event.id);
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        ]
    });
};
AccountSecuritySettings.propTypes = {
    loginEvents: (prop_types_default()).array.isRequired
};

;// CONCATENATED MODULE: ./src/app/(dashboard)/account/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 

















const now = new Date();
const tabs = [
    {
        label: "General",
        value: "general"
    },
    {
        label: "Billing",
        value: "billing"
    },
    {
        label: "Team",
        value: "team"
    },
    {
        label: "Notifications",
        value: "notifications"
    },
    {
        label: "Security",
        value: "security"
    }
];
const Page = ()=>{
    const user = (0,use_mocked_user/* useMockedUser */.I)();
    const [currentTab, setCurrentTab] = (0,react_.useState)("general");
    (0,use_page_view/* usePageView */.a)();
    const handleTabsChange = (0,react_.useCallback)((event, value)=>{
        setCurrentTab(value);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: Account"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "main",
                sx: {
                    flexGrow: 1,
                    py: 8
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
                    maxWidth: "xl",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 3,
                            sx: {
                                mb: 3
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h4",
                                    children: "Account"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Tabs_default()), {
                                            indicatorColor: "primary",
                                            onChange: handleTabsChange,
                                            scrollButtons: "auto",
                                            textColor: "primary",
                                            value: currentTab,
                                            variant: "scrollable",
                                            children: tabs.map((tab)=>/*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                                                    label: tab.label,
                                                    value: tab.value
                                                }, tab.value))
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {})
                                    ]
                                })
                            ]
                        }),
                        currentTab === "general" && /*#__PURE__*/ jsx_runtime_.jsx(AccountGeneralSettings, {
                            avatar: user.avatar || "",
                            email: user.email || "",
                            name: user.name || ""
                        }),
                        currentTab === "billing" && /*#__PURE__*/ jsx_runtime_.jsx(AccountBillingSettings, {
                            plan: "standard",
                            invoices: [
                                {
                                    id: "5547409069c59755261f5546",
                                    amount: 4.99,
                                    createdAt: (0,date_fns.subMonths)(now, 1).getTime()
                                },
                                {
                                    id: "a3e17f4b551ff8766903f31f",
                                    amount: 4.99,
                                    createdAt: (0,date_fns.subMonths)(now, 2).getTime()
                                },
                                {
                                    id: "28ca7c66fc360d8203644256",
                                    amount: 4.99,
                                    createdAt: (0,date_fns.subMonths)(now, 3).getTime()
                                }
                            ]
                        }),
                        currentTab === "team" && /*#__PURE__*/ jsx_runtime_.jsx(AccountTeamSettings, {
                            members: [
                                {
                                    avatar: "/assets/avatars/avatar-cao-yu.png",
                                    email: "cao.yu@devias.io",
                                    name: "Cao Yu",
                                    role: "Owner"
                                },
                                {
                                    avatar: "/assets/avatars/avatar-siegbert-gottfried.png",
                                    email: "siegbert.gottfried@devias.io",
                                    name: "Siegbert Gottfried",
                                    role: "Standard"
                                }
                            ]
                        }),
                        currentTab === "notifications" && /*#__PURE__*/ jsx_runtime_.jsx(AccountNotificationsSettings, {}),
                        currentTab === "security" && /*#__PURE__*/ jsx_runtime_.jsx(AccountSecuritySettings, {
                            loginEvents: [
                                {
                                    id: "1bd6d44321cb78fd915462fa",
                                    createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 5), 7), 1).getTime(),
                                    ip: "95.130.17.84",
                                    type: "Credential login",
                                    userAgent: "Chrome, Mac OS 10.15.7"
                                },
                                {
                                    id: "bde169c2fe9adea5d4598ea9",
                                    createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 25), 9), 1).getTime(),
                                    ip: "95.130.17.84",
                                    type: "Credential login",
                                    userAgent: "Chrome, Mac OS 10.15.7"
                                }
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 347987:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/account/page.tsx");


/***/ }),

/***/ 394284:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(369885);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(556786);




var ArrowRight = function ArrowRight(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "none"
  }, props, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
      fill: "#fff",
      fillOpacity: 0.01,
      d: "m12 5 7 7-7 7"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: 2,
      d: "M5 12h14m0 0-7-7m7 7-7 7"
    })]
  }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (ArrowRight);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,8470,6519,1920,9624,6461,7680,95,9494,2302,4368,2851,700], () => (__webpack_exec__(506478)));
module.exports = __webpack_exports__;

})();