(() => {
var exports = {};
exports.id = 8737;
exports.ids = [8737];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 652452:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'social',
        {
        children: [
        'profile',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 587855, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/social/profile/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/social/profile/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/social/profile/page"
  

/***/ }),

/***/ 261607:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 839736))

/***/ }),

/***/ 839736:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/MessageChatSquare.js
var MessageChatSquare = __webpack_require__(332500);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/DotsHorizontal.js
var DotsHorizontal = __webpack_require__(66519);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Image01.js
var Image01 = __webpack_require__(97484);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/UserPlus02.js
var UserPlus02 = __webpack_require__(668709);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tab/index.js
var Tab = __webpack_require__(189733);
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tabs/index.js
var Tabs = __webpack_require__(790206);
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tooltip/index.js
var Tooltip = __webpack_require__(556020);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/colors/index.js
var colors = __webpack_require__(983036);
// EXTERNAL MODULE: ./src/api/social/index.ts + 1 modules
var social = __webpack_require__(263292);
// EXTERNAL MODULE: ./src/components/router-link.tsx
var router_link = __webpack_require__(510079);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-mounted.ts
var use_mounted = __webpack_require__(887408);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/paths.ts
var paths = __webpack_require__(287842);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/SearchMd.js
var SearchMd = __webpack_require__(219057);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Input/index.js
var Input = __webpack_require__(378382);
var Input_default = /*#__PURE__*/__webpack_require__.n(Input);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(333518);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
;// CONCATENATED MODULE: ./src/sections/dashboard/social/social-connection.tsx














const SocialConnection = (props)=>{
    const { connection  } = props;
    const [status, setStatus] = (0,react_.useState)(connection.status);
    const handleConnectionAdd = (0,react_.useCallback)(()=>{
        setStatus("pending");
        dist/* default.success */.ZP.success("Request sent");
    }, []);
    const handleConnectionRemove = (0,react_.useCallback)(()=>{
        setStatus("not_connected");
    }, []);
    const showConnect = status === "not_connected";
    const showPending = status === "pending";
    return /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        variant: "outlined",
        sx: {
            height: "100%"
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
            alignItems: "flex-start",
            direction: "row",
            justifyContent: "space-between",
            spacing: 2,
            sx: {
                p: 2
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "flex-start",
                    direction: "row",
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                            component: "a",
                            href: "#",
                            src: connection.avatar,
                            sx: {
                                height: 56,
                                width: 56
                            }
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                flexGrow: 1
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                    color: "text.primary",
                                    href: "#",
                                    variant: "subtitle2",
                                    children: connection.name
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                    color: "text.secondary",
                                    gutterBottom: true,
                                    variant: "body2",
                                    children: [
                                        connection.commonConnections,
                                        " ",
                                        "connections in common"
                                    ]
                                }),
                                showConnect && /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    onClick: handleConnectionAdd,
                                    size: "small",
                                    variant: "outlined",
                                    children: "Connect"
                                }),
                                showPending && /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    onClick: handleConnectionRemove,
                                    size: "small",
                                    color: "inherit",
                                    children: "Pending"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                    })
                })
            ]
        })
    });
};
SocialConnection.propTypes = {
    // @ts-ignore
    connection: (prop_types_default()).object
};

;// CONCATENATED MODULE: ./src/sections/dashboard/social/social-connections.tsx












const SocialConnections = (props)=>{
    const { connections =[] , query ="" , onQueryChange , ...other } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                title: "Connections"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                spacing: 2,
                sx: {
                    px: 3,
                    py: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SearchMd/* default */.Z, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            flexGrow: 1
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                            disableUnderline: true,
                            fullWidth: true,
                            onChange: onQueryChange,
                            placeholder: "Search connections",
                            value: query
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    p: 3
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    container: true,
                    spacing: 3,
                    children: connections.map((connection)=>/*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(SocialConnection, {
                                connection: connection
                            })
                        }, connection.id))
                })
            })
        ]
    });
};
SocialConnections.propTypes = {
    connections: (prop_types_default()).array,
    query: (prop_types_default()).string,
    onQueryChange: (prop_types_default()).func
};

// EXTERNAL MODULE: ./src/sections/dashboard/social/social-post-add.tsx
var social_post_add = __webpack_require__(4317);
// EXTERNAL MODULE: ./src/sections/dashboard/social/social-post-card.tsx + 2 modules
var social_post_card = __webpack_require__(768654);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/BookOpen01.js
var BookOpen01 = __webpack_require__(979192);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Briefcase01.js
var Briefcase01 = __webpack_require__(587585);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Home02.js
var Home02 = __webpack_require__(378955);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Mail01.js
var Mail01 = __webpack_require__(871920);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/LinearProgress/index.js
var LinearProgress = __webpack_require__(154003);
var LinearProgress_default = /*#__PURE__*/__webpack_require__.n(LinearProgress);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/List/index.js
var List = __webpack_require__(854436);
var List_default = /*#__PURE__*/__webpack_require__.n(List);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItem/index.js
var ListItem = __webpack_require__(790777);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemAvatar/index.js
var ListItemAvatar = __webpack_require__(372355);
var ListItemAvatar_default = /*#__PURE__*/__webpack_require__.n(ListItemAvatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemText/index.js
var ListItemText = __webpack_require__(846517);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText);
;// CONCATENATED MODULE: ./src/sections/dashboard/social/social-about.tsx


















const SocialAbout = (props)=>{
    const { currentCity , currentJobCompany , currentJobTitle , email , originCity , previousJobCompany , previousJobTitle , profileProgress , quote , ...other } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 3,
        ...other,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        title: "Profile Progress"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((LinearProgress_default()), {
                                    value: profileProgress,
                                    variant: "determinate"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "subtitle2",
                                    children: "50% Set Up Complete"
                                })
                            ]
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        title: "About"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                color: "text.secondary",
                                sx: {
                                    mb: 2
                                },
                                variant: "subtitle2",
                                children: [
                                    '"',
                                    quote,
                                    '"'
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((List_default()), {
                                disablePadding: true,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                        disableGutters: true,
                                        divider: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    color: "action",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Briefcase01/* default */.Z, {})
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                disableTypography: true,
                                                primary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                    variant: "subtitle2",
                                                    children: [
                                                        currentJobTitle,
                                                        " ",
                                                        "at",
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                            color: "text.primary",
                                                            href: "#",
                                                            variant: "subtitle2",
                                                            children: currentJobCompany
                                                        })
                                                    ]
                                                }),
                                                secondary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                    color: "text.secondary",
                                                    variant: "body2",
                                                    children: [
                                                        "Past:",
                                                        " ",
                                                        previousJobTitle,
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                            color: "text.secondary",
                                                            href: "#",
                                                            variant: "body2",
                                                            children: previousJobCompany
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                        disableGutters: true,
                                        divider: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    color: "action",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(BookOpen01/* default */.Z, {})
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                primary: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                    color: "text.secondary",
                                                    sx: {
                                                        cursor: "pointer"
                                                    },
                                                    variant: "caption",
                                                    children: "Add school or collage"
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                        disableGutters: true,
                                        divider: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    color: "action",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Home02/* default */.Z, {})
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                disableTypography: true,
                                                primary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                    variant: "subtitle2",
                                                    children: [
                                                        "Lives in",
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                            color: "text.primary",
                                                            href: "#",
                                                            variant: "subtitle2",
                                                            children: currentCity
                                                        })
                                                    ]
                                                }),
                                                secondary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                    color: "text.secondary",
                                                    variant: "body2",
                                                    children: [
                                                        "Originally from",
                                                        " ",
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                            color: "text.secondary",
                                                            href: "#",
                                                            variant: "body2",
                                                            children: originCity
                                                        })
                                                    ]
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                        disableGutters: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    color: "action",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Mail01/* default */.Z, {})
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                                primary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "subtitle2",
                                                    children: email
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
SocialAbout.propTypes = {
    currentCity: (prop_types_default()).string.isRequired,
    currentJobCompany: (prop_types_default()).string.isRequired,
    currentJobTitle: (prop_types_default()).string.isRequired,
    email: (prop_types_default()).string.isRequired,
    originCity: (prop_types_default()).string.isRequired,
    previousJobCompany: (prop_types_default()).string.isRequired,
    previousJobTitle: (prop_types_default()).string.isRequired,
    profileProgress: (prop_types_default()).number.isRequired,
    quote: (prop_types_default()).string.isRequired
};

;// CONCATENATED MODULE: ./src/sections/dashboard/social/social-timeline.tsx







const SocialTimeline = (props)=>{
    const { posts =[] , profile , ...other } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        ...other,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
            container: true,
            spacing: 4,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    lg: 4,
                    xs: 12,
                    children: /*#__PURE__*/ jsx_runtime_.jsx(SocialAbout, {
                        currentCity: profile.currentCity,
                        currentJobCompany: profile.currentJobCompany,
                        currentJobTitle: profile.currentJobTitle,
                        email: profile.email,
                        originCity: profile.originCity,
                        previousJobCompany: profile.previousJobCompany,
                        previousJobTitle: profile.previousJobTitle,
                        profileProgress: profile.profileProgress,
                        quote: profile.quote
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    lg: 8,
                    xs: 12,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        spacing: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(social_post_add/* SocialPostAdd */.L, {}),
                            posts.map((post)=>/*#__PURE__*/ jsx_runtime_.jsx(social_post_card/* SocialPostCard */.d, {
                                    authorAvatar: post.author.avatar,
                                    authorName: post.author.name,
                                    comments: post.comments,
                                    createdAt: post.createdAt,
                                    isLiked: post.isLiked,
                                    likes: post.likes,
                                    media: post.media,
                                    message: post.message
                                }, post.id))
                        ]
                    })
                })
            ]
        })
    });
};
SocialTimeline.propTypes = {
    posts: (prop_types_default()).array,
    // @ts-ignore
    profile: (prop_types_default()).object.isRequired
};

;// CONCATENATED MODULE: ./src/app/(dashboard)/social/profile/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 


























const tabs = [
    {
        label: "Timeline",
        value: "timeline"
    },
    {
        label: "Connections",
        value: "connections"
    }
];
const useProfile = ()=>{
    const isMounted = (0,use_mounted/* useMounted */.s)();
    const [profile, setProfile] = (0,react_.useState)(null);
    const handleProfileGet = (0,react_.useCallback)(async ()=>{
        try {
            const response = await social/* socialApi.getProfile */.B.getProfile();
            if (isMounted()) {
                setProfile(response);
            }
        } catch (err) {
            console.error(err);
        }
    }, [
        isMounted
    ]);
    (0,react_.useEffect)(()=>{
        handleProfileGet();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []);
    return profile;
};
const usePosts = ()=>{
    const isMounted = (0,use_mounted/* useMounted */.s)();
    const [posts, setPosts] = (0,react_.useState)([]);
    const handlePostsGet = (0,react_.useCallback)(async ()=>{
        try {
            const response = await social/* socialApi.getPosts */.B.getPosts();
            if (isMounted()) {
                setPosts(response);
            }
        } catch (err) {
            console.error(err);
        }
    }, [
        isMounted
    ]);
    (0,react_.useEffect)(()=>{
        handlePostsGet();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []);
    return posts;
};
const useConnections = (search = "")=>{
    const [connections, setConnections] = (0,react_.useState)([]);
    const isMounted = (0,use_mounted/* useMounted */.s)();
    const handleConnectionsGet = (0,react_.useCallback)(async ()=>{
        const response = await social/* socialApi.getConnections */.B.getConnections();
        if (isMounted()) {
            setConnections(response);
        }
    }, [
        isMounted
    ]);
    (0,react_.useEffect)(()=>{
        handleConnectionsGet();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        search
    ]);
    return connections.filter((connection)=>{
        return connection.name?.toLowerCase().includes(search);
    });
};
const Page = ()=>{
    const profile = useProfile();
    const [currentTab, setCurrentTab] = (0,react_.useState)("timeline");
    const [status, setStatus] = (0,react_.useState)("not_connected");
    const posts = usePosts();
    const [connectionsQuery, setConnectionsQuery] = (0,react_.useState)("");
    const connections = useConnections(connectionsQuery);
    (0,use_page_view/* usePageView */.a)();
    const handleConnectionAdd = (0,react_.useCallback)(()=>{
        setStatus("pending");
    }, []);
    const handleConnectionRemove = (0,react_.useCallback)(()=>{
        setStatus("not_connected");
    }, []);
    const handleTabsChange = (0,react_.useCallback)((event, value)=>{
        setCurrentTab(value);
    }, []);
    const handleConnectionsQueryChange = (0,react_.useCallback)((event)=>{
        setConnectionsQuery(event.target.value);
    }, []);
    if (!profile) {
        return null;
    }
    const showConnect = status === "not_connected";
    const showPending = status === "pending";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: Social Profile"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "main",
                sx: {
                    flexGrow: 1,
                    py: 8
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
                    maxWidth: "lg",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                    style: {
                                        backgroundImage: `url(${profile.cover})`
                                    },
                                    sx: {
                                        backgroundPosition: "center",
                                        backgroundRepeat: "no-repeat",
                                        backgroundSize: "cover",
                                        borderRadius: 1,
                                        height: 348,
                                        position: "relative",
                                        "&:hover": {
                                            "& button": {
                                                visibility: "visible"
                                            }
                                        }
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                        startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Image01/* default */.Z, {})
                                        }),
                                        sx: {
                                            backgroundColor: colors.blueGrey[900],
                                            bottom: {
                                                lg: 24,
                                                xs: "auto"
                                            },
                                            color: "common.white",
                                            position: "absolute",
                                            right: 24,
                                            top: {
                                                lg: "auto",
                                                xs: 24
                                            },
                                            visibility: "hidden",
                                            "&:hover": {
                                                backgroundColor: colors.blueGrey[900]
                                            }
                                        },
                                        variant: "contained",
                                        children: "Change Cover"
                                    })
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 2,
                                    sx: {
                                        mt: 5
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "center",
                                            direction: "row",
                                            spacing: 2,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                    src: profile.avatar,
                                                    sx: {
                                                        height: 64,
                                                        width: 64
                                                    }
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            color: "text.secondary",
                                                            variant: "overline",
                                                            children: profile.bio
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            variant: "h6",
                                                            children: profile.name
                                                        })
                                                    ]
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                            sx: {
                                                flexGrow: 1
                                            }
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "center",
                                            direction: "row",
                                            spacing: 2,
                                            sx: {
                                                display: {
                                                    md: "block",
                                                    xs: "none"
                                                }
                                            },
                                            children: [
                                                showConnect && /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                    onClick: handleConnectionAdd,
                                                    size: "small",
                                                    startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(UserPlus02/* default */.Z, {})
                                                    }),
                                                    variant: "outlined",
                                                    children: "Connect"
                                                }),
                                                showPending && /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                    color: "primary",
                                                    onClick: handleConnectionRemove,
                                                    size: "small",
                                                    variant: "outlined",
                                                    children: "Pending"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                    component: router_link/* RouterLink */.r,
                                                    href: paths/* paths.dashboard.chat */.H.dashboard.chat,
                                                    size: "small",
                                                    startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(MessageChatSquare/* default */.Z, {})
                                                    }),
                                                    variant: "contained",
                                                    children: "Send Message"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                            title: "More options",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                                                })
                                            })
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Tabs_default()), {
                            indicatorColor: "primary",
                            onChange: handleTabsChange,
                            scrollButtons: "auto",
                            sx: {
                                mt: 5
                            },
                            textColor: "primary",
                            value: currentTab,
                            variant: "scrollable",
                            children: tabs.map((tab)=>/*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                                    label: tab.label,
                                    value: tab.value
                                }, tab.value))
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                mt: 3
                            },
                            children: [
                                currentTab === "timeline" && /*#__PURE__*/ jsx_runtime_.jsx(SocialTimeline, {
                                    posts: posts,
                                    profile: profile
                                }),
                                currentTab === "connections" && /*#__PURE__*/ jsx_runtime_.jsx(SocialConnections, {
                                    connections: connections,
                                    onQueryChange: handleConnectionsQueryChange,
                                    query: connectionsQuery
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 587855:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/social/profile/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,6519,7484,1920,9353,5804,2474,2391,2774,7680,95,9494,2302,2851,6077], () => (__webpack_exec__(652452)));
module.exports = __webpack_exports__;

})();