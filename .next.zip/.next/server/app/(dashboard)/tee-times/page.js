(() => {
var exports = {};
exports.id = 3672;
exports.ids = [3672];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 969450:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'tee-times',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 437883, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/tee-times/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/tee-times/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/tee-times/page"
  

/***/ }),

/***/ 189321:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 622041))

/***/ }),

/***/ 622041:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/SearchMd.js
var SearchMd = __webpack_require__(219057);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/InputAdornment/index.js
var InputAdornment = __webpack_require__(79150);
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/OutlinedInput/index.js
var OutlinedInput = __webpack_require__(877829);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tab/index.js
var Tab = __webpack_require__(189733);
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tabs/index.js
var Tabs = __webpack_require__(790206);
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs);
// EXTERNAL MODULE: ./src/hooks/use-update-effect.ts
var use_update_effect = __webpack_require__(824642);
;// CONCATENATED MODULE: ./src/sections/dashboard/teeTimes/tee-time-list-search.tsx













const tabs = [
    {
        label: "All",
        value: "all"
    },
    {
        label: "Upcoming",
        value: "upcoming"
    },
    {
        label: "Past",
        value: "past"
    }
];
const TeeTimeListSearch = (props)=>{
    const { onFiltersChange  } = props;
    const queryRef = (0,react_.useRef)(null);
    const [currentTab, setCurrentTab] = (0,react_.useState)("all");
    const [filters, setFilters] = (0,react_.useState)({
        query: undefined,
        status: undefined
    });
    const handleFiltersUpdate = (0,react_.useCallback)(()=>{
        onFiltersChange?.(filters);
    }, [
        filters,
        onFiltersChange
    ]);
    (0,use_update_effect/* useUpdateEffect */.r)(()=>{
        handleFiltersUpdate();
    }, [
        filters,
        handleFiltersUpdate
    ]);
    const handleTabsChange = (0,react_.useCallback)((event, tab)=>{
        setCurrentTab(tab);
        const status = tab === "all" ? undefined : tab;
        setFilters((prevState)=>({
                ...prevState,
                status
            }));
    }, []);
    const handleQueryChange = (0,react_.useCallback)((event)=>{
        event.preventDefault();
        const query = queryRef.current?.value || "";
        setFilters((prevState)=>({
                ...prevState,
                query
            }));
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Tabs_default()), {
                indicatorColor: "primary",
                onChange: handleTabsChange,
                scrollButtons: "auto",
                sx: {
                    px: 3
                },
                textColor: "primary",
                value: currentTab,
                variant: "scrollable",
                children: tabs.map((tab)=>/*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                        label: tab.label,
                        value: tab.value
                    }, tab.value))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                alignItems: "center",
                direction: "row",
                flexWrap: "wrap",
                sx: {
                    py: 2
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "form",
                    onChange: handleQueryChange,
                    onSubmit: handleQueryChange,
                    sx: {
                        flexGrow: 1
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                        defaultValue: "",
                        fullWidth: true,
                        inputProps: {
                            ref: queryRef
                        },
                        placeholder: "Search members...",
                        startAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                            position: "start",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(SearchMd/* default */.Z, {})
                            })
                        })
                    })
                })
            })
        ]
    });
};
TeeTimeListSearch.propTypes = {
    onFiltersChange: (prop_types_default()).func
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Table/index.js
var Table = __webpack_require__(620390);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableBody/index.js
var TableBody = __webpack_require__(843606);
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableCell/index.js
var TableCell = __webpack_require__(340514);
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableHead/index.js
var TableHead = __webpack_require__(30092);
var TableHead_default = /*#__PURE__*/__webpack_require__.n(TableHead);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableRow/index.js
var TableRow = __webpack_require__(893761);
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow);
// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
// EXTERNAL MODULE: ./src/components/scrollbar.tsx
var scrollbar = __webpack_require__(851716);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Rating/index.js
var Rating = __webpack_require__(247022);
var Rating_default = /*#__PURE__*/__webpack_require__.n(Rating);
// EXTERNAL MODULE: ./src/utils/common.ts
var common = __webpack_require__(867644);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/cjs/index.js
var cjs = __webpack_require__(845801);
// EXTERNAL MODULE: ./src/hooks/use-auth.ts
var use_auth = __webpack_require__(796372);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/index.js
var node = __webpack_require__(664085);
;// CONCATENATED MODULE: ./src/sections/dashboard/teeTimes/tee-time-list-table.tsx



















const TeeTimeListTable = (props)=>{
    const { count =0 , items =[] , onDeselectAll , onDeselectOne , onPageChange =()=>{} , onRowsPerPageChange , onSelectAll , onSelectOne , onRatingUpdate , page =0 , rowsPerPage =0 , selected =[] , isLoading , onOpenVoucher  } = props;
    // Initialize hover state for each item
    const [hoverStates, setHoverStates] = react_default().useState(items.map(()=>-1));
    const user = (0,use_auth/* useAuth */.a)();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            position: "relative"
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(scrollbar/* Scrollbar */.L, {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Table_default()), {
                    stickyHeader: true,
                    size: "small",
                    "aria-label": "a dense table",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((TableHead_default()), {
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: "Course Name"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: "Date/Time"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: "Player 1"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: "Player 2"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: "Player 3"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "center",
                                        children: "Player 4"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                            children: items.map((teeTime)=>{
                                const isSelected = selected.includes(String(teeTime.teeTime));
                                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                    hover: true,
                                    selected: isSelected,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            align: "center",
                                            children: teeTime.courseName?.trim() === "" ? user?.user?.name : teeTime.courseName
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            align: "center",
                                            children: (0,date_fns.format)(new Date(teeTime.teeTime), "dd/MM/yyyy hh:mm a")
                                        }),
                                        teeTime.records && teeTime.records.map((record, index)=>{
                                            const hoverState = hoverStates[index]; // Get hover state for the current row
                                            return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                                    align: "center",
                                                    children: [
                                                        record.userFirstName,
                                                        " ",
                                                        record.userLastName,
                                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            variant: "body2",
                                                            children: `(${record.userGolfLink ? record.userGolfLink : "No GOLF Link Number"})`
                                                        }),
                                                        record.userFirstName && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                            children: [
                                                                /*#__PURE__*/ jsx_runtime_.jsx((Rating_default()), {
                                                                    name: "hover-feedback",
                                                                    value: record.partnerRating,
                                                                    getLabelText: common/* getLabelText */.Kh,
                                                                    onChange: (event, newValue)=>onRatingUpdate(record, newValue ?? 0),
                                                                    onChangeActive: (event, newHover)=>{
                                                                        // Update the hover state for the current row
                                                                        const newHoverStates = [
                                                                            ...hoverStates
                                                                        ];
                                                                        newHoverStates[index] = newHover;
                                                                        setHoverStates(newHoverStates);
                                                                    },
                                                                    emptyIcon: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* Star01 */.M_q, {
                                                                        style: {
                                                                            opacity: 0.55
                                                                        },
                                                                        fontSize: "inherit"
                                                                    })
                                                                }),
                                                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                                    children: common/* labels */.p8[hoverState !== -1 && hoverState !== null && hoverState !== undefined ? hoverState : record.partnerRating]
                                                                })
                                                            ]
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx(node.Tooltip, {
                                                            title: "Provide member feedback",
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                                onClick: ()=>onOpenVoucher(Number(record.relatedFreeRoundId)),
                                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* AlertHexagon */.YfB, {})
                                                                })
                                                            })
                                                        })
                                                    ]
                                                })
                                            });
                                        })
                                    ]
                                }, teeTime.teeTime);
                            })
                        })
                    ]
                }),
                !isLoading && items.length <= 0 && /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    py: 6,
                    variant: "body2",
                    align: "center",
                    children: "\uD83D\uDE14 No Tee Times found."
                }),
                isLoading && items.length <= 0 && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                    py: 5,
                    sx: {
                        display: "flex",
                        flexDirection: "column",
                        alignItems: "center",
                        justifyContent: "center"
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(node.CircularProgress, {
                            size: 20
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            py: 1,
                            variant: "body2",
                            align: "center",
                            children: "Loading"
                        })
                    ]
                })
            ]
        })
    });
};
TeeTimeListTable.propTypes = {
    count: (prop_types_default()).number,
    items: (prop_types_default()).array,
    onDeselectAll: (prop_types_default()).func,
    onDeselectOne: (prop_types_default()).func,
    onPageChange: (prop_types_default()).func,
    onRowsPerPageChange: (prop_types_default()).func,
    onSelectAll: (prop_types_default()).func,
    onSelectOne: (prop_types_default()).func,
    page: (prop_types_default()).number,
    rowsPerPage: (prop_types_default()).number,
    selected: (prop_types_default()).array
};

// EXTERNAL MODULE: ./src/hooks/use-dialog.ts
var use_dialog = __webpack_require__(756964);
// EXTERNAL MODULE: ./node_modules/swr/core/dist/index.mjs + 1 modules
var dist = __webpack_require__(468149);
// EXTERNAL MODULE: ./src/utils/fetcher.ts
var fetcher = __webpack_require__(200490);
// EXTERNAL MODULE: ./src/utils/deep-copy.ts
var deep_copy = __webpack_require__(846447);
// EXTERNAL MODULE: ./src/utils/apply-sort.ts
var apply_sort = __webpack_require__(391734);
// EXTERNAL MODULE: ./src/utils/apply-pagination.ts
var apply_pagination = __webpack_require__(789989);
// EXTERNAL MODULE: ./src/api/main/index.ts
var main = __webpack_require__(15708);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var react_hot_toast_dist = __webpack_require__(333518);
// EXTERNAL MODULE: ./src/sections/dashboard/voucher/voucher-list-container.tsx
var voucher_list_container = __webpack_require__(909914);
// EXTERNAL MODULE: ./src/sections/dashboard/voucher/voucher-drawer/index.ts + 1 modules
var voucher_drawer = __webpack_require__(478315);
// EXTERNAL MODULE: ./src/hooks/use-voucher-store.ts
var use_voucher_store = __webpack_require__(256696);
;// CONCATENATED MODULE: ./src/app/(dashboard)/tee-times/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 






















const useTeeTimesSearch = ()=>{
    const [state, setState] = (0,react_.useState)({
        filters: {
            query: undefined,
            status: undefined
        },
        page: 0,
        rowsPerPage: 20,
        sortBy: "id",
        sortDir: "desc"
    });
    const handleFiltersChange = (0,react_.useCallback)((filters)=>{
        setState((prevState)=>({
                ...prevState,
                filters
            }));
    }, []);
    const handleSortChange = (0,react_.useCallback)((sortDir)=>{
        setState((prevState)=>({
                ...prevState,
                sortDir
            }));
    }, []);
    const handlePageChange = (0,react_.useCallback)((event, page)=>{
        setState((prevState)=>({
                ...prevState,
                page
            }));
    }, []);
    const handleRowsPerPageChange = (0,react_.useCallback)((event)=>{
        setState((prevState)=>({
                ...prevState,
                rowsPerPage: parseInt(event.target.value, 20)
            }));
    }, []);
    return {
        handleFiltersChange,
        handleSortChange,
        handlePageChange,
        handleRowsPerPageChange,
        state
    };
};
const useTeeTimesStore = (searchState)=>{
    const { data , error , mutate  } = (0,dist/* default */.ZP)("https://sit1api.futuregolf.com.au" + "/getPartner", fetcher/* fetcher */._, {
        revalidateOnFocus: true
    });
    const isLoading = !data && !error;
    if (data && data.teeTimes) {
        let filteredData = (0,deep_copy/* deepCopy */.p)(data.teeTimes);
        let count = filteredData.length;
        if (typeof searchState.filters !== "undefined") {
            // filter for search text
            console.log("search", searchState);
            filteredData = filteredData.filter((teeTime)=>{
                if (typeof searchState.filters.query !== "undefined" && searchState.filters.query !== "") {
                    let queryMatched = false;
                    const properties = [
                        "userFirstName",
                        "userLastName",
                        "userGolfLink",
                        "userId"
                    ];
                    if (teeTime) {
                        // Check if voucher is not null or undefined
                        properties.forEach((property)=>{
                            teeTime.records.forEach((record)=>{
                                const propertyValue = record[property];
                                if (propertyValue && typeof propertyValue === "string") {
                                    // Check if the property value is a non-null string
                                    if (propertyValue.toLowerCase().includes(String(searchState.filters?.query).toLowerCase())) {
                                        queryMatched = true;
                                    }
                                }
                            });
                        });
                    }
                    if (!queryMatched) {
                        return false;
                    }
                }
                return true;
            });
            // filter for tabs
            filteredData = filteredData.filter((teeTime)=>{
                if (typeof searchState.filters.status !== "undefined" && searchState.filters.status !== "") {
                    if (teeTime) {
                        // tab filtering
                        if (typeof searchState.filters.status !== "undefined") {
                            const teeTimeDate = new Date(teeTime.teeTime);
                            const statusMatched = searchState?.filters?.status === "upcoming" ? (0,date_fns.isAfter)(teeTimeDate, new Date()) : searchState?.filters?.status === "past" ? (0,date_fns.isBefore)(teeTimeDate, new Date()) : true;
                            if (!statusMatched) {
                                return false;
                            }
                        }
                    }
                }
                return true;
            });
            count = filteredData.length;
        }
        if (typeof searchState.sortBy !== "undefined" && typeof searchState.sortDir !== "undefined") {
            filteredData = (0,apply_sort/* applySort */.v)(filteredData, searchState.sortBy, searchState.sortDir);
        }
        if (typeof searchState.page !== "undefined" && typeof searchState.rowsPerPage !== "undefined") {
            filteredData = (0,apply_pagination/* applyPagination */.i)(filteredData, searchState.page, searchState.rowsPerPage);
        }
        return {
            teeTimes: filteredData,
            teeTimesCount: count,
            data: data,
            searchState: searchState,
            mutate
        };
    }
    return {
        teeTimes: [],
        teeTimesCount: 0,
        data: data,
        mutate,
        isLoading
    };
};
const useCurrentVoucher = (vouchers, voucherId)=>{
    return (0,react_.useMemo)(()=>{
        if (!voucherId) {
            return undefined;
        }
        return vouchers.find((voucher)=>Number(voucher.id) === Number(voucherId));
    }, [
        vouchers,
        voucherId
    ]);
};
const Page = ()=>{
    const rootRef = (0,react_.useRef)(null);
    const teeTimesSearch = useTeeTimesSearch();
    const teeTimesStore = useTeeTimesStore(teeTimesSearch.state);
    const vouchersStore = (0,use_voucher_store/* useVouchersStore */.k)(teeTimesSearch.state);
    const dialog = (0,use_dialog/* useDialog */.R)();
    const currentVoucher = useCurrentVoucher(vouchersStore.vouchers, dialog.data);
    const [showSnack, setShowSnackBar] = (0,react_.useState)({
        open: false,
        message: "",
        type: "success"
    });
    (0,use_page_view/* usePageView */.a)();
    const [pagination, setPagination] = (0,react_.useState)({
        data: teeTimesStore.teeTimes,
        offset: 0,
        numberPerPage: 20,
        pageCount: 0,
        currentData: []
    });
    (0,react_.useEffect)(()=>{
        setPagination({
            data: teeTimesStore.teeTimes,
            offset: 0,
            numberPerPage: 20,
            pageCount: 0,
            currentData: []
        });
    }, [
        teeTimesStore.teeTimesCount
    ]);
    (0,react_.useEffect)(()=>{
        if (teeTimesStore.data && teeTimesStore.teeTimesCount > 0) {
            setPagination((prevState)=>({
                    ...prevState,
                    data: teeTimesStore.teeTimes,
                    pageCount: prevState.data.length / prevState.numberPerPage,
                    currentData: teeTimesStore.teeTimes.slice(pagination.offset, pagination.offset + pagination.numberPerPage)
                }));
        }
    }, [
        teeTimesStore.searchState,
        teeTimesStore.data,
        teeTimesStore.teeTimesCount,
        pagination.numberPerPage,
        pagination.offset
    ]);
    (0,react_.useEffect)(()=>{
        if (!teeTimesStore?.data) teeTimesStore.mutate();
    }, [
        teeTimesStore?.data
    ]);
    const handlePageClick = (_, value)=>{
        const selected = value;
        const offset = (selected - 1) * pagination.numberPerPage;
        setPagination({
            ...pagination,
            offset
        });
    };
    const handleClose = (0,react_.useCallback)(()=>{
        setShowSnackBar({
            ...showSnack,
            open: false,
            message: ""
        });
    }, []);
    const handleVoucherOpen = (0,react_.useCallback)((relatedFreeRoundId)=>{
        // Close drawer if is the same order
        if (dialog.open && dialog.data === relatedFreeRoundId) {
            dialog.handleClose();
            return;
        }
        dialog.handleOpen(relatedFreeRoundId);
    }, [
        dialog
    ]);
    const handleRatingUpdate = async (teeTimeRecord, rating)=>{
        try {
            const response = await main/* mainApi.putVoucher */.m.putVoucher(Number(teeTimeRecord.relatedFreeRoundId), "wpcf-partner-rating", String(rating));
            if (response.response.status === 200) {
                teeTimesStore.mutate();
                react_hot_toast_dist/* default.success */.ZP.success(`Success, rating for ${teeTimeRecord.userFirstName} has been updated`);
            }
        } catch (err) {
            react_hot_toast_dist/* default.error */.ZP.error(`Whoops, there was an error in rating ${teeTimeRecord.userFirstName}`);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dedicated Tee Times"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                component: "main",
                sx: {
                    display: "flex",
                    flex: "1 1 auto",
                    overflow: "hidden",
                    position: "relative"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(voucher_list_container/* VoucherListContainer */.G, {
                        open: dialog.open,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
                            maxWidth: "xl",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                    sx: {
                                        py: 3
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                        alignItems: "flex-start",
                                        direction: "row",
                                        spacing: 4,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "h4",
                                                children: "Dedicated FG Tee Times"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(node.Divider, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(TeeTimeListSearch, {
                                    onFiltersChange: teeTimesSearch.handleFiltersChange,
                                    //   onSortChange={teeTimesSearch.handleSortChange}
                                    sortBy: teeTimesSearch.state.sortBy,
                                    sortDir: teeTimesSearch.state.sortDir
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(node.Divider, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(TeeTimeListTable, {
                                    count: teeTimesStore.teeTimesCount,
                                    items: pagination.currentData,
                                    onPageChange: teeTimesSearch.handlePageChange,
                                    onRowsPerPageChange: teeTimesSearch.handleRowsPerPageChange,
                                    page: teeTimesSearch.state.page,
                                    rowsPerPage: teeTimesSearch.state.rowsPerPage,
                                    onRatingUpdate: handleRatingUpdate,
                                    onOpenVoucher: handleVoucherOpen
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(node.Divider, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                    sx: {
                                        py: 3,
                                        display: "flex"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(node.Pagination, {
                                        sx: {
                                            marginLeft: "auto"
                                        },
                                        color: "primary",
                                        count: pagination.pageCount,
                                        onChange: handlePageClick,
                                        showFirstButton: true,
                                        showLastButton: true
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(voucher_drawer/* VoucherDrawer */.H, {
                        container: rootRef.current,
                        onClose: dialog.handleClose,
                        open: dialog.open,
                        voucher: currentVoucher
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 756964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ useDialog)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useDialog() {
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        open: false,
        data: undefined
    });
    const handleOpen = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((data)=>{
        setState({
            open: true,
            data
        });
    }, []);
    const handleClose = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setState({
            open: false
        });
    }, []);
    return {
        data: state.data,
        handleClose,
        handleOpen,
        open: state.open
    };
}


/***/ }),

/***/ 824642:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ useUpdateEffect)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/**
 * A custom useEffect hook that only triggers on updates, not on initial mount
 * @param {Function} effect
 * @param {Array<any>} dependencies
 */ const useUpdateEffect = (effect, dependencies = [])=>{
    const isInitialMount = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (isInitialMount.current) {
            isInitialMount.current = false;
        } else {
            return effect();
        }
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    dependencies);
};


/***/ }),

/***/ 256696:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ useVouchersStore)
/* harmony export */ });
/* harmony import */ var src_utils_fetcher__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(200490);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(468149);
/* harmony import */ var src_utils_deep_copy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(846447);
/* harmony import */ var src_utils_apply_sort__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(391734);
/* harmony import */ var src_utils_apply_pagination__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(789989);





const useVouchersStore = (searchState)=>{
    const { data , error , mutate  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP)("https://sit1api.futuregolf.com.au" + "/getPartner", src_utils_fetcher__WEBPACK_IMPORTED_MODULE_1__/* .fetcher */ ._, {
        revalidateOnFocus: true
    });
    const isLoading = !data && !error;
    if (data && data.vouchers) {
        let filteredData = (0,src_utils_deep_copy__WEBPACK_IMPORTED_MODULE_2__/* .deepCopy */ .p)(data.vouchers);
        let count = filteredData.length;
        if (typeof searchState.filters !== "undefined") {
            // filter for search text
            filteredData = filteredData.filter((voucher)=>{
                if (typeof searchState.filters.query !== "undefined" && searchState.filters.query !== "") {
                    let queryMatched = false;
                    const properties = [
                        "userFirstName",
                        "userLastName",
                        "voucherCode",
                        "userGolfLink"
                    ];
                    if (voucher) {
                        // Check if voucher is not null or undefined
                        properties.forEach((property)=>{
                            const propertyValue = voucher[property];
                            if (propertyValue && typeof propertyValue === "string") {
                                // Check if the property value is a non-null string
                                if (propertyValue.toLowerCase().includes(String(searchState.filters?.query).toLowerCase())) {
                                    queryMatched = true;
                                }
                            }
                        });
                    }
                    if (!queryMatched) {
                        return false;
                    }
                }
                return true;
            });
            // filter for tabs
            filteredData = filteredData.filter((voucher)=>{
                if (typeof searchState.filters.status !== "undefined" && searchState.filters.status !== "") {
                    if (voucher) {
                        // tab filtering
                        if (typeof searchState.filters.status !== "undefined") {
                            const statusMatched = searchState?.filters?.status.includes(voucher.status);
                            if (!statusMatched) {
                                return false;
                            }
                        }
                    }
                }
                return true;
            });
            count = filteredData.length;
        }
        if (typeof searchState.sortBy !== "undefined" && typeof searchState.sortDir !== "undefined") {
            filteredData = (0,src_utils_apply_sort__WEBPACK_IMPORTED_MODULE_3__/* .applySort */ .v)(filteredData, searchState.sortBy, searchState.sortDir);
        }
        if (typeof searchState.page !== "undefined" && typeof searchState.rowsPerPage !== "undefined") {
            filteredData = (0,src_utils_apply_pagination__WEBPACK_IMPORTED_MODULE_4__/* .applyPagination */ .i)(filteredData, searchState.page, searchState.rowsPerPage);
        }
        return {
            vouchers: filteredData,
            vouchersCount: count,
            data: data.vouchers,
            searchState: searchState,
            mutate
        };
    }
    return {
        vouchers: [],
        vouchersCount: 0,
        data: data,
        mutate,
        isLoading
    };
};


/***/ }),

/***/ 478315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "H": () => (/* reexport */ VoucherDrawer)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/X.js
var X = __webpack_require__(180501);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Drawer/index.js
var Drawer = __webpack_require__(379499);
var Drawer_default = /*#__PURE__*/__webpack_require__.n(Drawer);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/useMediaQuery/index.js
var useMediaQuery = __webpack_require__(975983);
// EXTERNAL MODULE: ./src/sections/dashboard/voucher/voucher-drawer/voucher-details.tsx + 1 modules
var voucher_details = __webpack_require__(819236);
;// CONCATENATED MODULE: ./src/sections/dashboard/voucher/voucher-drawer/voucher-drawer.tsx












const VoucherDrawer = (props)=>{
    const { container , onClose , open , voucher , onVerify , onRatingUpdate  } = props;
    const [isEditing, setIsEditing] = (0,react_.useState)(false);
    const lgUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("lg"));
    let content = null;
    if (voucher) {
        content = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    justifyContent: "space-between",
                    sx: {
                        px: 3,
                        py: 2
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            color: "inherit",
                            variant: "h6"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            color: "inherit",
                            onClick: onClose,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(X/* default */.Z, {})
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        px: 3,
                        py: 4
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(voucher_details/* VoucherDetails */.V, {
                        voucher: voucher,
                        onClose: onClose,
                        onRatingUpdate: onRatingUpdate,
                        viaVoucher: true
                    })
                })
            ]
        });
    }
    if (lgUp) {
        return /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
            anchor: "right",
            open: open,
            PaperProps: {
                sx: {
                    position: "relative",
                    width: 600
                }
            },
            SlideProps: {
                container
            },
            variant: "persistent",
            children: content
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
        anchor: "left",
        hideBackdrop: true,
        ModalProps: {
            container,
            sx: {
                pointerEvents: "none",
                position: "absolute"
            }
        },
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                maxWidth: "100%",
                width: 400,
                pointerEvents: "auto",
                position: "absolute"
            }
        },
        SlideProps: {
            container
        },
        variant: "temporary",
        children: content
    });
};
VoucherDrawer.propTypes = {
    container: (prop_types_default()).any,
    onClose: (prop_types_default()).func,
    open: (prop_types_default()).bool,
    // @ts-ignore
    voucher: (prop_types_default()).object
};

;// CONCATENATED MODULE: ./src/sections/dashboard/voucher/voucher-drawer/index.ts



/***/ }),

/***/ 909914:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ VoucherListContainer)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(522166);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);

const VoucherListContainer = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)("div", {
    shouldForwardProp: (prop)=>prop !== "open"
})(({ theme , open  })=>({
        flexGrow: 1,
        overflow: "auto",
        zIndex: 1,
        [theme.breakpoints.up("lg")]: {
            marginRight: -600
        },
        transition: theme.transitions.create("margin", {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        }),
        ...open && {
            [theme.breakpoints.up("lg")]: {
                marginRight: 0
            },
            transition: theme.transitions.create("margin", {
                easing: theme.transitions.easing.easeOut,
                duration: theme.transitions.duration.enteringScreen
            })
        }
    }));


/***/ }),

/***/ 200490:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ fetcher)
/* harmony export */ });
/* harmony import */ var _jwt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(205200);
// import { STORAGE_KEY } from "src/contexts/auth/auth-provider";

const fetcher = (url)=>{
    const accessToken = window.localStorage.getItem("accessToken");
    const decodedToken = (0,_jwt__WEBPACK_IMPORTED_MODULE_0__/* .decode */ .Jx)(String(accessToken));
    return fetch(url, {
        headers: {
            Authorization: `Bearer ${decodedToken.token}`
        }
    }).then((res)=>res.json()).catch((err)=>{
        throw err;
    });
};


/***/ }),

/***/ 437883:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/tee-times/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,3380,4755,6609,4609,5055,9894,4971,1368,3580,4714,4786,3595,3194,4292,4371,7680,95,9494,2302,4368,1734,717,5708,2235,9236], () => (__webpack_exec__(969450)));
module.exports = __webpack_exports__;

})();