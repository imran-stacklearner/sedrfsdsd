(() => {
var exports = {};
exports.id = 1130;
exports.ids = [1130,9236];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 257243:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 300883, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/page"
  

/***/ }),

/***/ 660652:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 9885))

/***/ }),

/***/ 9885:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
var react_default = /*#__PURE__*/__webpack_require__.n(react_);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-dialog.ts
var use_dialog = __webpack_require__(756964);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/sections/dashboard/voucher/voucher-list-container.tsx
var voucher_list_container = __webpack_require__(909914);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/SearchMd.js
var SearchMd = __webpack_require__(219057);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/InputAdornment/index.js
var InputAdornment = __webpack_require__(79150);
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/OutlinedInput/index.js
var OutlinedInput = __webpack_require__(877829);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tab/index.js
var Tab = __webpack_require__(189733);
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tabs/index.js
var Tabs = __webpack_require__(790206);
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TextField/index.js
var TextField = __webpack_require__(28379);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField);
// EXTERNAL MODULE: ./src/hooks/use-update-effect.ts
var use_update_effect = __webpack_require__(824642);
;// CONCATENATED MODULE: ./src/sections/dashboard/voucher/voucher-list-search.tsx














const tabOptions = [
    {
        label: "All",
        value: "all"
    },
    {
        label: "Pending",
        value: "1"
    },
    {
        label: "Verified",
        value: [
            "2",
            "4"
        ]
    }
];
const sortOptions = [
    {
        label: "Newest",
        value: "desc"
    },
    {
        label: "Oldest",
        value: "asc"
    }
];
const VoucherListSearch = (props)=>{
    const { onFiltersChange , onSortChange , sortDir ="asc"  } = props;
    const queryRef = (0,react_.useRef)(null);
    const [currentTab, setCurrentTab] = (0,react_.useState)("all");
    const [filters, setFilters] = (0,react_.useState)({
        query: undefined,
        status: undefined
    });
    const handleFiltersUpdate = (0,react_.useCallback)(()=>{
        onFiltersChange?.(filters);
    }, [
        filters,
        onFiltersChange
    ]);
    (0,use_update_effect/* useUpdateEffect */.r)(()=>{
        handleFiltersUpdate();
    }, [
        filters,
        handleFiltersUpdate
    ]);
    const handleTabsChange = (0,react_.useCallback)((event, tab)=>{
        setCurrentTab(tab);
        const status = tab === "all" ? undefined : tab;
        setFilters((prevState)=>({
                ...prevState,
                status
            }));
    }, []);
    const handleQueryChange = (0,react_.useCallback)((event)=>{
        event.preventDefault();
        const query = queryRef.current?.value || "";
        setFilters((prevState)=>({
                ...prevState,
                query
            }));
    }, []);
    const handleSortChange = (0,react_.useCallback)((event)=>{
        const sortDir = event.target.value;
        onSortChange?.(sortDir);
    }, [
        onSortChange
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Tabs_default()), {
                indicatorColor: "primary",
                onChange: handleTabsChange,
                scrollButtons: "auto",
                sx: {
                    px: 3
                },
                textColor: "primary",
                value: currentTab,
                variant: "scrollable",
                children: tabOptions.map((tab)=>/*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                        label: tab.label,
                        value: tab.value
                    }, tab.label))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                flexWrap: "wrap",
                gap: 3,
                sx: {
                    py: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        component: "form",
                        onChange: handleQueryChange,
                        onSubmit: handleQueryChange,
                        sx: {
                            flexGrow: 1
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                            defaultValue: "",
                            fullWidth: true,
                            inputProps: {
                                ref: queryRef
                            },
                            name: "search",
                            placeholder: "Search by member name or voucher code...",
                            startAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                position: "start",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(SearchMd/* default */.Z, {})
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                        label: "Sort By",
                        name: "sort",
                        onChange: handleSortChange,
                        select: true,
                        SelectProps: {
                            native: true
                        },
                        value: sortDir,
                        children: sortOptions.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                value: option.value,
                                children: option.label
                            }, option.value))
                    })
                ]
            })
        ]
    });
};
VoucherListSearch.propTypes = {
    onFiltersChange: (prop_types_default()).func,
    onSortChange: (prop_types_default()).func,
    sortBy: (prop_types_default()).string,
    sortDir: prop_types_default().oneOf([
        "asc",
        "desc"
    ])
};

// EXTERNAL MODULE: ./src/sections/dashboard/voucher/voucher-list-table.tsx
var voucher_list_table = __webpack_require__(93417);
// EXTERNAL MODULE: ./src/api/main/index.ts
var main = __webpack_require__(15708);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./src/sections/dashboard/voucher/voucher-drawer/index.ts + 1 modules
var voucher_drawer = __webpack_require__(478315);
// EXTERNAL MODULE: ./src/utils/common.ts
var common = __webpack_require__(867644);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/index.js
var node = __webpack_require__(664085);
// EXTERNAL MODULE: ./node_modules/@mui/icons-material/index.js
var icons_material = __webpack_require__(240347);
;// CONCATENATED MODULE: ./src/components/snack-bar.tsx




const SnackBar = (props)=>{
    const { text , open , type ="success" , onClose , setUndo  } = props;
    const action = /*#__PURE__*/ (0,jsx_runtime_.jsxs)((react_default()).Fragment, {
        children: [
            setUndo && /*#__PURE__*/ jsx_runtime_.jsx(node.Button, {
                color: type,
                size: "small",
                onClick: setUndo,
                children: "UNDO"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(node.IconButton, {
                size: "small",
                "aria-label": "close",
                color: "inherit",
                onClick: onClose,
                children: /*#__PURE__*/ jsx_runtime_.jsx(icons_material/* Close */.x8P, {
                    fontSize: "small"
                })
            })
        ]
    });
    return /*#__PURE__*/ jsx_runtime_.jsx(node.Snackbar, {
        anchorOrigin: {
            vertical: "top",
            horizontal: "center"
        },
        open: open,
        autoHideDuration: 6000,
        onClose: onClose,
        message: text,
        action: action
    });
};

// EXTERNAL MODULE: ./node_modules/date-fns-tz/esm/utcToZonedTime/index.js
var utcToZonedTime = __webpack_require__(771879);
// EXTERNAL MODULE: ./src/hooks/use-voucher-store.ts
var use_voucher_store = __webpack_require__(256696);
;// CONCATENATED MODULE: ./src/app/(dashboard)/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 





















const useVouchersSearch = ()=>{
    const [state, setState] = (0,react_.useState)({
        filters: {
            query: undefined,
            status: undefined
        },
        page: 0,
        rowsPerPage: 20,
        sortBy: "id",
        sortDir: "desc"
    });
    const handleFiltersChange = (0,react_.useCallback)((filters)=>{
        setState((prevState)=>({
                ...prevState,
                filters
            }));
    }, []);
    const handleSortChange = (0,react_.useCallback)((sortDir)=>{
        setState((prevState)=>({
                ...prevState,
                sortDir
            }));
    }, []);
    const handlePageChange = (0,react_.useCallback)((event, page)=>{
        setState((prevState)=>({
                ...prevState,
                page
            }));
    }, []);
    const handleRowsPerPageChange = (0,react_.useCallback)((event)=>{
        setState((prevState)=>({
                ...prevState,
                rowsPerPage: parseInt(event.target.value, 20)
            }));
    }, []);
    return {
        handleFiltersChange,
        handleSortChange,
        handlePageChange,
        handleRowsPerPageChange,
        state
    };
};
const useCurrentVoucher = (vouchers, voucherId)=>{
    return (0,react_.useMemo)(()=>{
        if (!voucherId) {
            return undefined;
        }
        return vouchers.find((voucher)=>voucher.id === voucherId);
    }, [
        vouchers,
        voucherId
    ]);
};
const Page = ()=>{
    const rootRef = (0,react_.useRef)(null);
    const vouchersSearch = useVouchersSearch();
    const vouchersStore = (0,use_voucher_store/* useVouchersStore */.k)(vouchersSearch.state);
    const dialog = (0,use_dialog/* useDialog */.R)();
    const currentVoucher = useCurrentVoucher(vouchersStore.vouchers, dialog.data);
    const [showSnack, setShowSnackBar] = (0,react_.useState)({
        open: false,
        message: "",
        type: "success"
    });
    const [previousData, setPreviousData] = (0,react_.useState)({
        type: "",
        id: 0,
        value: 0
    });
    (0,use_page_view/* usePageView */.a)();
    const [pagination, setPagination] = (0,react_.useState)({
        data: vouchersStore.vouchers,
        offset: 0,
        numberPerPage: 20,
        pageCount: 0,
        currentData: []
    });
    (0,react_.useEffect)(()=>{
        setPagination({
            data: vouchersStore.vouchers,
            offset: 0,
            numberPerPage: 20,
            pageCount: 0,
            currentData: []
        });
    }, [
        vouchersStore.vouchersCount
    ]);
    (0,react_.useEffect)(()=>{
        if (vouchersStore.data && vouchersStore.vouchersCount > 0) {
            setPagination((prevState)=>({
                    ...prevState,
                    data: vouchersStore.vouchers,
                    pageCount: prevState.data.length / prevState.numberPerPage,
                    currentData: vouchersStore.vouchers.slice(pagination.offset, pagination.offset + pagination.numberPerPage)
                }));
        }
    }, [
        vouchersStore.searchState,
        vouchersStore.data,
        vouchersStore.vouchersCount,
        pagination.numberPerPage,
        pagination.offset
    ]);
    (0,react_.useEffect)(()=>{
        if (!vouchersStore?.data) vouchersStore.mutate();
    }, [
        vouchersStore?.data
    ]);
    const handlePageClick = (_, value)=>{
        const selected = value;
        const offset = (selected - 1) * pagination.numberPerPage;
        setPagination({
            ...pagination,
            offset
        });
    };
    const handleClose = (0,react_.useCallback)(()=>{
        setShowSnackBar({
            ...showSnack,
            open: false,
            message: ""
        });
    }, []);
    const handleVoucherOpen = (0,react_.useCallback)((voucher)=>{
        // Close drawer if is the same order
        if (dialog.open && dialog.data === voucher.id) {
            dialog.handleClose();
            return;
        }
        dialog.handleOpen(voucher.id);
    }, [
        dialog
    ]);
    const handleVoucherUpdate = async (voucher, result)=>{
        try {
            const timestampString = Math.floor((0,utcToZonedTime/* default */.Z)(new Date(), "Australia/Melbourne").getTime() / 1000).toString();
            const response = await main/* mainApi.putVoucher */.m.putVoucher(Number(Number(voucher?.id)), "wpcf-verified-at", timestampString);
            await main/* mainApi.putVoucher */.m.putVoucher(Number(voucher?.id), "wpcf-fg-free-round-status", result);
            if (response.response.status === 200) {
                vouchersStore.mutate();
                setShowSnackBar({
                    ...showSnack,
                    open: true,
                    type: "success",
                    message: `Success, voucher ${voucher.voucherCode} has been marked as verified`
                });
                setPreviousData({
                    type: "voucherUpdate",
                    id: Number(voucher.id),
                    value: 0
                });
            }
        } catch (err) {
            setShowSnackBar({
                ...showSnack,
                open: true,
                type: "error",
                message: `Whoops, there was an error in updating voucher ${voucher.voucherCode}`
            });
        }
    };
    const handleRatingUpdate = async (voucher, rating, previousRating)=>{
        try {
            const response = await main/* mainApi.putVoucher */.m.putVoucher(Number(voucher.id), "wpcf-partner-rating", String(rating));
            if (response.response.status === 200) {
                vouchersStore.mutate();
                setShowSnackBar({
                    ...showSnack,
                    open: true,
                    type: "success",
                    message: `Success, rating for ${voucher.userFirstName} has been updated to ${common/* labels */.p8[rating]}!`
                });
                setPreviousData({
                    type: "ratingUpdate",
                    id: Number(voucher.id),
                    value: previousRating
                });
            }
        } catch (err) {
            setShowSnackBar({
                ...showSnack,
                open: true,
                type: "error",
                message: `Whoops, there was an error in rating ${voucher.userFirstName}`
            });
        }
    };
    const handleRatingUndo = async ()=>{
        try {
            const response = await main/* mainApi.putVoucher */.m.putVoucher(previousData.id, "wpcf-partner-rating", String(previousData.value));
            if (response.response.status === 200) {
                vouchersStore.mutate();
                setShowSnackBar({
                    ...showSnack,
                    open: true,
                    type: "success",
                    message: `Success, rating has been updated to back to ${common/* labels */.p8[previousData.value]}!`
                });
                setPreviousData({
                    type: "ratingUpdate",
                    id: 0,
                    value: 0
                });
            }
        } catch (err) {
            console.log("error", err);
        }
    };
    const handleVoucherUndo = async ()=>{
        try {
            const response = await main/* mainApi.putVoucher */.m.putVoucher(previousData.id, "wpcf-verified-at", "");
            await main/* mainApi.putVoucher */.m.putVoucher(previousData?.id, "wpcf-fg-free-round-status", "1" // update back to claimed status
            );
            if (response.response.status === 200) {
                vouchersStore.mutate();
                setShowSnackBar({
                    ...showSnack,
                    open: true,
                    type: "success",
                    message: `Success, voucher has been marked as unverified`
                });
                setPreviousData({
                    type: "voucherUpdate",
                    id: 0,
                    value: 0
                });
            }
        } catch (err) {
            console.log("error", err);
        }
    };
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Round Vouchers"
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                component: "main",
                ref: rootRef,
                sx: {
                    display: "flex",
                    flex: "1 1 auto",
                    overflow: "hidden",
                    position: "relative"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(SnackBar, {
                        text: showSnack.message,
                        open: showSnack.open,
                        onClose: handleClose,
                        setUndo: previousData.id > 0 ? previousData.type === "ratingUpdate" ? handleRatingUndo : previousData.type === "voucherUpdate" ? handleVoucherUndo : undefined : undefined
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(voucher_list_container/* VoucherListContainer */.G, {
                        open: dialog.open,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
                            maxWidth: "xl",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                    sx: {
                                        py: 3
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                        alignItems: "flex-start",
                                        direction: "row",
                                        justifyContent: "space-between",
                                        spacing: 4,
                                        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "h4",
                                                children: "Vouchers"
                                            })
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(VoucherListSearch, {
                                    onFiltersChange: vouchersSearch.handleFiltersChange,
                                    onSortChange: vouchersSearch.handleSortChange,
                                    sortBy: vouchersSearch.state.sortBy,
                                    sortDir: vouchersSearch.state.sortDir
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(voucher_list_table/* VoucherListTable */.J, {
                                    count: vouchersStore.vouchersCount,
                                    items: pagination.currentData,
                                    onPageChange: vouchersSearch.handlePageChange,
                                    onRowsPerPageChange: vouchersSearch.handleRowsPerPageChange,
                                    page: vouchersSearch.state.page,
                                    rowsPerPage: vouchersSearch.state.rowsPerPage,
                                    onMarkAsVerified: handleVoucherUpdate,
                                    onOpenVoucher: handleVoucherOpen,
                                    onRatingUpdate: handleRatingUpdate,
                                    isLoading: vouchersStore.isLoading
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                    sx: {
                                        py: 3,
                                        display: "flex"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(node.Pagination, {
                                        sx: {
                                            marginLeft: "auto"
                                        },
                                        color: "primary",
                                        count: pagination.pageCount,
                                        onChange: handlePageClick,
                                        showFirstButton: true,
                                        showLastButton: true
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(voucher_drawer/* VoucherDrawer */.H, {
                        container: rootRef.current,
                        onClose: dialog.handleClose,
                        open: dialog.open,
                        voucher: currentVoucher,
                        onRatingUpdate: handleRatingUpdate
                    })
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 756964:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ useDialog)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function useDialog() {
    const [state, setState] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)({
        open: false,
        data: undefined
    });
    const handleOpen = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)((data)=>{
        setState({
            open: true,
            data
        });
    }, []);
    const handleClose = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setState({
            open: false
        });
    }, []);
    return {
        data: state.data,
        handleClose,
        handleOpen,
        open: state.open
    };
}


/***/ }),

/***/ 82365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.useSearchParams)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 824642:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ useUpdateEffect)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

/**
 * A custom useEffect hook that only triggers on updates, not on initial mount
 * @param {Function} effect
 * @param {Array<any>} dependencies
 */ const useUpdateEffect = (effect, dependencies = [])=>{
    const isInitialMount = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(true);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (isInitialMount.current) {
            isInitialMount.current = false;
        } else {
            return effect();
        }
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    dependencies);
};


/***/ }),

/***/ 256696:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ useVouchersStore)
/* harmony export */ });
/* harmony import */ var src_utils_fetcher__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(200490);
/* harmony import */ var swr__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(468149);
/* harmony import */ var src_utils_deep_copy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(846447);
/* harmony import */ var src_utils_apply_sort__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(391734);
/* harmony import */ var src_utils_apply_pagination__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(789989);





const useVouchersStore = (searchState)=>{
    const { data , error , mutate  } = (0,swr__WEBPACK_IMPORTED_MODULE_0__/* ["default"] */ .ZP)("https://sit1api.futuregolf.com.au" + "/getPartner", src_utils_fetcher__WEBPACK_IMPORTED_MODULE_1__/* .fetcher */ ._, {
        revalidateOnFocus: true
    });
    const isLoading = !data && !error;
    if (data && data.vouchers) {
        let filteredData = (0,src_utils_deep_copy__WEBPACK_IMPORTED_MODULE_2__/* .deepCopy */ .p)(data.vouchers);
        let count = filteredData.length;
        if (typeof searchState.filters !== "undefined") {
            // filter for search text
            filteredData = filteredData.filter((voucher)=>{
                if (typeof searchState.filters.query !== "undefined" && searchState.filters.query !== "") {
                    let queryMatched = false;
                    const properties = [
                        "userFirstName",
                        "userLastName",
                        "voucherCode",
                        "userGolfLink"
                    ];
                    if (voucher) {
                        // Check if voucher is not null or undefined
                        properties.forEach((property)=>{
                            const propertyValue = voucher[property];
                            if (propertyValue && typeof propertyValue === "string") {
                                // Check if the property value is a non-null string
                                if (propertyValue.toLowerCase().includes(String(searchState.filters?.query).toLowerCase())) {
                                    queryMatched = true;
                                }
                            }
                        });
                    }
                    if (!queryMatched) {
                        return false;
                    }
                }
                return true;
            });
            // filter for tabs
            filteredData = filteredData.filter((voucher)=>{
                if (typeof searchState.filters.status !== "undefined" && searchState.filters.status !== "") {
                    if (voucher) {
                        // tab filtering
                        if (typeof searchState.filters.status !== "undefined") {
                            const statusMatched = searchState?.filters?.status.includes(voucher.status);
                            if (!statusMatched) {
                                return false;
                            }
                        }
                    }
                }
                return true;
            });
            count = filteredData.length;
        }
        if (typeof searchState.sortBy !== "undefined" && typeof searchState.sortDir !== "undefined") {
            filteredData = (0,src_utils_apply_sort__WEBPACK_IMPORTED_MODULE_3__/* .applySort */ .v)(filteredData, searchState.sortBy, searchState.sortDir);
        }
        if (typeof searchState.page !== "undefined" && typeof searchState.rowsPerPage !== "undefined") {
            filteredData = (0,src_utils_apply_pagination__WEBPACK_IMPORTED_MODULE_4__/* .applyPagination */ .i)(filteredData, searchState.page, searchState.rowsPerPage);
        }
        return {
            vouchers: filteredData,
            vouchersCount: count,
            data: data.vouchers,
            searchState: searchState,
            mutate
        };
    }
    return {
        vouchers: [],
        vouchersCount: 0,
        data: data,
        mutate,
        isLoading
    };
};


/***/ }),

/***/ 478315:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "H": () => (/* reexport */ VoucherDrawer)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/X.js
var X = __webpack_require__(180501);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Drawer/index.js
var Drawer = __webpack_require__(379499);
var Drawer_default = /*#__PURE__*/__webpack_require__.n(Drawer);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/useMediaQuery/index.js
var useMediaQuery = __webpack_require__(975983);
// EXTERNAL MODULE: ./src/sections/dashboard/voucher/voucher-drawer/voucher-details.tsx + 1 modules
var voucher_details = __webpack_require__(819236);
;// CONCATENATED MODULE: ./src/sections/dashboard/voucher/voucher-drawer/voucher-drawer.tsx












const VoucherDrawer = (props)=>{
    const { container , onClose , open , voucher , onVerify , onRatingUpdate  } = props;
    const [isEditing, setIsEditing] = (0,react_.useState)(false);
    const lgUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("lg"));
    let content = null;
    if (voucher) {
        content = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    justifyContent: "space-between",
                    sx: {
                        px: 3,
                        py: 2
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            color: "inherit",
                            variant: "h6"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            color: "inherit",
                            onClick: onClose,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(X/* default */.Z, {})
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        px: 3,
                        py: 4
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(voucher_details/* VoucherDetails */.V, {
                        voucher: voucher,
                        onClose: onClose,
                        onRatingUpdate: onRatingUpdate,
                        viaVoucher: true
                    })
                })
            ]
        });
    }
    if (lgUp) {
        return /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
            anchor: "right",
            open: open,
            PaperProps: {
                sx: {
                    position: "relative",
                    width: 600
                }
            },
            SlideProps: {
                container
            },
            variant: "persistent",
            children: content
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
        anchor: "left",
        hideBackdrop: true,
        ModalProps: {
            container,
            sx: {
                pointerEvents: "none",
                position: "absolute"
            }
        },
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                maxWidth: "100%",
                width: 400,
                pointerEvents: "auto",
                position: "absolute"
            }
        },
        SlideProps: {
            container
        },
        variant: "temporary",
        children: content
    });
};
VoucherDrawer.propTypes = {
    container: (prop_types_default()).any,
    onClose: (prop_types_default()).func,
    open: (prop_types_default()).bool,
    // @ts-ignore
    voucher: (prop_types_default()).object
};

;// CONCATENATED MODULE: ./src/sections/dashboard/voucher/voucher-drawer/index.ts



/***/ }),

/***/ 819236:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "V": () => (/* binding */ VoucherDetails)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./node_modules/yup/index.js
var yup = __webpack_require__(158952);
// EXTERNAL MODULE: ./src/utils/common.ts
var common = __webpack_require__(867644);
// EXTERNAL MODULE: ./src/sections/dashboard/voucher/voucher-list-table.tsx
var voucher_list_table = __webpack_require__(93417);
// EXTERNAL MODULE: ./src/paths.ts
var paths = __webpack_require__(287842);
// EXTERNAL MODULE: ./node_modules/react-hot-toast/dist/index.mjs + 1 modules
var dist = __webpack_require__(333518);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/index.js
var node = __webpack_require__(664085);
// EXTERNAL MODULE: ./src/components/file-dropzone.tsx
var file_dropzone = __webpack_require__(452235);
// EXTERNAL MODULE: ./node_modules/@mui/x-date-pickers/node/index.js
var x_date_pickers_node = __webpack_require__(998591);
// EXTERNAL MODULE: ./src/hooks/use-auth.ts
var use_auth = __webpack_require__(796372);
;// CONCATENATED MODULE: ./src/utils/file-to-base64.ts
const fileToBase64 = (file)=>new Promise((resolve, reject)=>{
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = ()=>resolve(reader.result);
        reader.onerror = (error)=>reject(error);
    });

// EXTERNAL MODULE: ./node_modules/formik/dist/index.js
var formik_dist = __webpack_require__(906135);
// EXTERNAL MODULE: ./src/hooks/use-mounted.ts
var use_mounted = __webpack_require__(887408);
// EXTERNAL MODULE: ./src/hooks/use-router.ts
var use_router = __webpack_require__(840513);
// EXTERNAL MODULE: ./src/hooks/use-search-params.ts
var use_search_params = __webpack_require__(82365);
// EXTERNAL MODULE: ./src/api/main/index.ts
var main = __webpack_require__(15708);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/cjs/index.js
var cjs = __webpack_require__(845801);
// EXTERNAL MODULE: ./src/sections/components/buttons/button.tsx
var buttons_button = __webpack_require__(633743);
;// CONCATENATED MODULE: ./src/sections/dashboard/voucher/voucher-drawer/voucher-details.tsx























const VoucherDetails = (props)=>{
    const { voucher , onClose , onRatingUpdate , viaVoucher  } = props;
    const [cover, setCover] = (0,react_.useState)();
    const user = (0,use_auth/* useAuth */.a)();
    const isMounted = (0,use_mounted/* useMounted */.s)();
    const router = (0,use_router/* useRouter */.t)();
    const searchParams = (0,use_search_params/* useSearchParams */.l)();
    const returnTo = searchParams.get("returnTo");
    const [files, setFiles] = (0,react_.useState)([]);
    const [hoverState, setHoverState] = (0,react_.useState)(voucher?.partnerRating || 0);
    // Initialize hover state for each item
    (0,react_.useEffect)(()=>{
        setFiles([]);
    }, [
        open
    ]);
    const handleDrop = (0,react_.useCallback)((newFiles)=>{
        setFiles((prevFiles)=>{
            return [
                ...prevFiles,
                ...newFiles
            ];
        });
    }, []);
    const handleRemove = (0,react_.useCallback)((file)=>{
        setFiles((prevFiles)=>{
            return prevFiles.filter((_file)=>_file !== file);
        });
    }, []);
    const handleRemoveAll = (0,react_.useCallback)(()=>{
        setFiles([]);
    }, []);
    const initialValues = {
        name: `${voucher?.userFirstName ?? ""} ${voucher?.userLastName ?? ""}`,
        feedbackDate: new Date(),
        rating: voucher?.partnerRating ?? 0,
        feedback: "",
        partnerName: user?.user?.name ?? "",
        submit: null
    };
    const validationSchema = yup/* object */.Ry({
        name: yup/* string */.Z_().max(255).required("Member name is required"),
        feedback: yup/* string */.Z_().max(750).required("Feedback is required")
    });
    function resetForm() {
        formik.resetForm();
        setFiles([]);
        onClose?.();
    }
    const formik = (0,formik_dist.useFormik)({
        initialValues,
        validationSchema,
        onSubmit: async (values, helpers)=>{
            const base64FilePromises = files.map((file)=>fileToBase64(file));
            try {
                const base64Files = await Promise.all(base64FilePromises);
                const res = await main/* mainApi.postPartnerFeedback */.m.postPartnerFeedback(1, values, // @ts-ignore
                base64Files);
                if (res.response.status === 200) {
                    dist/* default.success */.ZP.success("Feedback submitted to Future Golf");
                    resetForm();
                } else {
                    dist/* default.error */.ZP.error(`Whoops, there was an error in submitting this feedback`);
                }
            } catch (err) {
                console.error(err);
                if (isMounted()) {
                    helpers.setStatus({
                        success: false
                    });
                    helpers.setErrors({
                        submit: err.message
                    });
                    helpers.setSubmitting(false);
                }
            }
        }
    });
    let statusColor;
    if (voucher?.status && voucher_list_table/* statusMap */.h[voucher.status]) {
        statusColor = voucher_list_table/* statusMap */.h[voucher.status];
    } else {
        statusColor = "warning"; // Default value
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
        spacing: 6,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            noValidate: true,
            onSubmit: formik.handleSubmit,
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.Card, {
                            elevation: 16,
                            sx: {
                                borderRadius: 1,
                                justifyContent: "space-between",
                                px: 3,
                                py: 2
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(node.Grid, {
                                    xs: 12,
                                    sm: 6,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormControl, {
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.FormLabel, {
                                                sx: {
                                                    color: "text.primary",
                                                    mb: 1
                                                },
                                                children: "Member Name"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.OutlinedInput, {
                                                error: !!(formik.touched.name && formik.errors.name),
                                                fullWidth: true,
                                                placeholder: "John Smith",
                                                disabled: viaVoucher,
                                                name: "name",
                                                onBlur: formik.handleBlur,
                                                onChange: formik.handleChange,
                                                type: "text",
                                                value: formik.values.name
                                            })
                                        ]
                                    })
                                }),
                                voucher?.partnerRating && onRatingUpdate && /*#__PURE__*/ jsx_runtime_.jsx(node.Grid, {
                                    xs: 12,
                                    sm: 6,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormControl, {
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.FormLabel, {
                                                sx: {
                                                    color: "text.primary",
                                                    mt: 2,
                                                    mb: 1
                                                },
                                                children: "Rating"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.Rating, {
                                                name: "hover-feedback",
                                                value: voucher.partnerRating,
                                                getLabelText: common/* getLabelText */.Kh,
                                                onChange: (event, newValue)=>onRatingUpdate(voucher, newValue ?? 0, voucher.partnerRating),
                                                onChangeActive: (event, newHover)=>{
                                                    setHoverState(newHover);
                                                },
                                                emptyIcon: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* Star01 */.M_q, {
                                                    style: {
                                                        opacity: 0.55
                                                    },
                                                    fontSize: "inherit"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.Box, {
                                                sx: {
                                                    ml: 2
                                                },
                                                children: common/* labels */.p8[hoverState !== -1 && hoverState !== null && hoverState !== undefined ? hoverState : voucher.partnerRating]
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.Card, {
                            elevation: 16,
                            sx: {
                                borderRadius: 1,
                                justifyContent: "space-between",
                                px: 3,
                                py: 2
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(node.Grid, {
                                    xs: 12,
                                    sm: 6,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormControl, {
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.FormLabel, {
                                                sx: {
                                                    color: "text.primary",
                                                    mb: 1
                                                },
                                                children: "Feedback Date"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(x_date_pickers_node.DateTimePicker, {
                                                label: "Feedback Date",
                                                onChange: formik.handleChange,
                                                value: formik.values.feedbackDate,
                                                format: "dd/MM/yyyy hh:mm a"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(node.Grid, {
                                    xs: 12,
                                    sm: 6,
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormControl, {
                                        fullWidth: true,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.FormLabel, {
                                                sx: {
                                                    color: "text.primary",
                                                    mt: 2,
                                                    mb: 1
                                                },
                                                children: "Feedback"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(node.OutlinedInput, {
                                                error: !!(formik.touched.feedback && formik.errors.feedback),
                                                fullWidth: true,
                                                placeholder: "Your feedback...",
                                                minRows: 4,
                                                multiline: true,
                                                name: "feedback",
                                                onBlur: formik.handleBlur,
                                                onChange: formik.handleChange,
                                                type: "text",
                                                value: formik.values.feedback
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(node.Card, {
                            elevation: 16,
                            sx: {
                                borderRadius: 1,
                                justifyContent: "space-between",
                                px: 3,
                                py: 2
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(node.Grid, {
                                xs: 12,
                                sm: 6,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormControl, {
                                    fullWidth: true,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.FormLabel, {
                                            sx: {
                                                color: "text.primary",
                                                mb: 1
                                            },
                                            children: [
                                                "Attachments",
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "subtitle2",
                                                    children: "Maximum of 10 files"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "subtitle2",
                                                    children: "(optional)"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(file_dropzone/* FileDropzone */.Y, {
                                            accept: {
                                                "image/*": [],
                                                "application/pdf": [
                                                    ".pdf"
                                                ]
                                            },
                                            caption: "(PDF, JPG, PNG or SVG files only)",
                                            files: files,
                                            onDrop: handleDrop,
                                            onRemove: handleRemove,
                                            onRemoveAll: handleRemoveAll
                                        })
                                    ]
                                })
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(node.Card, {
                    elevation: 16,
                    sx: {
                        alignItems: "center",
                        borderRadius: 1,
                        display: "flex",
                        justifyContent: "space-between",
                        mt: 2,
                        mb: 8,
                        px: 3,
                        py: 2
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                            variant: "subtitle2",
                            sx: {
                                fontWeight: 300
                            },
                            children: [
                                "We appreciate your feedback,",
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "subtitle2",
                                    children: user.user?.name
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            spacing: 2,
                            children: [
                                !voucher && /*#__PURE__*/ jsx_runtime_.jsx(buttons_button/* Button */.z, {
                                    color: "inherit",
                                    //     component={RouterLink}
                                    href: paths/* paths.dashboard.memberFeedback */.H.dashboard.memberFeedback,
                                    onClick: ()=>(resetForm(), dist/* default.error */.ZP.error("Feedback cancelled")),
                                    children: "Cancel"
                                }),
                                formik.errors.submit && /*#__PURE__*/ jsx_runtime_.jsx(node.FormHelperText, {
                                    error: true,
                                    sx: {
                                        mt: 3
                                    },
                                    children: formik.errors.submit
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(buttons_button/* Button */.z, {
                                    disabled: formik.isSubmitting,
                                    type: "submit",
                                    variant: "contained",
                                    children: "Submit feedback"
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};
VoucherDetails.propTypes = {
    onApprove: (prop_types_default()).func,
    onEdit: (prop_types_default()).func,
    onReject: (prop_types_default()).func,
    // @ts-ignore
    voucher: (prop_types_default()).object
};


/***/ }),

/***/ 909914:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "G": () => (/* binding */ VoucherListContainer)
/* harmony export */ });
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(522166);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);

const VoucherListContainer = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)("div", {
    shouldForwardProp: (prop)=>prop !== "open"
})(({ theme , open  })=>({
        flexGrow: 1,
        overflow: "auto",
        zIndex: 1,
        [theme.breakpoints.up("lg")]: {
            marginRight: -600
        },
        transition: theme.transitions.create("margin", {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        }),
        ...open && {
            [theme.breakpoints.up("lg")]: {
                marginRight: 0
            },
            transition: theme.transitions.create("margin", {
                easing: theme.transitions.easing.easeOut,
                duration: theme.transitions.duration.enteringScreen
            })
        }
    }));


/***/ }),

/***/ 93417:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "J": () => (/* binding */ VoucherListTable),
/* harmony export */   "h": () => (/* binding */ statusMap)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(556786);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(869232);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _untitled_ui_icons_react_build_esm_CheckCircle__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(959982);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(746661);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(916816);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_material_Link__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(115917);
/* harmony import */ var _mui_material_Link__WEBPACK_IMPORTED_MODULE_20___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Link__WEBPACK_IMPORTED_MODULE_20__);
/* harmony import */ var _mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(381394);
/* harmony import */ var _mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(620390);
/* harmony import */ var _mui_material_Table__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Table__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(843606);
/* harmony import */ var _mui_material_TableBody__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(340514);
/* harmony import */ var _mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_TableHead__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(30092);
/* harmony import */ var _mui_material_TableHead__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableHead__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(893761);
/* harmony import */ var _mui_material_TableRow__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(66609);
/* harmony import */ var date_fns__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(date_fns__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var date_fns_tz__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(189371);
/* harmony import */ var date_fns_tz__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(771879);
/* harmony import */ var src_components_scrollbar__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(851716);
/* harmony import */ var _untitled_ui_icons_react__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(845801);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(556020);
/* harmony import */ var _mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var src_components_severity_pill__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(594368);
/* harmony import */ var src_utils_common__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(867644);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(247022);
/* harmony import */ var _mui_material_Rating__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Rating__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(664085);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_21__);






















const statusMap = {
    1: "success",
    2: "info",
    3: "warning",
    4: "success"
};
const VoucherListTable = (props)=>{
    const { items =[] , onMarkAsVerified , onOpenVoucher , onRatingUpdate , selected =[] , isLoading  } = props;
    // Initialize hover state for each item
    const [hoverStates, setHoverStates] = react__WEBPACK_IMPORTED_MODULE_1___default().useState(items.map(()=>-1));
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_7__["default"], {
            sx: {
                position: "relative"
            },
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(src_components_scrollbar__WEBPACK_IMPORTED_MODULE_3__/* .Scrollbar */ .L, {
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Table__WEBPACK_IMPORTED_MODULE_8___default()), {
                        stickyHeader: true,
                        size: "small",
                        "aria-label": "a dense table",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableHead__WEBPACK_IMPORTED_MODULE_9___default()), {
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Member Rating"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Action"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Name"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Claimed On"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "GOLF Link"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Voucher Code"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                            align: "center",
                                            children: "Verified On"
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableBody__WEBPACK_IMPORTED_MODULE_12___default()), {
                                children: items.length > 0 && items.map((voucher, index)=>{
                                    const isSelected = selected.includes(String(voucher.id));
                                    const hoverState = hoverStates[index]; // Get hover state for the current row
                                    // Create a hover state for the current row
                                    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableRow__WEBPACK_IMPORTED_MODULE_10___default()), {
                                        hover: true,
                                        selected: isSelected,
                                        children: [
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: [
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Rating__WEBPACK_IMPORTED_MODULE_13___default()), {
                                                        name: "hover-feedback",
                                                        value: voucher.partnerRating,
                                                        getLabelText: src_utils_common__WEBPACK_IMPORTED_MODULE_6__/* .getLabelText */ .Kh,
                                                        onChange: (event, newValue)=>onRatingUpdate(voucher, newValue ?? 0, voucher.partnerRating),
                                                        onChangeActive: (event, newHover)=>{
                                                            // Update the hover state for the current row
                                                            const newHoverStates = [
                                                                ...hoverStates
                                                            ];
                                                            newHoverStates[index] = newHover;
                                                            setHoverStates(newHoverStates);
                                                        },
                                                        emptyIcon: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_untitled_ui_icons_react__WEBPACK_IMPORTED_MODULE_4__/* .Star01 */ .M_q, {
                                                            style: {
                                                                opacity: 0.55
                                                            },
                                                            fontSize: "inherit"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_Box__WEBPACK_IMPORTED_MODULE_7__["default"], {
                                                        sx: {
                                                            ml: 2
                                                        },
                                                        children: src_utils_common__WEBPACK_IMPORTED_MODULE_6__/* .labels */ .p8[hoverState !== -1 && hoverState !== null && hoverState !== undefined ? hoverState : voucher.partnerRating]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: [
                                                    voucher.status === "1" && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        title: "Mark as verified",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                            onClick: ()=>onMarkAsVerified(voucher, "2"),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_16___default()), {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_untitled_ui_icons_react_build_esm_CheckCircle__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z, {})
                                                            })
                                                        })
                                                    }),
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                        title: "Provide member feedback",
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_15___default()), {
                                                            onClick: ()=>onOpenVoucher(voucher),
                                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_SvgIcon__WEBPACK_IMPORTED_MODULE_16___default()), {
                                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_untitled_ui_icons_react__WEBPACK_IMPORTED_MODULE_4__/* .AlertHexagon */ .YfB, {})
                                                            })
                                                        })
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: [
                                                    voucher.userFirstName,
                                                    " ",
                                                    voucher.userLastName
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: voucher.claimedDate
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: Number(voucher.userGolfLink) ? voucher.userGolfLink : "Unknown"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: voucher.voucherCode
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_TableCell__WEBPACK_IMPORTED_MODULE_11___default()), {
                                                align: "center",
                                                children: voucher.verifiedDate || [
                                                    "2"
                                                ].includes(voucher.status) ? voucher.verifiedDate ? (0,date_fns_tz__WEBPACK_IMPORTED_MODULE_17__/* ["default"] */ .Z)((0,date_fns_tz__WEBPACK_IMPORTED_MODULE_18__/* ["default"] */ .Z)((0,date_fns__WEBPACK_IMPORTED_MODULE_19__.fromUnixTime)(Number(voucher.verifiedDate)), "UTC"), "dd/MM/yyyy hh:mm:ss a", {
                                                    timeZone: "UTC"
                                                }) : "Unable to determine" : [
                                                    "4"
                                                ].includes(voucher.status) ? "Expired" : /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Tooltip__WEBPACK_IMPORTED_MODULE_14___default()), {
                                                    title: "Mark as verified",
                                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Link__WEBPACK_IMPORTED_MODULE_20___default()), {
                                                        variant: "inherit",
                                                        onClick: ()=>onMarkAsVerified(voucher, "2"),
                                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(src_components_severity_pill__WEBPACK_IMPORTED_MODULE_5__/* .SeverityPill */ .I, {
                                                            color: "warning",
                                                            children: "Mark as verified"
                                                        })
                                                    })
                                                })
                                            })
                                        ]
                                    }, voucher.id);
                                })
                            })
                        ]
                    }),
                    !isLoading && items.length <= 0 && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_21__.Typography, {
                        py: 6,
                        variant: "body2",
                        align: "center",
                        children: "\uD83D\uDE14 No vouchers found."
                    }),
                    isLoading && items.length <= 0 && /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material_Box__WEBPACK_IMPORTED_MODULE_7__["default"], {
                        py: 5,
                        sx: {
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center",
                            justifyContent: "center"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_21__.CircularProgress, {
                                size: 20
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_21__.Typography, {
                                py: 1,
                                variant: "body2",
                                align: "center",
                                children: "Loading"
                            })
                        ]
                    })
                ]
            })
        })
    });
};
VoucherListTable.propTypes = {
    count: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().number),
    items: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().array),
    onDeselectAll: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    onDeselectOne: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    onPageChange: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    onRowsPerPageChange: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    onSelect: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    onSelectAll: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().func),
    page: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().number),
    rowsPerPage: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().number),
    selected: (prop_types__WEBPACK_IMPORTED_MODULE_22___default().array)
};


/***/ }),

/***/ 867644:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Kh": () => (/* binding */ getLabelText),
/* harmony export */   "p8": () => (/* binding */ labels)
/* harmony export */ });
/* unused harmony exports VOUCHER_TYPES, VOUCHER_STATUS */
const VOUCHER_TYPES = {
    "1": {
        name: "Round of golf"
    },
    "2": {
        name: "Round of mini golf"
    },
    "3": {
        name: "Bucket of range balls"
    },
    "6": {
        name: "Skillest voucher"
    },
    "7": {
        name: "X-Golf $10 Credit voucher"
    },
    "8": {
        name: "X-Golf $25 Credit voucher"
    },
    "9": {
        name: "X-Golf $50 Credit voucher"
    },
    "10": {
        name: "X-Golf $75 Credit voucher"
    },
    undefined: {
        name: "Error"
    }
};
const VOUCHER_STATUS = {
    "1": {
        name: "Pending"
    },
    "2": {
        name: "Verified"
    },
    "3": {
        name: "Cancelled"
    },
    "6": {
        name: "Expired"
    },
    undefined: {
        name: "Error"
    }
};
const labels = {
    0: "No rating given",
    1: "Very bad",
    2: "Negative",
    3: "Average",
    4: "Great",
    5: "Brilliant"
};
function getLabelText(value) {
    return `${value} Star${value !== 1 ? "s" : ""}, ${labels[value]}`;
}


/***/ }),

/***/ 200490:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "_": () => (/* binding */ fetcher)
/* harmony export */ });
/* harmony import */ var _jwt__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(205200);
// import { STORAGE_KEY } from "src/contexts/auth/auth-provider";

const fetcher = (url)=>{
    const accessToken = window.localStorage.getItem("accessToken");
    const decodedToken = (0,_jwt__WEBPACK_IMPORTED_MODULE_0__/* .decode */ .Jx)(String(accessToken));
    return fetch(url, {
        headers: {
            Authorization: `Bearer ${decodedToken.token}`
        }
    }).then((res)=>res.json()).catch((err)=>{
        throw err;
    });
};


/***/ }),

/***/ 300883:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,3380,4755,6609,4609,5055,9894,4971,1368,3580,4714,4786,3595,3194,4292,4371,5878,347,7680,95,9494,2302,4368,1734,717,5708,2235], () => (__webpack_exec__(257243)));
module.exports = __webpack_exports__;

})();