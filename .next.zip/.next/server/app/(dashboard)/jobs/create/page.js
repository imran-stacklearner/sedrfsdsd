(() => {
var exports = {};
exports.id = 8927;
exports.ids = [8927];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 325442:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'jobs',
        {
        children: [
        'create',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 964583, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/jobs/create/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/jobs/create/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/jobs/create/page"
  

/***/ }),

/***/ 411722:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 861998))

/***/ }),

/***/ 861998:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Check.js
var Check = __webpack_require__(756427);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Step/index.js
var Step = __webpack_require__(82538);
var Step_default = /*#__PURE__*/__webpack_require__.n(Step);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/StepContent/index.js
var StepContent = __webpack_require__(685811);
var StepContent_default = /*#__PURE__*/__webpack_require__.n(StepContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/StepLabel/index.js
var StepLabel = __webpack_require__(906827);
var StepLabel_default = /*#__PURE__*/__webpack_require__.n(StepLabel);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stepper/index.js
var Stepper = __webpack_require__(736410);
var Stepper_default = /*#__PURE__*/__webpack_require__.n(Stepper);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ArrowRight.js
var ArrowRight = __webpack_require__(394284);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Radio/index.js
var Radio = __webpack_require__(307685);
var Radio_default = /*#__PURE__*/__webpack_require__.n(Radio);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/job-category-step.tsx










const categoryOptions = [
    {
        description: "Best for small, friendly-pocket projects",
        title: "Freelancers",
        value: "freelancers"
    },
    {
        description: "Limited-time projects with highly experienced individuals",
        title: "Contractor",
        value: "contractor"
    },
    {
        description: "Unlimited term contracts",
        title: "Employees",
        value: "employees"
    }
];
const JobCategoryStep = (props)=>{
    const { onBack , onNext , ...other } = props;
    const [category, setCategory] = (0,react_.useState)(categoryOptions[1].value);
    const handleCategoryChange = (0,react_.useCallback)((category)=>{
        setCategory(category);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 3,
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "h6",
                    children: "I’m looking for..."
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                spacing: 2,
                children: categoryOptions.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                        sx: {
                            alignItems: "center",
                            cursor: "pointer",
                            display: "flex",
                            p: 2,
                            ...category === option.value && {
                                backgroundColor: "primary.alpha12",
                                boxShadow: (theme)=>`${theme.palette.primary.main} 0 0 0 1px`
                            }
                        },
                        onClick: ()=>handleCategoryChange(option.value),
                        variant: "outlined",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            direction: "row",
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Radio_default()), {
                                    checked: category === option.value,
                                    color: "primary"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle1",
                                            children: option.title
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: option.description
                                        })
                                    ]
                                })
                            ]
                        })
                    }, option.value))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                    endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                    }),
                    onClick: onNext,
                    variant: "contained",
                    children: "Continue"
                })
            })
        ]
    });
};
JobCategoryStep.propTypes = {
    onBack: (prop_types_default()).func,
    onNext: (prop_types_default()).func
};

// EXTERNAL MODULE: ./src/components/quill-editor.tsx
var quill_editor = __webpack_require__(354131);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/job-description-step.tsx









const JobDescriptionStep = (props)=>{
    const { onBack , onNext , ...other } = props;
    const [content, setContent] = (0,react_.useState)("");
    const handleContentChange = (0,react_.useCallback)((value)=>{
        setContent(value);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 3,
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "h6",
                    children: "How would you describe the job post?"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(quill_editor/* QuillEditor */.B, {
                onChange: handleContentChange,
                placeholder: "Write something",
                sx: {
                    height: 400
                },
                value: content
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                spacing: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                        }),
                        onClick: onNext,
                        variant: "contained",
                        children: "Create Job"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        color: "inherit",
                        onClick: onBack,
                        children: "Back"
                    })
                ]
            })
        ]
    });
};
JobDescriptionStep.propTypes = {
    onBack: (prop_types_default()).func,
    onNext: (prop_types_default()).func
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Chip/index.js
var Chip = __webpack_require__(829553);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/InputAdornment/index.js
var InputAdornment = __webpack_require__(79150);
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TextField/index.js
var TextField = __webpack_require__(28379);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField);
// EXTERNAL MODULE: ./node_modules/@mui/x-date-pickers/node/MobileDatePicker/index.js
var MobileDatePicker = __webpack_require__(123595);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/job-details-step.tsx












const JobDetailsStep = (props)=>{
    const { onBack , onNext , ...other } = props;
    const [tag, setTag] = (0,react_.useState)("");
    const [tags, setTags] = (0,react_.useState)([]);
    const [startDate, setStartDate] = (0,react_.useState)(new Date("2022-09-22T11:41:50"));
    const [endDate, setEndDate] = (0,react_.useState)(new Date("2023-01-11T12:41:50"));
    const handleStartDateChange = (0,react_.useCallback)((date)=>{
        setStartDate(date);
    }, []);
    const handleEndDateChange = (0,react_.useCallback)((date)=>{
        setEndDate(date);
    }, []);
    const handleTagAdd = (0,react_.useCallback)((tag)=>{
        setTags((prevState)=>{
            return [
                ...prevState,
                tag
            ];
        });
    }, []);
    const handleTagDelete = (0,react_.useCallback)((tag)=>{
        setTags((prevState)=>{
            return prevState.filter((t)=>t !== tag);
        });
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 3,
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "h6",
                    children: "What is the job about?"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                spacing: 3,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                        fullWidth: true,
                        label: "Job Title",
                        name: "jobTitle",
                        placeholder: "e.g Salesforce Analyst"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                        fullWidth: true,
                        InputProps: {
                            endAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                position: "end",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    color: "inherit",
                                    sx: {
                                        ml: 2
                                    },
                                    onClick: ()=>{
                                        if (!tag) {
                                            return;
                                        }
                                        handleTagAdd(tag);
                                        setTag("");
                                    },
                                    children: "Add"
                                })
                            })
                        },
                        label: "Tags",
                        name: "tags",
                        onChange: (event)=>setTag(event.target.value),
                        value: tag
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        flexWrap: "wrap",
                        spacing: 1,
                        children: tags.map((tag, index)=>/*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                                label: tag,
                                onDelete: ()=>handleTagDelete(tag),
                                variant: "outlined"
                            }, index))
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "h6",
                    children: "When is the project starting?"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                spacing: 3,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(MobileDatePicker.MobileDatePicker, {
                        label: "Start Date",
                        format: "MM/dd/yyyy",
                        value: startDate,
                        onChange: handleStartDateChange
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(MobileDatePicker.MobileDatePicker, {
                        label: "End Date",
                        format: "MM/dd/yyyy",
                        value: endDate,
                        onChange: handleEndDateChange
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                spacing: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                        }),
                        onClick: onNext,
                        variant: "contained",
                        children: "Continue"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        color: "inherit",
                        onClick: onBack,
                        children: "Back"
                    })
                ]
            })
        ]
    });
};
JobDetailsStep.propTypes = {
    onBack: (prop_types_default()).func,
    onNext: (prop_types_default()).func
};

;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/job-preview.tsx








const JobPreview = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 2,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                        sx: {
                            backgroundColor: "success.main",
                            color: "success.contrastText",
                            height: 40,
                            width: 40
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Check/* default */.Z, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "h6",
                        sx: {
                            mt: 2
                        },
                        children: "All done!"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        color: "text.secondary",
                        variant: "body2",
                        children: "Here’s a preview of your newly created job"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                variant: "outlined",
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    flexWrap: "wrap",
                    justifyContent: "space-between",
                    sx: {
                        px: 2,
                        py: 1.5
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "subtitle1",
                                    children: "Senior Backend Engineer"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "caption",
                                    children: "Remote possible • $150k - $210K"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "caption",
                                    children: "1 minute ago"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    size: "small",
                                    children: "Apply"
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });

;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/job-create-form.tsx















const StepIcon = (props)=>{
    const { active , completed , icon  } = props;
    const highlight = active || completed;
    return /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
        sx: {
            height: 40,
            width: 40,
            ...highlight && {
                backgroundColor: "primary.main",
                color: "primary.contrastText"
            }
        },
        variant: "rounded",
        children: completed ? /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
            children: /*#__PURE__*/ jsx_runtime_.jsx(Check/* default */.Z, {})
        }) : icon
    });
};
StepIcon.propTypes = {
    active: (prop_types_default()).bool,
    completed: (prop_types_default()).bool,
    icon: (prop_types_default()).node.isRequired
};
const JobCreateForm = ()=>{
    const [activeStep, setActiveStep] = (0,react_.useState)(0);
    const [isComplete, setIsComplete] = (0,react_.useState)(false);
    const handleNext = (0,react_.useCallback)(()=>{
        setActiveStep((prevState)=>prevState + 1);
    }, []);
    const handleBack = (0,react_.useCallback)(()=>{
        setActiveStep((prevState)=>prevState - 1);
    }, []);
    const handleComplete = (0,react_.useCallback)(()=>{
        setIsComplete(true);
    }, []);
    const steps = (0,react_.useMemo)(()=>{
        return [
            {
                label: "Category",
                content: /*#__PURE__*/ jsx_runtime_.jsx(JobCategoryStep, {
                    onBack: handleBack,
                    onNext: handleNext
                })
            },
            {
                label: "Job Details",
                content: /*#__PURE__*/ jsx_runtime_.jsx(JobDetailsStep, {
                    onBack: handleBack,
                    onNext: handleNext
                })
            },
            {
                label: "Description",
                content: /*#__PURE__*/ jsx_runtime_.jsx(JobDescriptionStep, {
                    onBack: handleBack,
                    onNext: handleComplete
                })
            }
        ];
    }, [
        handleBack,
        handleNext,
        handleComplete
    ]);
    if (isComplete) {
        return /*#__PURE__*/ jsx_runtime_.jsx(JobPreview, {});
    }
    return /*#__PURE__*/ jsx_runtime_.jsx((Stepper_default()), {
        activeStep: activeStep,
        orientation: "vertical",
        sx: {
            "& .MuiStepConnector-line": {
                borderLeftColor: "divider",
                borderLeftWidth: 2,
                ml: 1
            }
        },
        children: steps.map((step, index)=>{
            const isCurrentStep = activeStep === index;
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Step_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((StepLabel_default()), {
                        StepIconComponent: StepIcon,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            sx: {
                                ml: 2
                            },
                            variant: "overline",
                            children: step.label
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((StepContent_default()), {
                        sx: {
                            borderLeftColor: "divider",
                            borderLeftWidth: 2,
                            ml: "20px",
                            ...isCurrentStep && {
                                py: 4
                            }
                        },
                        children: step.content
                    })
                ]
            }, step.label);
        })
    });
};

;// CONCATENATED MODULE: ./src/app/(dashboard)/jobs/create/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 







const Page = ()=>{
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: Job Create"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "main",
                sx: {
                    display: "flex",
                    flexGrow: 1
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                    container: true,
                    sx: {
                        flexGrow: 1
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            sm: 4,
                            sx: {
                                backgroundImage: "url(/assets/people-talking.png)",
                                backgroundPosition: "center",
                                backgroundRepeat: "no-repeat",
                                backgroundSize: "cover",
                                display: {
                                    xs: "none",
                                    md: "block"
                                }
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 8,
                            sx: {
                                p: {
                                    xs: 4,
                                    sm: 6,
                                    md: 8
                                }
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                maxWidth: "sm",
                                spacing: 3,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "h4",
                                        children: "Create Job Ad"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(JobCreateForm, {})
                                ]
                            })
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 964583:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/jobs/create/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,9535,3580,4714,3595,4202,7680,95,9494,2302,4131], () => (__webpack_exec__(325442)));
module.exports = __webpack_exports__;

})();