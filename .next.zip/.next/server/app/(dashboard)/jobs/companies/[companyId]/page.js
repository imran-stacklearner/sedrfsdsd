(() => {
var exports = {};
exports.id = 6974;
exports.ids = [6974];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 677282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 701400:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'jobs',
        {
        children: [
        'companies',
        {
        children: [
        '[companyId]',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 452277, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/jobs/companies/[companyId]/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/jobs/companies/[companyId]/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/jobs/companies/[companyId]/page"
  

/***/ }),

/***/ 44575:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 810849))

/***/ }),

/***/ 810849:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ArrowLeft.js
var ArrowLeft = __webpack_require__(627178);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tab/index.js
var Tab = __webpack_require__(189733);
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tabs/index.js
var Tabs = __webpack_require__(790206);
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/api/jobs/index.ts + 1 modules
var jobs = __webpack_require__(290048);
// EXTERNAL MODULE: ./src/components/router-link.tsx
var router_link = __webpack_require__(510079);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-mounted.ts
var use_mounted = __webpack_require__(887408);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/paths.ts
var paths = __webpack_require__(287842);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/Timeline/index.js
var Timeline = __webpack_require__(34029);
var Timeline_default = /*#__PURE__*/__webpack_require__.n(Timeline);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/TimelineConnector/index.js
var TimelineConnector = __webpack_require__(292635);
var TimelineConnector_default = /*#__PURE__*/__webpack_require__.n(TimelineConnector);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/TimelineContent/index.js
var TimelineContent = __webpack_require__(357189);
var TimelineContent_default = /*#__PURE__*/__webpack_require__.n(TimelineContent);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/TimelineDot/index.js
var TimelineDot = __webpack_require__(254977);
var TimelineDot_default = /*#__PURE__*/__webpack_require__.n(TimelineDot);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/TimelineItem/index.js
var TimelineItem = __webpack_require__(375076);
var TimelineItem_default = /*#__PURE__*/__webpack_require__.n(TimelineItem);
// EXTERNAL MODULE: ./node_modules/@mui/lab/node/TimelineSeparator/index.js
var TimelineSeparator = __webpack_require__(63909);
var TimelineSeparator_default = /*#__PURE__*/__webpack_require__.n(TimelineSeparator);
// EXTERNAL MODULE: ./src/utils/get-initials.ts
var get_initials = __webpack_require__(388080);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/company-activity.tsx
















const renderContent = (activity)=>{
    switch(activity.type){
        case "new_job":
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                sx: {
                    alignItems: "center",
                    display: "flex",
                    flexWrap: "wrap"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        sx: {
                            mr: 0.5
                        },
                        variant: "subtitle2",
                        children: activity.author
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        sx: {
                            mr: 0.5
                        },
                        variant: "body2",
                        children: "added a new job"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        color: "primary",
                        variant: "subtitle2",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                            href: "#",
                            children: activity.addedJob
                        })
                    })
                ]
            });
        case "new_team_member":
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                sx: {
                    alignItems: "center",
                    display: "flex",
                    flexWrap: "wrap"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        sx: {
                            mr: 0.5
                        },
                        variant: "subtitle2",
                        children: activity.author
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        sx: {
                            mr: 0.5
                        },
                        variant: "body2",
                        children: "added"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        sx: {
                            mr: 0.5
                        },
                        variant: "subtitle2",
                        children: activity.addedMember
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "body2",
                        children: "as a team member"
                    })
                ]
            });
        case "created":
            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                sx: {
                    alignItems: "center",
                    display: "flex",
                    flexWrap: "wrap"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        sx: {
                            mr: 0.5
                        },
                        variant: "subtitle2",
                        children: activity.author
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        sx: {
                            mr: 0.5
                        },
                        variant: "body2",
                        children: "created"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "subtitle2",
                        children: activity.createdCompany
                    })
                ]
            });
        default:
            return null;
    }
};
const CompanyActivity = (props)=>{
    const { activities =[] , ...other } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 3,
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "h6",
                    children: "Activity"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                spacing: 3,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Timeline_default()), {
                        sx: {
                            p: 0,
                            m: 0
                        },
                        children: activities.map((activity, index)=>{
                            const showConnector = activities.length - 1 > index;
                            const createdAt = (0,date_fns.format)(activity.createdAt, "MMM dd, HH:mm a");
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TimelineItem_default()), {
                                sx: {
                                    "&:before": {
                                        display: "none"
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TimelineSeparator_default()), {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((TimelineDot_default()), {
                                                sx: {
                                                    border: 0,
                                                    p: 0
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                    src: activity.avatar,
                                                    children: (0,get_initials/* getInitials */.Q)(activity.author)
                                                })
                                            }),
                                            showConnector && /*#__PURE__*/ jsx_runtime_.jsx((TimelineConnector_default()), {
                                                sx: {
                                                    minHeight: 30
                                                }
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TimelineContent_default()), {
                                        children: [
                                            renderContent(activity),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "caption",
                                                sx: {
                                                    mt: 1
                                                },
                                                children: createdAt
                                            })
                                        ]
                                    })
                                ]
                            }, activity.id);
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            display: "flex",
                            justifyContent: "center"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            children: "Load more"
                        })
                    })
                ]
            })
        ]
    });
};
CompanyActivity.propTypes = {
    activities: (prop_types_default()).array
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/File04.js
var File04 = __webpack_require__(20116);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Badge/index.js
var Badge = __webpack_require__(382361);
var Badge_default = /*#__PURE__*/__webpack_require__.n(Badge);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardActions/index.js
var CardActions = __webpack_require__(640362);
var CardActions_default = /*#__PURE__*/__webpack_require__.n(CardActions);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardMedia/index.js
var CardMedia = __webpack_require__(823359);
var CardMedia_default = /*#__PURE__*/__webpack_require__.n(CardMedia);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/company-assets.tsx













const CompanyAssets = (props)=>{
    const { assets =[] , ...other } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 3,
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                    variant: "h6",
                    children: [
                        "Assets (",
                        assets.length,
                        ")"
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    display: "grid",
                    gap: 3,
                    gridTemplateColumns: "repeat(2, minmax(0, 180px))"
                },
                children: assets.map((asset)=>{
                    const isPdf = asset.extension === "pdf";
                    const isImage = [
                        "jpg",
                        "jpeg",
                        "png",
                        ""
                    ].includes(asset.extension);
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                        variant: "outlined",
                        children: [
                            isPdf && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    display: "flex",
                                    backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.900" : "neutral.100",
                                    height: 100,
                                    justifyContent: "center",
                                    py: 3
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Badge_default()), {
                                    anchorOrigin: {
                                        horizontal: "right",
                                        vertical: "bottom"
                                    },
                                    badgeContent: "PDF",
                                    color: "primary",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        sx: {
                                            fontSize: 48
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(File04/* default */.Z, {})
                                    })
                                })
                            }),
                            isImage && /*#__PURE__*/ jsx_runtime_.jsx((CardMedia_default()), {
                                image: asset.url,
                                sx: {
                                    height: 100
                                }
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    p: 2
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "subtitle2",
                                        children: asset.fileName
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "caption",
                                        children: asset.size
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                                sx: {
                                    justifyContent: "center"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    color: "inherit",
                                    size: "small",
                                    children: "Download"
                                })
                            })
                        ]
                    }, asset.id);
                })
            })
        ]
    });
};
CompanyAssets.propTypes = {
    assets: (prop_types_default()).array
};

// EXTERNAL MODULE: ./node_modules/react-markdown/lib/react-markdown.js + 124 modules
var react_markdown = __webpack_require__(508115);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ArrowRight.js
var ArrowRight = __webpack_require__(394284);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ImageList/index.js
var ImageList = __webpack_require__(847453);
var ImageList_default = /*#__PURE__*/__webpack_require__.n(ImageList);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ImageListItem/index.js
var ImageListItem = __webpack_require__(801754);
var ImageListItem_default = /*#__PURE__*/__webpack_require__.n(ImageListItem);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
// EXTERNAL MODULE: ./src/sections/dashboard/jobs/company-jobs.tsx
var company_jobs = __webpack_require__(531738);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Chip/index.js
var Chip = __webpack_require__(829553);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/company-member.tsx








const CompanyMember = (props)=>{
    const { member  } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
        sx: {
            borderColor: "divider",
            borderRadius: 1,
            borderStyle: "solid",
            borderWidth: 1,
            px: 3,
            py: 4
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                spacing: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                        src: member.avatar,
                        children: (0,get_initials/* getInitials */.Q)(member.name)
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "subtitle2",
                                children: member.name
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.secondary",
                                variant: "body2",
                                children: member.role
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                alignItems: "center",
                direction: "row",
                flexWrap: "wrap",
                spacing: 1,
                sx: {
                    mt: 2
                },
                children: (member.skills || []).map((skill)=>/*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                        label: skill,
                        size: "small"
                    }, skill))
            })
        ]
    });
};
CompanyMember.propTypes = {
    // @ts-ignore
    member: (prop_types_default()).object.isRequired
};

;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/company-overview.tsx


















const MarkdownWrapper = (0,styles.styled)("div")(({ theme  })=>({
        color: theme.palette.text.secondary,
        fontFamily: theme.typography.fontFamily,
        "& p": {
            fontSize: theme.typography.body2.fontSize,
            lineHeight: theme.typography.body1.lineHeight,
            marginBottom: theme.spacing(2)
        }
    }));
const CompanyOverview = (props)=>{
    const { company , ...other } = props;
    // Limit to 2 members visible
    const members = (company.members || []).slice(0, 2);
    const images = company.images || [];
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "h5",
                    children: company.shortDescription
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    mt: 3
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(MarkdownWrapper, {
                    children: company.description && /*#__PURE__*/ jsx_runtime_.jsx(react_markdown/* ReactMarkdown */.D, {
                        children: company.description
                    })
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((ImageList_default()), {
                cols: 3,
                gap: 24,
                variant: "masonry",
                children: images.map((image, index)=>/*#__PURE__*/ jsx_runtime_.jsx((ImageListItem_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                            alt: `${company.name} gallery`,
                            src: `${image}?w=248&fit=crop&auto=format`,
                            srcSet: `${image}?w=248&fit=crop&auto=format&dpr=2 2x`
                        })
                    }, index))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                flexWrap: "wrap",
                justifyContent: "space-between",
                spacing: 3,
                sx: {
                    mt: 3
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "h6",
                        children: "Jobs"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Link_default()), {
                        color: "inherit",
                        component: router_link/* RouterLink */.r,
                        href: paths/* paths.dashboard.jobs.companies.details */.H.dashboard.jobs.companies.details,
                        variant: "subtitle2",
                        sx: {
                            alignItems: "center",
                            display: "flex"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mr: 1
                                },
                                variant: "subtitle2",
                                children: "Jobs"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    mt: 3
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(company_jobs/* CompanyJobs */.i, {
                    jobs: company.jobs
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                sx: {
                    my: 3
                }
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                flexWrap: "wrap",
                justifyContent: "space-between",
                spacing: 3,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "h6",
                        children: "Members"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Link_default()), {
                        color: "inherit",
                        component: router_link/* RouterLink */.r,
                        href: paths/* paths.dashboard.jobs.companies.details */.H.dashboard.jobs.companies.details,
                        variant: "subtitle2",
                        sx: {
                            alignItems: "center",
                            display: "flex"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                sx: {
                                    mr: 1
                                },
                                variant: "subtitle2",
                                children: "Members"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    mb: -1.5,
                    mt: 1.5,
                    mx: -1.5
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    container: true,
                    spacing: 3,
                    children: members.map((member)=>/*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(CompanyMember, {
                                member: member
                            })
                        }, member.id))
                })
            })
        ]
    });
};
CompanyOverview.propTypes = {
    // @ts-ignore
    company: (prop_types_default()).object.isRequired
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Rating/index.js
var Rating = __webpack_require__(247022);
var Rating_default = /*#__PURE__*/__webpack_require__.n(Rating);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/company-review.tsx










const CompanyReview = (props)=>{
    const { review  } = props;
    const ago = (0,date_fns.formatDistanceStrict)(review.createdAt, new Date(), {
        addSuffix: true
    });
    return /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        variant: "outlined",
        children: /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                spacing: 2,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        spacing: 2,
                        alignItems: {
                            xs: "flex-start",
                            sm: "center"
                        },
                        direction: {
                            xs: "column",
                            sm: "row"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                src: review.avatar,
                                children: (0,get_initials/* getInitials */.Q)(review.author)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                spacing: 1,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "subtitle1",
                                        children: review.title
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                        alignItems: "center",
                                        direction: "row",
                                        divider: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                            children: "•"
                                        }),
                                        flexWrap: "wrap",
                                        spacing: 2,
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                alignItems: "center",
                                                direction: "row",
                                                spacing: 1,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Rating_default()), {
                                                        value: review.rating / 5,
                                                        precision: 0.1,
                                                        readOnly: true,
                                                        max: 1
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                        noWrap: true,
                                                        variant: "subtitle2",
                                                        children: [
                                                            review.rating,
                                                            "/5"
                                                        ]
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                noWrap: true,
                                                variant: "subtitle2",
                                                children: review.author
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                noWrap: true,
                                                variant: "body2",
                                                children: ago
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "body1",
                        children: review.description
                    })
                ]
            })
        })
    });
};
CompanyReview.propTypes = {
    // @ts-ignore
    review: (prop_types_default()).object.isRequired
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/OutlinedInput/index.js
var OutlinedInput = __webpack_require__(877829);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput);
// EXTERNAL MODULE: ./src/hooks/use-mocked-user.ts
var use_mocked_user = __webpack_require__(782851);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/company-review-add.tsx










const CompanyReviewAdd = ()=>{
    const user = (0,use_mocked_user/* useMockedUser */.I)();
    const [rating, setRating] = (0,react_.useState)(null);
    const handleRatingChange = (0,react_.useCallback)((event, newRating)=>{
        setRating(newRating);
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        alignItems: "flex-start",
        direction: "row",
        spacing: 2,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                src: user.avatar,
                children: (0,get_initials/* getInitials */.Q)(user.name)
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                sx: {
                    flexGrow: 1
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                        fullWidth: true,
                        multiline: true,
                        placeholder: "Send your review",
                        rows: 3
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        flexWrap: "wrap",
                        justifyContent: "space-between",
                        spacing: 1,
                        sx: {
                            mt: 3
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Rating_default()), {
                                onChange: handleRatingChange,
                                value: rating
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                variant: "contained",
                                children: "Send Review"
                            })
                        ]
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/company-reviews-summary.tsx







const CompanyReviewsSummary = (props)=>{
    const { averageRating , totalReviews  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        variant: "outlined",
        children: /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: {
                    xs: "flex-start",
                    sm: "center"
                },
                direction: {
                    xs: "column",
                    sm: "row"
                },
                flexWrap: "wrap",
                gap: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "subtitle2",
                        children: "Overall reviews"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        divider: /*#__PURE__*/ jsx_runtime_.jsx("span", {
                            children: "•"
                        }),
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                alignItems: "center",
                                direction: "row",
                                spacing: 1,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Rating_default()), {
                                        value: averageRating / 5,
                                        precision: 0.1,
                                        readOnly: true,
                                        max: 1
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                        noWrap: true,
                                        variant: "subtitle2",
                                        children: [
                                            averageRating,
                                            "/5"
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                color: "text.secondary",
                                variant: "body2",
                                children: [
                                    totalReviews,
                                    " reviews in total"
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};
CompanyReviewsSummary.propTypes = {
    averageRating: (prop_types_default()).number.isRequired,
    totalReviews: (prop_types_default()).number.isRequired
};

;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/company-reviews.tsx









const CompanyReviews = (props)=>{
    const { reviews =[] , averageRating =0 , ...other } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 3,
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "h6",
                    children: "Reviews"
                })
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                spacing: 3,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(CompanyReviewsSummary, {
                        averageRating: averageRating,
                        totalReviews: reviews.length
                    }),
                    reviews.map((review)=>/*#__PURE__*/ jsx_runtime_.jsx(CompanyReview, {
                            review: review
                        }, review.id)),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            display: "flex",
                            justifyContent: "center"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            children: "Load more"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(CompanyReviewAdd, {})
                ]
            })
        ]
    });
};
CompanyReviews.propTypes = {
    reviews: (prop_types_default()).array,
    averageRating: (prop_types_default()).number
};

// EXTERNAL MODULE: ./src/components/property-list.tsx
var property_list = __webpack_require__(982009);
// EXTERNAL MODULE: ./src/components/property-list-item.tsx
var property_list_item = __webpack_require__(925115);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/company-summary.tsx











const CompanySummary = (props)=>{
    const { company , ...other } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        ...other,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    component: "p",
                    sx: {
                        mb: 2
                    },
                    variant: "overline",
                    children: "About"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(property_list/* PropertyList */.c, {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(property_list_item/* PropertyListItem */.c, {
                            align: "vertical",
                            label: "Website",
                            sx: {
                                px: 0,
                                py: 1
                            },
                            value: company.website
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(property_list_item/* PropertyListItem */.c, {
                            align: "vertical",
                            label: "Locations",
                            sx: {
                                px: 0,
                                py: 1
                            },
                            children: (company.locations || []).map((location)=>/*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "body2",
                                    children: location
                                }, location))
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(property_list_item/* PropertyListItem */.c, {
                            align: "vertical",
                            label: "Company size",
                            sx: {
                                px: 0,
                                py: 1
                            },
                            value: company.employees
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                    sx: {
                        my: 2
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    component: "p",
                    sx: {
                        mb: 2
                    },
                    variant: "overline",
                    children: "Founders"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                    spacing: 2,
                    children: (company.founders || []).map((founder)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                    src: founder.avatar,
                                    children: (0,get_initials/* getInitials */.Q)(founder.name)
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: founder.name
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: founder.role
                                        })
                                    ]
                                })
                            ]
                        }, founder.id))
                })
            ]
        })
    });
};
CompanySummary.propTypes = {
    // @ts-ignore
    company: (prop_types_default()).object.isRequired
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Grid/index.js
var Grid = __webpack_require__(889216);
var Grid_default = /*#__PURE__*/__webpack_require__.n(Grid);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/company-team.tsx






const CompanyTeam = (props)=>{
    const { members =[] , ...other } = props;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 3,
        ...other,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                    variant: "h6",
                    children: [
                        "Team (",
                        members.length,
                        ")"
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                    container: true,
                    spacing: 3,
                    children: members.map((member)=>/*#__PURE__*/ jsx_runtime_.jsx((Grid_default()), {
                            item: true,
                            xs: 12,
                            sm: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(CompanyMember, {
                                member: member
                            })
                        }, member.id))
                })
            })
        ]
    });
};
CompanyTeam.propTypes = {
    members: (prop_types_default()).array
};

;// CONCATENATED MODULE: ./src/app/(dashboard)/jobs/companies/[companyId]/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 





























const tabs = [
    {
        label: "Overview",
        value: "overview"
    },
    {
        label: "Reviews",
        value: "reviews"
    },
    {
        label: "Activity",
        value: "activity"
    },
    {
        label: "Team",
        value: "team"
    },
    {
        label: "Assets",
        value: "assets"
    }
];
const useCompany = ()=>{
    const isMounted = (0,use_mounted/* useMounted */.s)();
    const [company, setCompany] = (0,react_.useState)(null);
    const handleCompanyGet = (0,react_.useCallback)(async ()=>{
        try {
            const response = await jobs/* jobsApi.getCompany */.Y.getCompany();
            if (isMounted()) {
                setCompany(response);
            }
        } catch (err) {
            console.error(err);
        }
    }, [
        isMounted
    ]);
    (0,react_.useEffect)(()=>{
        handleCompanyGet();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []);
    return company;
};
const Page = ()=>{
    const company = useCompany();
    const [currentTab, setCurrentTab] = (0,react_.useState)("overview");
    (0,use_page_view/* usePageView */.a)();
    const handleTabsChange = (0,react_.useCallback)((event, value)=>{
        setCurrentTab(value);
    }, []);
    if (!company) {
        return null;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: Company Details"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "main",
                sx: {
                    flexGrow: 1,
                    py: 8
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                    maxWidth: "lg",
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                        container: true,
                        spacing: 4,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Link_default()), {
                                        color: "text.primary",
                                        component: router_link/* RouterLink */.r,
                                        href: paths/* paths.dashboard.jobs.index */.H.dashboard.jobs.index,
                                        sx: {
                                            alignItems: "center",
                                            display: "inline-flex"
                                        },
                                        underline: "hover",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                sx: {
                                                    mr: 1
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowLeft/* default */.Z, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "subtitle2",
                                                children: "Jobs"
                                            })
                                        ]
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                lg: 8,
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                                            disableTypography: true,
                                            title: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                alignItems: "flex-start",
                                                direction: "row",
                                                spacing: 2,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                        src: company.logo,
                                                        variant: "rounded",
                                                        children: (0,get_initials/* getInitials */.Q)(company.name)
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                        spacing: 1,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                variant: "h6",
                                                                children: company.name
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                variant: "body2",
                                                                children: company.shortDescription
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Tabs_default()), {
                                            indicatorColor: "primary",
                                            onChange: handleTabsChange,
                                            scrollButtons: "auto",
                                            sx: {
                                                px: 3
                                            },
                                            textColor: "primary",
                                            value: currentTab,
                                            variant: "scrollable",
                                            children: tabs.map((tab)=>/*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                                                    label: tab.label,
                                                    value: tab.value
                                                }, tab.value))
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                                            children: [
                                                currentTab === "overview" && /*#__PURE__*/ jsx_runtime_.jsx(CompanyOverview, {
                                                    company: company
                                                }),
                                                currentTab === "reviews" && /*#__PURE__*/ jsx_runtime_.jsx(CompanyReviews, {
                                                    reviews: company.reviews || [],
                                                    averageRating: company.averageRating
                                                }),
                                                currentTab === "activity" && /*#__PURE__*/ jsx_runtime_.jsx(CompanyActivity, {
                                                    activities: company.activities || []
                                                }),
                                                currentTab === "team" && /*#__PURE__*/ jsx_runtime_.jsx(CompanyTeam, {
                                                    members: company.members || []
                                                }),
                                                currentTab === "assets" && /*#__PURE__*/ jsx_runtime_.jsx(CompanyAssets, {
                                                    assets: company.assets || []
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                lg: 4,
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CompanySummary, {
                                    company: company
                                })
                            })
                        ]
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 452277:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/jobs/companies/[companyId]/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,3580,8115,3171,8626,7680,95,9494,2302,2851,5754,700], () => (__webpack_exec__(701400)));
module.exports = __webpack_exports__;

})();