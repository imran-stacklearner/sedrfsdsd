(() => {
var exports = {};
exports.id = 4414;
exports.ids = [4414];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 721551:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'jobs',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 457451, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/jobs/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/jobs/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/jobs/page"
  

/***/ }),

/***/ 124161:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 986446))

/***/ }),

/***/ 986446:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronLeft.js
var ChevronLeft = __webpack_require__(459378);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronRight.js
var ChevronRight = __webpack_require__(492382);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/api/jobs/index.ts + 1 modules
var jobs = __webpack_require__(290048);
// EXTERNAL MODULE: ./src/components/router-link.tsx
var router_link = __webpack_require__(510079);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-mounted.ts
var use_mounted = __webpack_require__(887408);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/paths.ts
var paths = __webpack_require__(287842);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/CheckVerified01.js
var CheckVerified01 = __webpack_require__(253700);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Star01.js
var Star01 = __webpack_require__(796756);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Users01.js
var Users01 = __webpack_require__(906668);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./src/utils/get-initials.ts
var get_initials = __webpack_require__(388080);
// EXTERNAL MODULE: ./src/sections/dashboard/jobs/company-jobs.tsx
var company_jobs = __webpack_require__(531738);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/company-card.tsx

















const CompanyCard = (props)=>{
    const { company , ...other } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
        ...other,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "flex-start",
                    spacing: 2,
                    direction: {
                        xs: "column",
                        sm: "row"
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                            component: router_link/* RouterLink */.r,
                            href: paths/* paths.dashboard.jobs.companies.details */.H.dashboard.jobs.companies.details,
                            src: company.logo,
                            variant: "rounded",
                            children: (0,get_initials/* getInitials */.Q)(company.name)
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                    color: "text.primary",
                                    component: router_link/* RouterLink */.r,
                                    href: paths/* paths.dashboard.jobs.companies.details */.H.dashboard.jobs.companies.details,
                                    variant: "h6",
                                    children: company.name
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "body2",
                                    children: company.shortDescription
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    flexWrap: "wrap",
                                    spacing: 3,
                                    sx: {
                                        mt: 1
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "center",
                                            spacing: 1,
                                            direction: "row",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    color: "action",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Users01/* default */.Z, {})
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    color: "text.secondary",
                                                    noWrap: true,
                                                    variant: "overline",
                                                    children: company.employees
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "center",
                                            spacing: 1,
                                            direction: "row",
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    color: "action",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Star01/* default */.Z, {})
                                                }),
                                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                    color: "text.secondary",
                                                    noWrap: true,
                                                    variant: "overline",
                                                    children: [
                                                        company.averageRating,
                                                        "/5"
                                                    ]
                                                })
                                            ]
                                        }),
                                        company.isVerified && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "center",
                                            direction: "row",
                                            spacing: 0.5,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    sx: {
                                                        color: "background.paper",
                                                        "& path": {
                                                            fill: (theme)=>theme.palette.success.main,
                                                            fillOpacity: 1
                                                        }
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(CheckVerified01/* default */.Z, {})
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    color: "success",
                                                    noWrap: true,
                                                    variant: "overline",
                                                    children: "Verified"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        mt: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(company_jobs/* CompanyJobs */.i, {
                        jobs: company.jobs
                    })
                })
            ]
        })
    });
};
CompanyCard.propTypes = {
    // @ts-ignore
    company: (prop_types_default()).object.isRequired
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/SearchMd.js
var SearchMd = __webpack_require__(219057);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Checkbox/index.js
var Checkbox = __webpack_require__(63754);
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Chip/index.js
var Chip = __webpack_require__(829553);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/FormControlLabel/index.js
var FormControlLabel = __webpack_require__(128353);
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Input/index.js
var Input = __webpack_require__(378382);
var Input_default = /*#__PURE__*/__webpack_require__.n(Input);
// EXTERNAL MODULE: ./src/components/multi-select.tsx
var multi_select = __webpack_require__(37155);
;// CONCATENATED MODULE: ./src/sections/dashboard/jobs/job-list-search.tsx














const typeOptions = [
    {
        label: "Freelance",
        value: "freelance"
    },
    {
        label: "Full Time",
        value: "fullTime"
    },
    {
        label: "Part Time",
        value: "partTime"
    },
    {
        label: "Internship",
        value: "internship"
    }
];
const levelOptions = [
    {
        label: "Novice",
        value: "novice"
    },
    {
        label: "Expert",
        value: "expert"
    }
];
const locationOptions = [
    {
        label: "Africa",
        value: "africa"
    },
    {
        label: "Asia",
        value: "asia"
    },
    {
        label: "Europe",
        value: "europe"
    },
    {
        label: "North America",
        value: "northAmerica"
    },
    {
        label: "South America",
        value: "southAmerica"
    }
];
const roleOptions = [
    {
        label: "Web Developer",
        value: "webDeveloper"
    },
    {
        label: "Android Developer",
        value: "androidDeveloper"
    },
    {
        label: "iOS Developer",
        value: "iosDeveloper"
    }
];
const JobListSearch = (props)=>{
    const chips = (0,react_.useMemo)(()=>[
            {
                label: "Type",
                field: "type",
                value: "freelance",
                displayValue: "Freelance"
            },
            {
                label: "Type",
                field: "type",
                value: "internship",
                displayValue: "Internship"
            },
            {
                label: "Level",
                field: "level",
                value: "novice",
                displayValue: "Novice"
            },
            {
                label: "Location",
                field: "location",
                value: "asia",
                displayValue: "Asia"
            },
            {
                label: "Role",
                field: "role",
                value: "webDeveloper",
                displayValue: "Web Developer"
            }
        ], []);
    // We memoize this part to prevent re-render issues
    const typeValues = (0,react_.useMemo)(()=>chips.filter((chip)=>chip.field === "type").map((chip)=>chip.value), [
        chips
    ]);
    const levelValues = (0,react_.useMemo)(()=>chips.filter((chip)=>chip.field === "level").map((chip)=>chip.value), [
        chips
    ]);
    const locationValues = (0,react_.useMemo)(()=>chips.filter((chip)=>chip.field === "location").map((chip)=>chip.value), [
        chips
    ]);
    const roleValues = (0,react_.useMemo)(()=>chips.filter((chip)=>chip.field === "role").map((chip)=>chip.value), [
        chips
    ]);
    const showChips = chips.length > 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                spacing: 2,
                sx: {
                    p: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SearchMd/* default */.Z, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            flexGrow: 1
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                            disableUnderline: true,
                            fullWidth: true,
                            placeholder: "Enter a keyword"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            showChips ? /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                alignItems: "center",
                direction: "row",
                flexWrap: "wrap",
                gap: 1,
                sx: {
                    p: 2
                },
                children: chips.map((chip, index)=>/*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                        label: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                alignItems: "center",
                                display: "flex",
                                "& span": {
                                    fontWeight: 600
                                }
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                        children: chip.label
                                    }),
                                    ":",
                                    " ",
                                    chip.displayValue || chip.value
                                ]
                            })
                        }),
                        onDelete: ()=>{},
                        variant: "outlined"
                    }, index))
            }) : /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    p: 2.5
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    variant: "subtitle2",
                    children: "No filters applied"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                flexWrap: "wrap",
                spacing: 2,
                sx: {
                    p: 1
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(multi_select/* MultiSelect */.N, {
                        label: "Type",
                        options: typeOptions,
                        value: typeValues
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(multi_select/* MultiSelect */.N, {
                        label: "Level",
                        options: levelOptions,
                        value: levelValues
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(multi_select/* MultiSelect */.N, {
                        label: "Location",
                        options: locationOptions,
                        value: locationValues
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(multi_select/* MultiSelect */.N, {
                        label: "Role",
                        options: roleOptions,
                        value: roleValues
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            flexGrow: 1
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                        control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                            defaultChecked: true
                        }),
                        label: "In network"
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/app/(dashboard)/jobs/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 



















const useCompanies = ()=>{
    const isMounted = (0,use_mounted/* useMounted */.s)();
    const [companies, setCompanies] = (0,react_.useState)([]);
    const handleCompaniesGet = (0,react_.useCallback)(async ()=>{
        try {
            const response = await jobs/* jobsApi.getCompanies */.Y.getCompanies();
            if (isMounted()) {
                setCompanies(response);
            }
        } catch (err) {
            console.error(err);
        }
    }, [
        isMounted
    ]);
    (0,react_.useEffect)(()=>{
        handleCompaniesGet();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []);
    return companies;
};
const Page = ()=>{
    const companies = useCompanies();
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: Job Browse"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "main",
                sx: {
                    flexGrow: 1,
                    py: 8
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
                    maxWidth: "lg",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                            alignItems: "center",
                            container: true,
                            sx: {
                                backgroundColor: "neutral.900",
                                borderRadius: 1,
                                color: "common.white",
                                px: 4,
                                py: 8
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                                    xs: 12,
                                    sm: 7,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "inherit",
                                            variant: "h3",
                                            children: "Reach 50k+ potential candidates."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "neutral.500",
                                            sx: {
                                                mt: 2
                                            },
                                            variant: "body1",
                                            children: "Post your job today for free. Promotions start at $99."
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                            color: "primary",
                                            component: router_link/* RouterLink */.r,
                                            href: paths/* paths.dashboard.jobs.create */.H.dashboard.jobs.create,
                                            size: "large",
                                            sx: {
                                                mt: 3
                                            },
                                            variant: "contained",
                                            children: "Post a job"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    sm: 5,
                                    sx: {
                                        display: {
                                            xs: "none",
                                            sm: "flex"
                                        },
                                        justifyContent: "center"
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                        src: "/assets/iconly/iconly-glass-shield.svg"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 4,
                            sx: {
                                mt: 4
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(JobListSearch, {}),
                                companies.map((company)=>/*#__PURE__*/ jsx_runtime_.jsx(CompanyCard, {
                                        company: company
                                    }, company.id)),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    justifyContent: "flex-end",
                                    spacing: 2,
                                    sx: {
                                        px: 3,
                                        py: 2
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                            disabled: true,
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                fontSize: "small",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronLeft/* default */.Z, {})
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                fontSize: "small",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronRight/* default */.Z, {})
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 457451:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/jobs/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,2765,6668,6438,7680,95,9494,2302,5754,7155], () => (__webpack_exec__(721551)));
module.exports = __webpack_exports__;

})();