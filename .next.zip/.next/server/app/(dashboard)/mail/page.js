(() => {
var exports = {};
exports.id = 5546;
exports.ids = [5546];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 677282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 400896:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        '(dashboard)',
        {
        children: [
        'mail',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 137480, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/mail/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 361679)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/mail/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/(dashboard)/mail/page"
  

/***/ }),

/***/ 212586:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 923258))

/***/ }),

/***/ 923258:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/useMediaQuery/index.js
var useMediaQuery = __webpack_require__(975983);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/hooks/use-search-params.ts
var use_search_params = __webpack_require__(82365);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Attachment01.js
var Attachment01 = __webpack_require__(517163);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Expand01.js
var Expand01 = __webpack_require__(471600);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Image01.js
var Image01 = __webpack_require__(97484);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Minimize01.js
var Minimize01 = __webpack_require__(265591);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/X.js
var X = __webpack_require__(180501);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Backdrop/index.js
var Backdrop = __webpack_require__(62788);
var Backdrop_default = /*#__PURE__*/__webpack_require__.n(Backdrop);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Input/index.js
var Input = __webpack_require__(378382);
var Input_default = /*#__PURE__*/__webpack_require__.n(Input);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Paper/index.js
var Paper = __webpack_require__(427561);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Portal/index.js
var Portal = __webpack_require__(257636);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tooltip/index.js
var Tooltip = __webpack_require__(556020);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/components/quill-editor.tsx
var quill_editor = __webpack_require__(354131);
;// CONCATENATED MODULE: ./src/sections/dashboard/mail/mail-composer.tsx





















const MailComposer = (props)=>{
    const { maximize =false , message ="" , onClose , onMaximize , onMessageChange , onMinimize , onSubjectChange , onToChange , open =false , subject ="" , to =""  } = props;
    const handleSubjectChange = (0,react_.useCallback)((event)=>{
        onSubjectChange?.(event.target.value);
    }, [
        onSubjectChange
    ]);
    const handleToChange = (0,react_.useCallback)((event)=>{
        onToChange?.(event.target.value);
    }, [
        onToChange
    ]);
    if (!open) {
        return null;
    }
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Portal["default"], {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx((Backdrop_default()), {
                open: maximize
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Paper_default()), {
                sx: {
                    bottom: 0,
                    display: "flex",
                    flexDirection: "column",
                    margin: 3,
                    maxHeight: (theme)=>`calc(100% - ${theme.spacing(6)})`,
                    maxWidth: (theme)=>`calc(100% - ${theme.spacing(6)})`,
                    minHeight: 500,
                    outline: "none",
                    position: "fixed",
                    right: 0,
                    width: 600,
                    zIndex: 1400,
                    overflow: "hidden",
                    ...maximize && {
                        borderRadius: 0,
                        height: "100%",
                        margin: 0,
                        maxHeight: "100%",
                        maxWidth: "100%",
                        width: "100%"
                    }
                },
                elevation: 12,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                        sx: {
                            alignItems: "center",
                            display: "flex",
                            px: 2,
                            py: 1
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "h6",
                                children: "New Message"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    flexGrow: 1
                                }
                            }),
                            maximize ? /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: onMinimize,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Minimize01/* default */.Z, {})
                                })
                            }) : /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: onMaximize,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Expand01/* default */.Z, {})
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                onClick: onClose,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(X/* default */.Z, {})
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                        disableUnderline: true,
                        fullWidth: true,
                        onChange: handleToChange,
                        placeholder: "To",
                        sx: {
                            p: 1,
                            borderBottom: 1,
                            borderColor: "divider"
                        },
                        value: to
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                        disableUnderline: true,
                        fullWidth: true,
                        onChange: handleSubjectChange,
                        placeholder: "Subject",
                        sx: {
                            p: 1,
                            borderBottom: 1,
                            borderColor: "divider"
                        },
                        value: subject
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(quill_editor/* QuillEditor */.B, {
                        onChange: onMessageChange,
                        placeholder: "Leave a message",
                        sx: {
                            border: "none",
                            flexGrow: 1
                        },
                        value: message
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        justifyContent: "space-between",
                        spacing: 3,
                        sx: {
                            p: 2
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                alignItems: "center",
                                direction: "row",
                                spacing: 1,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                        title: "Attach image",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                            size: "small",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Image01/* default */.Z, {})
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                        title: "Attach file",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                            size: "small",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Attachment01/* default */.Z, {})
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    variant: "contained",
                                    children: "Send"
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
MailComposer.propTypes = {
    maximize: (prop_types_default()).bool,
    message: (prop_types_default()).string,
    onClose: (prop_types_default()).func,
    onMaximize: (prop_types_default()).func,
    onMessageChange: (prop_types_default()).func,
    onMinimize: (prop_types_default()).func,
    onSubjectChange: (prop_types_default()).func,
    onToChange: (prop_types_default()).func,
    open: (prop_types_default()).bool,
    subject: (prop_types_default()).string,
    to: (prop_types_default()).string
};

// EXTERNAL MODULE: ./src/paths.ts
var paths = __webpack_require__(287842);
// EXTERNAL MODULE: ./src/store/index.ts + 2 modules
var store = __webpack_require__(754835);
// EXTERNAL MODULE: ./src/utils/deep-copy.ts
var deep_copy = __webpack_require__(846447);
;// CONCATENATED MODULE: ./src/api/mail/data.ts
const now = new Date();
const labels = [
    {
        id: "all",
        name: "All Mail",
        type: "system"
    },
    {
        id: "inbox",
        name: "Inbox",
        totalCount: 0,
        type: "system",
        unreadCount: 1
    },
    {
        id: "sent",
        name: "Sent",
        totalCount: 0,
        type: "system",
        unreadCount: 0
    },
    {
        id: "drafts",
        name: "Drafts",
        totalCount: 0,
        type: "system",
        unreadCount: 0
    },
    {
        id: "trash",
        name: "Trash",
        totalCount: 1,
        type: "system",
        unreadCount: 0
    },
    {
        id: "spam",
        name: "Spam",
        totalCount: 0,
        type: "system",
        unreadCount: 0
    },
    {
        id: "important",
        name: "Important",
        totalCount: 1,
        type: "system",
        unreadCount: 0
    },
    {
        id: "starred",
        name: "Starred",
        totalCount: 1,
        type: "system",
        unreadCount: 1
    },
    {
        id: "work",
        color: "#43A048",
        name: "Work",
        totalCount: 1,
        type: "custom",
        unreadCount: 0
    },
    {
        id: "business",
        color: "#1E88E5",
        name: "Business",
        totalCount: 2,
        type: "custom",
        unreadCount: 1
    },
    {
        id: "personal",
        color: "#FB8A00",
        name: "Personal",
        totalCount: 1,
        type: "custom",
        unreadCount: 0
    }
];
const emails = [
    {
        id: "5e86bcc3e1b53b6365d71638",
        attachments: [
            {
                id: "945d887e97f480359d3f591f",
                name: "working-sketch.png",
                size: "128.5Kb",
                type: "image",
                url: "/assets/covers/abstract-1-4x4-small.png"
            },
            {
                id: "09223c93e60f815fdce487af",
                name: "summer-vouchers.pdf",
                size: "782.3Kb",
                type: "file",
                url: "#"
            },
            {
                id: "165adb24c7b6a2e9aebba766",
                name: "desktop-coffee.png",
                size: "568.2Kb",
                type: "image",
                url: "/assets/covers/minimal-1-4x4-small.png"
            }
        ],
        createdAt: now.getTime(),
        folder: "inbox",
        from: {
            avatar: "/assets/avatars/avatar-marcus-finn.png",
            email: "marcus.finn@devias.io",
            name: "Marcus Finn"
        },
        isImportant: true,
        isStarred: false,
        isUnread: true,
        labelIds: [
            "work",
            "business"
        ],
        message: `
Hi Matt, I saw your work on instagram and would be interested in getting a quote for Logo and slider

Integer velit massa, pharetra sed lacus eu, pulvinar faucibus ex. Ut pretium ex id turpis elementum, aliquam accumsan enim sollicitudin. Sed nec consectetur lorem, ac ullamcorper augue. Suspendisse tempus ligula suscipit finibus vehicula. Morbi viverra finibus lectus, egestas dictum mi mollis nec. Proin eget vehicula eros, sit amet molestie ipsum. Morbi feugiat, elit non placerat fringilla, leo risus tristique felis, sollicitudin tristique nibh arcu nec arcu. Maecenas vel turpis nibh. Etiam in lectus quis felis facilisis dictum. Morbi id vehicula lectus, vel imperdiet dolor. Phasellus consequat tempor tellus, quis placerat quam posuere eget. Mauris blandit, nisl eu sollicitudin tincidunt, tellus diam accumsan arcu, vel pharetra lectus est nec nisi. In sem dolor, mollis sed risus eu, mattis dictum lectus. Suspendisse urna est, finibus et urna non, tincidunt placerat eros.

Donec viverra ipsum id auctor rutrum. Morbi consequat a nunc non interdum. Nulla accumsan eget felis a dictum. Cras rhoncus tortor eget velit fringilla suscipit. Donec quis arcu eu nibh aliquet auctor eget fringilla felis. Sed commodo efficitur massa. Proin maximus elit in suscipit laoreet. Integer pretium arcu ac mauris ullamcorper auctor. Vivamus tincidunt lacus eget purus feugiat tincidunt. Etiam feugiat gravida ullamcorper. Pellentesque cursus vehicula lectus et consectetur. Orci varius natoque penatibus et magnis dis parturient montes, nascetur ridiculus mus. Nam ligula risus, congue eu pellentesque id, volutpat aliquam arcu. Donec efficitur ipsum id neque rhoncus viverra. Vestibulum hendrerit et eros eu bibendum.


Kind regards,

Marcus Finn
    `,
        subject: "Website redesign. Interested in collaboration",
        to: [
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                email: "anika.visser@devias.io",
                name: "Anika Visser"
            }
        ]
    },
    {
        id: "5e86bcbd8406cd3055f2b6c8",
        createdAt: now.getTime(),
        folder: "spam",
        from: {
            avatar: "/assets/avatars/avatar-miron-vitold.png",
            email: "miron.vitold@devias.io",
            name: "Miron Vitold"
        },
        isImportant: false,
        isStarred: true,
        isUnread: false,
        labelIds: [],
        message: `
Hey, nice projects! I really liked the one in react. What's your quote on kinda similar project?
    `,
        subject: "Amazing work",
        to: [
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                email: "anika.visser@devias.io",
                name: "Anika Visser"
            }
        ]
    },
    {
        id: "5e86bcb9fee1ec12453fa13b",
        createdAt: now.getTime(),
        folder: "inbox",
        from: {
            avatar: "/assets/avatars/avatar-penjani-inyene.png",
            email: "penjani.inyene@devias.io",
            name: "Penjani Inyene"
        },
        isImportant: false,
        isStarred: false,
        isUnread: false,
        labelIds: [
            "business"
        ],
        message: `
Dear Anika, Your flight is coming up soon. Please don’t forget to check in for your scheduled flight.
    `,
        subject: "Flight reminder",
        to: [
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                email: "anika.visser@devias.io",
                name: "Anika Visser"
            }
        ]
    },
    {
        id: "5e86bcb5575181a5e527e24f",
        createdAt: now.getTime(),
        folder: "trash",
        from: {
            avatar: "/assets/avatars/avatar-carson-darrin.png",
            email: "carson.darrin@devias.io",
            name: "Carson Darrin"
        },
        isImportant: false,
        isStarred: false,
        isUnread: true,
        labelIds: [
            "personal"
        ],
        message: `
My market leading client has another fantastic opportunity for an experienced Software Developer to join them on a heavily remote basis
    `,
        subject: "Possible candidates for the position",
        to: [
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                email: "anika.visser@devias.io",
                name: "Anika Visser"
            }
        ]
    }
];

;// CONCATENATED MODULE: ./src/api/mail/index.ts


class MailApi {
    getLabels(request) {
        return Promise.resolve((0,deep_copy/* deepCopy */.p)(labels));
    }
    getEmails(request = {}) {
        const { label  } = request;
        return new Promise((resolve, reject)=>{
            try {
                // Initially we make a copy of all emails.
                // On a real server this will be different since there will be a real DB query.
                const clonedEmails = (0,deep_copy/* deepCopy */.p)(emails);
                let filteredEmails = [];
                // Get all user custom labels
                const customLabels = labels.reduce((acc, label)=>{
                    if (label.type === "custom") {
                        acc.push(label.id);
                    }
                    return acc;
                }, []);
                if (label && customLabels.includes(label)) {
                    filteredEmails = clonedEmails.filter((email)=>email.labelIds.includes(label));
                } else {
                    switch(label){
                        case undefined:
                        case "inbox":
                            filteredEmails = clonedEmails.filter((email)=>email.folder === "inbox");
                            break;
                        case "all":
                            filteredEmails = [
                                ...clonedEmails
                            ];
                            break;
                        case "sent":
                        case "trash":
                            filteredEmails = clonedEmails.filter((email)=>email.folder === label);
                            break;
                        case "starred":
                            filteredEmails = clonedEmails.filter((email)=>email.isStarred);
                            break;
                        case "important":
                            filteredEmails = clonedEmails.filter((email)=>email.isImportant);
                            break;
                        default:
                    }
                }
                resolve(filteredEmails);
            } catch (err) {
                console.error("[Mail Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
    getEmail(request) {
        const { emailId  } = request;
        return new Promise((resolve, reject)=>{
            try {
                const clonedEmails = (0,deep_copy/* deepCopy */.p)(emails);
                // Find the mail
                const email = clonedEmails.find((email)=>email.id === emailId);
                if (!email) {
                    reject(new Error("Email not found"));
                    return;
                }
                resolve(email);
            } catch (err) {
                console.error("[Mail Api]: ", err);
                reject(new Error("Internal server error"));
            }
        });
    }
}
const mailApi = new MailApi();

// EXTERNAL MODULE: ./src/slices/mail.ts
var mail = __webpack_require__(162154);
;// CONCATENATED MODULE: ./src/thunks/mail.ts


const getLabels = ()=>async (dispatch)=>{
        const response = await mailApi.getLabels();
        dispatch(mail/* slice.actions.getLabels */.t.actions.getLabels(response));
    };
const getEmails = (params)=>async (dispatch)=>{
        const response = await mailApi.getEmails(params);
        dispatch(mail/* slice.actions.getEmails */.t.actions.getEmails(response));
    };
const getEmail = (params)=>async (dispatch)=>{
        const response = await mailApi.getEmail(params);
        dispatch(mail/* slice.actions.getEmail */.t.actions.getEmail(response));
    };
const thunks = {
    getEmail,
    getEmails,
    getLabels
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Download01.js
var Download01 = __webpack_require__(24165);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
;// CONCATENATED MODULE: ./src/sections/dashboard/mail/mail-thread-attachments.tsx








const MailThreadAttachments = (props)=>{
    const { attachments =[]  } = props;
    const count = attachments.length;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        spacing: 2,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                variant: "h6",
                children: [
                    count,
                    " Attachments"
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                alignItems: "flex-start",
                direction: "row",
                spacing: 2,
                flexWrap: "wrap",
                children: attachments.map((attachment)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 1,
                        sx: {
                            alignItems: "center",
                            cursor: "pointer",
                            display: "flex"
                        },
                        children: [
                            attachment.type === "image" && /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                src: attachment.url,
                                variant: "rounded"
                            }),
                            attachment.type === "file" && /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                variant: "rounded",
                                sx: {
                                    backgroundColor: "primary.light"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "overline",
                                    children: "PDF"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        noWrap: true,
                                        variant: "subtitle2",
                                        children: attachment.name
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: attachment.size
                                    })
                                ]
                            })
                        ]
                    }, attachment.id))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                    color: "inherit",
                    startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Download01/* default */.Z, {})
                    }),
                    size: "small",
                    children: "Download all"
                })
            })
        ]
    });
};
MailThreadAttachments.propTypes = {
    attachments: (prop_types_default()).array
};

// EXTERNAL MODULE: ./node_modules/react-markdown/lib/react-markdown.js + 124 modules
var react_markdown = __webpack_require__(508115);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
;// CONCATENATED MODULE: ./src/sections/dashboard/mail/mail-thread-message.tsx




const MarkdownWrapper = (0,styles.styled)("div")(({ theme  })=>({
        color: theme.palette.text.primary,
        fontFamily: theme.typography.body1.fontFamily,
        "& > p": {
            fontSize: theme.typography.body1.fontSize,
            lineHeight: theme.typography.body1.lineHeight,
            marginBottom: theme.spacing(2)
        }
    }));
const MailThreadMessage = (props)=>{
    const { message =""  } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(MarkdownWrapper, {
        children: /*#__PURE__*/ jsx_runtime_.jsx(react_markdown/* ReactMarkdown */.D, {
            children: message
        })
    });
};
MailThreadMessage.propTypes = {
    message: (prop_types_default()).string
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/FaceSmile.js
var FaceSmile = __webpack_require__(173710);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Link01.js
var Link01 = __webpack_require__(921695);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TextField/index.js
var TextField = __webpack_require__(28379);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField);
// EXTERNAL MODULE: ./src/hooks/use-mocked-user.ts
var use_mocked_user = __webpack_require__(782851);
;// CONCATENATED MODULE: ./src/sections/dashboard/mail/mail-thread-reply.tsx















const MailThreadReply = (props)=>{
    const user = (0,use_mocked_user/* useMockedUser */.I)();
    const fileRef = (0,react_.useRef)(null);
    const [message, setMessage] = (0,react_.useState)("");
    const handleMessageChange = (0,react_.useCallback)((event)=>{
        setMessage(event.target.value);
    }, []);
    const handleFileAttach = (0,react_.useCallback)(()=>{
        fileRef.current?.click();
    }, []);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    p: 3
                },
                ...props,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "flex-start",
                    direction: "row",
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                            src: user.avatar
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                flexGrow: 1
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                    fullWidth: true,
                                    maxRows: 7,
                                    minRows: 3,
                                    multiline: true,
                                    onChange: handleMessageChange,
                                    placeholder: "Leave a message",
                                    value: message,
                                    variant: "outlined"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    justifyContent: "space-between",
                                    spacing: 3,
                                    sx: {
                                        mt: 2
                                    },
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "center",
                                            direction: "row",
                                            spacing: 1,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                                    title: "Attach image",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                        onClick: handleFileAttach,
                                                        size: "small",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Image01/* default */.Z, {})
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                                    title: "Attach file",
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                        onClick: handleFileAttach,
                                                        size: "small",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Attachment01/* default */.Z, {})
                                                        })
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Link01/* default */.Z, {})
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(FaceSmile/* default */.Z, {})
                                                    })
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                variant: "contained",
                                                children: "Reply"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("input", {
                hidden: true,
                ref: fileRef,
                type: "file"
            })
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ArrowLeft.js
var ArrowLeft = __webpack_require__(627178);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronLeft.js
var ChevronLeft = __webpack_require__(459378);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronRight.js
var ChevronRight = __webpack_require__(492382);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/DotsHorizontal.js
var DotsHorizontal = __webpack_require__(66519);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/SearchMd.js
var SearchMd = __webpack_require__(219057);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Trash02.js
var Trash02 = __webpack_require__(459074);
// EXTERNAL MODULE: ./node_modules/@mui/icons-material/Reply.js
var Reply = __webpack_require__(933545);
// EXTERNAL MODULE: ./node_modules/@mui/icons-material/ReplyAll.js
var ReplyAll = __webpack_require__(260714);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/InputAdornment/index.js
var InputAdornment = __webpack_require__(79150);
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/OutlinedInput/index.js
var OutlinedInput = __webpack_require__(877829);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput);
// EXTERNAL MODULE: ./src/components/router-link.tsx
var router_link = __webpack_require__(510079);
// EXTERNAL MODULE: ./src/utils/get-initials.ts
var get_initials = __webpack_require__(388080);
;// CONCATENATED MODULE: ./src/sections/dashboard/mail/mail-thread-toolbar.tsx
























const MailThreadToolbar = (props)=>{
    const { backHref , createdAt , from , to  } = props;
    const mdUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("md"));
    const formattedCreatedAt = (0,date_fns.format)(createdAt, "MMMM d yyyy, h:mm:ss a");
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                justifyContent: "space-between",
                spacing: 2,
                sx: {
                    p: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                            title: "Back",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                component: router_link/* RouterLink */.r,
                                href: backHref,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowLeft/* default */.Z, {})
                                })
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 1,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                fullWidth: true,
                                placeholder: "Search message",
                                size: "small",
                                startAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                    position: "start",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(SearchMd/* default */.Z, {})
                                    })
                                }),
                                sx: {
                                    width: 200
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                title: "Previous email",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronLeft/* default */.Z, {})
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                title: "Next email",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronRight/* default */.Z, {})
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                justifyContent: "space-between",
                spacing: 2,
                sx: {
                    p: 3
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                src: from.avatar || undefined,
                                sx: {
                                    height: 48,
                                    width: 48
                                },
                                children: (0,get_initials/* getInitials */.Q)(from.name)
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        component: "span",
                                        variant: "subtitle2",
                                        children: from.name
                                    }),
                                    " ",
                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                        color: "text.secondary",
                                        component: "span",
                                        variant: "body2",
                                        children: from.email
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "subtitle2",
                                        children: [
                                            "To:",
                                            " ",
                                            to.map((person)=>/*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                    color: "inherit",
                                                    children: person.email
                                                }, person.email))
                                        ]
                                    }),
                                    formattedCreatedAt && /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        noWrap: true,
                                        variant: "caption",
                                        children: formattedCreatedAt
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 1,
                        children: [
                            mdUp && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                        title: "Reply",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Reply["default"], {})
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                        title: "Reply all",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ReplyAll["default"], {})
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                        title: "Delete",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Trash02/* default */.Z, {})
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                title: "More options",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                                    })
                                })
                            })
                        ]
                    })
                ]
            })
        ]
    });
};
MailThreadToolbar.propTypes = {
    backHref: (prop_types_default()).string.isRequired,
    createdAt: (prop_types_default()).number.isRequired,
    // @ts-ignore
    from: (prop_types_default()).object.isRequired,
    to: (prop_types_default()).array.isRequired
};

;// CONCATENATED MODULE: ./src/sections/dashboard/mail/mail-thread.tsx













const useEmail = (emailId)=>{
    const dispatch = (0,store/* useDispatch */.I0)();
    const email = (0,store/* useSelector */.v9)((state)=>state.mail.emails.byId[emailId]);
    (0,react_.useEffect)(()=>{
        dispatch(thunks.getEmail({
            emailId
        }));
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        emailId
    ]);
    return email;
};
const MailThread = (props)=>{
    const { emailId , currentLabelId  } = props;
    const email = useEmail(emailId);
    if (!email) {
        return null;
    }
    const backHref = currentLabelId && currentLabelId !== "inbox" ? paths/* paths.dashboard.mail */.H.dashboard.mail + `?label=${currentLabelId}` : paths/* paths.dashboard.mail */.H.dashboard.mail;
    const hasMessage = !!email.message;
    const hasAttachments = email.attachments && email.attachments.length > 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        sx: {
            flexGrow: 1,
            height: "100%",
            overflowY: "auto"
        },
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(MailThreadToolbar, {
                backHref: backHref,
                createdAt: email.createdAt,
                from: email.from,
                to: email.to
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                sx: {
                    flexGrow: 1,
                    px: 3,
                    py: 6
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "h3",
                        children: email.subject
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        sx: {
                            mt: 2
                        },
                        spacing: 6,
                        children: [
                            hasMessage && /*#__PURE__*/ jsx_runtime_.jsx(MailThreadMessage, {
                                message: email.message
                            }),
                            hasAttachments && /*#__PURE__*/ jsx_runtime_.jsx(MailThreadAttachments, {
                                attachments: email.attachments
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MailThreadReply, {})
        ]
    });
};
MailThread.propTypes = {
    emailId: (prop_types_default()).string.isRequired,
    currentLabelId: (prop_types_default()).string
};

;// CONCATENATED MODULE: ./src/sections/dashboard/mail/mail-container.tsx

const MailContainer = (0,styles.styled)("div", {
    shouldForwardProp: (prop)=>prop !== "open"
})(({ theme , open  })=>({
        flexGrow: 1,
        overflow: "hidden",
        [theme.breakpoints.up("md")]: {
            marginLeft: -280
        },
        transition: theme.transitions.create("margin", {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        }),
        ...open && {
            [theme.breakpoints.up("md")]: {
                marginLeft: 0
            },
            transition: theme.transitions.create("margin", {
                easing: theme.transitions.easing.easeOut,
                duration: theme.transitions.duration.enteringScreen
            })
        }
    }));

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Menu01.js
var Menu01 = __webpack_require__(913629);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/RefreshCcw02.js
var RefreshCcw02 = __webpack_require__(273856);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Checkbox/index.js
var Checkbox = __webpack_require__(63754);
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Bookmark.js
var Bookmark = __webpack_require__(517978);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Star01.js
var Star01 = __webpack_require__(796756);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Chip/index.js
var Chip = __webpack_require__(829553);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip);
;// CONCATENATED MODULE: ./src/sections/dashboard/mail/mail-item.tsx

















const MailItem = (props)=>{
    const { email , onDeselect , onSelect , selected , href , ...other } = props;
    const handleSelectToggle = (0,react_.useCallback)((event)=>{
        if (event.target.checked) {
            onSelect?.();
        } else {
            onDeselect?.();
        }
    }, [
        onSelect,
        onDeselect
    ]);
    const createdAt = (0,date_fns.format)(email.createdAt, "dd MMM");
    const hasAnyAttachments = !!(email.attachments && email.attachments.length > 0);
    const hasManyAttachments = !!(email.attachments && email.attachments.length > 1);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
        sx: {
            alignItems: "center",
            borderBottomWidth: 1,
            borderBottomStyle: "solid",
            borderBottomColor: "divider",
            display: "flex",
            p: 2,
            ...!email.isUnread && {
                position: "relative",
                "&:before": {
                    backgroundColor: "primary.main",
                    content: '" "',
                    height: "100%",
                    left: 0,
                    position: "absolute",
                    top: 0,
                    width: 4
                },
                "& $name, & $subject": {
                    fontWeight: 600
                }
            },
            ...selected && {
                backgroundColor: "primary.lightest"
            },
            ...!selected && {
                "&:hover": {
                    backgroundColor: "action.hover"
                }
            }
        },
        ...other,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                sx: {
                    alignItems: "center",
                    display: {
                        md: "flex",
                        xs: "none"
                    },
                    mr: 1
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                        checked: selected,
                        onChange: handleSelectToggle
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                        title: "Starred",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                sx: {
                                    ...email.isStarred && {
                                        color: "warning.main",
                                        "& path": {
                                            fill: (theme)=>theme.palette.warning.main,
                                            fillOpacity: 1
                                        }
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Star01/* default */.Z, {})
                            })
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                        title: "Important",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                sx: {
                                    ...email.isImportant && {
                                        color: "warning.main",
                                        "& path": {
                                            fill: (theme)=>theme.palette.warning.main,
                                            fillOpacity: 1
                                        }
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Bookmark/* default */.Z, {})
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                component: router_link/* RouterLink */.r,
                href: href,
                sx: {
                    alignItems: "center",
                    cursor: "pointer",
                    display: "flex",
                    flexGrow: 1,
                    flexWrap: {
                        xs: "wrap",
                        md: "nowrap"
                    },
                    minWidth: 1,
                    textDecoration: "none"
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                        sx: {
                            alignItems: "center",
                            display: "flex"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                src: email.from.avatar || undefined,
                                children: (0,get_initials/* getInitials */.Q)(email.from.name)
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.primary",
                                sx: {
                                    width: 120,
                                    ml: 2,
                                    ...!email.isUnread && {
                                        fontWeight: 600
                                    }
                                },
                                noWrap: true,
                                variant: "body2",
                                children: email.from.name
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                        sx: {
                            flexGrow: 1,
                            ml: {
                                xs: 0,
                                md: 2
                            },
                            my: {
                                xs: 2,
                                md: 0
                            },
                            overflow: "hidden",
                            width: {
                                xs: "100%",
                                md: "auto"
                            }
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    alignItems: "center",
                                    display: "flex",
                                    maxWidth: 800,
                                    width: "100%"
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.primary",
                                        sx: {
                                            fontWeight: 600,
                                            minWidth: 100,
                                            maxWidth: 400,
                                            mr: 1
                                        },
                                        noWrap: true,
                                        variant: "body2",
                                        children: email.subject
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                        color: "text.secondary",
                                        noWrap: true,
                                        variant: "body2",
                                        children: [
                                            "—",
                                            email.message
                                        ]
                                    })
                                ]
                            }),
                            hasAnyAttachments && /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    mt: 1
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                                        icon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Attachment01/* default */.Z, {})
                                        }),
                                        label: email.attachments[0].name,
                                        size: "small"
                                    }),
                                    hasManyAttachments && /*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                                        label: "+1",
                                        size: "small",
                                        sx: {
                                            ml: 1
                                        }
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        color: "text.secondary",
                        variant: "caption",
                        sx: {
                            display: "block",
                            textAlign: {
                                xs: "left",
                                md: "right"
                            },
                            whiteSpace: "nowrap",
                            width: 100
                        },
                        children: createdAt
                    })
                ]
            })
        ]
    });
};
MailItem.propTypes = {
    // @ts-ignore
    email: (prop_types_default()).object.isRequired,
    href: (prop_types_default()).string.isRequired,
    onDeselect: (prop_types_default()).func,
    onSelect: (prop_types_default()).func,
    selected: (prop_types_default()).bool.isRequired
};

;// CONCATENATED MODULE: ./src/sections/dashboard/mail/mail-list.tsx























const useEmails = (currentLabelId)=>{
    const dispatch = (0,store/* useDispatch */.I0)();
    const { emails  } = (0,store/* useSelector */.v9)((state)=>state.mail);
    (0,react_.useEffect)(()=>{
        dispatch(thunks.getEmails({
            label: currentLabelId
        }));
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        currentLabelId
    ]);
    return emails;
};
const useSelectionModel = (emailIds)=>{
    const [selected, setSelected] = (0,react_.useState)([]);
    (0,react_.useEffect)(()=>{
        setSelected([]);
    }, [
        emailIds
    ]);
    const handleSelectAll = (0,react_.useCallback)(()=>{
        setSelected([
            ...emailIds
        ]);
    }, [
        emailIds
    ]);
    const handleSelectOne = (0,react_.useCallback)((emailId)=>{
        setSelected((prevState)=>{
            if (!prevState.includes(emailId)) {
                return [
                    ...prevState,
                    emailId
                ];
            }
            return prevState;
        });
    }, []);
    const handleDeselectAll = (0,react_.useCallback)(()=>{
        setSelected([]);
    }, []);
    const handleDeselectOne = (0,react_.useCallback)((emailId)=>{
        setSelected((prevState)=>{
            return prevState.filter((id)=>id !== emailId);
        });
    }, []);
    return {
        handleDeselectAll,
        handleDeselectOne,
        handleSelectAll,
        handleSelectOne,
        selected
    };
};
const MailList = (props)=>{
    const { currentLabelId , onSidebarToggle , ...other } = props;
    const emails = useEmails(currentLabelId);
    const { handleDeselectAll , handleDeselectOne , handleSelectAll , handleSelectOne , selected  } = useSelectionModel(emails.allIds);
    const handleToggleAll = (0,react_.useCallback)((event)=>{
        if (event.target.checked) {
            handleSelectAll();
        } else {
            handleDeselectAll();
        }
    }, [
        handleSelectAll,
        handleDeselectAll
    ]);
    const selectedAll = selected.length === emails.allIds.length;
    const selectedSome = selected.length > 0 && selected.length < emails.allIds.length;
    const hasEmails = emails.allIds.length > 0;
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        sx: {
            height: "100%",
            overflow: "hidden"
        },
        ...other,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                justifyContent: "space-between",
                spacing: 2,
                sx: {
                    p: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            onClick: onSidebarToggle,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Menu01/* default */.Z, {})
                            })
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 1,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                fullWidth: true,
                                placeholder: "Search email",
                                size: "small",
                                startAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                    position: "start",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(SearchMd/* default */.Z, {})
                                    })
                                }),
                                sx: {
                                    width: 200
                                }
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                color: "text.secondary",
                                sx: {
                                    display: {
                                        xs: "none",
                                        md: "block"
                                    },
                                    mx: 2,
                                    whiteSpace: "nowrap"
                                },
                                variant: "body2",
                                children: [
                                    "1 - ",
                                    emails.allIds.length,
                                    " of ",
                                    emails.allIds.length
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                title: "Next page",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronLeft/* default */.Z, {})
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                title: "Previous page",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronRight/* default */.Z, {})
                                    })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                title: "Refresh",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(RefreshCcw02/* default */.Z, {})
                                    })
                                })
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            hasEmails ? /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                        sx: {
                            alignItems: "center",
                            borderBottomColor: "divider",
                            borderBottomStyle: "solid",
                            borderBottomWidth: 1,
                            display: {
                                xs: "none",
                                md: "flex"
                            },
                            p: 2
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                checked: selectedAll,
                                indeterminate: selectedSome,
                                onChange: handleToggleAll
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "subtitle2",
                                children: "Select all"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    flexGrow: 1
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                title: "More options",
                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                                    })
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                        children: emails.allIds.map((emailId)=>{
                            const isSelected = selected.includes(emailId);
                            const href = currentLabelId && currentLabelId !== "inbox" ? paths/* paths.dashboard.mail */.H.dashboard.mail + `?emailId=${emailId}&label=${currentLabelId}` : paths/* paths.dashboard.mail */.H.dashboard.mail + `?emailId=${emailId}`;
                            return /*#__PURE__*/ jsx_runtime_.jsx(MailItem, {
                                email: emails.byId[emailId],
                                href: href,
                                onDeselect: ()=>handleDeselectOne(emailId),
                                onSelect: ()=>handleSelectOne(emailId),
                                selected: isSelected
                            }, emailId);
                        })
                    })
                ]
            }) : /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                justifyContent: "center",
                spacing: 2,
                sx: {
                    flexGrow: 1,
                    p: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        component: "img",
                        src: "/assets/errors/error-404.png",
                        sx: {
                            height: "auto",
                            maxWidth: 120
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        color: "text.secondary",
                        variant: "h5",
                        children: "There are no emails"
                    })
                ]
            })
        ]
    });
};
MailList.propTypes = {
    currentLabelId: (prop_types_default()).string,
    onSidebarToggle: (prop_types_default()).func
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Plus.js
var Plus = __webpack_require__(959309);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Drawer/index.js
var Drawer = __webpack_require__(379499);
var Drawer_default = /*#__PURE__*/__webpack_require__.n(Drawer);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/List/index.js
var List = __webpack_require__(854436);
var List_default = /*#__PURE__*/__webpack_require__.n(List);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListSubheader/index.js
var ListSubheader = __webpack_require__(248891);
var ListSubheader_default = /*#__PURE__*/__webpack_require__.n(ListSubheader);
// EXTERNAL MODULE: ./src/hooks/use-router.ts
var use_router = __webpack_require__(840513);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/AlertCircle.js
var AlertCircle = __webpack_require__(142885);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Inbox01.js
var Inbox01 = __webpack_require__(174569);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Mail01.js
var Mail01 = __webpack_require__(871920);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Mail04.js
var Mail04 = __webpack_require__(815318);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Send01.js
var Send01 = __webpack_require__(376131);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Tag01.js
var Tag01 = __webpack_require__(156769);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ButtonBase/index.js
var ButtonBase = __webpack_require__(269860);
var ButtonBase_default = /*#__PURE__*/__webpack_require__.n(ButtonBase);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItem/index.js
var ListItem = __webpack_require__(790777);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem);
;// CONCATENATED MODULE: ./src/sections/dashboard/mail/mail-label.tsx
















const systemLabelIcons = {
    all: /*#__PURE__*/ jsx_runtime_.jsx(Mail01/* default */.Z, {}),
    inbox: /*#__PURE__*/ jsx_runtime_.jsx(Inbox01/* default */.Z, {}),
    sent: /*#__PURE__*/ jsx_runtime_.jsx(Send01/* default */.Z, {}),
    trash: /*#__PURE__*/ jsx_runtime_.jsx(Trash02/* default */.Z, {}),
    drafts: /*#__PURE__*/ jsx_runtime_.jsx(Mail04/* default */.Z, {}),
    spam: /*#__PURE__*/ jsx_runtime_.jsx(AlertCircle/* default */.Z, {}),
    starred: /*#__PURE__*/ jsx_runtime_.jsx(Star01/* default */.Z, {}),
    important: /*#__PURE__*/ jsx_runtime_.jsx(Bookmark/* default */.Z, {})
};
const getIcon = (label)=>{
    if (label.type === "system") {
        return systemLabelIcons[label.id];
    }
    return /*#__PURE__*/ jsx_runtime_.jsx(Tag01/* default */.Z, {});
};
const getColor = (label)=>{
    if (label.type === "custom") {
        return label.color || "inherit";
    }
    return "inherit";
};
const MailLabel = (props)=>{
    const { active , label , ...other } = props;
    const icon = getIcon(label);
    const color = getColor(label);
    const showUnreadCount = !!(label.unreadCount && label.unreadCount > 0);
    return /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
        disableGutters: true,
        disablePadding: true,
        sx: {
            "& + &": {
                mt: 1
            }
        },
        ...other,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ButtonBase_default()), {
            sx: {
                borderRadius: 1,
                color: "text.secondary",
                flexGrow: 1,
                fontSize: (theme)=>theme.typography.button.fontSize,
                fontWeight: (theme)=>theme.typography.button.fontWeight,
                justifyContent: "flex-start",
                lineHeight: (theme)=>theme.typography.button.lineHeight,
                py: 1,
                px: 2,
                textAlign: "left",
                "&:hover": {
                    backgroundColor: "action.hover"
                },
                ...active && {
                    backgroundColor: "action.selected",
                    color: "text.primary"
                }
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                    sx: {
                        color,
                        mr: 1
                    },
                    children: icon
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        flexGrow: 1
                    },
                    children: label.name
                }),
                showUnreadCount && /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "inherit",
                    variant: "subtitle2",
                    children: label.unreadCount
                })
            ]
        })
    });
};
MailLabel.propTypes = {
    active: (prop_types_default()).bool,
    // @ts-ignore
    label: (prop_types_default()).object.isRequired,
    onClick: (prop_types_default()).func
};

;// CONCATENATED MODULE: ./src/sections/dashboard/mail/mail-sidebar.tsx


















const groupLabels = (labels)=>{
    const groups = {
        system: [],
        custom: []
    };
    labels.forEach((label)=>{
        if (label.type === "system") {
            groups.system.push(label);
        } else {
            groups.custom.push(label);
        }
    });
    return groups;
};
const MailSidebar = (props)=>{
    const { currentLabelId ="inbox" , container , labels , onClose , onCompose , open , ...other } = props;
    const router = (0,use_router/* useRouter */.t)();
    const mdUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("md"));
    const handleLabelSelect = (0,react_.useCallback)((label)=>{
        if (!mdUp) {
            onClose?.();
        }
        const href = label.id !== "inbox" ? paths/* paths.dashboard.mail */.H.dashboard.mail + `?label=${label.id}` : paths/* paths.dashboard.mail */.H.dashboard.mail;
        router.push(href);
    }, [
        router,
        mdUp,
        onClose
    ]);
    // Maybe use memo
    const groupedLabels = groupLabels(labels);
    const content = /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                spacing: 2,
                sx: {
                    pt: 2,
                    px: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "h5",
                        sx: {
                            flexGrow: 1
                        },
                        children: "Mailbox"
                    }),
                    !mdUp && /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        onClick: onClose,
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(X/* default */.Z, {})
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    p: 2
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                    fullWidth: true,
                    onClick: onCompose,
                    startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                    }),
                    sx: {
                        mt: 2
                    },
                    variant: "contained",
                    children: "Compose"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    pb: 2,
                    px: 2
                },
                children: Object.keys(groupedLabels).map((type)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(react_.Fragment, {
                        children: [
                            type === "custom" && /*#__PURE__*/ jsx_runtime_.jsx((ListSubheader_default()), {
                                disableSticky: true,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "overline",
                                    children: "Labels"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                                disablePadding: true,
                                children: groupedLabels[type].map((label)=>{
                                    const isActive = currentLabelId === label.id;
                                    return /*#__PURE__*/ jsx_runtime_.jsx(MailLabel, {
                                        active: isActive,
                                        label: label,
                                        onClick: ()=>handleLabelSelect(label)
                                    }, label.id);
                                })
                            })
                        ]
                    }, type))
            })
        ]
    });
    if (mdUp) {
        return /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
            anchor: "left",
            open: open,
            PaperProps: {
                sx: {
                    position: "relative",
                    width: 280
                }
            },
            SlideProps: {
                container
            },
            variant: "persistent",
            ...other,
            children: content
        });
    }
    return /*#__PURE__*/ jsx_runtime_.jsx((Drawer_default()), {
        anchor: "left",
        hideBackdrop: true,
        ModalProps: {
            container,
            sx: {
                pointerEvents: "none",
                position: "absolute"
            }
        },
        onClose: onClose,
        open: open,
        PaperProps: {
            sx: {
                maxWidth: "100%",
                width: 280,
                pointerEvents: "auto",
                position: "absolute"
            }
        },
        SlideProps: {
            container
        },
        variant: "temporary",
        ...other,
        children: content
    });
};
MailSidebar.propTypes = {
    container: (prop_types_default()).any,
    currentLabelId: (prop_types_default()).string,
    labels: (prop_types_default()).array.isRequired,
    onClose: (prop_types_default()).func,
    onCompose: (prop_types_default()).func,
    open: (prop_types_default()).bool
};

;// CONCATENATED MODULE: ./src/app/(dashboard)/mail/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 














const useLabels = ()=>{
    const dispatch = (0,store/* useDispatch */.I0)();
    const labels = (0,store/* useSelector */.v9)((state)=>state.mail.labels);
    const handleLabelsGet = (0,react_.useCallback)(()=>{
        dispatch(thunks.getLabels());
    }, [
        dispatch
    ]);
    (0,react_.useEffect)(()=>{
        handleLabelsGet();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []);
    return labels;
};
const useComposer = ()=>{
    const initialState = {
        isFullScreen: false,
        isOpen: false,
        message: "",
        subject: "",
        to: ""
    };
    const [state, setState] = (0,react_.useState)(initialState);
    const handleOpen = (0,react_.useCallback)(()=>{
        setState((prevState)=>({
                ...prevState,
                isOpen: true
            }));
    }, []);
    const handleClose = (0,react_.useCallback)(()=>{
        setState(initialState);
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    []);
    const handleMaximize = (0,react_.useCallback)(()=>{
        setState((prevState)=>({
                ...prevState,
                isFullScreen: true
            }));
    }, []);
    const handleMinimize = (0,react_.useCallback)(()=>{
        setState((prevState)=>({
                ...prevState,
                isFullScreen: false
            }));
    }, []);
    const handleMessageChange = (0,react_.useCallback)((message)=>{
        setState((prevState)=>({
                ...prevState,
                message
            }));
    }, []);
    const handleSubjectChange = (0,react_.useCallback)((subject)=>{
        setState((prevState)=>({
                ...prevState,
                subject
            }));
    }, []);
    const handleToChange = (0,react_.useCallback)((to)=>{
        setState((prevState)=>({
                ...prevState,
                to
            }));
    }, []);
    return {
        ...state,
        handleClose,
        handleMaximize,
        handleMessageChange,
        handleMinimize,
        handleOpen,
        handleSubjectChange,
        handleToChange
    };
};
const useSidebar = ()=>{
    const mdUp = (0,useMediaQuery["default"])((theme)=>theme.breakpoints.up("md"));
    const [open, setOpen] = (0,react_.useState)(mdUp);
    const handleScreenResize = (0,react_.useCallback)(()=>{
        if (!mdUp) {
            setOpen(false);
        } else {
            setOpen(true);
        }
    }, [
        mdUp
    ]);
    (0,react_.useEffect)(()=>{
        handleScreenResize();
    }, // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        mdUp
    ]);
    const handleToggle = (0,react_.useCallback)(()=>{
        setOpen((prevState)=>!prevState);
    }, []);
    const handleClose = (0,react_.useCallback)(()=>{
        setOpen(false);
    }, []);
    return {
        handleToggle,
        handleClose,
        open
    };
};
const Page = ()=>{
    const rootRef = (0,react_.useRef)(null);
    const searchParams = (0,use_search_params/* useSearchParams */.l)();
    const emailId = searchParams.get("emailId");
    const currentLabelId = searchParams.get("label") || undefined;
    const labels = useLabels();
    const composer = useComposer();
    const sidebar = useSidebar();
    (0,use_page_view/* usePageView */.a)();
    const view = emailId ? "details" : "list";
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Dashboard: Mail"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                component: "main",
                sx: {
                    backgroundColor: "background.paper",
                    flex: "1 1 auto",
                    overflow: "hidden",
                    position: "relative"
                },
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                    ref: rootRef,
                    sx: {
                        bottom: 0,
                        display: "flex",
                        left: 0,
                        position: "absolute",
                        right: 0,
                        top: 0
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(MailSidebar, {
                            container: rootRef.current,
                            currentLabelId: currentLabelId,
                            labels: labels,
                            onClose: sidebar.handleClose,
                            onCompose: composer.handleOpen,
                            open: sidebar.open
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(MailContainer, {
                            open: sidebar.open,
                            children: [
                                view === "details" && /*#__PURE__*/ jsx_runtime_.jsx(MailThread, {
                                    currentLabelId: currentLabelId,
                                    emailId: emailId
                                }),
                                view === "list" && /*#__PURE__*/ jsx_runtime_.jsx(MailList, {
                                    currentLabelId: currentLabelId,
                                    onSidebarToggle: sidebar.handleToggle
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(MailComposer, {
                maximize: composer.isFullScreen,
                message: composer.message,
                onClose: composer.handleClose,
                onMaximize: composer.handleMaximize,
                onMessageChange: composer.handleMessageChange,
                onMinimize: composer.handleMinimize,
                onSubjectChange: composer.handleSubjectChange,
                onToChange: composer.handleToChange,
                open: composer.isOpen,
                subject: composer.subject,
                to: composer.to
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 82365:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "l": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.useSearchParams)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 846447:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "p": () => (/* binding */ deepCopy)
/* harmony export */ });
// eslint-disable-next-line consistent-return
function deepCopy(obj) {
    if (typeof obj !== "object" || obj === null) {
        return obj;
    }
    if (obj instanceof Date) {
        return new Date(obj.getTime());
    }
    if (obj instanceof Array) {
        return obj.reduce((arr, item, index)=>{
            arr[index] = deepCopy(item);
            return arr;
        }, []);
    }
    if (obj instanceof Object) {
        return Object.keys(obj).reduce((newObj, key)=>{
            newObj[key] = deepCopy(obj[key]);
            return newObj;
        }, {});
    }
}


/***/ }),

/***/ 388080:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ getInitials)
/* harmony export */ });
const getInitials = (name = "")=>name.replace(/\s+/, " ").split(" ").slice(0, 2).map((v)=>v && v[0].toUpperCase()).join("");


/***/ }),

/***/ 137480:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/(dashboard)/mail/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,4755,6609,4609,5055,9894,4971,9535,6519,7484,1920,9353,8115,2765,2474,6131,9074,5878,1093,7680,95,9494,2302,2851,4131], () => (__webpack_exec__(400896)));
module.exports = __webpack_exports__;

})();