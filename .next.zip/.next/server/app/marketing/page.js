(() => {
var exports = {};
exports.id = 245;
exports.ids = [245];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 114682:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'marketing',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 343638, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/page.tsx"],
          
        }]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 586068)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/marketing/page"
  

/***/ }),

/***/ 351403:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 784836))

/***/ }),

/***/ 784836:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
;// CONCATENATED MODULE: ./src/sections/home/home-cta.tsx






const HomeCta = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: "neutral.800",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "top center",
            backgroundImage: 'url("/assets/gradient-bg.svg")',
            color: "neutral.100",
            py: "120px"
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
            maxWidth: "lg",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    spacing: 2,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            align: "center",
                            color: "inherit",
                            variant: "h3",
                            children: "Start saving time today!"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            align: "center",
                            color: "inherit",
                            variant: "subtitle2",
                            children: "Not just a set of tools, the package includes ready-to-deploy conceptual applications written in JavaScript & TypeScript."
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    justifyContent: "center",
                    spacing: 2,
                    sx: {
                        mt: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        component: "a",
                        href: "https://mui.com/store/items/devias-kit-pro",
                        target: "_blank",
                        variant: "contained",
                        children: "Purchase Now"
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronDown.js
var ChevronDown = __webpack_require__(870261);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronRight.js
var ChevronRight = __webpack_require__(492382);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Collapse/index.js
var Collapse = __webpack_require__(836136);
var Collapse_default = /*#__PURE__*/__webpack_require__.n(Collapse);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
;// CONCATENATED MODULE: ./src/sections/home/home-faqs.tsx












const faqs = [
    {
        question: "Do you have a free demo to review the code before purchasing?",
        answer: "Yes, you can check out our open source dashboard template which should give you an overview of the code quality and folder structure. Keep in mind that some aspects may differ from this Paid version."
    },
    {
        question: "How many projects can I build with Devias Kit PRO?",
        answer: "The license is per project (domain), but if you intend to develop an unknown number of projects feel free to contact us and we'll find a solution."
    },
    {
        question: "How many projects can I build with this template?",
        answer: "Absolutely! If you intend to charge users for using your product Extended license is created specifically for this context."
    },
    {
        question: "What browsers does the template support?",
        answer: "The components in MUI are designed to work in the latest, stable releases of all major browsers, including Chrome, Firefox, Safari, and Edge. We don't support Internet Explorer 11."
    },
    {
        question: "For what kind of projects is the Standard license intended?",
        answer: "The Standard license is designed for internal applications in which staff will access the application. An example could be the back-office dashboard of a public-facing e-commerce website in which staff would sign in and manage inventory, customers, etc."
    }
];
const Faq = (props)=>{
    const { answer , question  } = props;
    const [isExpanded, setIsExpanded] = (0,react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
        onClick: ()=>setIsExpanded((prevState)=>!prevState),
        spacing: 2,
        sx: {
            cursor: "pointer"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                justifyContent: "space-between",
                spacing: 2,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "subtitle1",
                        children: question
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        children: isExpanded ? /*#__PURE__*/ jsx_runtime_.jsx(ChevronDown/* default */.Z, {}) : /*#__PURE__*/ jsx_runtime_.jsx(ChevronRight/* default */.Z, {})
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Collapse_default()), {
                in: isExpanded,
                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    color: "text.secondary",
                    variant: "body2",
                    children: answer
                })
            })
        ]
    });
};
Faq.propTypes = {
    question: (prop_types_default()).string.isRequired,
    answer: (prop_types_default()).string.isRequired
};
const HomeFaqs = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            py: "120px"
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "lg",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                container: true,
                spacing: 4,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        md: 6,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h3",
                                    children: "Everything you need to know"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "subtitle2",
                                    children: "Frequently asked questions"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        md: 6,
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                            spacing: 4,
                            children: faqs.map((faq, index)=>/*#__PURE__*/ jsx_runtime_.jsx(Faq, {
                                    ...faq
                                }, index))
                        })
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/LinkExternal01.js
var LinkExternal01 = __webpack_require__(890109);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
;// CONCATENATED MODULE: ./src/sections/home/home-features.tsx











const features = [
    {
        id: "experts",
        title: "Built by experts",
        description: "All of the code follows MUI best practices, it’s written by our in-house team of experts.",
        imageDark: "/assets/home-features-experts-dark.png",
        imageLight: "/assets/home-features-experts-light.png"
    },
    {
        id: "figma",
        title: "Design Files",
        description: "We've included the source Figma files to Plus & Extended licenses so you can get creative! Build layouts with confidence.",
        imageDark: "/assets/home-features-figma-dark.png",
        imageLight: "/assets/home-features-figma-light.png"
    },
    {
        id: "tech",
        title: "Built with modern technologies",
        description: "Each template is a well-structured CRA & Next.js project, giving you a codebase that’s productive and enjoyable to work in.",
        imageDark: "/assets/home-features-tech-dark.png",
        imageLight: "/assets/home-features-tech-light.png"
    },
    {
        id: "customize",
        title: "Easy to customize",
        description: "Everything is styled using global theme overrides, just open the theme file in your editor and change whatever you want.",
        imageDark: "/assets/home-features-customize-dark.png",
        imageLight: "/assets/home-features-customize-light.png"
    },
    {
        id: "productive",
        title: "Built with CRA & Next.js",
        description: "Well-structured, thoughtfully componentized CRA & Next.js project, giving you a codebase that’s productive and enjoyable to work in.",
        imageDark: "/assets/home-features-nextjs-dark.png",
        imageLight: "/assets/home-features-nextjs-light.png"
    }
];
const HomeFeatures = ()=>{
    const theme = (0,styles.useTheme)();
    const [activeFeature, setActiveFeature] = (0,react_.useState)(0);
    const feature = features[activeFeature];
    const image = theme.palette.mode === "dark" ? feature?.imageDark : feature?.imageLight;
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: "neutral.800",
            backgroundRepeat: "no-repeat",
            backgroundPosition: "top center",
            backgroundImage: 'url("/assets/gradient-bg.svg")',
            color: "common.white",
            py: "120px"
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
            maxWidth: "lg",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    spacing: 2,
                    sx: {
                        mb: 8
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            align: "center",
                            color: "inherit",
                            variant: "h3",
                            children: "Everything you need to run your project."
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            align: "center",
                            color: "inherit",
                            variant: "subtitle2",
                            children: "Not just a set of tools, the package includes ready-to-deploy conceptual application."
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                    alignItems: "center",
                    container: true,
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                spacing: 1,
                                children: features.map((feature, index)=>{
                                    const isActive = activeFeature === index;
                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                        onClick: ()=>setActiveFeature(index),
                                        sx: {
                                            borderRadius: 2.5,
                                            color: "neutral.400",
                                            cursor: "pointer",
                                            p: 3,
                                            transition: (theme)=>theme.transitions.create([
                                                    "background-color, box-shadow",
                                                    "color"
                                                ], {
                                                    easing: theme.transitions.easing.easeOut,
                                                    duration: theme.transitions.duration.enteringScreen
                                                }),
                                            ...isActive && {
                                                backgroundColor: "primary.alpha12",
                                                boxShadow: (theme)=>`${theme.palette.primary.main} 0 0 0 1px`,
                                                color: "common.white"
                                            },
                                            "&:hover": {
                                                ...!isActive && {
                                                    backgroundColor: "primary.alpha4",
                                                    boxShadow: (theme)=>`${theme.palette.primary.main} 0 0 0 1px`,
                                                    color: "common.white"
                                                }
                                            }
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "inherit",
                                                sx: {
                                                    mb: 1
                                                },
                                                variant: "h6",
                                                children: feature.title
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "inherit",
                                                variant: "body2",
                                                children: feature.description
                                            }),
                                            feature.id === "figma" && /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                sx: {
                                                    mt: 3
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                                    color: "success",
                                                    component: "a",
                                                    endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                        fontSize: "small",
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(LinkExternal01/* default */.Z, {})
                                                    }),
                                                    href: "https://www.figma.com/file/xrx6uDljzsWuDZiuz3ITCp/Devias-Kit-Pro-UI-6.0-Master",
                                                    size: "small",
                                                    target: "_blank",
                                                    variant: "contained",
                                                    children: "Preview in Figma"
                                                })
                                            })
                                        ]
                                    }, feature.id);
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    "& img": {
                                        width: "100%"
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    src: image
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Eye.js
var Eye = __webpack_require__(800408);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/LayoutBottom.js
var LayoutBottom = __webpack_require__(893552);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Rating/index.js
var Rating = __webpack_require__(247022);
var Rating_default = /*#__PURE__*/__webpack_require__.n(Rating);
// EXTERNAL MODULE: ./src/components/router-link.tsx
var router_link = __webpack_require__(510079);
// EXTERNAL MODULE: ./src/paths.ts
var paths = __webpack_require__(287842);
// EXTERNAL MODULE: ./node_modules/react-syntax-highlighter/dist/cjs/index.js
var cjs = __webpack_require__(41250);
// EXTERNAL MODULE: ./node_modules/@mui/system/colorManipulator.js
var colorManipulator = __webpack_require__(229551);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tab/index.js
var Tab = __webpack_require__(189733);
var Tab_default = /*#__PURE__*/__webpack_require__.n(Tab);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tabs/index.js
var Tabs = __webpack_require__(790206);
var Tabs_default = /*#__PURE__*/__webpack_require__.n(Tabs);
// EXTERNAL MODULE: ./src/theme/colors.ts
var colors = __webpack_require__(399807);
;// CONCATENATED MODULE: ./src/utils/code-style.ts

const codeStyle = {
    'code[class*="language-"]': {
        color: colors/* neutral.50 */.n$[50],
        background: "none",
        textShadow: "0 1px rgba(0, 0, 0, 0.3)",
        fontFamily: "'Roboto Mono', Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace",
        fontSize: "14px",
        textAlign: "left",
        whiteSpace: "pre",
        wordSpacing: "normal",
        wordBreak: "normal",
        wordWrap: "normal",
        lineHeight: "1.5",
        MozTabSize: "4",
        OTabSize: "4",
        tabSize: "4",
        WebkitHyphens: "none",
        MozHyphens: "none",
        msHyphens: "none",
        hyphens: "none"
    },
    'pre[class*="language-"]': {
        color: colors/* neutral.50 */.n$[50],
        background: colors/* neutral.800 */.n$[800],
        textShadow: "0 1px rgba(0, 0, 0, 0.3)",
        fontFamily: "'Roboto Mono', Consolas, Monaco, 'Andale Mono', 'Ubuntu Mono', monospace",
        fontSize: "14px",
        textAlign: "left",
        whiteSpace: "pre",
        wordSpacing: "normal",
        wordBreak: "normal",
        wordWrap: "normal",
        lineHeight: "1.5",
        MozTabSize: "4",
        OTabSize: "4",
        tabSize: "4",
        WebkitHyphens: "none",
        MozHyphens: "none",
        msHyphens: "none",
        hyphens: "none",
        padding: "1em",
        margin: ".5em 0",
        overflow: "auto",
        borderRadius: "8px"
    },
    ':not(pre) > code[class*="language-"]': {
        background: colors/* neutral.800 */.n$[800],
        padding: ".1em",
        borderRadius: ".3em",
        whiteSpace: "normal"
    },
    comment: {
        color: "#6272a4"
    },
    prolog: {
        color: "#6272a4"
    },
    doctype: {
        color: "#6272a4"
    },
    cdata: {
        color: "#6272a4"
    },
    punctuation: {
        color: "#f8f8f2"
    },
    ".namespace": {
        Opacity: ".7"
    },
    property: {
        color: "#ff79c6"
    },
    tag: {
        color: "#ff79c6"
    },
    constant: {
        color: "#ff79c6"
    },
    symbol: {
        color: "#ff79c6"
    },
    deleted: {
        color: "#ff79c6"
    },
    boolean: {
        color: "#bd93f9"
    },
    number: {
        color: "#bd93f9"
    },
    selector: {
        color: "#50fa7b"
    },
    "attr-name": {
        color: "#50fa7b"
    },
    string: {
        color: "#50fa7b"
    },
    char: {
        color: "#50fa7b"
    },
    builtin: {
        color: "#50fa7b"
    },
    inserted: {
        color: "#50fa7b"
    },
    operator: {
        color: "#f8f8f2"
    },
    entity: {
        color: "#f8f8f2",
        cursor: "help"
    },
    url: {
        color: "#f8f8f2"
    },
    ".language-css .token.string": {
        color: "#f8f8f2"
    },
    ".style .token.string": {
        color: "#f8f8f2"
    },
    variable: {
        color: "#f8f8f2"
    },
    atrule: {
        color: "#f1fa8c"
    },
    "attr-value": {
        color: "#f1fa8c"
    },
    function: {
        color: "#f1fa8c"
    },
    "class-name": {
        color: "#f1fa8c"
    },
    keyword: {
        color: "#8be9fd"
    },
    regex: {
        color: "#ffb86c"
    },
    important: {
        color: "#ffb86c",
        fontWeight: "bold"
    },
    bold: {
        fontWeight: "bold"
    },
    italic: {
        fontStyle: "italic"
    }
};

;// CONCATENATED MODULE: ./src/sections/home/home-code-samples.tsx










const samples = [
    {
        lang: "jsx",
        label: ".jsx",
        icon: "/assets/logos/logo-javascript.svg",
        code: `"import { useState } from 'react';\\nimport { usePageView } from 'src/hooks/use-page-view';\\nimport { useUser } from 'src/hooks/use-user';\\n\\nconst Page = () => {\\n  const user = useUser();\\n  const [currentTab, setCurrentTab] = useState('general');\\n\\n  usePageView();\\n\\n  return (\\n    <Box\\n      component=\\"main\\"\\n      sx={{ flexGrow: 1, py: 8 }}\\n    >\\n      <Container maxWidth=\\"xl\\">\\n        <Stack\\n          spacing={3}\\n          sx={{ mb: 3 }}\\n        >\\n          <Typography variant=\\"h4\\">\\n            Account\\n          </Typography>\\n          <div>\\n            <Tabs\\n              indicatorColor=\\"primary\\"\\n              onChange={() => {}}\\n              scrollButtons=\\"auto\\"\\n              textColor=\\"primary\\"\\n              value={currentTab}\\n              variant=\\"scrollable\\"\\n            >\\n              {[].map((tab) => (\\n                <Tab\\n                  key={tab.value}\\n                  label={tab.label}\\n                  value={tab.value}\\n                />\\n              ))}\\n            </Tabs>\\n            <Divider />\\n          </div>\\n        </Stack>\\n      </Container>\\n    </Box>\\n  );\\n};\\n"`
    },
    {
        lang: "tsx",
        label: ".tsx",
        icon: "/assets/logos/logo-typescript.svg",
        code: `"import { useState } from 'react';\\nimport type { NextPage } from 'next';\\nimport { usePageView } from 'src/hooks/use-page-view';\\nimport { useUser } from 'src/hooks/use-user';\\n\\nconst Page: NextPage = () => {\\n  const user = useUser();\\n  const [currentTab, setCurrentTab] = useState<string>('general');\\n\\n  usePageView();\\n\\n  return (\\n    <Box\\n      component=\\"main\\"\\n      sx={{ flexGrow: 1, py: 8 }}\\n    >\\n      <Container maxWidth=\\"xl\\">\\n        <Stack\\n          spacing={3}\\n          sx={{ mb: 3 }}\\n        >\\n          <Typography variant=\\"h4\\">\\n            Account\\n          </Typography>\\n          <div>\\n            <Tabs\\n              indicatorColor=\\"primary\\"\\n              onChange={() => {}}\\n              scrollButtons=\\"auto\\"\\n              textColor=\\"primary\\"\\n              value={currentTab}\\n              variant=\\"scrollable\\"\\n            >\\n              {[].map((tab) => (\\n                <Tab\\n                  key={tab.value}\\n                  label={tab.label}\\n                  value={tab.value}\\n                />\\n              ))}\\n            </Tabs>\\n            <Divider />\\n          </div>\\n        </Stack>\\n      </Container>\\n    </Box>\\n  );\\n};\\n"`
    }
];
const HomeCodeSamples = ()=>{
    const [lang, setLang] = (0,react_.useState)(samples[0].lang);
    const handleLangChange = (0,react_.useCallback)((event, value)=>{
        setLang(value);
    }, []);
    const code = (0,react_.useMemo)(()=>{
        return samples.find((sample)=>sample.lang === lang)?.code.trim() || "";
    }, [
        lang
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
        sx: {
            display: "flex",
            flexDirection: "column"
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                direction: "row",
                justifyContent: "space-between",
                spacing: 2,
                sx: {
                    backdropFilter: "blur(6px)",
                    backgroundColor: (theme)=>(0,colorManipulator.alpha)(theme.palette.neutral[800], .95),
                    borderBottomColor: "neutral.700",
                    borderBottomStyle: "solid",
                    borderBottomWidth: 1,
                    borderTopLeftRadius: (theme)=>theme.shape.borderRadius,
                    borderTopRightRadius: (theme)=>theme.shape.borderRadius,
                    boxShadow: 24,
                    flex: "0 0 auto",
                    overflow: "hidden",
                    px: 2
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 1,
                        sx: {
                            py: 2,
                            "& > div": {
                                backgroundColor: "rgba(255, 255, 255, 0.16)",
                                borderRadius: "50%",
                                height: 10,
                                width: 10
                            }
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {}),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {})
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Tabs_default()), {
                        onChange: handleLangChange,
                        value: lang,
                        children: samples.map((sample)=>/*#__PURE__*/ jsx_runtime_.jsx((Tab_default()), {
                                label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 1,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                            sx: {
                                                borderRadius: "4px",
                                                flex: "0 0 auto",
                                                height: 20,
                                                overflow: "hidden",
                                                width: 20,
                                                "& img": {
                                                    width: "100%"
                                                }
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                src: sample.icon
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            sx: {
                                                color: "neutral.300"
                                            },
                                            variant: "body2",
                                            children: sample.label
                                        })
                                    ]
                                }),
                                value: sample.lang
                            }, sample.lang))
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    backdropFilter: "blur(6px)",
                    backgroundColor: (theme)=>(0,colorManipulator.alpha)(theme.palette.neutral[800], .9),
                    borderBottomLeftRadius: (theme)=>theme.shape.borderRadius,
                    borderBottomRightRadius: (theme)=>theme.shape.borderRadius,
                    flex: "1 1 auto",
                    overflow: "hidden",
                    p: 2,
                    "& pre": {
                        background: "none !important",
                        borderRadius: "0 !important",
                        fontSize: "12px !important",
                        height: "100%",
                        m: "0 !important",
                        overflow: "hidden !important",
                        p: "0 !important"
                    },
                    "& code": {
                        fontSize: "12px !important"
                    }
                },
                children: /*#__PURE__*/ jsx_runtime_.jsx(cjs/* Prism */.p1, {
                    language: lang,
                    style: codeStyle,
                    children: JSON.parse(code)
                })
            })
        ]
    });
};

;// CONCATENATED MODULE: ./src/sections/home/home-hero.tsx














const HomeHero = ()=>{
    const theme = (0,styles.useTheme)();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundRepeat: "no-repeat",
            backgroundPosition: "top center",
            backgroundImage: 'url("/assets/gradient-bg.svg")',
            pt: "120px"
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
            maxWidth: "lg",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                    maxWidth: "sm",
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                            variant: "h1",
                            sx: {
                                mb: 2
                            },
                            children: [
                                "Let us worry about the\xa0",
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    component: "span",
                                    color: "primary.main",
                                    variant: "inherit",
                                    children: "User Experience"
                                }),
                                ", you focus on Developing."
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            color: "text.secondary",
                            sx: {
                                fontSize: 20,
                                fontWeight: 500
                            },
                            children: "A professional kit that comes with ready-to-use MUI components developed with one common goal in mind, help you build faster & beautiful applications."
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            flexWrap: "wrap",
                            spacing: 1,
                            sx: {
                                my: 3
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Rating_default()), {
                                    readOnly: true,
                                    value: 4.7,
                                    precision: 0.1,
                                    max: 5
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.primary",
                                    variant: "caption",
                                    sx: {
                                        fontWeight: 700
                                    },
                                    children: "4.7/5"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "caption",
                                    children: "based on (70+ reviews)"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    component: router_link/* RouterLink */.r,
                                    href: paths/* paths.dashboard.index */.H.dashboard.index,
                                    startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        fontSize: "small",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Eye/* default */.Z, {})
                                    }),
                                    sx: (theme)=>theme.palette.mode === "dark" ? {
                                            backgroundColor: "neutral.50",
                                            color: "neutral.900",
                                            "&:hover": {
                                                backgroundColor: "neutral.200"
                                            }
                                        } : {
                                            backgroundColor: "neutral.900",
                                            color: "neutral.50",
                                            "&:hover": {
                                                backgroundColor: "neutral.700"
                                            }
                                        },
                                    variant: "contained",
                                    children: "Live Demo"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    color: "inherit",
                                    component: router_link/* RouterLink */.r,
                                    href: paths/* paths.components.index */.H.components.index,
                                    startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        fontSize: "small",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(LayoutBottom/* default */.Z, {})
                                    }),
                                    children: "Components"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                    sx: {
                        pt: "120px",
                        position: "relative"
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                overflow: "hidden",
                                width: "90%",
                                fontSize: 0,
                                mt: -2,
                                mx: -2,
                                pt: 2,
                                px: 2,
                                "& img": {
                                    borderTopLeftRadius: (theme)=>theme.shape.borderRadius * 2.5,
                                    borderTopRightRadius: (theme)=>theme.shape.borderRadius * 2.5,
                                    boxShadow: 16,
                                    width: "100%"
                                }
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                src: theme.palette.mode === "dark" ? "/assets/home-thumbnail-dark.png" : "/assets/home-thumbnail-light.png"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                maxHeight: "100%",
                                maxWidth: "100%",
                                overflow: "hidden",
                                position: "absolute",
                                right: 0,
                                top: 40,
                                "& > div": {
                                    height: 460,
                                    width: 560
                                }
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(HomeCodeSamples, {})
                        })
                    ]
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
;// CONCATENATED MODULE: ./src/components/logos/logo-accenture.tsx

const LogoAccenture = (props)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 93,
        height: 24,
        viewBox: "0 0 93 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                clipPath: "url(#clip0_11275_169474)",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M53.7278 6.69767L58.9743 4.74419L53.7278 2.73488V0L62.7138 3.62791V5.86046L53.7278 9.48837V6.69767Z",
                        fill: "currentColor"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M4.10915 24C2.21147 24 0.648682 23.0511 0.648682 20.9302V20.8186C0.648682 18.2511 2.88124 17.3581 5.61612 17.3581H6.89984V16.8558C6.89984 15.7953 6.45333 15.1814 5.33705 15.1814C4.3324 15.1814 3.83008 15.7395 3.77426 16.5209H0.983565C1.20682 14.1767 3.04868 13.0604 5.5045 13.0604C8.01612 13.0604 9.85798 14.1209 9.85798 16.7442V23.7767H7.01147V22.5488C6.45333 23.3302 5.5045 24 4.10915 24ZM6.89984 20.3162V19.3116H5.72775C4.27659 19.3116 3.55101 19.7023 3.55101 20.6511V20.7628C3.55101 21.4883 3.99752 21.9907 5.00217 21.9907C6.00682 21.9349 6.89984 21.3767 6.89984 20.3162ZM16.4998 24C13.5975 24 11.4766 22.2139 11.4766 18.6418V18.4744C11.4766 14.9023 13.7091 13.0046 16.4998 13.0046C18.8998 13.0046 20.8533 14.2325 21.0766 16.9674H18.2859C18.1185 15.9628 17.5603 15.293 16.5557 15.293C15.3278 15.293 14.4347 16.2976 14.4347 18.3628V18.6976C14.4347 20.8186 15.2161 21.7674 16.5557 21.7674C17.5603 21.7674 18.2859 21.0418 18.4533 19.8697H21.1324C20.965 22.3256 19.3464 24 16.4998 24ZM27.4394 24C24.5371 24 22.4161 22.2139 22.4161 18.6418V18.4744C22.4161 14.9023 24.6487 13.0046 27.4394 13.0046C29.8394 13.0046 31.7929 14.2325 32.0161 16.9674H29.2254C29.058 15.9628 28.4998 15.293 27.4952 15.293C26.2673 15.293 25.3743 16.2976 25.3743 18.3628V18.6976C25.3743 20.8186 26.1557 21.7674 27.4952 21.7674C28.4998 21.7674 29.2254 21.0418 29.3929 19.8697H32.0719C31.9045 22.3256 30.2859 24 27.4394 24ZM38.4347 24C35.4208 24 33.3557 22.2139 33.3557 18.6976V18.4744C33.3557 14.9581 35.5324 13.0046 38.3789 13.0046C41.0022 13.0046 43.1789 14.4558 43.1789 17.9721V19.2558H36.3138C36.4254 21.1535 37.2626 21.879 38.4905 21.879C39.6068 21.879 40.2208 21.2651 40.444 20.5395H43.1789C42.844 22.493 41.1696 24 38.4347 24ZM36.3696 17.3023H40.2766C40.2208 15.7395 39.4952 15.0697 38.3231 15.0697C37.4301 15.1256 36.5929 15.6279 36.3696 17.3023ZM44.965 13.2837H47.9231V14.8465C48.4254 13.8418 49.4859 13.0604 51.1045 13.0604C53.0022 13.0604 54.2859 14.2325 54.2859 16.7442V23.7767H51.3278V17.1907C51.3278 15.9628 50.8254 15.4046 49.765 15.4046C48.7603 15.4046 47.9231 16.0186 47.9231 17.3581V23.7767H44.965V13.2837V13.2837ZM59.6998 10.1023V13.2837H61.7092V15.4604H59.6998V20.4279C59.6998 21.2093 60.0347 21.6 60.7603 21.6C61.2068 21.6 61.4859 21.5442 61.765 21.4325V23.7209C61.4301 23.8325 60.8161 23.9442 60.0905 23.9442C57.8022 23.9442 56.7417 22.8837 56.7417 20.7628V15.4604H55.5138V13.2837H56.7417V11.3302L59.6998 10.1023ZM72.7603 23.7767H69.858V22.2139C69.3557 23.2186 68.351 24 66.7882 24C64.8905 24 63.4952 22.8279 63.4952 20.3721V13.2837H66.4533V19.9814C66.4533 21.2093 66.9557 21.7674 67.9603 21.7674C68.965 21.7674 69.8022 21.0976 69.8022 19.8139V13.2837H72.7603V23.7767ZM74.9371 13.2837H77.8952V15.2372C78.5091 13.8418 79.5138 13.1721 81.0766 13.1721V16.0744C79.0673 16.0744 77.8952 16.6883 77.8952 18.4186V23.8325H74.9371V13.2837ZM87.0487 24C84.0347 24 81.9696 22.2139 81.9696 18.6976V18.4744C81.9696 14.9581 84.1464 13.0046 86.9929 13.0046C89.6161 13.0046 91.7929 14.4558 91.7929 17.9721V19.2558H84.9836C85.0952 21.1535 85.9324 21.879 87.1603 21.879C88.2766 21.879 88.8905 21.2651 89.1138 20.5395H91.8487C91.4022 22.493 89.7836 24 87.0487 24ZM84.9278 17.3023H88.8905C88.8347 15.7395 88.1092 15.0697 86.9371 15.0697C86.044 15.1256 85.2068 15.6279 84.9278 17.3023Z",
                        fill: "currentColor"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_11275_169474",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 92,
                        height: 24,
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })
        ]
    });

;// CONCATENATED MODULE: ./src/components/logos/logo-att.tsx

const LogoAtt = (props)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 59,
        height: 24,
        viewBox: "0 0 59 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                clipPath: "url(#clip0_11275_169477)",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M54.162 16.81C54.0069 16.81 53.9 16.7017 53.9 16.5459V8.80852H51.2895C51.1342 8.80852 51.0272 8.70069 51.0272 8.54475V7.47745C51.0272 7.32116 51.1343 7.21304 51.2895 7.21304H58.2382C58.3933 7.21304 58.5 7.32128 58.5 7.47745V8.54469C58.5 8.70052 58.3933 8.80852 58.2382 8.80852H55.6279V16.5458C55.6279 16.7017 55.5205 16.81 55.3659 16.81H54.162ZM34.165 12.947L32.7946 8.98869L31.412 12.947H34.165ZM37.2043 16.4974C37.2642 16.6537 37.1687 16.81 37.0018 16.81H35.7625C35.5836 16.81 35.4762 16.7263 35.4164 16.5576L34.7135 14.5189H30.8642L30.16 16.5576C30.1009 16.7263 29.9932 16.81 29.8148 16.81H28.6472C28.492 16.81 28.3846 16.6537 28.4442 16.4974L31.6741 7.45346C31.7339 7.28497 31.8411 7.21345 32.0195 7.21345H33.6166C33.7956 7.21345 33.9148 7.28502 33.9743 7.45346L37.2043 16.4974ZM46.4624 15.5142C47.2248 15.5142 47.7376 15.1429 48.1548 14.5069L46.2243 12.4193C45.485 12.8395 45.0081 13.2588 45.0081 14.0988C45.0082 14.9266 45.6753 15.5142 46.4624 15.5142ZM46.9986 8.48456C46.379 8.48456 46.0215 8.8808 46.0215 9.40852C46.0215 9.81633 46.2356 10.1763 46.7245 10.7042C47.5706 10.212 47.9283 9.91231 47.9283 9.38464C47.9283 8.89242 47.6186 8.48456 46.9986 8.48456ZM52.279 16.4741C52.4337 16.6422 52.3386 16.81 52.1474 16.81H50.6337C50.4312 16.81 50.3239 16.7618 50.1929 16.6057L49.2871 15.5984C48.6793 16.4142 47.8324 17.0258 46.4264 17.0258C44.6864 17.0258 43.3153 15.9703 43.3153 14.1592C43.3153 12.7673 44.0547 12.0234 45.1752 11.3997C44.6265 10.764 44.3767 10.0922 44.3767 9.50468C44.3767 8.01679 45.4135 6.99731 46.9745 6.99731C48.5717 6.99731 49.5492 7.94533 49.5492 9.34856C49.5492 10.5482 48.6912 11.2193 47.7851 11.7235L49.1202 13.1755L49.8709 11.8555C49.9662 11.6998 50.0735 11.6396 50.264 11.6396H51.4198C51.6108 11.6396 51.7181 11.7719 51.5993 11.9757L50.2641 14.2785L52.279 16.4741ZM40.3845 16.81C40.5395 16.81 40.6473 16.7017 40.6473 16.5459V8.80852H43.257C43.412 8.80852 43.5191 8.70069 43.5191 8.54475V7.47745C43.5191 7.32116 43.412 7.21304 43.257 7.21304H36.3083C36.1531 7.21304 36.0461 7.32128 36.0461 7.47745V8.54469C36.0461 8.70052 36.1532 8.80852 36.3083 8.80852H38.918V16.5458C38.918 16.7017 39.0257 16.81 39.1804 16.81H40.3845Z",
                        fill: "currentColor"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M5.11134 21.4772C7.13263 23.0526 9.66969 23.9991 12.4223 23.9991C15.4345 23.9991 18.1806 22.8731 20.2764 21.0247C20.3018 21.0021 20.2893 20.9872 20.2642 21.0021C19.3238 21.6345 16.6434 23.015 12.4224 23.015C8.75417 23.015 6.436 22.1909 5.12688 21.4552C5.10183 21.4427 5.09256 21.4617 5.11134 21.4772ZM13.2316 22.0906C16.1655 22.0906 19.3895 21.2853 21.3177 19.6913C21.8454 19.2569 22.348 18.6789 22.7981 17.9021C23.0572 17.4551 23.3107 16.924 23.5171 16.402C23.5263 16.3766 23.5107 16.3642 23.4917 16.3928C21.6985 19.0497 16.5061 20.7069 11.1446 20.7069C7.35488 20.7069 3.27723 19.4867 1.6808 17.1568C1.66509 17.1353 1.64937 17.1445 1.65894 17.1692C3.14613 20.3519 7.65791 22.0906 13.2316 22.0906ZM10.026 16.8106C3.92405 16.8106 1.04685 13.9492 0.524933 11.9965C0.518497 11.9682 0.5 11.9744 0.5 11.9998C0.5 12.6572 0.565349 13.5055 0.677781 14.0686C0.731417 14.3427 0.952976 14.7729 1.27781 15.1158C2.75537 16.6665 6.43913 18.8394 12.8188 18.8394C21.5109 18.8394 23.4983 15.9241 23.9042 14.9654C24.1944 14.2798 24.3447 13.0407 24.3447 11.9998C24.3447 11.748 24.3385 11.5468 24.329 11.3493C24.329 11.3172 24.3106 11.3146 24.3042 11.3458C23.8698 13.6917 16.4435 16.8106 10.026 16.8106ZM1.64937 6.85206C1.29972 7.55073 0.912155 8.72942 0.796939 9.33946C0.746435 9.60084 0.767947 9.72636 0.858983 9.92142C1.59034 11.4838 5.2897 13.9836 13.9189 13.9836C19.1833 13.9836 23.2728 12.6814 23.9354 10.3051C24.0574 9.86759 24.0639 9.40572 23.9072 8.78336C23.7321 8.08791 23.4041 7.27691 23.1265 6.70745C23.1174 6.68888 23.1012 6.69163 23.1045 6.71358C23.2076 9.8304 14.575 11.8392 10.2194 11.8392C5.50146 11.8392 1.56541 9.94652 1.56541 7.55668C1.56541 7.32706 1.61261 7.09738 1.67152 6.85837C1.67744 6.83653 1.65888 6.83291 1.64937 6.85206ZM20.2957 3.02524C20.3458 3.10429 20.3708 3.18866 20.3708 3.30221C20.3708 4.63544 16.3182 6.99399 9.86701 6.99399C5.12688 6.99399 4.23943 5.22347 4.23943 4.0975C4.23943 3.69501 4.39274 3.28318 4.73039 2.86492C4.74882 2.84005 4.73317 2.83048 4.71189 2.84899C4.09609 3.37443 3.53028 3.96567 3.03393 4.60391C2.79677 4.90575 2.64955 5.17315 2.64955 5.33335C2.64955 7.66673 8.46054 9.35855 13.894 9.35855C19.6834 9.35855 22.2672 7.45562 22.2672 5.78331C22.2672 5.18564 22.0361 4.83674 21.445 4.16032C21.0613 3.72029 20.6984 3.36199 20.3143 3.0093C20.2957 2.99389 20.2828 3.00644 20.2957 3.02524ZM18.5209 1.69231C16.7341 0.613975 14.6593 0.000488281 12.4224 0.000488281C10.1699 0.000488281 8.03255 0.635401 6.23938 1.74228C5.70151 2.07559 5.39877 2.34269 5.39877 2.68604C5.39877 3.69816 7.74802 4.78642 11.9159 4.78642C16.0405 4.78642 19.2396 3.59442 19.2396 2.44702C19.2396 2.17315 19.0019 1.98153 18.5209 1.69231Z",
                        fill: "currentColor"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_11275_169477",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 58,
                        height: 24,
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })
        ]
    });

;// CONCATENATED MODULE: ./src/components/logos/logo-aws.tsx

const LogoAws = (props)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 41,
        height: 24,
        viewBox: "0 0 41 24",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                clipPath: "url(#clip0_11275_169470)",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        d: "M11.9542 8.75601C11.9542 9.24392 12.007 9.63953 12.0993 9.92963C12.2048 10.2197 12.3366 10.5362 12.5213 10.8791C12.5872 10.9846 12.6136 11.0901 12.6136 11.1824C12.6136 11.3143 12.5345 11.4461 12.363 11.578L11.5323 12.1318C11.4136 12.211 11.2949 12.2505 11.1894 12.2505C11.0575 12.2505 10.9257 12.1846 10.7938 12.0659C10.6092 11.8681 10.4509 11.6571 10.3191 11.4461C10.1872 11.2219 10.0553 10.9714 9.91028 10.6681C8.88171 11.8813 7.5894 12.4879 6.03335 12.4879C4.92566 12.4879 4.04214 12.1714 3.39599 11.5384C2.74984 10.9055 2.42017 10.0615 2.42017 9.00656C2.42017 7.88568 2.81577 6.97579 3.62017 6.29007C4.42456 5.60436 5.49269 5.2615 6.85094 5.2615C7.29929 5.2615 7.76083 5.30106 8.24874 5.367C8.73665 5.43293 9.23775 5.53843 9.76522 5.65711V4.69447C9.76522 3.69227 9.55423 2.99337 9.14544 2.58458C8.72346 2.17579 8.01137 1.97799 6.99599 1.97799C6.53445 1.97799 6.05973 2.03073 5.57181 2.14941C5.0839 2.2681 4.60918 2.41315 4.14764 2.59777C3.93665 2.69007 3.77841 2.74282 3.6861 2.7692C3.59379 2.79557 3.52786 2.80876 3.47511 2.80876C3.2905 2.80876 3.19819 2.67689 3.19819 2.39996V1.75381C3.19819 1.54282 3.22456 1.38458 3.2905 1.29227C3.35643 1.19996 3.47511 1.10766 3.65973 1.01535C4.12126 0.777987 4.67511 0.580184 5.32126 0.421943C5.96742 0.250514 6.65313 0.171393 7.37841 0.171393C8.94764 0.171393 10.0949 0.527437 10.8334 1.23952C11.5586 1.95161 11.9279 3.03293 11.9279 4.48348V8.75601H11.9542ZM6.60039 10.7604C7.03555 10.7604 7.4839 10.6813 7.95863 10.523C8.43335 10.3648 8.85533 10.0747 9.21138 9.67909C9.42236 9.42854 9.58061 9.15161 9.65973 8.83513C9.73885 8.51865 9.7916 8.13623 9.7916 7.68788V7.13403C9.40918 7.04172 9.00039 6.9626 8.57841 6.90985C8.15643 6.85711 7.74764 6.83073 7.33885 6.83073C6.45533 6.83073 5.80918 7.00216 5.37401 7.35821C4.93885 7.71425 4.72786 8.21535 4.72786 8.87469C4.72786 9.49447 4.8861 9.95601 5.21577 10.2725C5.53225 10.6022 5.99379 10.7604 6.60039 10.7604ZM17.1894 12.1846C16.952 12.1846 16.7938 12.145 16.6883 12.0527C16.5828 11.9736 16.4905 11.789 16.4114 11.5384L13.3125 1.34502C13.2334 1.08128 13.1938 0.909855 13.1938 0.817547C13.1938 0.606558 13.2993 0.487877 13.5103 0.487877H14.8026C15.0531 0.487877 15.2246 0.527437 15.3169 0.619745C15.4224 0.698866 15.5015 0.883481 15.5806 1.13403L17.796 9.8637L19.8531 1.13403C19.9191 0.870294 19.9982 0.698866 20.1037 0.619745C20.2092 0.540624 20.3938 0.487877 20.6312 0.487877H21.6861C21.9366 0.487877 22.1081 0.527437 22.2136 0.619745C22.3191 0.698866 22.4114 0.883481 22.4641 1.13403L24.5476 9.96919L26.829 1.13403C26.9081 0.870294 27.0004 0.698866 27.0927 0.619745C27.1982 0.540624 27.3696 0.487877 27.607 0.487877H28.8334C29.0443 0.487877 29.163 0.593371 29.163 0.817547C29.163 0.883481 29.1498 0.949415 29.1366 1.02854C29.1235 1.10766 29.0971 1.21315 29.0443 1.35821L25.8663 11.5516C25.7872 11.8153 25.6949 11.9868 25.5894 12.0659C25.4839 12.145 25.3125 12.1978 25.0883 12.1978H23.9542C23.7037 12.1978 23.5323 12.1582 23.4268 12.0659C23.3213 11.9736 23.229 11.8022 23.1762 11.5384L21.1323 3.03293L19.1015 11.5252C19.0356 11.789 18.9564 11.9604 18.8509 12.0527C18.7454 12.145 18.5608 12.1846 18.3235 12.1846H17.1894ZM34.1345 12.5406C33.4487 12.5406 32.763 12.4615 32.1037 12.3033C31.4443 12.145 30.9301 11.9736 30.5872 11.7758C30.3762 11.6571 30.2312 11.5252 30.1784 11.4066C30.1257 11.2879 30.0993 11.156 30.0993 11.0373V10.3648C30.0993 10.0879 30.2048 9.95601 30.4026 9.95601C30.4817 9.95601 30.5608 9.9692 30.6399 9.99557C30.7191 10.0219 30.8377 10.0747 30.9696 10.1274C31.418 10.3252 31.9059 10.4835 32.4202 10.589C32.9476 10.6945 33.4619 10.7472 33.9894 10.7472C34.8202 10.7472 35.4663 10.6022 35.9147 10.3121C36.363 10.0219 36.6004 9.59996 36.6004 9.0593C36.6004 8.69007 36.4817 8.38678 36.2443 8.13623C36.007 7.88568 35.5586 7.6615 34.9125 7.45051L33.0004 6.85711C32.0377 6.55381 31.3257 6.10546 30.8905 5.51205C30.4553 4.93183 30.2312 4.28568 30.2312 3.59996C30.2312 3.04612 30.3498 2.55821 30.5872 2.13623C30.8246 1.71425 31.141 1.34502 31.5366 1.05491C31.9323 0.751613 32.3806 0.527437 32.9081 0.369195C33.4356 0.210954 33.9894 0.14502 34.5696 0.14502C34.8597 0.14502 35.163 0.158206 35.4531 0.197767C35.7564 0.237327 36.0334 0.290074 36.3103 0.342822C36.574 0.408756 36.8246 0.47469 37.0619 0.553811C37.2993 0.632932 37.4839 0.712052 37.6158 0.791173C37.8004 0.896668 37.9323 1.00216 38.0114 1.12084C38.0905 1.22634 38.1301 1.37139 38.1301 1.55601V2.17579C38.1301 2.45271 38.0246 2.59777 37.8268 2.59777C37.7213 2.59777 37.5498 2.54502 37.3257 2.43952C36.574 2.09667 35.7301 1.92524 34.7938 1.92524C34.0421 1.92524 33.4487 2.04392 33.0399 2.29447C32.6312 2.54502 32.4202 2.92744 32.4202 3.4681C32.4202 3.83733 32.552 4.15381 32.8158 4.40436C33.0795 4.65491 33.5674 4.90546 34.2663 5.12964L36.1388 5.72304C37.0883 6.02634 37.774 6.44832 38.1828 6.98898C38.5916 7.52963 38.7894 8.14941 38.7894 8.83513C38.7894 9.40216 38.6707 9.91645 38.4465 10.3648C38.2092 10.8132 37.8927 11.2088 37.4839 11.5252C37.0751 11.8549 36.5872 12.0923 36.0202 12.2637C35.4268 12.4483 34.807 12.5406 34.1345 12.5406Z",
                        fill: "currentColor"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M36.6267 18.9495C32.2883 22.1539 25.985 23.855 20.5652 23.855C12.9696 23.855 6.12564 21.0462 0.956412 16.378C0.547621 16.0088 0.916852 15.5077 1.40476 15.7978C6.99597 19.0418 13.8927 21.0066 21.0267 21.0066C25.8399 21.0066 31.1278 20.0044 35.9938 17.9473C36.7191 17.6176 37.3388 18.422 36.6267 18.9495Z",
                        fill: "currentColor"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M38.4333 16.8924C37.8794 16.1803 34.7673 16.5495 33.3563 16.7209C32.9344 16.7737 32.8684 16.4045 33.2508 16.1275C35.73 14.3869 39.8047 14.888 40.2794 15.4682C40.7541 16.0616 40.1476 20.1363 37.8267 22.088C37.4706 22.3913 37.1278 22.233 37.286 21.8374C37.8135 20.5319 38.9871 17.5913 38.4333 16.8924Z",
                        fill: "currentColor"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_11275_169470",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 40,
                        height: 24,
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })
        ]
    });

;// CONCATENATED MODULE: ./src/components/logos/logo-bolt.tsx

const LogoBolt = (props)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 39,
        height: 22,
        viewBox: "0 0 39 22",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                clipPath: "url(#clip0_11275_169468)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    fillRule: "evenodd",
                    clipRule: "evenodd",
                    d: "M30.6523 0.500005V16.2887H26.8688V1.28944L30.6523 0.500005ZM19.8797 17.785C20.9245 17.785 21.7715 18.6166 21.7715 19.6425C21.7715 20.6683 20.9245 21.5 19.8797 21.5C18.8349 21.5 17.9879 20.6683 17.9879 19.6425C17.9879 18.6166 18.8349 17.785 19.8797 17.785ZM19.8797 4.98378C23.101 4.98378 25.718 7.54818 25.718 10.7162C25.718 13.8843 23.101 16.4487 19.8797 16.4487C16.6532 16.4487 14.0415 13.8843 14.0415 10.7162C14.0415 7.54818 16.6584 4.98378 19.8797 4.98378ZM19.8797 12.5737C20.9254 12.5737 21.7715 11.743 21.7715 10.7162C21.7715 9.68944 20.9254 8.85874 19.8797 8.85874C18.834 8.85874 17.9879 9.68944 17.9879 10.7162C17.9879 11.743 18.834 12.5737 19.8797 12.5737ZM7.97731 12.5737C8.62891 12.5737 9.15967 12.0526 9.15967 11.4128C9.15967 10.773 8.62891 10.2518 7.97731 10.2518H5.13963V12.5737H7.97731ZM5.13963 4.21499V6.53687H7.24161C7.89321 6.53687 8.42397 6.0157 8.42397 5.37592C8.42397 4.73612 7.89321 4.21499 7.24161 4.21499H5.13963ZM11.4613 7.9403C12.3757 8.82776 12.9432 10.0558 12.938 11.4128C12.938 14.1062 10.7152 16.2887 7.97206 16.2887H1.35083V0.5H7.23636C9.97946 0.5 12.2023 2.68256 12.2023 5.37592C12.2023 6.315 11.9343 7.19732 11.4613 7.9403ZM37.799 8.91034H35.9126V11.8256C35.9126 12.7079 36.2016 13.358 36.9582 13.358C37.447 13.358 37.8043 13.2496 37.8043 13.2496V15.9843C37.8043 15.9843 37.0213 16.4487 35.9598 16.4487H35.9126C35.8652 16.4487 35.8232 16.4435 35.7759 16.4435H35.7391C35.7181 16.4435 35.6918 16.4383 35.6708 16.4383C33.5583 16.33 32.1237 15.0245 32.1237 12.7595V3.14693L35.9073 2.35749V5.19533H37.799V8.91034Z",
                    fill: "currentColor"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_11275_169468",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 38,
                        height: 21,
                        fill: "white",
                        transform: "translate(0.5 0.5)"
                    })
                })
            })
        ]
    });

;// CONCATENATED MODULE: ./src/components/logos/logo-samsung.tsx

const LogoSamsung = (props)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 106,
        height: 16,
        viewBox: "0 0 106 16",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                clipPath: "url(#clip0_11275_169463)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M99.6098 7.02737V9.20543H101.136V11.3664C101.14 11.5595 101.13 11.7678 101.097 11.9344C101.036 12.3375 100.655 13.0238 99.5714 13.0238C98.4948 13.0238 98.12 12.3375 98.055 11.9344C98.0276 11.7678 98.016 11.5595 98.016 11.3664V4.54097C98.016 4.29953 98.0322 4.03528 98.0833 3.83527C98.1572 3.4715 98.4786 2.75411 99.5634 2.75411C100.702 2.75411 100.986 3.51043 101.052 3.83527C101.094 4.05043 101.097 4.41133 101.097 4.41133V5.24014H104.846V4.75018C104.846 4.75018 104.863 4.23894 104.818 3.76183C104.536 0.960353 102.235 0.0740204 99.5965 0.0740204C96.9533 0.0740204 94.699 0.968599 94.3706 3.76183C94.341 4.01726 94.2957 4.47672 94.2957 4.75018V11.0289C94.2957 11.3024 94.3045 11.5141 94.3549 12.0138C94.5996 14.7382 96.9533 15.7039 99.586 15.7039C102.235 15.7039 104.572 14.7382 104.821 12.0138C104.865 11.5141 104.87 11.3024 104.876 11.0289V7.02737H99.6098ZM73.7587 0.475766H69.9937V11.5239C69.9996 11.7164 69.9937 11.9327 69.9606 12.0913C69.8821 12.4622 69.5688 13.1759 68.53 13.1759C67.5047 13.1759 67.1831 12.4622 67.1105 12.0913C67.0728 11.9327 67.0681 11.7164 67.0728 11.5239V0.475766H63.309V11.181C63.3042 11.4569 63.3258 12.0207 63.342 12.1684C63.6018 14.958 65.7934 15.8637 68.53 15.8637C71.272 15.8637 73.4623 14.958 73.7268 12.1684C73.7477 12.0207 73.775 11.4569 73.7587 11.181V0.475766ZM39.1651 0.475766L37.287 12.1496L35.41 0.475766H29.3368L29.0147 15.4099H32.7353L32.8361 1.58493L35.396 15.4099H39.171L41.7333 1.58493L41.8344 15.4099H45.5644L45.2314 0.475766H39.1651ZM16.6791 0.475766L13.9215 15.4099H17.9428L20.0209 1.58493L22.0491 15.4099H26.0425L23.2964 0.475766H16.6791ZM86.9168 12.4995L83.411 0.475766H77.8866V15.2542H81.5411L81.3289 2.84577L85.094 15.2542H90.3923V0.475766H86.7138L86.9168 12.4995ZM53.113 4.36243C53.0469 4.0675 53.066 3.75416 53.1002 3.59039C53.2067 3.11233 53.5269 2.59092 54.4494 2.59092C55.3092 2.59092 55.8133 3.12862 55.8133 3.93557V4.84875H59.4835V3.80785C59.4835 0.590056 56.6078 0.084568 54.5257 0.084568C51.9034 0.084568 49.7619 0.951724 49.3708 3.37293C49.2673 4.03183 49.2417 4.61671 49.4063 5.36306C50.044 8.38199 55.283 9.25778 56.0435 11.167C56.1777 11.5286 56.1392 11.9898 56.0708 12.2616C55.9569 12.7584 55.6237 13.2582 54.636 13.2582C53.7096 13.2582 53.152 12.7239 53.152 11.9187L53.1509 10.4854H49.2004V11.6247C49.2004 14.9259 51.778 15.922 54.5542 15.922C57.213 15.922 59.409 15.0105 59.7613 12.5398C59.9293 11.2632 59.8026 10.4318 59.7351 10.1186C59.1196 7.0222 53.5357 6.0908 53.113 4.36243ZM4.69816 4.32581C4.62609 4.02474 4.64291 3.70698 4.68305 3.5413C4.78475 3.06554 5.10684 2.53492 6.04562 2.53492C6.91634 2.53492 7.42902 3.07781 7.42902 3.89127V4.81557H11.1422V3.76643C11.1422 0.517763 8.22251 0 6.11769 0C3.47341 0 1.31277 0.88058 0.917457 3.31924C0.809262 3.98869 0.790714 4.57759 0.94708 5.33218C1.59166 8.38545 6.8825 9.26833 7.65229 11.2003C7.79642 11.5595 7.75284 12.0207 7.68135 12.303C7.5592 12.805 7.22334 13.3119 6.22741 13.3119C5.29743 13.3119 4.74117 12.7684 4.74117 11.9521L4.736 10.515H0.741211V11.6569C0.741211 14.9959 3.35528 16 6.15305 16C8.84282 16 11.0516 15.0805 11.412 12.5812C11.5911 11.293 11.4567 10.4546 11.3963 10.1366C10.768 7.00225 5.12195 6.07393 4.69816 4.32581Z",
                    fill: "currentColor"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_11275_169463",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 105,
                        height: 16,
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })
        ]
    });

;// CONCATENATED MODULE: ./src/components/logos/logo-visma.tsx

const LogoVisma = (props)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        width: 91,
        height: 18,
        viewBox: "0 0 91 18",
        fill: "none",
        xmlns: "http://www.w3.org/2000/svg",
        ...props,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("g", {
                clipPath: "url(#clip0_11275_169465)",
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M10.069 0.720459C14.9116 1.18915 20.2229 3.61017 23.2694 7.12535C27.1746 11.5774 25.8472 16.0299 20.301 17.0449C14.7554 18.1385 7.10062 15.3269 3.19541 10.8743C0.227039 7.43726 0.305703 4.00075 3.03918 2.12653L18.4262 13.5302L10.069 0.720459Z",
                        fill: "currentColor"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("path", {
                        fillRule: "evenodd",
                        clipRule: "evenodd",
                        d: "M86.3013 17.0448L84.3489 9.2338C84.1135 8.29697 83.9578 7.35958 83.8021 6.50032H83.7235C83.5678 7.4377 83.4891 8.29696 83.2548 9.31191L81.3013 17.0448H77.9429L82.3955 0.798463H85.0514L89.7383 17.0448H86.3013ZM35.0632 0.798463L37.0161 8.60888C37.3286 9.54626 37.4067 10.4842 37.5629 11.3424H37.641C37.7973 10.4055 37.8754 9.46759 38.1097 8.53076L40.0626 0.798463H43.421L38.969 17.0448H36.3131L31.6267 0.798463H35.0632ZM45.8415 0.798463H49.0442V17.0448H45.8415V0.798463ZM67.1658 0.798463L68.8051 10.4061L70.1331 0.798463H74.4289L76.0693 17.0448H72.789L72.0078 5.32859L71.461 9.31191L70.1331 17.0448H67.6339L66.0716 9.2338L65.5248 5.64105V5.32859H65.4467L64.978 17.0448H61.541L62.9476 0.798463H67.1658ZM57.0114 0.798463C56.4646 1.18904 56.0745 1.89152 55.7621 2.59456C54.9028 4.54744 55.8397 6.10919 56.6208 7.51526C56.6995 7.67149 56.8562 7.90584 56.9333 8.14019C58.7299 11.108 59.3548 13.2947 58.1055 16.4187L57.7931 17.0442H53.8873C54.356 16.6531 54.8242 16.1074 55.0585 15.4819C55.9964 13.3728 54.9028 11.4205 53.8873 9.46704C52.7161 7.20225 51.4658 4.85935 52.7937 1.65663C52.8724 1.34417 53.1848 0.797363 53.1848 0.797363H57.0114V0.798463Z",
                        fill: "currentColor"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_11275_169465",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        width: 90,
                        height: 18,
                        fill: "white",
                        transform: "translate(0.5)"
                    })
                })
            })
        ]
    });

;// CONCATENATED MODULE: ./src/sections/home/home-reviews.tsx
















const QuotesIcon = ()=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
        fill: "none",
        height: "79",
        viewBox: "0 0 105 79",
        width: "105",
        xmlns: "http://www.w3.org/2000/svg",
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("g", {
                clipPath: "url(#clip0_17690_94764)",
                children: /*#__PURE__*/ jsx_runtime_.jsx("path", {
                    d: "M25.086 78.1818C20.265 78.1818 15.971 76.9768 12.204 74.5658C8.437 72.0048 5.424 68.4638 3.164 63.9438C1.054 59.4238 0 54.3008 0 48.5758C0 43.3028 0.904 38.1798 2.712 33.2078C4.671 28.2358 7.458 23.6408 11.074 19.4218C14.6576 15.0819 18.8433 11.2767 23.504 8.12177C28.325 4.80677 33.599 2.39677 39.324 0.889771L50.398 14.6758C43.919 17.2368 38.721 20.6268 34.804 24.8458C31.037 29.0648 29.154 32.6808 29.154 35.6938C29.154 37.0498 29.531 38.5568 30.284 40.2138C31.188 41.7208 32.921 43.3028 35.482 44.9598C39.249 47.3698 41.81 49.9318 43.166 52.6438C44.673 55.2048 45.426 58.1438 45.426 61.4578C45.426 66.5808 43.467 70.6478 39.55 73.6618C35.783 76.6748 30.962 78.1818 25.086 78.1818V78.1818ZM79.326 78.1818C74.505 78.1818 70.211 76.9768 66.444 74.5658C62.677 72.0048 59.664 68.4638 57.404 63.9438C55.294 59.4238 54.24 54.3008 54.24 48.5758C54.24 43.3028 55.144 38.1798 56.952 33.2078C58.911 28.2358 61.698 23.6408 65.314 19.4218C68.8976 15.0819 73.0833 11.2767 77.744 8.12177C82.565 4.80677 87.839 2.39677 93.564 0.889771L104.638 14.6758C98.159 17.2368 92.961 20.6268 89.044 24.8458C85.277 29.0648 83.394 32.6808 83.394 35.6938C83.394 37.0498 83.771 38.5568 84.524 40.2138C85.428 41.7208 87.161 43.3028 89.722 44.9598C93.489 47.3698 96.05 49.9318 97.406 52.6438C98.913 55.2048 99.666 58.1438 99.666 61.4578C99.666 66.5808 97.707 70.6478 93.79 73.6618C90.023 76.6748 85.202 78.1818 79.326 78.1818V78.1818Z",
                    fill: "black",
                    fillOpacity: "0.04"
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("defs", {
                children: /*#__PURE__*/ jsx_runtime_.jsx("clipPath", {
                    id: "clip0_17690_94764",
                    children: /*#__PURE__*/ jsx_runtime_.jsx("rect", {
                        fill: "white",
                        height: "78.0005",
                        transform: "translate(0 0.889771)",
                        width: "105"
                    })
                })
            })
        ]
    });
const reviews = [
    {
        author: "Oded R.",
        message: "I'm highly satisfied with our decision to use this template. It's actually 2 for 1 - we got a beautiful design(responsive, looks great with so many different options and components) AND we got an excellent source code with an actual project [...]",
        stars: 5
    },
    {
        author: "Mark S.",
        message: "I really like the depth and quality with this template. Well constructed and a very useful source of ideas and best practices. I highly recommend it.",
        stars: 5
    },
    {
        author: "Lorenz N.",
        message: "It comes packed with probably more components and feature samples than you will ever need in a single App. The code is well structured and the documentation covers all essential parts. They are maybe not covering [...]",
        stars: 5
    },
    {
        author: "Ruthy G.",
        message: "I received a kind, considerate and immediate response, thank you very much!",
        stars: 5
    },
    {
        author: "Dean H.",
        message: "While many templates are next.js, the support is quick and AMAZING and I was able to port this to using react-router v6. Very happy with the quality of everything!!!",
        stars: 5
    },
    {
        author: "Cole S.",
        message: "Great template and great customer support. Easy to customize, code is easy to read, documentation is good. Very happy!",
        stars: 5
    }
];
const HomeReviews = ()=>/*#__PURE__*/ jsx_runtime_.jsx("div", {
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Container_default()), {
            maxWidth: "lg",
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    justifyContent: "center",
                    spacing: 3,
                    sx: {
                        py: 3
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            align: "center",
                            color: "text.secondary",
                            variant: "body2",
                            children: "Used by companies like:"
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            flexWrap: "wrap",
                            gap: 4,
                            justifyContent: "center",
                            sx: {
                                color: "action.active",
                                "& > *": {
                                    flex: "0 0 auto"
                                }
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx(LogoSamsung, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(LogoVisma, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(LogoBolt, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(LogoAws, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(LogoAccenture, {}),
                                /*#__PURE__*/ jsx_runtime_.jsx(LogoAtt, {})
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    spacing: 8,
                    sx: {
                        py: "120px"
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    align: "center",
                                    variant: "h3",
                                    children: "Loved by businesses worldwide."
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    align: "center",
                                    color: "text.secondary",
                                    variant: "subtitle1",
                                    children: "Our template is so simple that people can’t help but fall in love with it. Simplicity is easy when you just skip tons of mission-critical features."
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            container: true,
                            spacing: 3,
                            children: reviews.map((review, index)=>/*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                    xs: 12,
                                    md: 6,
                                    lg: 4,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                                        sx: {
                                            height: "100%"
                                        },
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                                            sx: {
                                                display: "flex",
                                                flexDirection: "column",
                                                position: "relative",
                                                height: "100%"
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                    sx: {
                                                        position: "absolute"
                                                    },
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(QuotesIcon, {})
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Rating_default()), {
                                                        readOnly: true,
                                                        sx: {
                                                            color: "success.main"
                                                        },
                                                        value: review.stars
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    sx: {
                                                        flexGrow: 1,
                                                        mt: 2
                                                    },
                                                    children: review.message
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                                                    sx: {
                                                        my: 2
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    color: "text.secondary",
                                                    children: review.author
                                                })
                                            ]
                                        })
                                    })
                                }, index))
                        })
                    ]
                })
            ]
        })
    });

;// CONCATENATED MODULE: ./src/app/marketing/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 







const Page = ()=>{
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(HomeHero, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(HomeFeatures, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(HomeReviews, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(HomeCta, {}),
                    /*#__PURE__*/ jsx_runtime_.jsx(HomeFaqs, {})
                ]
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 903268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.usePathname)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 343638:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,3380,4755,5006,408,109,2210,7680,4018], () => (__webpack_exec__(114682)));
module.exports = __webpack_exports__;

})();