(() => {
var exports = {};
exports.id = 3581;
exports.ids = [3581];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 285438:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'marketing',
        {
        children: [
        'components',
        {
        children: [
        'lists',
        {
        children: [
        'grid-lists',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 410761, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/lists/grid-lists/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 586068)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/lists/grid-lists/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/marketing/components/lists/grid-lists/page"
  

/***/ }),

/***/ 895343:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 124444))

/***/ }),

/***/ 124444:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/layouts/components/index.ts + 2 modules
var components = __webpack_require__(898394);
// EXTERNAL MODULE: ./src/sections/components/previewer.tsx
var previewer = __webpack_require__(213718);
// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardMedia/index.js
var CardMedia = __webpack_require__(823359);
var CardMedia_default = /*#__PURE__*/__webpack_require__.n(CardMedia);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Chip/index.js
var Chip = __webpack_require__(829553);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
;// CONCATENATED MODULE: ./src/sections/components/grid-lists/grid-list-1.tsx










const now = new Date();
const posts = [
    {
        id: "24b76cac9a128cd949747080",
        author: {
            avatar: "/assets/avatars/avatar-jie-yan-song.png",
            name: "Jie Yan Song"
        },
        category: "Programming",
        cover: "/assets/covers/business-2-4x4-large.png",
        publishedAt: (0,date_fns.subMinutes)((0,date_fns.subSeconds)(now, 16), 45).getTime(),
        readTime: "5 min",
        shortDescription: "Aliquam dapibus elementum nulla at malesuada. Ut mi nisl, aliquet non mollis vel, feugiat non nibh. Vivamus sit amet tristique dui. Praesent in bibendum arcu, at placerat augue. Nam varius fermentum diam, at tristique libero ultrices non. Praesent scelerisque diam vitae posuere dignissim. In et purus ac sapien posuere accumsan sit amet id diam. Pellentesque sit amet nulla ante. Maecenas nec leo vitae quam volutpat pretium id vitae augue.",
        title: "Why I Still Lisp, and You Should Too"
    },
    {
        id: "a9c19d0caf2ca91020aacd1f",
        author: {
            avatar: "/assets/avatars/avatar-omar-darboe.png",
            name: "Omar Darobe"
        },
        category: "Productivity",
        cover: "/assets/covers/minimal-1-4x4-small.png",
        publishedAt: (0,date_fns.subHours)((0,date_fns.subMinutes)((0,date_fns.subSeconds)(now, 29), 51), 6).getTime(),
        readTime: "6 min",
        shortDescription: "Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Morbi in turpis ac quam luctus interdum. Nullam ac lorem ligula. Integer sed massa bibendum, blandit ipsum et, iaculis augue. Curabitur nec enim eget dolor tincidunt posuere eget nec dolor. Ut ullamcorper dignissim arcu vel laoreet. Sed ligula dolor, vulputate quis eros ac, maximus pharetra orci. Aenean lobortis volutpat vehicula. Suspendisse vel nunc enim. Cras ultrices metus libero, non aliquam diam condimentum vel. Vestibulum arcu leo, consectetur id diam a, semper elementum odio. Proin eleifend volutpat sapien tempor bibendum. Etiam sagittis nulla sit amet aliquam sollicitudin.",
        title: "Scrum Has Hit the Glass Ceiling"
    },
    {
        id: "44df90cbf89963b8aa625c7d",
        author: {
            avatar: "/assets/avatars/avatar-siegbert-gottfried.png",
            name: "Siegbert Gottfried"
        },
        category: "Entrepreneurs",
        cover: "/assets/covers/business-2-4x4-small.png",
        publishedAt: (0,date_fns.subHours)((0,date_fns.subMinutes)((0,date_fns.subSeconds)(now, 6), 46), 16).getTime(),
        readTime: "3 min",
        shortDescription: "Praesent eget leo mauris. Morbi ac vulputate nibh. In hac habitasse platea dictumst. Praesent fermentum lacus eleifend erat cursus, congue rhoncus mi porta. Mauris rhoncus mollis nisl, vitae tempus tortor. Proin sit amet feugiat felis. Donec nunc urna, pretium sed viverra vel, blandit at urna. Integer pharetra placerat mauris, at fringilla arcu dignissim a. Morbi nec fermentum purus. Integer vel justo interdum lectus euismod bibendum.",
        title: "How Model View Controller (MVC) Architectures Work"
    }
];
const GridList1 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
            container: true,
            spacing: 3,
            children: posts.map((post)=>/*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    xs: 12,
                    md: 4,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                        sx: {
                            height: "100%",
                            p: 2
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    pt: "calc(100% * 4 / 4)",
                                    position: "relative"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((CardMedia_default()), {
                                    image: post.cover,
                                    sx: {
                                        height: "100%",
                                        position: "absolute",
                                        top: 0,
                                        width: "100%"
                                    }
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    mt: 2
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                                            label: post.category,
                                            variant: "outlined"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                        sx: {
                                            display: "flex",
                                            alignItems: "center",
                                            my: 2
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                src: post.author.avatar
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                                sx: {
                                                    ml: 2
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "subtitle2",
                                                        children: post.author.name
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        color: "text.secondary",
                                                        variant: "caption",
                                                        children: `${(0,date_fns.format)(post.publishedAt, "dd MMM")} · ${post.readTime} read`
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                        color: "text.primary",
                                        variant: "h6",
                                        children: post.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        sx: {
                                            height: 72,
                                            mt: 1,
                                            overflow: "hidden",
                                            textOverflow: "ellipsis",
                                            WebkitBoxOrient: "vertical",
                                            WebkitLineClamp: 2
                                        },
                                        variant: "body1",
                                        children: post.shortDescription
                                    })
                                ]
                            })
                        ]
                    })
                }, post.id))
        })
    });

// EXTERNAL MODULE: ./node_modules/numeral/numeral.js
var numeral = __webpack_require__(518470);
var numeral_default = /*#__PURE__*/__webpack_require__.n(numeral);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Heart.js
var Heart = __webpack_require__(711304);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Users01.js
var Users01 = __webpack_require__(906668);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Rating/index.js
var Rating = __webpack_require__(247022);
var Rating_default = /*#__PURE__*/__webpack_require__.n(Rating);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tooltip/index.js
var Tooltip = __webpack_require__(556020);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip);
;// CONCATENATED MODULE: ./src/sections/components/grid-lists/grid-list-2.tsx


















const grid_list_2_now = new Date();
const projects = [
    {
        id: "5e8dcef8f95685ce21f16f3d",
        author: {
            id: "5e887b7602bdbc4dbb234b27",
            avatar: "/assets/avatars/avatar-jie-yan-song.png",
            name: "Jie Yan Song"
        },
        budget: 6125.0,
        caption: "We're looking for experienced Developers and Product Designers to come aboard and help us build succesful businesses through software.",
        currency: "$",
        isLiked: true,
        likes: 7,
        location: "Europe",
        image: "/assets/covers/abstract-2-4x4-small.png",
        rating: 5,
        membersCount: 2,
        title: "Mella Full Screen Slider",
        type: "Full-Time",
        updatedAt: (0,date_fns.subMinutes)(grid_list_2_now, 24).getTime()
    },
    {
        id: "5e8dcf076c50b9d8e756a5a2",
        author: {
            id: "5e887d0b3d090c1b8f162003",
            avatar: "/assets/avatars/avatar-omar-darboe.png",
            name: "Omar Darobe"
        },
        budget: 4205.0,
        caption: "We're looking for experienced Developers and Product Designers to come aboard and help us build succesful businesses through software.",
        currency: "$",
        isLiked: true,
        likes: 12,
        location: "Europe",
        image: "/assets/covers/business-1-4x4-small.png",
        rating: 4.5,
        membersCount: 3,
        title: "Overview Design",
        type: "Full-Time",
        updatedAt: (0,date_fns.subHours)(grid_list_2_now, 1).getTime()
    },
    {
        id: "5e8dcf105a6732b3ed82cf7a",
        author: {
            id: "5e88792be2d4cfb4bf0971d9",
            avatar: "/assets/avatars/avatar-siegbert-gottfried.png",
            name: "Siegbert Gottfried"
        },
        budget: 2394.0,
        caption: "We're looking for experienced Developers and Product Designers to come aboard and help us build succesful businesses through software.",
        currency: "$",
        isLiked: true,
        likes: 18,
        location: "Europe",
        image: "/assets/covers/minimal-2-4x4-small.png",
        rating: 4.7,
        membersCount: 8,
        title: "Ten80 Web Design",
        type: "Full-Time",
        updatedAt: (0,date_fns.subHours)(grid_list_2_now, 16).getTime()
    }
];
const GridList2 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
            container: true,
            spacing: 3,
            children: projects.map((project)=>{
                const updatedAgo = (0,date_fns.formatDistanceToNowStrict)(project.updatedAt);
                const budget = numeral_default()(project.budget).format(`${project.currency}0,0.00`);
                return /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    xs: 12,
                    md: 4,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    p: 2
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((CardMedia_default()), {
                                        image: project.image,
                                        sx: {
                                            backgroundColor: "neutral.50",
                                            height: 200
                                        }
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                        sx: {
                                            alignItems: "center",
                                            display: "flex",
                                            mt: 2
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                src: project.author.avatar
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                                sx: {
                                                    ml: 2
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        color: "text.primary",
                                                        variant: "h6",
                                                        children: project.title
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                        color: "text.secondary",
                                                        variant: "body2",
                                                        children: [
                                                            "by",
                                                            " ",
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                                color: "text.primary",
                                                                variant: "subtitle2",
                                                                children: project.author.name
                                                            }),
                                                            " ",
                                                            "| Updated ",
                                                            updatedAgo,
                                                            " ago"
                                                        ]
                                                    })
                                                ]
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    pb: 2,
                                    px: 3
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "body2",
                                    children: project.caption
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    px: 3,
                                    py: 2
                                },
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    justifyContent: "space-between",
                                    spacing: 3,
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "subtitle2",
                                                    children: budget
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    color: "text.secondary",
                                                    variant: "body2",
                                                    children: "Budget"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "subtitle2",
                                                    children: project.location
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    color: "text.secondary",
                                                    variant: "body2",
                                                    children: "Location"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "subtitle2",
                                                    children: project.type
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    color: "text.secondary",
                                                    variant: "body2",
                                                    children: "Type"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    alignItems: "center",
                                    display: "flex",
                                    pl: 2,
                                    pr: 3,
                                    py: 2
                                },
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                        sx: {
                                            alignItems: "center",
                                            display: "flex"
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                                title: "Unlike",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                        sx: {
                                                            color: "error.main",
                                                            "& path": {
                                                                fill: (theme)=>theme.palette.error.main,
                                                                fillOpacity: 1
                                                            }
                                                        },
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Heart/* default */.Z, {})
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "subtitle2",
                                                children: project.likes
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                        sx: {
                                            alignItems: "center",
                                            display: "flex",
                                            ml: 2
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Users01/* default */.Z, {})
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                sx: {
                                                    ml: 1
                                                },
                                                variant: "subtitle2",
                                                children: project.membersCount
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                        sx: {
                                            flexGrow: 1
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Rating_default()), {
                                        readOnly: true,
                                        size: "small",
                                        value: project.rating
                                    })
                                ]
                            })
                        ]
                    })
                }, project.id);
            })
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/FileCheck03.js
var FileCheck03 = __webpack_require__(429283);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Download01.js
var Download01 = __webpack_require__(24165);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/DotsHorizontal.js
var DotsHorizontal = __webpack_require__(66519);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardActions/index.js
var CardActions = __webpack_require__(640362);
var CardActions_default = /*#__PURE__*/__webpack_require__.n(CardActions);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
// EXTERNAL MODULE: ./src/utils/bytes-to-size.ts
var bytes_to_size = __webpack_require__(98323);
;// CONCATENATED MODULE: ./src/sections/components/grid-lists/grid-list-3.tsx

















const files = [
    {
        id: "5e8dd0721b9e0fab56d7238b",
        mimeType: "image/png",
        name: "example-project1.png",
        size: 1024 * 1024 * 3,
        url: "/assets/covers/abstract-2-4x4-small.png"
    },
    {
        id: "5e8dd0784431995a30eb2586",
        mimeType: "application/zip",
        name: "docs.zip",
        size: 1024 * 1024 * 25,
        url: "#"
    },
    {
        id: "5e8dd07cbb62749296ecee1c",
        mimeType: "image/png",
        name: "example-project2.png",
        size: 1024 * 1024 * 2,
        url: "/assets/covers/minimal-2-4x4-small.png"
    }
];
const GridList3 = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
            container: true,
            spacing: 3,
            children: files.map((file)=>{
                const isImage = file.mimeType.includes("image/");
                return /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    md: 4,
                    xs: 12,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                        children: [
                            isImage ? /*#__PURE__*/ jsx_runtime_.jsx((CardMedia_default()), {
                                image: file.url,
                                sx: {
                                    height: 140
                                }
                            }) : /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    alignItems: "center",
                                    backgroundColor: "neutral.50",
                                    color: "common.black",
                                    display: "flex",
                                    height: 140,
                                    justifyContent: "center"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(FileCheck03/* default */.Z, {})
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                                sx: {
                                    display: "flex",
                                    justifyContent: "space-between"
                                },
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "subtitle2",
                                                children: file.name
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "caption",
                                                children: (0,bytes_to_size/* bytesToSize */.R)(file.size)
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                            title: "More options",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                edge: "end",
                                                size: "small",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                                                })
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                                sx: {
                                    justifyContent: "center"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    color: "inherit",
                                    size: "small",
                                    startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Download01/* default */.Z, {})
                                    }),
                                    children: "Download"
                                })
                            })
                        ]
                    })
                }, file.id);
            })
        })
    });
};

;// CONCATENATED MODULE: ./src/sections/components/grid-lists/grid-list-4.tsx












const applicants = [
    {
        id: "5e887a62195cc5aef7e8ca5d",
        avatar: "/assets/avatars/avatar-marcus-finn.png",
        commonContacts: 12,
        cover: "/assets/covers/minimal-1-4x4-small.png",
        name: "Marcus Finn",
        skills: [
            "UX",
            "Frontend development",
            "HTML5",
            "VueJS",
            "ReactJS"
        ]
    },
    {
        id: "5e86809283e28b96d2d38537",
        avatar: "/assets/avatars/avatar-anika-visser.png",
        commonContacts: 17,
        cover: "/assets/covers/abstract-1-4x4-small.png",
        name: "Anika Visser",
        skills: [
            "Backend development",
            "Firebase",
            "MongoDB",
            "ExpressJS"
        ]
    },
    {
        id: "5e887ac47eed253091be10cb",
        avatar: "/assets/avatars/avatar-carson-darrin.png",
        commonContacts: 5,
        cover: "/assets/covers/minimal-2-4x4-small.png",
        name: "Carson Darrin",
        skills: [
            "UI",
            "UX",
            "Full-Stack development",
            "Angular",
            "ExpressJS"
        ]
    }
];
const GridList4 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
            container: true,
            spacing: 3,
            children: applicants.map((applicant)=>/*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    md: 4,
                    xs: 12,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                        sx: {
                            height: "100%"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((CardMedia_default()), {
                                image: applicant.cover,
                                sx: {
                                    height: 200
                                }
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                                sx: {
                                    pt: 0
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                        sx: {
                                            display: "flex",
                                            justifyContent: "center",
                                            mb: 2,
                                            mt: "-50px"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                            alt: "Applicant",
                                            src: applicant.avatar,
                                            sx: {
                                                border: "3px solid #FFFFFF",
                                                height: 100,
                                                width: 100
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                        align: "center",
                                        color: "text.primary",
                                        sx: {
                                            display: "block"
                                        },
                                        underline: "none",
                                        variant: "h6",
                                        children: applicant.name
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                        align: "center",
                                        variant: "body2",
                                        color: "text.secondary",
                                        children: [
                                            applicant.commonContacts,
                                            " ",
                                            "contacts in common"
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                                        sx: {
                                            my: 2
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                        alignItems: "center",
                                        direction: "row",
                                        flexWrap: "wrap",
                                        gap: 0.5,
                                        children: applicant.skills.map((skill)=>/*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                                                label: skill,
                                                sx: {
                                                    m: 0.5
                                                },
                                                variant: "outlined"
                                            }, skill))
                                    })
                                ]
                            })
                        ]
                    })
                }, applicant.id))
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Clock.js
var Clock = __webpack_require__(477159);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Share07.js
var Share07 = __webpack_require__(738913);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardActionArea/index.js
var CardActionArea = __webpack_require__(55789);
var CardActionArea_default = /*#__PURE__*/__webpack_require__.n(CardActionArea);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
;// CONCATENATED MODULE: ./src/sections/components/grid-lists/grid-list-5.tsx


















const grid_list_5_now = new Date();
const grid_list_5_posts = [
    {
        id: "5e887faca2b7a1ddce01221a",
        author: {
            id: "5e86809283e28b96d2d38537",
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subHours)(grid_list_5_now, 4).getTime(),
        likes: 24,
        media: "/assets/covers/abstract-1-4x4-small.png",
        message: "Hey guys! What's your favorite framework?"
    },
    {
        id: "5e887faf03e78a5359765636",
        author: {
            id: "5e86809283e28b96d2d38537",
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        createdAt: (0,date_fns.subHours)(grid_list_5_now, 7).getTime(),
        likes: 65,
        media: "/assets/covers/minimal-1-4x3-small.png",
        message: "Just made this overview screen for a project, what-cha thinkin?"
    }
];
const GridList5 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
            container: true,
            spacing: 3,
            children: grid_list_5_posts.map((post)=>{
                const ago = (0,date_fns.formatDistanceToNowStrict)(post.createdAt);
                return /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    md: 6,
                    xs: 12,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                        sx: {
                            height: "100%"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                                avatar: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                    src: post.author.avatar
                                }),
                                disableTypography: true,
                                subheader: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 0.5,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            color: "action",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Clock/* default */.Z, {})
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "caption",
                                            children: [
                                                ago,
                                                " ago"
                                            ]
                                        })
                                    ]
                                }),
                                title: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                    color: "text.primary",
                                    variant: "subtitle2",
                                    children: post.author.name
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    pb: 2,
                                    px: 3
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "body1",
                                        children: post.message
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                        sx: {
                                            mt: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((CardActionArea_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((CardMedia_default()), {
                                                image: post.media,
                                                sx: {
                                                    backgroundPosition: "top",
                                                    height: 350
                                                }
                                            })
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                        sx: {
                                            alignItems: "center",
                                            display: "flex",
                                            mt: 2
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                                title: "Unlike",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                        sx: {
                                                            color: "error.main",
                                                            "& path": {
                                                                fill: (theme)=>theme.palette.error.main,
                                                                fillOpacity: 1
                                                            }
                                                        },
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Heart/* default */.Z, {})
                                                    })
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "subtitle2",
                                                children: post.likes
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                sx: {
                                                    flexGrow: 1
                                                }
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Share07/* default */.Z, {})
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }, post.id);
            })
        })
    });

;// CONCATENATED MODULE: ./src/sections/components/grid-lists/grid-list-6.tsx











const contacts = [
    {
        id: "5e887ac47eed253091be10cb",
        avatar: "/assets/avatars/avatar-carson-darrin.png",
        commonContacts: 10,
        name: "Carson Darrin",
        status: "Rejected"
    },
    {
        id: "5e887b209c28ac3dd97f6db5",
        avatar: "/assets/avatars/avatar-fran-perez.png",
        commonContacts: 8,
        name: "Fran Perez",
        status: "Pending"
    },
    {
        id: "5e86805e2bafd54f66cc95c3",
        avatar: "/assets/avatars/avatar-miron-vitold.png",
        commonContacts: 5,
        name: "Miron Vitold",
        status: "Not Connected"
    }
];
const GridList6 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
            spacing: 3,
            children: contacts.map((contact)=>/*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        sx: {
                            p: 2
                        },
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                src: contact.avatar,
                                sx: {
                                    height: 60,
                                    width: 60
                                }
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    flexGrow: 1
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                        color: "text.primary",
                                        variant: "h5",
                                        children: contact.name
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                        color: "text.secondary",
                                        gutterBottom: true,
                                        variant: "body2",
                                        children: [
                                            contact.commonContacts,
                                            " ",
                                            "connections in common"
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                        size: "small",
                                        variant: "outlined",
                                        children: contact.status
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                                })
                            })
                        ]
                    })
                }, contact.id))
        })
    });

;// CONCATENATED MODULE: ./src/app/marketing/components/lists/grid-lists/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 













const page_components = [
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GridList1, {}),
        title: "Grid list 1"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GridList2, {}),
        title: "Grid list 2"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GridList3, {}),
        title: "Grid list 3"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GridList4, {}),
        title: "Grid list 4"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GridList5, {}),
        title: "Grid list 5"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GridList6, {}),
        title: "Grid list 6"
    }
];
const Page = ()=>{
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Components: Grid Lists"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Layout */.A, {
                title: "Grid Lists",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "main",
                    sx: {
                        flexGrow: 1,
                        py: 8
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                        maxWidth: "lg",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                            spacing: 8,
                            children: page_components.map((component)=>/*#__PURE__*/ jsx_runtime_.jsx(previewer/* Previewer */.M, {
                                    title: component.title,
                                    children: component.element
                                }, component.title))
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 903268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.usePathname)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 488141:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ useSettings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34383);


const useSettings = ()=>(0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__/* .SettingsContext */ .J6);


/***/ }),

/***/ 98323:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "R": () => (/* binding */ bytesToSize)
/* harmony export */ });
/* eslint-disable no-restricted-properties */ const bytesToSize = (bytes, decimals = 2)=>{
    if (bytes === 0) {
        return "0 Bytes";
    }
    const k = 1024;
    const dm = decimals < 0 ? 0 : decimals;
    const sizes = [
        "Bytes",
        "KB",
        "MB",
        "GB",
        "TB",
        "PB",
        "EB",
        "ZB",
        "YB"
    ];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return `${parseFloat((bytes / Math.pow(k, i)).toFixed(dm))} ${sizes[i]}`;
};


/***/ }),

/***/ 410761:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/lists/grid-lists/page.tsx");


/***/ }),

/***/ 24165:
/***/ ((__unused_webpack___webpack_module__, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var _babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(369885);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(556786);




var Download01 = function Download01(props) {
  return /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsxs)("svg", (0,_babel_runtime_helpers_esm_extends__WEBPACK_IMPORTED_MODULE_2__/* ["default"] */ .Z)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "none"
  }, props, {
    children: [/*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
      fill: "#fff",
      fillOpacity: 0.01,
      d: "m17 10-5 5-5-5"
    }), /*#__PURE__*/(0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_1__.jsx)("path", {
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: 2,
      d: "M21 15v1.2c0 1.6802 0 2.5202-.327 3.162a2.9994 2.9994 0 0 1-1.311 1.311C18.7202 21 17.8802 21 16.2 21H7.8c-1.6802 0-2.5202 0-3.162-.327a2.9997 2.9997 0 0 1-1.311-1.311C3 18.7202 3 17.8802 3 16.2V15m14-5-5 5m0 0-5-5m5 5V3"
    })]
  }));
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Download01);

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,3380,4755,6609,5006,2983,8470,6519,5804,9283,6668,7680,4018,9274], () => (__webpack_exec__(285438)));
module.exports = __webpack_exports__;

})();