(() => {
var exports = {};
exports.id = 4582;
exports.ids = [4582];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 848626:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'marketing',
        {
        children: [
        'components',
        {
        children: [
        'lists',
        {
        children: [
        'grouped-lists',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 339157, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/lists/grouped-lists/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 586068)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/lists/grouped-lists/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/marketing/components/lists/grouped-lists/page"
  

/***/ }),

/***/ 400792:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 731082))

/***/ }),

/***/ 731082:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/layouts/components/index.ts + 2 modules
var components = __webpack_require__(898394);
// EXTERNAL MODULE: ./src/sections/components/previewer.tsx
var previewer = __webpack_require__(213718);
// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/DotsHorizontal.js
var DotsHorizontal = __webpack_require__(66519);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/List/index.js
var List = __webpack_require__(854436);
var List_default = /*#__PURE__*/__webpack_require__.n(List);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItem/index.js
var ListItem = __webpack_require__(790777);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemAvatar/index.js
var ListItemAvatar = __webpack_require__(372355);
var ListItemAvatar_default = /*#__PURE__*/__webpack_require__.n(ListItemAvatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemText/index.js
var ListItemText = __webpack_require__(846517);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
;// CONCATENATED MODULE: ./src/sections/components/grouped-lists/grouped-list-1.tsx

















const now = new Date();
const activities = [
    {
        id: "5e89140bcc768199d1e0dc49",
        createdAt: (0,date_fns.subMinutes)(now, 23).getTime(),
        customer: {
            id: "5e887a62195cc5aef7e8ca5d",
            avatar: "/assets/avatars/avatar-marcus-finn.png",
            name: "Marcus Finn"
        },
        description: "Created account",
        type: "register"
    },
    {
        id: "5e891411b0290b175166cd32",
        createdAt: (0,date_fns.subMinutes)(now, 56).getTime(),
        customer: {
            id: "5e887ac47eed253091be10cb",
            avatar: "/assets/avatars/avatar-carson-darrin.png",
            name: "Carson Darrin"
        },
        description: "Subscription Purchase",
        type: "payment"
    },
    {
        id: "5e89141633dc5e52c923ef27",
        createdAt: (0,date_fns.subHours)(now, 2).getTime(),
        customer: {
            id: "5e887b209c28ac3dd97f6db5",
            avatar: "/assets/avatars/avatar-fran-perez.png",
            name: "Fran Perez"
        },
        description: "Submitted a ticket",
        type: "ticket_create"
    },
    {
        id: "5e89141bd975c7f33aee9f4b",
        createdAt: (0,date_fns.subMinutes)(now, 5).getTime(),
        customer: {
            id: "5e887b7602bdbc4dbb234b27",
            avatar: "/assets/avatars/avatar-jie-yan-song.png",
            name: "Jie Yan Song"
        },
        description: "Subscription Purchase",
        type: "payment"
    },
    {
        id: "5e891421d7945778863cf9ca",
        createdAt: (0,date_fns.subMinutes)(now, 5).getTime(),
        customer: {
            id: "5e86809283e28b96d2d38537",
            avatar: "/assets/avatars/avatar-anika-visser.png",
            name: "Anika Visser"
        },
        description: "Subscription Purchase",
        type: "payment"
    }
];
const GroupedList1 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "sm",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        action: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                            })
                        }),
                        title: "Activity"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                        sx: {
                            display: "flex"
                        },
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    p: 3,
                                    flexGrow: 1,
                                    "&:first-of-type": {
                                        borderRight: (theme)=>`1px solid ${theme.palette.divider}`
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        align: "center",
                                        variant: "h5",
                                        children: "15,245"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        align: "center",
                                        color: "text.secondary",
                                        component: "h4",
                                        variant: "overline",
                                        children: "Registered"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    p: 3,
                                    flexGrow: 1,
                                    "&:first-of-type": {
                                        borderRight: (theme)=>`1px solid ${theme.palette.divider}`
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        align: "center",
                                        variant: "h5",
                                        children: "357"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        align: "center",
                                        color: "text.secondary",
                                        component: "h4",
                                        variant: "overline",
                                        children: "Online"
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                    /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                        disablePadding: true,
                        children: activities.map((activity, index)=>{
                            const showDivider = index < activities.length - 1;
                            const ago = (0,date_fns.formatDistanceToNowStrict)(activity.createdAt);
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                divider: showDivider,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                            src: activity.customer.avatar,
                                            sx: {
                                                cursor: "pointer"
                                            }
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                        disableTypography: true,
                                        primary: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                            color: "text.primary",
                                            sx: {
                                                cursor: "pointer"
                                            },
                                            underline: "none",
                                            variant: "subtitle2",
                                            children: activity.customer.name
                                        }),
                                        secondary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: activity.description
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                        color: "text.secondary",
                                        noWrap: true,
                                        variant: "caption",
                                        children: [
                                            ago,
                                            " ago"
                                        ]
                                    })
                                ]
                            }, activity.id);
                        })
                    })
                ]
            })
        })
    });

// EXTERNAL MODULE: ./node_modules/numeral/numeral.js
var numeral = __webpack_require__(518470);
var numeral_default = /*#__PURE__*/__webpack_require__.n(numeral);
;// CONCATENATED MODULE: ./src/sections/components/grouped-lists/grouped-list-2.tsx
















const referrals = [
    {
        color: "#455A64",
        initials: "GT",
        name: "GitHub",
        value: 53032
    },
    {
        color: "#00BCD4",
        initials: "TW",
        name: "Twitter",
        value: 39551
    },
    {
        color: "#3949AB",
        initials: "HN",
        name: "Hacker News",
        value: 23150
    },
    {
        color: "#F44336",
        initials: "SO",
        name: "Stack Overflow",
        value: 14093
    },
    {
        color: "#E65100",
        initials: "RD",
        name: "Reddit.com",
        value: 7251
    },
    {
        color: "#263238",
        initials: "DE",
        name: "Dev.to",
        value: 5694
    },
    {
        color: "#0D47A1",
        initials: "FB",
        name: "Facebook",
        value: 3643
    },
    {
        color: "#263238",
        initials: "MD",
        name: "Medium",
        value: 1654
    }
];
const GroupedList2 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "sm",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                sx: {
                    display: "flex",
                    flexDirection: "column"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        action: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                            })
                        }),
                        title: "Top Referrals"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                    /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                        disablePadding: true,
                        children: referrals.map((referral, index)=>{
                            const showDivider = index < referrals.length - 1;
                            const value = numeral_default()(referral.value).format("0,0");
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                divider: showDivider,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                            sx: {
                                                backgroundColor: referral.color,
                                                color: "common.white",
                                                fontSize: 14,
                                                fontWeight: 600
                                            },
                                            children: referral.initials
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                        primary: referral.name,
                                        primaryTypographyProps: {
                                            variant: "subtitle2"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: value
                                    })
                                ]
                            }, referral.name);
                        })
                    })
                ]
            })
        })
    });

// EXTERNAL MODULE: ./node_modules/@mui/material/node/AvatarGroup/index.js
var AvatarGroup = __webpack_require__(792438);
var AvatarGroup_default = /*#__PURE__*/__webpack_require__.n(AvatarGroup);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tooltip/index.js
var Tooltip = __webpack_require__(556020);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip);
// EXTERNAL MODULE: ./src/components/scrollbar.tsx
var scrollbar = __webpack_require__(851716);
;// CONCATENATED MODULE: ./src/sections/components/grouped-lists/grouped-list-3.tsx

















const grouped_list_3_now = new Date();
const tasks = [
    {
        id: "5eff24b501ba5281ddb5378c",
        deadline: (0,date_fns.addDays)((0,date_fns.addHours)(grouped_list_3_now, 1), 1).getTime(),
        members: [
            {
                avatar: "/assets/avatars/avatar-marcus-finn.png",
                name: "Marcus Finn"
            },
            {
                avatar: "/assets/avatars/avatar-carson-darrin.png",
                name: "Carson Darrin"
            }
        ],
        title: "Update the API for the project"
    },
    {
        id: "5eff24bb5bb3bd1beeddde78",
        deadline: (0,date_fns.addDays)((0,date_fns.addHours)(grouped_list_3_now, 1), 2).getTime(),
        members: [
            {
                avatar: "/assets/avatars/avatar-penjani-inyene.png",
                name: "Penjani Inyene"
            },
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                name: "Anika Visser"
            },
            {
                avatar: "/assets/avatars/avatar-nasimiyu-danai.png",
                name: "Nasimiyu Danai"
            }
        ],
        title: "Redesign the landing page"
    },
    {
        id: "5eff24c019175119993fc1ff",
        deadline: grouped_list_3_now.getTime(),
        members: [
            {
                avatar: "/assets/avatars/avatar-miron-vitold.png",
                name: "Miron Vitold"
            }
        ],
        title: "Solve the bug for the showState"
    },
    {
        id: "5eff24c52ce9fdadffa11959",
        deadline: null,
        members: [
            {
                avatar: "/assets/avatars/avatar-marcus-finn.png",
                name: "Marcus Finn"
            },
            {
                avatar: "/assets/avatars/avatar-siegbert-gottfried.png",
                name: "Siegbert Gottfried"
            }
        ],
        title: "Release v1.0 Beta"
    },
    {
        id: "5eff24ca3ffab939b667258b",
        deadline: null,
        members: [
            {
                avatar: "/assets/avatars/avatar-jie-yan-song.png",
                name: "Jie Yan Song"
            },
            {
                avatar: "/assets/avatars/avatar-marcus-finn.png",
                name: "Marcus Finn"
            },
            {
                avatar: "/assets/avatars/avatar-anika-visser.png",
                name: "Anika Visser"
            }
        ],
        title: "GDPR Compliance"
    },
    {
        id: "5eff24cf8740fc9faca4e463",
        deadline: null,
        members: [
            {
                avatar: "/assets/avatars/avatar-penjani-inyene.png",
                name: "Penjani Inyene"
            }
        ],
        title: "Redesign Landing Page"
    }
];
const getDeadline = (task)=>{
    let deadline = "";
    if (task.deadline) {
        const deadlineDate = task.deadline;
        if ((0,date_fns.isAfter)(deadlineDate, grouped_list_3_now) && (0,date_fns.differenceInDays)(deadlineDate, grouped_list_3_now) < 3) {
            deadline = `${(0,date_fns.differenceInDays)(deadlineDate, grouped_list_3_now)} days remaining`;
        }
    }
    return deadline;
};
const GroupedList3 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    action: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                        })
                    }),
                    title: "Team Tasks"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                        sx: {
                            minWidth: 400
                        },
                        children: tasks.map((task, index)=>{
                            const showDivider = index < tasks.length - 1;
                            const deadline = getDeadline(task);
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                divider: showDivider,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                        primary: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                            color: "text.primary",
                                            noWrap: true,
                                            sx: {
                                                cursor: "pointer"
                                            },
                                            variant: "subtitle2",
                                            children: task.title
                                        }),
                                        secondary: deadline
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((AvatarGroup_default()), {
                                        max: 3,
                                        children: task.members.map((member)=>/*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                                title: "View",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                    src: member.avatar
                                                })
                                            }, member.name))
                                    })
                                ]
                            }, task.id);
                        })
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/CreditCard02.js
var CreditCard02 = __webpack_require__(600925);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Mail01.js
var Mail01 = __webpack_require__(871920);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Send01.js
var Send01 = __webpack_require__(376131);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronRight.js
var ChevronRight = __webpack_require__(492382);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemIcon/index.js
var ListItemIcon = __webpack_require__(126765);
var ListItemIcon_default = /*#__PURE__*/__webpack_require__.n(ListItemIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemSecondaryAction/index.js
var ListItemSecondaryAction = __webpack_require__(120662);
var ListItemSecondaryAction_default = /*#__PURE__*/__webpack_require__.n(ListItemSecondaryAction);
;// CONCATENATED MODULE: ./src/sections/components/grouped-lists/grouped-list-4.tsx
















const notifications = [
    {
        id: "5e8883a4f7877f898c408c27",
        message: "to send service quotes",
        type: "invite",
        value: 6
    },
    {
        id: "5e8883aa34190e0457a6e2b9",
        message: "from clients",
        type: "message",
        value: 2
    },
    {
        id: "5e8883af168cad3e1f4fe0ae",
        message: "that needs your confirmation",
        type: "payout",
        value: 1
    }
];
const iconsMap = {
    invite: /*#__PURE__*/ jsx_runtime_.jsx(Send01/* default */.Z, {}),
    message: /*#__PURE__*/ jsx_runtime_.jsx(Mail01/* default */.Z, {}),
    payout: /*#__PURE__*/ jsx_runtime_.jsx(CreditCard02/* default */.Z, {})
};
const GroupedList4 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
            children: /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                children: notifications.map((notification, index)=>{
                    const showDivider = index < notifications.length - 1;
                    const icon = iconsMap[notification.type];
                    const title = `${notification.value} ${notification.type}s ${notification.message}`;
                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                        divider: showDivider,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: icon
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "subtitle2",
                                    children: title
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((ListItemSecondaryAction_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                    title: "View",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                        edge: "end",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronRight/* default */.Z, {})
                                        })
                                    })
                                })
                            })
                        ]
                    }, notification.id);
                })
            })
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ArrowRight.js
var ArrowRight = __webpack_require__(394284);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Image01.js
var Image01 = __webpack_require__(97484);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Table/index.js
var Table = __webpack_require__(620390);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableBody/index.js
var TableBody = __webpack_require__(843606);
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableCell/index.js
var TableCell = __webpack_require__(340514);
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableRow/index.js
var TableRow = __webpack_require__(893761);
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow);
// EXTERNAL MODULE: ./node_modules/prop-types/index.js
var prop_types = __webpack_require__(869232);
var prop_types_default = /*#__PURE__*/__webpack_require__.n(prop_types);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
;// CONCATENATED MODULE: ./src/components/circular-progress.tsx



const CircularProgressRoot = (0,styles.styled)("div")({
    height: 56,
    width: 56
});
const CircularProgressBackground = (0,styles.styled)("path")(({ theme  })=>({
        fill: "none",
        stroke: theme.palette.mode === "dark" ? "rgba(0,0,0,0.15)" : "rgba(0,0,0,0.05)",
        strokeWidth: 4
    }));
const CircularProgressValue = (0,styles.styled)("path")(({ theme  })=>({
        animation: "$progress 1s ease-out forwards",
        fill: "none",
        stroke: theme.palette.primary.main,
        strokeWidth: 4,
        "@keyframes progress": {
            "0%": {
                strokeDasharray: "0 100"
            }
        }
    }));
const CircularProgress = (props)=>{
    const { value , ...other } = props;
    return /*#__PURE__*/ jsx_runtime_.jsx(CircularProgressRoot, {
        ...other,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("svg", {
            viewBox: "0 0 36 36",
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(CircularProgressBackground, {
                    d: "M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831",
                    strokeDasharray: "100, 100"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(CircularProgressValue, {
                    d: "M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831",
                    strokeDasharray: `${value}, 100`
                })
            ]
        })
    });
};
CircularProgress.propTypes = {
    value: (prop_types_default()).number.isRequired
};

;// CONCATENATED MODULE: ./src/sections/components/grouped-lists/grouped-list-5.tsx



















const products = [
    {
        id: "5eff2512c6f8737d08325676",
        conversionRate: 93,
        currency: "$",
        image: "/assets/products/product-1.png",
        name: "Healthcare Erbology",
        profit: 53500,
        sales: 13153
    },
    {
        id: "5eff2516247f9a6fcca9f151",
        conversionRate: 76,
        currency: "$",
        image: "/assets/products/product-2.png",
        name: "Makeup Lancome Rouge",
        profit: 45763,
        sales: 10300
    },
    {
        id: "5eff251a3bb9ab7290640f18",
        conversionRate: 60,
        currency: "$",
        image: null,
        name: "Lounge Puff Fabric Slipper",
        profit: 28700,
        sales: 5300
    },
    {
        id: "5eff251e297fd17f0dc18a8b",
        conversionRate: 46,
        currency: "$",
        image: "/assets/products/product-4.png",
        name: "Skincare Necessaire",
        profit: 20400,
        sales: 1203
    },
    {
        id: "5eff2524ef813f061b3ea39f",
        conversionRate: 41,
        currency: "$",
        image: "/assets/products/product-5.png",
        name: "Skincare Soja CO",
        profit: 15200,
        sales: 254
    }
];
const GroupedList5 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    action: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                        })
                    }),
                    title: "Profitable Products"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Table_default()), {
                        sx: {
                            minWidth: 700
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                            children: products.map((product)=>{
                                const sales = numeral_default()(product.sales).format("0,0");
                                const profit = numeral_default()(product.profit).format(`${product.currency}0,0.00`);
                                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                    hover: true,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                alignItems: "center",
                                                direction: "row",
                                                spacing: 2,
                                                children: [
                                                    product.image ? /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                        sx: {
                                                            alignItems: "center",
                                                            backgroundColor: "neutral.50",
                                                            backgroundImage: `url(${product.image})`,
                                                            backgroundPosition: "center",
                                                            backgroundSize: "cover",
                                                            borderRadius: 1,
                                                            display: "flex",
                                                            height: 80,
                                                            justifyContent: "center",
                                                            overflow: "hidden",
                                                            width: 80
                                                        }
                                                    }) : /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                        sx: {
                                                            alignItems: "center",
                                                            backgroundColor: "neutral.50",
                                                            borderRadius: 1,
                                                            display: "flex",
                                                            height: 80,
                                                            justifyContent: "center",
                                                            width: 80
                                                        },
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Image01/* default */.Z, {})
                                                        })
                                                    }),
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                variant: "subtitle2",
                                                                children: product.name
                                                            }),
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                                color: "text.secondary",
                                                                noWrap: true,
                                                                variant: "body2",
                                                                children: [
                                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                        color: "success.main",
                                                                        component: "span",
                                                                        variant: "subtitle2",
                                                                        children: sales
                                                                    }),
                                                                    " ",
                                                                    "Sales"
                                                                ]
                                                            })
                                                        ]
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "subtitle2",
                                                    children: "Profit"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    color: "text.secondary",
                                                    noWrap: true,
                                                    variant: "body2",
                                                    children: profit
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                alignItems: "center",
                                                direction: "row",
                                                justifyContent: "flex-end",
                                                spacing: 2,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                                        children: [
                                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                                align: "right",
                                                                variant: "subtitle2",
                                                                children: [
                                                                    product.conversionRate,
                                                                    "%"
                                                                ]
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                color: "text.secondary",
                                                                variant: "body2",
                                                                children: "Conversion Rate"
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(CircularProgress, {
                                                        value: product.conversionRate
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }, product.id);
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        display: "flex",
                        justifyContent: "flex-end",
                        p: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        color: "inherit",
                        endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                        }),
                        size: "small",
                        children: "See All"
                    })
                })
            ]
        })
    });

;// CONCATENATED MODULE: ./src/sections/components/grouped-lists/grouped-list-6.tsx












const grouped_list_6_now = new Date();
const transactions = [
    {
        id: "d46800328cd510a668253b45",
        amount: 25000,
        currency: "usd",
        createdAt: grouped_list_6_now.getTime(),
        sender: "Devias",
        type: "receive"
    },
    {
        id: "b4b19b21656e44b487441c50",
        amount: 6843,
        currency: "usd",
        createdAt: (0,date_fns.subDays)(grouped_list_6_now, 1).getTime(),
        sender: "Zimbru",
        type: "send"
    },
    {
        id: "56c09ad91f6d44cb313397db",
        amount: 91823,
        currency: "usd",
        createdAt: (0,date_fns.subDays)(grouped_list_6_now, 1).getTime(),
        sender: "Vertical Jelly",
        type: "send"
    },
    {
        id: "aaeb96c5a131a55d9623f44d",
        amount: 49550,
        currency: "usd",
        createdAt: (0,date_fns.subDays)(grouped_list_6_now, 3).getTime(),
        sender: "Devias",
        type: "receive"
    }
];
const GroupedList6 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Latest Transactions"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx((Table_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                        children: transactions.map((transaction)=>{
                            const createdAtMonth = (0,date_fns.format)(transaction.createdAt, "LLL").toUpperCase();
                            const createdAtDay = (0,date_fns.format)(transaction.createdAt, "d");
                            const type = transaction.type === "receive" ? "Payment received" : "Payment sent";
                            const amount = (transaction.type === "receive" ? "+" : "-") + " " + numeral_default()(transaction.amount).format("$0,0.00");
                            const amountColor = transaction.type === "receive" ? "success.main" : "error.main";
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                sx: {
                                    "&:last-child td, &:last-child th": {
                                        border: 0
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        width: 100,
                                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                            sx: {
                                                p: 1
                                            },
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    align: "center",
                                                    color: "text.secondary",
                                                    variant: "subtitle2",
                                                    children: createdAtMonth
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    align: "center",
                                                    color: "text.secondary",
                                                    variant: "h6",
                                                    children: createdAtDay
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "subtitle2",
                                                children: transaction.sender
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "body2",
                                                children: type
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                        align: "right",
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: amountColor,
                                                variant: "subtitle2",
                                                children: amount
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "body2",
                                                children: transaction.currency.toUpperCase()
                                            })
                                        ]
                                    })
                                ]
                            }, transaction.id);
                        })
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Badge/index.js
var Badge = __webpack_require__(382361);
var Badge_default = /*#__PURE__*/__webpack_require__.n(Badge);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardActions/index.js
var CardActions = __webpack_require__(640362);
var CardActions_default = /*#__PURE__*/__webpack_require__.n(CardActions);
// EXTERNAL MODULE: ./src/utils/date-locale.ts
var date_locale = __webpack_require__(268003);
;// CONCATENATED MODULE: ./src/sections/components/grouped-lists/grouped-list-7.tsx















const grouped_list_7_now = new Date();
const messages = [
    {
        id: "b91cbe81ee3efefba6b915a7",
        content: "Hello, we spoke earlier on the phone",
        createdAt: (0,date_fns.subMinutes)(grouped_list_7_now, 2).getTime(),
        senderAvatar: "/assets/avatars/avatar-alcides-antonio.png",
        senderName: "Alcides Antonio",
        senderOnline: true
    },
    {
        id: "de0eb1ac517aae1aa57c0b7e",
        content: "Is the job still available?",
        createdAt: (0,date_fns.subMinutes)(grouped_list_7_now, 56).getTime(),
        senderAvatar: "/assets/avatars/avatar-marcus-finn.png",
        senderName: "Marcus Finn",
        senderOnline: true
    },
    {
        id: "38e2b0942c90d0ad724e6f40",
        content: "What is a screening task? I’d like to",
        createdAt: (0,date_fns.subHours)((0,date_fns.subMinutes)(grouped_list_7_now, 23), 3).getTime(),
        senderAvatar: "/assets/avatars/avatar-carson-darrin.png",
        senderName: "Carson Darrin",
        senderOnline: false
    },
    {
        id: "467505f3356f25a69f4c4890",
        content: "Still waiting for feedback",
        createdAt: (0,date_fns.subHours)((0,date_fns.subMinutes)(grouped_list_7_now, 6), 8).getTime(),
        senderAvatar: "/assets/avatars/avatar-fran-perez.png",
        senderName: "Fran Perez",
        senderOnline: true
    },
    {
        id: "7e6af808e801a8361ce4cf8b",
        content: "Need more information about current campaigns",
        createdAt: (0,date_fns.subHours)((0,date_fns.subMinutes)(grouped_list_7_now, 18), 10).getTime(),
        senderAvatar: "/assets/avatars/avatar-jie-yan-song.png",
        senderName: "Jie Yan Song",
        senderOnline: false
    }
];
const GroupedList7 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            display: "flex",
            justifyContent: "center",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            sx: {
                maxWidth: 363
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Inbox"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                    disablePadding: true,
                    children: messages.map((message)=>{
                        const ago = (0,date_fns.formatDistanceStrict)(message.createdAt, new Date(), {
                            addSuffix: true,
                            locale: date_locale/* customLocale */.Z
                        });
                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                            sx: {
                                "&:hover": {
                                    backgroundColor: "action.hover",
                                    cursor: "pointer"
                                }
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                    children: message.senderOnline ? /*#__PURE__*/ jsx_runtime_.jsx((Badge_default()), {
                                        anchorOrigin: {
                                            horizontal: "right",
                                            vertical: "bottom"
                                        },
                                        color: "success",
                                        variant: "dot",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                            src: message.senderAvatar
                                        })
                                    }) : /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                        src: message.senderAvatar
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                    disableTypography: true,
                                    primary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        sx: {
                                            overflow: "hidden",
                                            textOverflow: "ellipsis",
                                            whiteSpace: "nowrap"
                                        },
                                        variant: "subtitle2",
                                        children: message.senderName
                                    }),
                                    secondary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        sx: {
                                            overflow: "hidden",
                                            textOverflow: "ellipsis",
                                            whiteSpace: "nowrap"
                                        },
                                        variant: "body2",
                                        children: message.content
                                    }),
                                    sx: {
                                        pr: 2
                                    }
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    sx: {
                                        whiteSpace: "nowrap"
                                    },
                                    variant: "caption",
                                    children: ago
                                })
                            ]
                        }, message.id);
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        color: "inherit",
                        size: "small",
                        children: "Go to chat"
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
;// CONCATENATED MODULE: ./src/sections/components/grouped-lists/grouped-list-8.tsx















const members = [
    {
        id: "5e887a62195cc5aef7e8ca5d",
        avatar: "/assets/avatars/avatar-marcus-finn.png",
        job: "Front End Developer",
        name: "Marcus Finn"
    },
    {
        id: "5e887ac47eed253091be10cb",
        avatar: "/assets/avatars/avatar-carson-darrin.png",
        job: "UX Designer",
        name: "Carson Darrin"
    },
    {
        id: "5e887b7602bdbc4dbb234b27",
        avatar: "/assets/avatars/avatar-jie-yan-song.png",
        job: "Copyright",
        name: "Jie Yan Song"
    }
];
const GroupedList8 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "sm",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        sx: {
                            pb: 0
                        },
                        title: "Project members",
                        titleTypographyProps: {
                            variant: "overline"
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                            disablePadding: true,
                            children: members.map((member)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                    disableGutters: true,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                src: member.avatar
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                            primary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "subtitle2",
                                                children: member.name
                                            }),
                                            secondary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "body2",
                                                children: member.job
                                            })
                                        })
                                    ]
                                }, member.id))
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                    /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                        sx: {
                            justifyContent: "center"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            size: "small",
                            children: "Manage members"
                        })
                    })
                ]
            })
        })
    });

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Rating/index.js
var Rating = __webpack_require__(247022);
var Rating_default = /*#__PURE__*/__webpack_require__.n(Rating);
;// CONCATENATED MODULE: ./src/sections/components/grouped-lists/grouped-list-9.tsx










const grouped_list_9_now = new Date();
const reviews = [
    {
        id: "5f0366cd843161f193ebadd4",
        author: {
            avatar: "/assets/avatars/avatar-marcus-finn.png",
            name: "Marcus Finn"
        },
        comment: "Great company, providing an awesome & easy to use product.",
        createdAt: (0,date_fns.subHours)(grouped_list_9_now, 2).getTime(),
        value: 5
    },
    {
        id: "to33twsyjphcfj55y3t07261",
        author: {
            avatar: "/assets/avatars/avatar-miron-vitold.png",
            name: "Miron Vitold"
        },
        comment: "Not the best people managers, poor management skills, poor career development programs. Communication from corporate & leadership isn't always clear and is sometime one-sided. Low pay compared to FANG.",
        createdAt: (0,date_fns.subHours)(grouped_list_9_now, 2).getTime(),
        value: 2
    },
    {
        id: "6z9dwxjzkqbmxuluxx2681jd",
        author: {
            avatar: "/assets/avatars/avatar-carson-darrin.png",
            name: "Carson Darrin"
        },
        comment: "I have been working with this company full-time. Great for the work life balance. Cons, decentralized decision making process across the organization.",
        createdAt: (0,date_fns.subHours)(grouped_list_9_now, 2).getTime(),
        value: 4
    }
];
const GroupedList9 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
            spacing: 3,
            children: reviews.map((review)=>{
                const ago = (0,date_fns.formatDistanceToNowStrict)(review.createdAt);
                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                            avatar: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                src: review.author.avatar
                            }),
                            disableTypography: true,
                            subheader: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    alignItems: "center",
                                    display: "flex",
                                    flexWrap: "wrap",
                                    mt: 1
                                },
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                        sx: {
                                            alignItems: "center",
                                            display: "flex",
                                            mr: 1
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Rating_default()), {
                                                readOnly: true,
                                                value: 5
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                sx: {
                                                    ml: 1
                                                },
                                                variant: "subtitle2",
                                                children: review.value
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: [
                                            "| For",
                                            " ",
                                            /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                color: "text.primary",
                                                variant: "subtitle2",
                                                children: "Low Budget"
                                            }),
                                            " ",
                                            "| ",
                                            ago,
                                            " ago"
                                        ]
                                    })
                                ]
                            }),
                            title: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                color: "text.primary",
                                variant: "subtitle2",
                                children: review.author.name
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                pb: 2,
                                px: 3
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.secondary",
                                variant: "body1",
                                children: review.comment
                            })
                        })
                    ]
                }, review.id);
            })
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Download01.js
var Download01 = __webpack_require__(24165);
;// CONCATENATED MODULE: ./src/sections/components/grouped-lists/grouped-list-10.tsx










const grouped_list_10_now = new Date();
const grouped_list_10_activities = [
    {
        id: "5e8dd0828d628e6f40abdfe8",
        createdAt: (0,date_fns.subMinutes)(grouped_list_10_now, 23).getTime(),
        description: "has uploaded a new file",
        subject: "Project author",
        type: "upload_file"
    },
    {
        id: "5e8dd0893a6725f2bb603617",
        createdAt: (0,date_fns.subHours)(grouped_list_10_now, 2).getTime(),
        description: "joined team as a Front-End Developer",
        subject: "Adrian Stefan",
        type: "join_team"
    },
    {
        id: "5e8dd08f44603e3300b75cf1",
        createdAt: (0,date_fns.subHours)(grouped_list_10_now, 9).getTime(),
        description: "joined team as a Full Stack Developer",
        subject: "Alexandru Robert",
        type: "join_team"
    }
];
const GroupedList10 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
            spacing: 3,
            children: grouped_list_10_activities.map((activity)=>{
                const ago = (0,date_fns.formatDistanceToNowStrict)(activity.createdAt);
                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                    sx: {
                        alignItems: "center",
                        display: "flex",
                        p: 2
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                            sx: {
                                backgroundColor: "primary.main",
                                color: "common.white"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Download01/* default */.Z, {})
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                            sx: {
                                ml: 2
                            },
                            variant: "body2",
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                    color: "text.primary",
                                    variant: "subtitle2",
                                    children: activity.subject
                                }),
                                " ",
                                activity.description
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                            sx: {
                                ml: "auto"
                            },
                            variant: "caption",
                            children: [
                                ago,
                                " ago"
                            ]
                        })
                    ]
                }, activity.id);
            })
        })
    });

// EXTERNAL MODULE: ./src/components/severity-pill.tsx
var severity_pill = __webpack_require__(594368);
;// CONCATENATED MODULE: ./src/sections/components/grouped-lists/grouped-list-11.tsx












const campaigns = [
    {
        id: "4be0679f811115c9d2d28497",
        clickRate: 6.32,
        conversionRate: 1.05,
        createdAt: "Jan 23 2022",
        name: "Summer Active Health",
        platform: "Google",
        status: "draft",
        target: "Men Group"
    },
    {
        id: "4e1cd375bfa59e4347404e20",
        clickRate: 7.94,
        conversionRate: 0.31,
        createdAt: "Feb 1 2022",
        name: "New prospects blog",
        platform: "Facebook",
        status: "active",
        target: "Woman Married Group"
    },
    {
        id: "6b37fdf83195ca7e36622040",
        clickRate: 20.15,
        conversionRate: 2.1,
        createdAt: "Feb 5 2022",
        name: "Amazon Gift Cards",
        platform: "Facebook",
        status: "stopped",
        target: "Young Group"
    },
    {
        id: "e3651f8f9565cdbe8d2e5fea",
        clickRate: 7.94,
        conversionRate: 0.5,
        createdAt: "Feb 1 2022",
        name: "Best Marketing Course Online",
        platform: "Bing",
        status: "draft",
        target: "Young Group"
    }
];
const statusColorsMap = {
    draft: "secondary",
    active: "success",
    stopped: "error"
};
const GroupedList11 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Campaigns Summary"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx((Table_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                        children: campaigns.map((campaign)=>{
                            const statusColor = statusColorsMap[campaign.status];
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                sx: {
                                    "&:last-child td, &:last-child th": {
                                        border: 0
                                    }
                                },
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                sx: {
                                                    cursor: "pointer"
                                                },
                                                variant: "subtitle2",
                                                children: campaign.name
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                                sx: {
                                                    alignItems: "center",
                                                    display: "flex",
                                                    mt: 1
                                                },
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        color: "text.secondary",
                                                        variant: "body2",
                                                        children: campaign.platform
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                        sx: {
                                                            height: 4,
                                                            width: 4,
                                                            borderRadius: 4,
                                                            backgroundColor: "text.secondary",
                                                            mx: 1
                                                        }
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        color: "text.secondary",
                                                        variant: "body2",
                                                        children: `${campaign.target}, ${campaign.createdAt}`
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(severity_pill/* SeverityPill */.I, {
                                            color: statusColor,
                                            children: campaign.status
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                variant: "subtitle2",
                                                children: [
                                                    campaign.clickRate,
                                                    "%"
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                sx: {
                                                    mt: 1
                                                },
                                                variant: "body2",
                                                children: "Click Rate"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                        children: [
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                variant: "subtitle2",
                                                children: [
                                                    campaign.conversionRate,
                                                    "%"
                                                ]
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                sx: {
                                                    mt: 1
                                                },
                                                variant: "body2",
                                                children: "Conversions"
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        align: "right",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                            size: "small",
                                            variant: "outlined",
                                            children: "View"
                                        })
                                    })
                                ]
                            }, campaign.id);
                        })
                    })
                })
            ]
        })
    });

;// CONCATENATED MODULE: ./src/app/marketing/components/lists/grouped-lists/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 


















const page_components = [
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GroupedList1, {}),
        title: "Grouped list 1"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GroupedList2, {}),
        title: "Grouped list 2"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GroupedList3, {}),
        title: "Grouped list 3"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GroupedList4, {}),
        title: "Grouped list 4"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GroupedList5, {}),
        title: "Grouped list 5"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GroupedList6, {}),
        title: "Grouped list 6"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GroupedList7, {}),
        title: "Grouped list 7"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GroupedList8, {}),
        title: "Grouped list 8"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GroupedList9, {}),
        title: "Grouped list 9"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GroupedList10, {}),
        title: "Grouped list 10"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(GroupedList11, {}),
        title: "Grouped list 11"
    }
];
const Page = ()=>{
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Components: Grouped Lists"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Layout */.A, {
                title: "Grouped Lists",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "main",
                    sx: {
                        flexGrow: 1,
                        py: 8
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                        maxWidth: "lg",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                            spacing: 8,
                            children: page_components.map((component)=>/*#__PURE__*/ jsx_runtime_.jsx(previewer/* Previewer */.M, {
                                    title: component.title,
                                    children: component.element
                                }, component.title))
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 903268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.usePathname)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 488141:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ useSettings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34383);


const useSettings = ()=>(0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__/* .SettingsContext */ .J6);


/***/ }),

/***/ 339157:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/lists/grouped-lists/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,3380,4755,6609,4609,5006,2983,8470,6519,7484,1920,6131,925,5465,7680,9494,4018,9274,4368], () => (__webpack_exec__(848626)));
module.exports = __webpack_exports__;

})();