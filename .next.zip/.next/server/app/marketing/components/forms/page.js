(() => {
var exports = {};
exports.id = 1838;
exports.ids = [1838];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 523490:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'marketing',
        {
        children: [
        'components',
        {
        children: [
        'forms',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 532277, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/forms/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 586068)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/forms/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/marketing/components/forms/page"
  

/***/ }),

/***/ 702981:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 751181))

/***/ }),

/***/ 751181:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/layouts/components/index.ts + 2 modules
var components = __webpack_require__(898394);
// EXTERNAL MODULE: ./src/sections/components/previewer.tsx
var previewer = __webpack_require__(213718);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Switch/index.js
var Switch = __webpack_require__(877876);
var Switch_default = /*#__PURE__*/__webpack_require__.n(Switch);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TextField/index.js
var TextField = __webpack_require__(28379);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
;// CONCATENATED MODULE: ./src/sections/components/forms/form-1.tsx







const Form1 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                    container: true,
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "Full name",
                                name: "name",
                                required: true,
                                value: "Miron Vitold"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "Email address",
                                name: "email",
                                required: true,
                                value: "miron.vitold@devias.io"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "Country",
                                name: "country",
                                value: "USA"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "State/Region",
                                name: "state",
                                value: "New York"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "Address 1",
                                name: "address1",
                                value: "Street John Wick, no. 7"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "Address 2",
                                name: "address2",
                                value: "House #25"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "Phone number",
                                name: "phone",
                                value: "+55 748 327 439"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    gutterBottom: true,
                                    variant: "subtitle2",
                                    children: "Email Verified"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "body2",
                                    children: "Disabling this will automatically send the user a verification email"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                    defaultChecked: true,
                                    edge: "start",
                                    name: "isVerified"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    gutterBottom: true,
                                    variant: "subtitle2",
                                    children: "Discounted Prices"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "body2",
                                    children: "This will give the user discounted prices for all products"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                    color: "primary",
                                    defaultChecked: false,
                                    edge: "start",
                                    name: "hasDiscount"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        mt: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        type: "submit",
                        variant: "contained",
                        children: "Update Customer"
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/SearchMd.js
var SearchMd = __webpack_require__(219057);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Checkbox/index.js
var Checkbox = __webpack_require__(63754);
var Checkbox_default = /*#__PURE__*/__webpack_require__.n(Checkbox);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Chip/index.js
var Chip = __webpack_require__(829553);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/FormControlLabel/index.js
var FormControlLabel = __webpack_require__(128353);
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Input/index.js
var Input = __webpack_require__(378382);
var Input_default = /*#__PURE__*/__webpack_require__.n(Input);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./src/components/multi-select.tsx
var multi_select = __webpack_require__(37155);
;// CONCATENATED MODULE: ./src/sections/components/forms/form-2.tsx












const categoryOptions = [
    {
        label: "Digital",
        value: "digital"
    },
    {
        label: "Service",
        value: "service"
    }
];
const statusOptions = [
    {
        label: "Published",
        value: "published"
    },
    {
        label: "Draft",
        value: "draft"
    }
];
const stockOptions = [
    {
        label: "All",
        value: "all"
    },
    {
        label: "Available",
        value: "available"
    },
    {
        label: "Out of Stock",
        value: "outOfStock"
    }
];
const Form2 = ()=>{
    // We memoize this part to prevent re-render issues
    const chips = (0,react_.useMemo)(()=>[
            {
                label: "Category",
                field: "category",
                value: "digital",
                displayValue: "Digital"
            },
            {
                label: "Category",
                field: "category",
                value: "service",
                displayValue: "Service"
            },
            {
                label: "Status",
                field: "status",
                value: "published",
                displayValue: "Published"
            },
            {
                label: "Stock",
                field: "inStock",
                value: "outOfStock",
                displayValue: "Out of Stock"
            }
        ], []);
    const categoryValues = (0,react_.useMemo)(()=>chips.filter((chip)=>chip.field === "category").map((chip)=>chip.value), [
        chips
    ]);
    const statusValues = (0,react_.useMemo)(()=>chips.filter((chip)=>chip.field === "status").map((chip)=>chip.value), [
        chips
    ]);
    const stockValues = (0,react_.useMemo)(()=>chips.filter((chip)=>chip.field === "inStock").map((chip)=>chip.value), [
        chips
    ]);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
        sx: {
            p: 3
        },
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                sx: {
                    alignItems: "center",
                    display: "flex",
                    p: 2
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(SearchMd/* default */.Z, {})
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            flexGrow: 1,
                            ml: 3
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                            disableUnderline: true,
                            fullWidth: true,
                            placeholder: "Enter a keyword"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                sx: {
                    alignItems: "center",
                    display: "flex",
                    flexWrap: "wrap",
                    p: 2
                },
                children: chips.map((chip, index)=>/*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                        label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                alignItems: "center",
                                display: "flex",
                                "& span": {
                                    fontWeight: 600
                                }
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("span", {
                                    children: chip.label
                                }),
                                ":",
                                " ",
                                chip.displayValue
                            ]
                        }),
                        onDelete: ()=>{},
                        sx: {
                            m: 1
                        },
                        variant: "outlined"
                    }, index))
            }),
            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                alignItems: "center",
                direction: "row",
                flexWrap: "wrap",
                spacing: 2,
                sx: {
                    p: 1
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx(multi_select/* MultiSelect */.N, {
                        label: "Category",
                        options: categoryOptions,
                        value: categoryValues
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(multi_select/* MultiSelect */.N, {
                        label: "Status",
                        options: statusOptions,
                        value: statusValues
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(multi_select/* MultiSelect */.N, {
                        label: "Stock",
                        options: stockOptions,
                        value: stockValues
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            flexGrow: 1
                        }
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                        control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                            defaultChecked: true
                        }),
                        label: "In network"
                    })
                ]
            })
        ]
    });
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardActions/index.js
var CardActions = __webpack_require__(640362);
var CardActions_default = /*#__PURE__*/__webpack_require__.n(CardActions);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
;// CONCATENATED MODULE: ./src/sections/components/forms/form-3.tsx











const Form3 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Notifications"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                        container: true,
                        spacing: 6,
                        wrap: "wrap",
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 6,
                                md: 4,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        gutterBottom: true,
                                        variant: "subtitle2",
                                        children: "System"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        gutterBottom: true,
                                        variant: "body2",
                                        children: "You will receive emails in your business email address"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                                defaultChecked: true
                                            }),
                                            label: "Email alerts"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {}),
                                            label: "Push Notifications"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                                defaultChecked: true
                                            }),
                                            label: "Text message"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                                defaultChecked: true
                                            }),
                                            label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "body1",
                                                        children: "Phone calls"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        color: "text.secondary",
                                                        variant: "caption",
                                                        children: "Short voice phone updating you"
                                                    })
                                                ]
                                            })
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                                xs: 12,
                                sm: 6,
                                md: 4,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        gutterBottom: true,
                                        variant: "subtitle2",
                                        children: "Chat App"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        gutterBottom: true,
                                        variant: "body2",
                                        children: "You will receive emails in your business email address"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                                defaultChecked: true
                                            }),
                                            label: "Email"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                            control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                                defaultChecked: true
                                            }),
                                            label: "Push notifications"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                    sx: {
                        justifyContent: "flex-end",
                        p: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        type: "submit",
                        variant: "contained",
                        children: "Save Settings"
                    })
                })
            ]
        })
    });

;// CONCATENATED MODULE: ./src/sections/components/forms/form-4.tsx






const Form4 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                    container: true,
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            sm: 6,
                            md: 4,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "Password",
                                name: "password",
                                type: "password"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            sm: 6,
                            md: 4,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "Password Confirmation",
                                name: "passwordConfirm",
                                type: "password"
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                    sx: {
                        pt: 2
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        display: "flex",
                        justifyContent: "flex-end",
                        p: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        color: "primary",
                        type: "submit",
                        variant: "contained",
                        children: "Change Password"
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Autocomplete/index.js
var Autocomplete = __webpack_require__(590039);
var Autocomplete_default = /*#__PURE__*/__webpack_require__.n(Autocomplete);
;// CONCATENATED MODULE: ./src/sections/components/forms/form-5.tsx












const countries = [
    {
        text: "Jersey",
        value: "JE"
    },
    {
        text: "Jordan",
        value: "JO"
    },
    {
        text: "Kazakhstan",
        value: "KZ"
    },
    {
        text: "Kenya",
        value: "KE"
    },
    {
        text: "Kiribati",
        value: "KI"
    },
    {
        text: "Korea, Democratic People'S Republic of",
        value: "KP"
    },
    {
        text: "Korea, Republic of",
        value: "KR"
    },
    {
        text: "Kuwait",
        value: "KW"
    },
    {
        text: "Kyrgyzstan",
        value: "KG"
    },
    {
        text: "Lao People'S Democratic Republic",
        value: "LA"
    }
];
const Form5 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Profile"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                        container: true,
                        spacing: 4,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                    fullWidth: true,
                                    label: "Name",
                                    name: "name"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                    fullWidth: true,
                                    helperText: "We will use this email to contact you",
                                    label: "Email Address",
                                    name: "email",
                                    required: true,
                                    type: "email"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                    fullWidth: true,
                                    label: "Phone Number",
                                    name: "phone"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Autocomplete_default()), {
                                    getOptionLabel: (option)=>option.text,
                                    options: countries,
                                    renderInput: (params)=>/*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                            ...params,
                                            fullWidth: true,
                                            label: "Country",
                                            name: "country"
                                        })
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                    fullWidth: true,
                                    label: "State/Region",
                                    name: "state"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 6,
                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                    fullWidth: true,
                                    label: "City",
                                    name: "city"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 6,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        gutterBottom: true,
                                        variant: "subtitle2",
                                        children: "Public Profile"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: "Means that anyone viewing your profile will be able to see your contacts details"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                        edge: "start",
                                        name: "isPublic"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                                xs: 12,
                                md: 6,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        gutterBottom: true,
                                        variant: "subtitle2",
                                        children: "Available to hire"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: "Toggling this will let your teammates know that you are available for acquiring new projects"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                        color: "primary",
                                        edge: "start",
                                        name: "canHire"
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                    sx: {
                        justifyContent: "flex-end",
                        p: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        color: "primary",
                        type: "submit",
                        variant: "contained",
                        children: "Save Settings"
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@mui/x-date-pickers/node/DateTimePicker/index.js
var DateTimePicker = __webpack_require__(824786);
;// CONCATENATED MODULE: ./src/sections/components/forms/form-6.tsx










const Form6 = ()=>{
    const [startDate, setStartDate] = (0,react_.useState)(new Date());
    const [endDate, setEndDate] = (0,react_.useState)(new Date());
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                            fullWidth: true,
                            label: "Title",
                            name: "title"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                            fullWidth: true,
                            label: "Description",
                            name: "description"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {
                                    name: "allDay"
                                }),
                                label: "All day"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(DateTimePicker.DateTimePicker, {
                            onChange: (newDate)=>setStartDate(newDate),
                            label: "Start date",
                            value: startDate
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(DateTimePicker.DateTimePicker, {
                            onChange: (newDate)=>setEndDate(newDate),
                            label: "End date",
                            value: endDate
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                    sx: {
                        my: 3
                    }
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                    sx: {
                        alignItems: "center",
                        display: "flex"
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                flexGrow: 1
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            children: "Cancel"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            sx: {
                                ml: 1
                            },
                            type: "submit",
                            variant: "contained",
                            children: "Confirm"
                        })
                    ]
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/OutlinedInput/index.js
var OutlinedInput = __webpack_require__(877829);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput);
;// CONCATENATED MODULE: ./src/sections/components/forms/form-7.tsx







const Form7 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                    container: true,
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                            xs: 12,
                            lg: 6,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    sx: {
                                        mb: 1
                                    },
                                    variant: "subtitle2",
                                    children: "Name"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                    fullWidth: true,
                                    name: "name",
                                    required: true
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                            xs: 12,
                            lg: 6,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    sx: {
                                        mb: 1
                                    },
                                    variant: "subtitle2",
                                    children: "Company"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                    fullWidth: true,
                                    name: "company"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                            xs: 12,
                            lg: 6,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    sx: {
                                        mb: 1
                                    },
                                    variant: "subtitle2",
                                    children: "Email"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                    fullWidth: true,
                                    name: "email",
                                    type: "email"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                            xs: 12,
                            lg: 6,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    sx: {
                                        mb: 1
                                    },
                                    variant: "subtitle2",
                                    children: "Phone"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                    fullWidth: true,
                                    name: "phone",
                                    required: true,
                                    type: "tel"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                            xs: 12,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    sx: {
                                        mb: 1
                                    },
                                    variant: "subtitle2",
                                    children: "Message"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                    fullWidth: true,
                                    name: "message",
                                    required: true,
                                    multiline: true,
                                    rows: 6
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        display: "flex",
                        justifyContent: "center",
                        mt: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        color: "primary",
                        fullWidth: true,
                        size: "large",
                        variant: "contained",
                        children: "Let's Talk"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                    align: "center",
                    color: "text.secondary",
                    sx: {
                        mt: 2
                    },
                    variant: "body2",
                    children: [
                        "By submitting this, you agree to the",
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                            color: "text.primary",
                            href: "#",
                            underline: "always",
                            variant: "subtitle2",
                            children: "Privacy Policy"
                        }),
                        " ",
                        "and",
                        " ",
                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                            color: "text.primary",
                            href: "#",
                            underline: "always",
                            variant: "subtitle2",
                            children: "Cookie Policy"
                        }),
                        "."
                    ]
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Plus.js
var Plus = __webpack_require__(959309);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/x-date-pickers/node/MobileDatePicker/index.js
var MobileDatePicker = __webpack_require__(123595);
;// CONCATENATED MODULE: ./src/sections/components/forms/form-8.tsx













const Form8 = ()=>{
    const [startDate, setStartDate] = (0,react_.useState)(new Date());
    const [endDate, setEndDate] = (0,react_.useState)(new Date());
    const tags = [
        "Full-Time"
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                spacing: 4,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        spacing: 1,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "h5",
                                children: "Please select one option"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.secondary",
                                variant: "body1",
                                children: "Proin tincidunt lacus sed ante efficitur efficitur. Quisque aliquam fringilla velit sit amet euismod."
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        spacing: 4,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "Project Name",
                                name: "projectName"
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                spacing: 2,
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                        alignItems: "center",
                                        direction: "row",
                                        spacing: 2,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                fullWidth: true,
                                                label: "Tags",
                                                name: "tags"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Plus/* default */.Z, {})
                                                })
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                        alignItems: "center",
                                        direction: "row",
                                        flexWrap: "wrap",
                                        spacing: 1,
                                        children: tags.map((tag)=>/*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                                                avatar: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                                    children: tag.slice(0, 1)
                                                }),
                                                label: tag,
                                                onDelete: ()=>{},
                                                variant: "outlined"
                                            }, tag))
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                alignItems: "center",
                                direction: "row",
                                spacing: 3,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx(MobileDatePicker.MobileDatePicker, {
                                        label: "Start Date",
                                        onChange: (newDate)=>setStartDate(newDate),
                                        value: startDate
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(MobileDatePicker.MobileDatePicker, {
                                        label: "End Date",
                                        onChange: (newDate)=>setEndDate(newDate),
                                        value: endDate
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            display: "flex",
                            justifyContent: "flex-end"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "primary",
                            type: "submit",
                            variant: "contained",
                            children: "Next"
                        })
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Paper/index.js
var Paper = __webpack_require__(427561);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Radio/index.js
var Radio = __webpack_require__(307685);
var Radio_default = /*#__PURE__*/__webpack_require__.n(Radio);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/RadioGroup/index.js
var RadioGroup = __webpack_require__(214891);
;// CONCATENATED MODULE: ./src/sections/components/forms/form-9.tsx








const typeOptions = [
    {
        description: "I'm looking for teammates to join in a personal project",
        title: "I'm a freelancer",
        value: "freelancer"
    },
    {
        description: "I'm looking for freelancer or contractors to take care of my project",
        title: "I’m a project owner",
        value: "projectOwner"
    },
    {
        description: "I'm looking for freelancer or contractors to take care of my project",
        title: "I want to join affiliate",
        value: "affiliate"
    }
];
const Form9 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                component: RadioGroup["default"],
                spacing: 3,
                children: typeOptions.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx((Paper_default()), {
                        sx: {
                            alignItems: "flex-start",
                            display: "flex",
                            p: 2
                        },
                        variant: "outlined",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                            control: /*#__PURE__*/ jsx_runtime_.jsx((Radio_default()), {}),
                            label: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                sx: {
                                    ml: 2
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "subtitle2",
                                        children: option.title
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: option.description
                                    })
                                ]
                            }),
                            value: option.value
                        }, option.value)
                    }, option.value))
            })
        })
    });

// EXTERNAL MODULE: ./src/components/quill-editor.tsx
var quill_editor = __webpack_require__(354131);
;// CONCATENATED MODULE: ./src/sections/components/forms/form-10.tsx






const Form10 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                    fullWidth: true,
                    label: "Product Name",
                    name: "name"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    sx: {
                        mt: 3,
                        mb: 2
                    },
                    variant: "subtitle2",
                    children: "Description"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(quill_editor/* QuillEditor */.B, {
                    placeholder: "Write something",
                    sx: {
                        height: 400
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        display: "flex",
                        justifyContent: "flex-end",
                        mt: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        type: "submit",
                        variant: "contained",
                        children: "Update"
                    })
                })
            ]
        })
    });

;// CONCATENATED MODULE: ./src/sections/components/forms/form-11.tsx







const Form11 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                    container: true,
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "Price",
                                name: "price",
                                type: "number"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                            xs: 12,
                            md: 6,
                            children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                fullWidth: true,
                                label: "Sale price",
                                name: "salePrice",
                                type: "number"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                            xs: 12,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                            name: "isTaxable"
                                        }),
                                        label: "Product is taxable"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                            name: "includesTaxes"
                                        }),
                                        label: "Price includes taxes"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        display: "flex",
                        justifyContent: "flex-end",
                        mt: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        type: "submit",
                        variant: "contained",
                        children: "Update"
                    })
                })
            ]
        })
    });

;// CONCATENATED MODULE: ./src/sections/components/forms/form-12.tsx





const form_12_categoryOptions = [
    {
        label: "Shirts",
        value: "shirts"
    },
    {
        label: "Phones",
        value: "phones"
    },
    {
        label: "Cars",
        value: "cars"
    }
];
const Form12 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                            fullWidth: true,
                            label: "Category",
                            name: "category",
                            select: true,
                            SelectProps: {
                                native: true
                            },
                            children: form_12_categoryOptions.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: option.value,
                                    children: option.label
                                }, option.value))
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                            fullWidth: true,
                            label: "Product Code",
                            name: "productCode"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                            fullWidth: true,
                            label: "Product Sku",
                            name: "productSku"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        mt: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        type: "submit",
                        variant: "contained",
                        children: "Create Product"
                    })
                })
            ]
        })
    });

;// CONCATENATED MODULE: ./src/sections/components/forms/form-13.tsx











const paymentMethods = [
    {
        label: "Visa Credit/Debit Card",
        value: "visa"
    },
    {
        label: "PayPal",
        value: "paypal"
    }
];
const Form13 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    spacing: 6,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 3,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 2,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                            sx: {
                                                alignItems: "center",
                                                border: (theme)=>`1px solid ${theme.palette.divider}`,
                                                borderRadius: 20,
                                                display: "flex",
                                                height: 40,
                                                justifyContent: "center",
                                                width: 40
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                sx: {
                                                    fontWeight: "fontWeightBold"
                                                },
                                                variant: "h6",
                                                children: "1"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "h6",
                                            children: "Billing Address"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                                        container: true,
                                        spacing: 3,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                xs: 12,
                                                sm: 6,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                    fullWidth: true,
                                                    label: "First Name",
                                                    name: "firstName"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                xs: 12,
                                                sm: 6,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                    fullWidth: true,
                                                    label: "Last Name",
                                                    name: "lastName"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                xs: 12,
                                                sm: 6,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                    fullWidth: true,
                                                    label: "Street Address",
                                                    name: "address"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                xs: 12,
                                                sm: 6,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                    fullWidth: true,
                                                    label: "Street Line 2 (optional)",
                                                    name: "optionalAddress"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                xs: 12,
                                                sm: 3,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                    fullWidth: true,
                                                    label: "State",
                                                    name: "state"
                                                })
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                xs: 12,
                                                sm: 3,
                                                children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                    fullWidth: true,
                                                    label: "Zip",
                                                    name: "zip"
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 3,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 2,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                            sx: {
                                                alignItems: "center",
                                                border: (theme)=>`1px solid ${theme.palette.divider}`,
                                                borderRadius: 20,
                                                display: "flex",
                                                height: 40,
                                                justifyContent: "center",
                                                width: 40
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                sx: {
                                                    fontWeight: "fontWeightBold"
                                                },
                                                variant: "h6",
                                                children: "2"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "h6",
                                            children: "Shipping Address"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                            defaultChecked: true
                                        }),
                                        label: "Same as billing address"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 3,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 2,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                            sx: {
                                                alignItems: "center",
                                                border: (theme)=>`1px solid ${theme.palette.divider}`,
                                                borderRadius: 20,
                                                display: "flex",
                                                height: 40,
                                                justifyContent: "center",
                                                width: 40
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                sx: {
                                                    fontWeight: "fontWeightBold"
                                                },
                                                variant: "h6",
                                                children: "3"
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "h6",
                                            children: "Payment Method"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    spacing: 3,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(RadioGroup["default"], {
                                                name: "paymentMethod",
                                                sx: {
                                                    flexDirection: "row"
                                                },
                                                children: paymentMethods.map((paymentMethod)=>/*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Radio_default()), {}),
                                                        label: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                            variant: "body1",
                                                            children: paymentMethod.label
                                                        }),
                                                        value: paymentMethod.value
                                                    }, paymentMethod.value))
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                                                container: true,
                                                spacing: 3,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                        xs: 12,
                                                        sm: 6,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                            fullWidth: true,
                                                            label: "Name on Card",
                                                            name: "cardOwner"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                        xs: 12,
                                                        sm: 6
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                        xs: 12,
                                                        sm: 6,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                            fullWidth: true,
                                                            label: "Card Number",
                                                            name: "cardNumber"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                        xs: 12,
                                                        sm: 6
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                        xs: 12,
                                                        sm: 3,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                            fullWidth: true,
                                                            label: "Expire Date",
                                                            name: "cardExpirationDate",
                                                            placeholder: "MM/YY"
                                                        })
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                                                        xs: 12,
                                                        sm: 3,
                                                        children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                                            fullWidth: true,
                                                            label: "Security Code",
                                                            name: "cardSecurityCode"
                                                        })
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        display: "flex",
                        justifyContent: "flex-end",
                        mt: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        type: "submit",
                        variant: "contained",
                        children: "Submit"
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/numeral/numeral.js
var numeral = __webpack_require__(518470);
var numeral_default = /*#__PURE__*/__webpack_require__.n(numeral);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/FormControl/index.js
var FormControl = __webpack_require__(380428);
var FormControl_default = /*#__PURE__*/__webpack_require__.n(FormControl);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/List/index.js
var List = __webpack_require__(854436);
var List_default = /*#__PURE__*/__webpack_require__.n(List);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItem/index.js
var ListItem = __webpack_require__(790777);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemAvatar/index.js
var ListItemAvatar = __webpack_require__(372355);
var ListItemAvatar_default = /*#__PURE__*/__webpack_require__.n(ListItemAvatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemSecondaryAction/index.js
var ListItemSecondaryAction = __webpack_require__(120662);
var ListItemSecondaryAction_default = /*#__PURE__*/__webpack_require__.n(ListItemSecondaryAction);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemText/index.js
var ListItemText = __webpack_require__(846517);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/MenuItem/index.js
var MenuItem = __webpack_require__(662360);
var MenuItem_default = /*#__PURE__*/__webpack_require__.n(MenuItem);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Select/index.js
var Select = __webpack_require__(679006);
var Select_default = /*#__PURE__*/__webpack_require__.n(Select);
;// CONCATENATED MODULE: ./src/sections/components/forms/form-14.tsx
















const products = [
    {
        id: "97375399bf10f57d0f0f7fd9",
        image: "/assets/products/product-1.png",
        name: "Healthcare Erbology",
        price: 23.99,
        quantity: 1
    },
    {
        id: "ece4069546ff025047b97735",
        image: "/assets/products/product-2.png",
        name: "Makeup Lancome Rouge",
        price: 95.00,
        quantity: 1
    }
];
const Form14 = ()=>{
    const subtotalAmount = numeral_default()(20).format("$00.00");
    const shippingAmount = numeral_default()(10).format("$00.00");
    const totalAmount = numeral_default()(12).format("$00.00");
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
            onSubmit: (event)=>event.preventDefault(),
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                    sx: {
                        p: 3
                    },
                    variant: "outlined",
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "h6",
                            children: "Order Summary"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                            sx: {
                                mt: 2
                            },
                            children: products.map((product)=>{
                                const price = numeral_default()(product.price).format("$00.00");
                                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                    disableGutters: true,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                            sx: {
                                                pr: 2
                                            },
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                sx: {
                                                    alignItems: "center",
                                                    display: "flex",
                                                    height: 100,
                                                    justifyContent: "center",
                                                    overflow: "hidden",
                                                    width: 100,
                                                    "& img": {
                                                        width: "100%",
                                                        height: "auto"
                                                    }
                                                },
                                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                                    alt: product.name,
                                                    src: product.image
                                                })
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                            primary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                sx: {
                                                    fontWeight: "fontWeightBold"
                                                },
                                                variant: "subtitle2",
                                                children: product.name
                                            }),
                                            secondary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                sx: {
                                                    mt: 1
                                                },
                                                variant: "body1",
                                                children: price
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemSecondaryAction_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((FormControl_default()), {
                                                size: "small",
                                                variant: "outlined",
                                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Select_default()), {
                                                    value: product.quantity,
                                                    children: [
                                                        /*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                                                            value: 1,
                                                            children: "1"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                                                            value: 2,
                                                            children: "2"
                                                        }),
                                                        /*#__PURE__*/ jsx_runtime_.jsx((MenuItem_default()), {
                                                            value: 3,
                                                            children: "3"
                                                        })
                                                    ]
                                                })
                                            })
                                        })
                                    ]
                                }, product.id);
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                            fullWidth: true,
                            placeholder: "Discount Code",
                            size: "small",
                            sx: {
                                mt: 2
                            },
                            variant: "outlined"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                display: "flex",
                                justifyContent: "flex-end",
                                mt: 2
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                type: "button",
                                children: "Apply Coupon"
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                display: "flex",
                                justifyContent: "space-between",
                                mt: 2
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "subtitle2",
                                    children: "Subtotal"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "subtitle2",
                                    children: subtotalAmount
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                display: "flex",
                                justifyContent: "space-between",
                                mt: 2
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "subtitle2",
                                    children: "Shipping Tax"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "subtitle2",
                                    children: shippingAmount
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                            sx: {
                                my: 2
                            }
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                display: "flex",
                                justifyContent: "space-between"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "subtitle2",
                                    children: "Total"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "subtitle2",
                                    children: totalAmount
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        display: "flex",
                        justifyContent: "flex-end",
                        mt: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        color: "primary",
                        type: "submit",
                        variant: "contained",
                        children: "Complete order"
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/sections/components/forms/form-16.tsx











const Form16 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "sm",
            children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                    sx: {
                        display: "flex",
                        flexDirection: "column",
                        minHeight: 400,
                        p: 4
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                display: "flex",
                                justifyContent: "space-between"
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "h4",
                                            children: "Register"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            sx: {
                                                mt: 1
                                            },
                                            variant: "body2",
                                            children: "Register on the internal platform"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    alt: "Amplify",
                                    src: "/assets/logos/logo-amplify.svg",
                                    style: {
                                        maxWidth: "53.62px",
                                        width: "100%"
                                    }
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                flexGrow: 1,
                                mt: 3
                            },
                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("form", {
                                onSubmit: (event)=>event.preventDefault(),
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                        fullWidth: true,
                                        label: "Name",
                                        margin: "normal",
                                        name: "name"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                        fullWidth: true,
                                        label: "Email Address",
                                        margin: "normal",
                                        name: "email",
                                        type: "email"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                        fullWidth: true,
                                        label: "Password",
                                        margin: "normal",
                                        name: "password",
                                        type: "password"
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                        sx: {
                                            alignItems: "center",
                                            display: "flex",
                                            ml: -1,
                                            mt: 2
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Checkbox_default()), {
                                                name: "policy"
                                            }),
                                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "body2",
                                                children: [
                                                    "I have read the",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        href: "#",
                                                        children: "Terms and Conditions"
                                                    })
                                                ]
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                        sx: {
                                            mt: 2
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                            fullWidth: true,
                                            size: "large",
                                            type: "submit",
                                            variant: "contained",
                                            children: "Register"
                                        })
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                            sx: {
                                my: 3
                            }
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                            color: "text.secondary",
                            href: "#",
                            variant: "body2",
                            children: "Having an account"
                        })
                    ]
                })
            })
        })
    });

;// CONCATENATED MODULE: ./src/app/marketing/components/forms/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 






















const page_components = [
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form1, {}),
        title: "Form 1"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form2, {}),
        title: "Form 2"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form3, {}),
        title: "Form 3"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form4, {}),
        title: "Form 4"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form5, {}),
        title: "Form 5"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form6, {}),
        title: "Form 6"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form7, {}),
        title: "Form 7"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form8, {}),
        title: "Form 8"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form9, {}),
        title: "Form 9"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form10, {}),
        title: "Form 10"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form11, {}),
        title: "Form 11"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form12, {}),
        title: "Form 12"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form13, {}),
        title: "Form 13"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form14, {}),
        title: "Form 14"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Form16, {}),
        title: "Form 16"
    }
];
const Page = ()=>{
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Components: Forms"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Layout */.A, {
                title: "Forms",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "main",
                    sx: {
                        flexGrow: 1,
                        py: 8
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                        maxWidth: "lg",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                            spacing: 8,
                            children: page_components.map((component)=>/*#__PURE__*/ jsx_runtime_.jsx(previewer/* Previewer */.M, {
                                    title: component.title,
                                    children: component.element
                                }, component.title))
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 903268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.usePathname)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 69281:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ usePopover)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

function usePopover() {
    const anchorRef = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(null);
    const [open, setOpen] = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(false);
    const handleOpen = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setOpen(true);
    }, []);
    const handleClose = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setOpen(false);
    }, []);
    const handleToggle = (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>{
        setOpen((prevState)=>!prevState);
    }, []);
    return {
        anchorRef,
        handleClose,
        handleOpen,
        handleToggle,
        open
    };
}


/***/ }),

/***/ 488141:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ useSettings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34383);


const useSettings = ()=>(0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__/* .SettingsContext */ .J6);


/***/ }),

/***/ 532277:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/forms/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,3380,5006,2983,8470,9535,3580,4714,4786,3595,4226,7680,4018,9274,4131,7155], () => (__webpack_exec__(523490)));
module.exports = __webpack_exports__;

})();