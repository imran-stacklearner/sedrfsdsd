(() => {
var exports = {};
exports.id = 2203;
exports.ids = [2203];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 667849:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'marketing',
        {
        children: [
        'components',
        {
        children: [
        'data-display',
        {
        children: [
        'quick-stats',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 130136, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/data-display/quick-stats/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 586068)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/data-display/quick-stats/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/marketing/components/data-display/quick-stats/page"
  

/***/ }),

/***/ 914959:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 722966))

/***/ }),

/***/ 722966:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/layouts/components/index.ts + 2 modules
var components = __webpack_require__(898394);
// EXTERNAL MODULE: ./src/sections/components/previewer.tsx
var previewer = __webpack_require__(213718);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/DotsHorizontal.js
var DotsHorizontal = __webpack_require__(66519);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
// EXTERNAL MODULE: ./src/components/chart.tsx
var chart = __webpack_require__(400929);
;// CONCATENATED MODULE: ./src/sections/components/quick-stats/quick-stats-1.tsx











const chartSeries = [
    56,
    24,
    20
];
const labels = [
    "Subscriptions",
    "Affiliate",
    "Sales"
];
const useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.warning.main,
            theme.palette.info.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        labels,
        legend: {
            show: false
        },
        plotOptions: {
            pie: {
                expandOnClick: false
            }
        },
        states: {
            active: {
                filter: {
                    type: "none"
                }
            },
            hover: {
                filter: {
                    type: "none"
                }
            }
        },
        stroke: {
            show: false
        },
        theme: {
            mode: theme.palette.mode
        },
        tooltip: {
            fillSeriesColor: false
        }
    };
};
const QuickStats1 = ()=>{
    const chartOptions = useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    action: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                        })
                    }),
                    title: "Earnings Source"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        p: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                        height: 300,
                        options: chartOptions,
                        series: chartSeries,
                        type: "donut"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        display: "flex"
                    },
                    children: chartSeries.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                display: "flex",
                                flexDirection: "column",
                                flexGrow: 1,
                                justifyContent: "center",
                                px: 2,
                                py: 3,
                                textAlign: "center",
                                "&:not(:last-of-type)": {
                                    borderRight: 1,
                                    borderColor: "divider"
                                }
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                    variant: "h4",
                                    children: [
                                        item,
                                        "%"
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "overline",
                                    children: labels[index]
                                })
                            ]
                        }, index))
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/CurrencyDollar.js
var CurrencyDollar = __webpack_require__(609543);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Folder.js
var Folder = __webpack_require__(632058);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Unstable_Grid2/index.js
var Unstable_Grid2 = __webpack_require__(377974);
var Unstable_Grid2_default = /*#__PURE__*/__webpack_require__.n(Unstable_Grid2);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/LinearProgress/index.js
var LinearProgress = __webpack_require__(154003);
var LinearProgress_default = /*#__PURE__*/__webpack_require__.n(LinearProgress);
// EXTERNAL MODULE: ./src/components/severity-pill.tsx
var severity_pill = __webpack_require__(594368);
;// CONCATENATED MODULE: ./src/sections/components/quick-stats/quick-stats-2.tsx












const QuickStats2 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
            container: true,
            spacing: 3,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    xs: 12,
                    md: 6,
                    lg: 3,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            spacing: 2,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    spacing: 1,
                                    sx: {
                                        flexGrow: 1
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "overline",
                                            children: "Today's money"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "center",
                                            direction: "row",
                                            spacing: 1,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "h5",
                                                    children: "$24,000"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(severity_pill/* SeverityPill */.I, {
                                                    color: "success",
                                                    children: "4%"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                    sx: {
                                        backgroundColor: "primary.main",
                                        color: "primary.contrastText",
                                        height: 48,
                                        width: 48
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(CurrencyDollar/* default */.Z, {})
                                    })
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    xs: 12,
                    md: 6,
                    lg: 3,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            spacing: 2,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    spacing: 1,
                                    sx: {
                                        flexGrow: 1
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "overline",
                                            children: "New projects"
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                            alignItems: "center",
                                            direction: "row",
                                            spacing: 1,
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                    variant: "h5",
                                                    children: "12"
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx(severity_pill/* SeverityPill */.I, {
                                                    color: "error",
                                                    children: "-10%"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                    sx: {
                                        backgroundColor: "primary.main",
                                        color: "primary.contrastText",
                                        height: 48,
                                        width: 48
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Folder/* default */.Z, {})
                                    })
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    xs: 12,
                    md: 6,
                    lg: 3,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 1,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "overline",
                                    children: "System Health"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 1,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "h5",
                                            children: "74%"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((LinearProgress_default()), {
                                            color: "primary",
                                            sx: {
                                                flexGrow: 1
                                            },
                                            value: 74,
                                            variant: "determinate"
                                        })
                                    ]
                                })
                            ]
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    xs: 12,
                    md: 6,
                    lg: 3,
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                        sx: {
                            alignItems: "center",
                            backgroundColor: "primary.main",
                            color: "primary.contrastText",
                            display: "flex",
                            justifyContent: "space-between"
                        },
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            spacing: 2,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    spacing: 1,
                                    sx: {
                                        flexGrow: 1
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "inherit",
                                            variant: "overline",
                                            children: "Roi per customer"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "inherit",
                                            variant: "h5",
                                            children: "$25.50"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                    sx: {
                                        backgroundColor: "primary.contrastText",
                                        color: "primary.main",
                                        height: 48,
                                        width: 48
                                    },
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(CurrencyDollar/* default */.Z, {})
                                    })
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });

;// CONCATENATED MODULE: ./src/sections/components/quick-stats/quick-stats-3.tsx







const QuickStats3 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                container: true,
                sx: {
                    "& > *:not(:last-of-type)": {
                        borderRight: (theme)=>({
                                md: `1px solid ${theme.palette.divider}`
                            }),
                        borderBottom: (theme)=>({
                                xs: `1px solid ${theme.palette.divider}`,
                                md: "none"
                            })
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        sm: 6,
                        md: 3,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            spacing: 1,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h5",
                                    children: "$4,250.00"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    sx: {
                                        mt: 1
                                    },
                                    variant: "overline",
                                    children: "Next payout"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        sm: 6,
                        md: 3,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            spacing: 1,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h5",
                                    children: "$12,500.00"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "overline",
                                    children: "Total income"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        sm: 6,
                        md: 3,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            spacing: 1,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h5",
                                    children: "230"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "overline",
                                    children: "Today's Visitors"
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        md: 3,
                        sm: 6,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            spacing: 1,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 1,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            component: "span",
                                            variant: "h5",
                                            children: "5"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(severity_pill/* SeverityPill */.I, {
                                            color: "primary",
                                            children: "Live"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "overline",
                                    children: "Active now"
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });

;// CONCATENATED MODULE: ./src/sections/components/quick-stats/quick-stats-4.tsx







const QuickStats4 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                container: true,
                sx: {
                    "& > *:not(:last-of-type)": {
                        borderRight: (theme)=>({
                                md: `1px solid ${theme.palette.divider}`
                            }),
                        borderBottom: (theme)=>({
                                xs: `1px solid ${theme.palette.divider}`,
                                md: "none"
                            })
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        sm: 6,
                        md: 3,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            spacing: 1,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    component: "h2",
                                    variant: "overline",
                                    children: "Total Income"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 1,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "h5",
                                            children: "$854,355.00"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(severity_pill/* SeverityPill */.I, {
                                            color: "success",
                                            children: "+25%"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        sm: 6,
                        md: 3,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            spacing: 1,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    component: "h5",
                                    variant: "overline",
                                    children: "Total Expanses"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 1,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "h5",
                                            children: "$373,250.50"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(severity_pill/* SeverityPill */.I, {
                                            color: "success",
                                            children: "+12%"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        sm: 6,
                        md: 3,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            spacing: 1,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    component: "h2",
                                    variant: "overline",
                                    children: "Net Profit"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 1,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "h5",
                                            children: "$123,532.00"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(severity_pill/* SeverityPill */.I, {
                                            color: "error",
                                            children: "-20%"
                                        })
                                    ]
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        sm: 6,
                        md: 3,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            spacing: 1,
                            sx: {
                                p: 3
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    component: "h2",
                                    variant: "overline",
                                    children: "Active Subscriptions"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h5",
                                    children: "26,000"
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });

;// CONCATENATED MODULE: ./src/sections/components/quick-stats/quick-stats-5.tsx








const quick_stats_5_chartSeries = [
    {
        data: [
            23,
            11,
            22,
            27,
            13,
            22,
            37,
            21,
            44,
            22,
            30
        ]
    }
];
const quick_stats_5_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            toolbar: {
                show: false
            },
            zoom: {
                enabled: false
            }
        },
        colors: [
            theme.palette.primary.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        grid: {
            show: false
        },
        stroke: {
            curve: "smooth",
            width: 3
        },
        theme: {
            mode: theme.palette.mode
        },
        tooltip: {
            enabled: false
        },
        xaxis: {
            labels: {
                show: false
            },
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            }
        },
        yaxis: {
            show: false
        }
    };
};
const Graphic = ()=>{
    const chartOptions = quick_stats_5_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            alignItems: "center",
            display: "flex",
            height: 54,
            width: 177
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
            options: chartOptions,
            series: quick_stats_5_chartSeries,
            type: "line"
        })
    });
};
const QuickStats5 = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
                container: true,
                sx: {
                    "& > *:not(:last-of-type)": {
                        borderRight: (theme)=>({
                                md: `1px solid ${theme.palette.divider}`
                            }),
                        borderBottom: (theme)=>({
                                xs: `1px solid ${theme.palette.divider}`,
                                md: "none"
                            })
                    }
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        md: 4,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            sx: {
                                p: 3
                            },
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "overline",
                                            children: "Sales"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "h5",
                                            children: "$1,529.96"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "caption",
                                            children: "vs. $1,214.20 last day"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Graphic, {})
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        md: 4,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            sx: {
                                p: 3
                            },
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "overline",
                                            children: "Cost"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "h5",
                                            children: "$321.00"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "caption",
                                            children: "vs. $252.00 last day"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Graphic, {})
                            ]
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                        xs: 12,
                        md: 4,
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            sx: {
                                p: 3
                            },
                            spacing: 2,
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "overline",
                                            children: "Profit"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "h5",
                                            children: "$997.00"
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "caption",
                                            children: "vs. $683.00 last day"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(Graphic, {})
                            ]
                        })
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ArrowRight.js
var ArrowRight = __webpack_require__(394284);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronDown.js
var ChevronDown = __webpack_require__(870261);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ChevronUp.js
var ChevronUp = __webpack_require__(267083);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardActions/index.js
var CardActions = __webpack_require__(640362);
var CardActions_default = /*#__PURE__*/__webpack_require__.n(CardActions);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
;// CONCATENATED MODULE: ./src/sections/components/quick-stats/quick-stats-6.tsx

















const quick_stats_6_chartSeries = [
    83
];
const quick_stats_6_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main
        ],
        fill: {
            opacity: 1,
            type: "solid"
        },
        plotOptions: {
            radialBar: {
                dataLabels: {
                    show: false
                },
                hollow: {
                    size: "50%"
                },
                track: {
                    background: theme.palette.background.default
                }
            }
        },
        states: {
            active: {
                filter: {
                    type: "none"
                }
            },
            hover: {
                filter: {
                    type: "none"
                }
            }
        },
        theme: {
            mode: theme.palette.mode
        }
    };
};
const QuickStats6 = ()=>{
    const chartOptions = quick_stats_6_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Unstable_Grid2_default()), {
            container: true,
            spacing: 3,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 2,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                                            height: 160,
                                            options: chartOptions,
                                            series: quick_stats_6_chartSeries,
                                            type: "radialBar",
                                            width: 160
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                            sx: {
                                                flexGrow: 1
                                            },
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                spacing: 1,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "h4",
                                                        children: "0.299 BTC"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "subtitle2",
                                                        children: "Weekly earnings"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                            sx: {
                                                backgroundColor: "success.alpha8",
                                                color: "success.main"
                                            },
                                            variant: "rounded",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronUp/* default */.Z, {})
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    color: "inherit",
                                    endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                                    }),
                                    children: "See all activity"
                                })
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Unstable_Grid2_default()), {
                    xs: 12,
                    md: 6,
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                    alignItems: "center",
                                    direction: "row",
                                    spacing: 2,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                                            height: 160,
                                            options: chartOptions,
                                            series: quick_stats_6_chartSeries,
                                            type: "radialBar",
                                            width: 160
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                            sx: {
                                                flexGrow: 1
                                            },
                                            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                spacing: 1,
                                                children: [
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "h4",
                                                        children: "$52,000.00"
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "subtitle2",
                                                        children: "Your private wallet"
                                                    })
                                                ]
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                            sx: {
                                                backgroundColor: "error.alpha8",
                                                color: "error.main"
                                            },
                                            variant: "rounded",
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(ChevronDown/* default */.Z, {})
                                            })
                                        })
                                    ]
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                            /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    color: "inherit",
                                    endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                                    }),
                                    children: "Withdraw money"
                                })
                            })
                        ]
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/sections/components/quick-stats/quick-stats-7.tsx









const QuickStats7 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Profile Progress"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        spacing: 2,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((LinearProgress_default()), {
                                value: 50,
                                variant: "determinate"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.secondary",
                                variant: "subtitle2",
                                children: "50% Set Up Complete"
                            })
                        ]
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/RefreshCcw02.js
var RefreshCcw02 = __webpack_require__(273856);
;// CONCATENATED MODULE: ./src/sections/components/quick-stats/quick-stats-8.tsx










const quick_stats_8_chartSeries = [
    {
        name: "Conversions",
        data: [
            14,
            43,
            98,
            68,
            155,
            18,
            8
        ]
    }
];
const quick_stats_8_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            toolbar: {
                show: false
            },
            zoom: {
                enabled: false
            }
        },
        colors: [
            theme.palette.primary.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        grid: {
            yaxis: {
                lines: {
                    show: false
                }
            },
            xaxis: {
                lines: {
                    show: false
                }
            }
        },
        legend: {
            show: false
        },
        stroke: {
            width: 2
        },
        theme: {
            mode: theme.palette.mode
        },
        xaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            },
            labels: {
                show: false
            }
        },
        yaxis: {
            labels: {
                show: false
            }
        },
        tooltip: {
            enabled: false
        }
    };
};
const QuickStats8 = ()=>{
    const chartOptions = quick_stats_8_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
            maxWidth: "sm",
            sx: {
                mx: "auto"
            },
            children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    spacing: 2,
                    sx: {
                        p: 3
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                            sx: {
                                backgroundColor: "primary.main",
                                color: "primary.contrastText"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(RefreshCcw02/* default */.Z, {})
                            })
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                flexGrow: 1
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    noWrap: true,
                                    variant: "body1",
                                    children: "Conversions"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "h4",
                                    children: "361"
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                maxWidth: 200
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                                height: 100,
                                type: "line",
                                options: chartOptions,
                                series: quick_stats_8_chartSeries
                            })
                        })
                    ]
                })
            })
        })
    });
};

// EXTERNAL MODULE: ./node_modules/numeral/numeral.js
var numeral = __webpack_require__(518470);
var numeral_default = /*#__PURE__*/__webpack_require__.n(numeral);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/TrendUp02.js
var TrendUp02 = __webpack_require__(548065);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/TrendDown02.js
var TrendDown02 = __webpack_require__(821867);
;// CONCATENATED MODULE: ./src/sections/components/quick-stats/quick-stats-9.tsx
















const quick_stats_9_chartSeries = [
    21500,
    15300,
    1076.81
];
const quick_stats_9_labels = [
    "US Dollars",
    "Bitcoin",
    "XRP Ripple"
];
const quick_stats_9_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent"
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.info.main,
            theme.palette.warning.main
        ],
        dataLabels: {
            enabled: false
        },
        grid: {
            padding: {
                top: 0,
                right: 0,
                bottom: 0,
                left: 0
            }
        },
        labels: quick_stats_9_labels,
        legend: {
            show: false
        },
        plotOptions: {
            pie: {
                expandOnClick: false
            },
            radialBar: {
                dataLabels: {
                    show: false
                },
                hollow: {
                    size: "100%"
                }
            }
        },
        states: {
            active: {
                filter: {
                    type: "none"
                }
            },
            hover: {
                filter: {
                    type: "none"
                }
            }
        },
        stroke: {
            width: 0
        },
        theme: {
            mode: theme.palette.mode
        },
        tooltip: {
            fillSeriesColor: false
        }
    };
};
const QuickStats9 = ()=>{
    const chartOptions = quick_stats_9_useChartOptions();
    const totalAmount = quick_stats_9_chartSeries.reduce((acc, item)=>acc += item, 0);
    const formattedTotalAmount = numeral_default()(totalAmount).format("$0,0.00");
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Current Balance",
                    subheader: "Balance across all your accounts"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        flexWrap: "wrap",
                        spacing: 3,
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    alignItems: "center",
                                    display: "flex",
                                    height: 200,
                                    justifyContent: "center",
                                    width: 200
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                                    height: 200,
                                    options: chartOptions,
                                    series: quick_stats_9_chartSeries,
                                    type: "donut"
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                spacing: 4,
                                sx: {
                                    flexGrow: 1
                                },
                                children: [
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                        spacing: 1,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "overline",
                                                children: "Total balance"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "h4",
                                                children: formattedTotalAmount
                                            })
                                        ]
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                        spacing: 1,
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "overline",
                                                children: "Available currency"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                                component: "ul",
                                                spacing: 1,
                                                sx: {
                                                    listStyle: "none",
                                                    m: 0,
                                                    p: 0
                                                },
                                                children: quick_stats_9_chartSeries.map((item, index)=>{
                                                    const amount = numeral_default()(item).format("$0,0.00");
                                                    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                        alignItems: "center",
                                                        component: "li",
                                                        direction: "row",
                                                        spacing: 2,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                                sx: {
                                                                    backgroundColor: chartOptions.colors[index],
                                                                    borderRadius: "4px",
                                                                    height: 16,
                                                                    width: 16
                                                                }
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                sx: {
                                                                    flexGrow: 1
                                                                },
                                                                variant: "subtitle2",
                                                                children: quick_stats_9_labels[index]
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                color: "text.secondary",
                                                                variant: "subtitle2",
                                                                children: amount
                                                            })
                                                        ]
                                                    }, index);
                                                })
                                            })
                                        ]
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardActions_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                fontSize: "small",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(TrendUp02/* default */.Z, {})
                            }),
                            size: "small",
                            children: "Add funds"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                fontSize: "small",
                                children: /*#__PURE__*/ jsx_runtime_.jsx(TrendDown02/* default */.Z, {})
                            }),
                            size: "small",
                            children: "Transfer funds"
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/app/marketing/components/data-display/quick-stats/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 
















const page_components = [
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(QuickStats1, {}),
        title: "Quick stats 1"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(QuickStats2, {}),
        title: "Quick stats 2"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(QuickStats3, {}),
        title: "Quick stats 3"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(QuickStats4, {}),
        title: "Quick stats 4"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(QuickStats5, {}),
        title: "Quick stats 5"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(QuickStats6, {}),
        title: "Quick stats 6"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(QuickStats7, {}),
        title: "Quick stats 7"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(QuickStats8, {}),
        title: "Quick stats 8"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(QuickStats9, {}),
        title: "Quick stats 9"
    }
];
const Page = ()=>{
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Components: Quick Stats"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Layout */.A, {
                title: "Quick Stats",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "main",
                    sx: {
                        flexGrow: 1,
                        py: 8
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                        maxWidth: "lg",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                            spacing: 8,
                            children: page_components.map((component)=>/*#__PURE__*/ jsx_runtime_.jsx(previewer/* Previewer */.M, {
                                    title: component.title,
                                    children: component.element
                                }, component.title))
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 903268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.usePathname)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 488141:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ useSettings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34383);


const useSettings = ()=>(0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__/* .SettingsContext */ .J6);


/***/ }),

/***/ 130136:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/data-display/quick-stats/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,3380,5006,2983,8470,9535,6519,9543,7363,7680,4018,9274,4368,929], () => (__webpack_exec__(667849)));
module.exports = __webpack_exports__;

})();