(() => {
var exports = {};
exports.id = 7362;
exports.ids = [7362];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 677282:
/***/ ((module) => {

"use strict";
module.exports = require("process");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 229790:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'marketing',
        {
        children: [
        'components',
        {
        children: [
        'data-display',
        {
        children: [
        'detail-lists',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 72188, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/data-display/detail-lists/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 586068)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/data-display/detail-lists/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/marketing/components/data-display/detail-lists/page"
  

/***/ }),

/***/ 544188:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 764956))

/***/ }),

/***/ 764956:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/layouts/components/index.ts + 2 modules
var components = __webpack_require__(898394);
// EXTERNAL MODULE: ./src/sections/components/previewer.tsx
var previewer = __webpack_require__(213718);
// EXTERNAL MODULE: ./node_modules/numeral/numeral.js
var numeral = __webpack_require__(518470);
var numeral_default = /*#__PURE__*/__webpack_require__.n(numeral);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ArrowRight.js
var ArrowRight = __webpack_require__(394284);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/List/index.js
var List = __webpack_require__(854436);
var List_default = /*#__PURE__*/__webpack_require__.n(List);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItem/index.js
var ListItem = __webpack_require__(790777);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemText/index.js
var ListItemText = __webpack_require__(846517);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
;// CONCATENATED MODULE: ./src/sections/components/detail-lists/detail-list-1.tsx
















const assets = [
    {
        amount: 21500,
        color: "#6C76C4",
        name: "US Dollars"
    },
    {
        amount: 15300,
        color: "#33BB78",
        name: "Bitcoin"
    },
    {
        amount: 1076.81,
        color: "#FF4081",
        name: "XRP Ripple"
    }
];
const DetailList1 = ()=>{
    const totalAmount = assets.reduce((acc, asset)=>acc += asset.amount, 0);
    const formattedTotalAmount = numeral_default()(totalAmount).format("$0,0.00");
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "sm",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        subheader: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "h4",
                            children: formattedTotalAmount
                        }),
                        sx: {
                            pb: 0
                        },
                        title: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            color: "text.secondary",
                            variant: "overline",
                            children: "Total balance"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {
                                sx: {
                                    mb: 2
                                }
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                color: "text.secondary",
                                variant: "overline",
                                children: "Available currency"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                                disablePadding: true,
                                sx: {
                                    pt: 2
                                },
                                children: assets.map((currency)=>{
                                    const amount = numeral_default()(currency.amount).format("$0,0.00");
                                    return /*#__PURE__*/ jsx_runtime_.jsx((ListItem_default()), {
                                        disableGutters: true,
                                        sx: {
                                            pb: 2,
                                            pt: 0
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                            disableTypography: true,
                                            primary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                alignItems: "center",
                                                direction: "row",
                                                justifyContent: "space-between",
                                                spacing: 2,
                                                children: [
                                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                                        alignItems: "center",
                                                        direction: "row",
                                                        spacing: 2,
                                                        children: [
                                                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                                sx: {
                                                                    backgroundColor: currency.color,
                                                                    height: 8,
                                                                    width: 8,
                                                                    borderRadius: "50%"
                                                                }
                                                            }),
                                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                                variant: "subtitle2",
                                                                children: currency.name
                                                            })
                                                        ]
                                                    }),
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        color: "text.secondary",
                                                        variant: "subtitle2",
                                                        children: amount
                                                    })
                                                ]
                                            })
                                        })
                                    }, currency.name);
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                alignItems: "flex-start",
                                spacing: 1,
                                sx: {
                                    mt: 2
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                        color: "inherit",
                                        endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                                        }),
                                        children: "Add money"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                        color: "inherit",
                                        endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                                        }),
                                        children: "Withdraw funds"
                                    })
                                ]
                            })
                        ]
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Lock01.js
var Lock01 = __webpack_require__(105305);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/User01.js
var User01 = __webpack_require__(325055);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Table/index.js
var Table = __webpack_require__(620390);
var Table_default = /*#__PURE__*/__webpack_require__.n(Table);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableBody/index.js
var TableBody = __webpack_require__(843606);
var TableBody_default = /*#__PURE__*/__webpack_require__.n(TableBody);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableCell/index.js
var TableCell = __webpack_require__(340514);
var TableCell_default = /*#__PURE__*/__webpack_require__.n(TableCell);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TableRow/index.js
var TableRow = __webpack_require__(893761);
var TableRow_default = /*#__PURE__*/__webpack_require__.n(TableRow);
// EXTERNAL MODULE: ./src/components/severity-pill.tsx
var severity_pill = __webpack_require__(594368);
;// CONCATENATED MODULE: ./src/sections/components/detail-lists/detail-list-2.tsx
















const DetailList2 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Contact Details"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx((Table_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableBody_default()), {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Email"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "body2",
                                                children: "miron.vitold@devias.io"
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx(severity_pill/* SeverityPill */.I, {
                                                color: "success",
                                                children: "Email verified"
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Phone"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: "+55 748 327 439"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Country"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: "USA"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "State/Region"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: "New York"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Address 1"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: "Street John Wick, no. 7"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Address 2"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: "House #25"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "flex-start",
                    spacing: 1,
                    sx: {
                        p: 1
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Lock01/* default */.Z, {})
                            }),
                            children: "Reset & Send Password"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(User01/* default */.Z, {})
                            }),
                            children: "Login as Customer"
                        })
                    ]
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/CurrencyDollar.js
var CurrencyDollar = __webpack_require__(609543);
// EXTERNAL MODULE: ./node_modules/@babel/runtime/helpers/esm/extends.js
var esm_extends = __webpack_require__(369885);
// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
;// CONCATENATED MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Receipt.js



var Receipt = function Receipt(props) {
  return /*#__PURE__*/(0,jsx_runtime_.jsx)("svg", (0,esm_extends/* default */.Z)({
    xmlns: "http://www.w3.org/2000/svg",
    width: 24,
    height: 24,
    fill: "none"
  }, props, {
    children: /*#__PURE__*/(0,jsx_runtime_.jsx)("path", {
      fill: "#fff",
      fillOpacity: 0.01,
      stroke: "currentColor",
      strokeLinecap: "round",
      strokeLinejoin: "round",
      strokeWidth: 2,
      d: "M4 7.8c0-1.6802 0-2.5202.327-3.162a3 3 0 0 1 1.311-1.311C6.2798 3 7.1198 3 8.8 3h6.4c1.6802 0 2.5202 0 3.162.327a2.9997 2.9997 0 0 1 1.311 1.311C20 5.2798 20 6.1198 20 7.8V21l-2.75-2-2.5 2L12 19l-2.75 2-2.5-2L4 21V7.8Z"
    })
  }));
};
/* harmony default export */ const esm_Receipt = (Receipt);
;// CONCATENATED MODULE: ./src/sections/components/detail-lists/detail-list-3.tsx















const DetailList3 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Invoices/CheckoutBilling"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx((Table_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableBody_default()), {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Credit Card"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: "**** **** **** **** 4142"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Paid"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: "2 ($50.00)"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Draft"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: "1 ($5.00)"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Unpaid/Due"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: "1 ($12.00)"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Refunded"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: "0 ($0.00)"
                                        })
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Gross Income"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "body2",
                                            children: "$1,200.00"
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "flex-start",
                    spacing: 1,
                    sx: {
                        p: 1
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(CurrencyDollar/* default */.Z, {})
                            }),
                            children: "Create Invoice"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(esm_Receipt, {})
                            }),
                            children: "Resend Due Invoices"
                        })
                    ]
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Mail01.js
var Mail01 = __webpack_require__(871920);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TextField/index.js
var TextField = __webpack_require__(28379);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField);
;// CONCATENATED MODULE: ./src/sections/components/detail-lists/detail-list-4.tsx

















const now = new Date();
const emails = [
    {
        id: "5ece2ce3613486d95ffaea58",
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 34), 5), 3).getTime(),
        description: "Order confirmation"
    },
    {
        id: "5ece2ce8cebf7ad1d100c0cd",
        createdAt: (0,date_fns.subDays)((0,date_fns.subHours)((0,date_fns.subMinutes)(now, 49), 11), 4).getTime(),
        description: "Order confirmation"
    }
];
const emailOptions = [
    "Resend last invoice",
    "Send password reset",
    "Send verification"
];
const DetailList4 = ()=>{
    const [emailOption, setEmailOption] = (0,react_.useState)(emailOptions[0]);
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Emails"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                            fullWidth: true,
                            name: "option",
                            onChange: (event)=>setEmailOption(event.target.value),
                            select: true,
                            SelectProps: {
                                native: true
                            },
                            value: emailOption,
                            variant: "outlined",
                            children: emailOptions.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: option,
                                    children: option
                                }, option))
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                mt: 2
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Mail01/* default */.Z, {})
                                }),
                                variant: "contained",
                                children: "Send email"
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                mt: 2
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Table_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx((TableBody_default()), {
                                    children: emails.map((email)=>{
                                        const createdAt = (0,date_fns.format)(email.createdAt, "dd/MM/yyyy | HH:mm");
                                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                        variant: "subtitle2",
                                                        children: email.description
                                                    })
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                                    children: createdAt
                                                })
                                            ]
                                        }, email.id);
                                    })
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardActions/index.js
var CardActions = __webpack_require__(640362);
var CardActions_default = /*#__PURE__*/__webpack_require__.n(CardActions);
;// CONCATENATED MODULE: ./src/sections/components/detail-lists/detail-list-5.tsx


















const order = {
    id: "5ecb8a6879877087d4aa2690",
    coupon: null,
    createdAt: new Date().getTime(),
    currency: "$",
    customer: {
        address1: "Street John Wick, no. 7",
        address2: "House #25",
        city: "San Diego",
        country: "USA",
        email: "miron.vitold@devias.io",
        name: "Miron Vitold"
    },
    items: [
        {
            id: "5ecb8abbdd6dfb1f9d6bf98b",
            billingCycle: "monthly",
            currency: "$",
            name: "Project Points",
            quantity: 25,
            unitAmount: 50.25
        },
        {
            id: "5ecb8ac10f116d04bed990eb",
            billingCycle: "monthly",
            currency: "$",
            name: "Freelancer Subscription",
            quantity: 1,
            unitAmount: 5.0
        }
    ],
    number: "DEV-103",
    paymentMethod: "CreditCard",
    status: "pending",
    totalAmount: 500.0
};
const statusOptions = [
    "Canceled",
    "Completed",
    "Rejected"
];
const DetailList5 = ()=>{
    const [status, setStatus] = (0,react_.useState)(statusOptions[0]);
    const handleChange = (0,react_.useCallback)((event)=>{
        setStatus(event.target.value);
    }, []);
    const createdAt = (0,date_fns.format)(order.createdAt, "dd/MM/yyyy HH:mm");
    const totalAmount = numeral_default()(order.totalAmount).format(`${order.currency}0,0.00`);
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Order info"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ jsx_runtime_.jsx((Table_default()), {
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableBody_default()), {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Customer"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: order.customer.name
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: order.customer.address1
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: order.customer.city
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                                children: order.customer.country
                                            })
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "ID"
                                        })
                                    }),
                                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableCell_default()), {
                                        children: [
                                            "#",
                                            order.id
                                        ]
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Number"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: order.number
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Date"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: createdAt
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Promotion Code"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: order.coupon ? order.coupon : "N/A"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Total Amount"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: totalAmount
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((TableRow_default()), {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            variant: "subtitle2",
                                            children: "Status"
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((TableCell_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                                            fullWidth: true,
                                            name: "option",
                                            onChange: handleChange,
                                            select: true,
                                            SelectProps: {
                                                native: true
                                            },
                                            value: status,
                                            variant: "outlined",
                                            children: statusOptions.map((option)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                                    value: option,
                                                    children: option
                                                }, option))
                                        })
                                    })
                                ]
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        color: "inherit",
                        startIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(esm_Receipt, {})
                        }),
                        children: "Resend Invoice"
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/react-markdown/lib/react-markdown.js + 124 modules
var react_markdown = __webpack_require__(508115);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Chip/index.js
var Chip = __webpack_require__(829553);
var Chip_default = /*#__PURE__*/__webpack_require__.n(Chip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
;// CONCATENATED MODULE: ./src/sections/components/detail-lists/detail-list-6.tsx









const MarkdownWrapper = (0,styles.styled)("div")(({ theme  })=>({
        color: theme.palette.text.primary,
        fontFamily: theme.typography.fontFamily,
        "& p": {
            margin: 0
        },
        "& p+p": {
            marginTop: theme.spacing(2)
        }
    }));
const description = `
Design files are attached in the files tab.

Develop the web app screens for our product called "PDFace". Please look at the wireframes, system activity workflow and read the section above to understand what we're trying to archive.

There's not many screens we need designed, but there will be modals and various other system triggered events that will need to be considered.

The project has been created in Sketch so let me know if there are any problems opening this project and I'll try to convert into a usable file.
`;
const DetailList6 = ()=>{
    const tags = [
        "React JS"
    ];
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
            children: /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "overline",
                                    children: "Project Name"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    variant: "subtitle2",
                                    children: "Develop a PDF Export App"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "overline",
                                    children: "Tags"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: tags.map((tag)=>/*#__PURE__*/ jsx_runtime_.jsx((Chip_default()), {
                                            label: tag,
                                            variant: "outlined"
                                        }, tag))
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                    color: "text.secondary",
                                    variant: "overline",
                                    children: "Description"
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx(MarkdownWrapper, {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(react_markdown/* ReactMarkdown */.D, {
                                        children: description
                                    })
                                })
                            ]
                        })
                    ]
                })
            })
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
;// CONCATENATED MODULE: ./src/sections/components/detail-lists/detail-list-7.tsx












const DetailList7 = ()=>{
    const deadline = (0,date_fns.format)((0,date_fns.addDays)(new Date(), 14).getTime(), "dd MMM yyyy");
    const budget = numeral_default()(12500.0).format("$0,0.00");
    const lastUpdate = (0,date_fns.format)((0,date_fns.subMinutes)(new Date(), 23).getTime(), "dd MMM yyyy");
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    avatar: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                        src: "/assets/avatars/avatar-omar-darboe.png"
                    }),
                    disableTypography: true,
                    subheader: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                        color: "text.primary",
                        underline: "none",
                        variant: "subtitle2",
                        children: "Omar Darobe"
                    }),
                    style: {
                        paddingBottom: 0
                    },
                    title: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        color: "text.secondary",
                        sx: {
                            display: "block"
                        },
                        variant: "overline",
                        children: "Contest holder"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    sx: {
                        pt: 0
                    },
                    children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((List_default()), {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                disableGutters: true,
                                divider: true,
                                sx: {
                                    justifyContent: "space-between",
                                    padding: 2
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "subtitle2",
                                        children: "Deadline"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: deadline
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                disableGutters: true,
                                divider: true,
                                sx: {
                                    justifyContent: "space-between",
                                    padding: 2
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "subtitle2",
                                        children: "Budget"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: budget
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                disableGutters: true,
                                sx: {
                                    justifyContent: "space-between",
                                    padding: 2
                                },
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "subtitle2",
                                        children: "Last Update"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "body2",
                                        children: lastUpdate
                                    })
                                ]
                            })
                        ]
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/BookOpen01.js
var BookOpen01 = __webpack_require__(979192);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Briefcase01.js
var Briefcase01 = __webpack_require__(587585);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Home02.js
var Home02 = __webpack_require__(378955);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemAvatar/index.js
var ListItemAvatar = __webpack_require__(372355);
var ListItemAvatar_default = /*#__PURE__*/__webpack_require__.n(ListItemAvatar);
;// CONCATENATED MODULE: ./src/sections/components/detail-lists/detail-list-8.tsx
















const DetailList8 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "About"
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            color: "text.secondary",
                            variant: "subtitle2",
                            children: '" Everyone thinks of changing the world, but no one thinks of changing himself. "'
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((List_default()), {
                            children: [
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                    disableGutters: true,
                                    divider: true,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                color: "action",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Briefcase01/* default */.Z, {})
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                            disableTypography: true,
                                            primary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                variant: "subtitle2",
                                                children: [
                                                    "Product Designer at",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        color: "text.primary",
                                                        href: "#",
                                                        variant: "subtitle2",
                                                        children: "Devias"
                                                    })
                                                ]
                                            }),
                                            secondary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "caption",
                                                children: [
                                                    "Past: UX Designer",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        color: "text.secondary",
                                                        href: "#",
                                                        variant: "caption",
                                                        children: "Focus Aesthetic Dynamics"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                    disableGutters: true,
                                    divider: true,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                color: "action",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(BookOpen01/* default */.Z, {})
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                            primary: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                color: "text.secondary",
                                                sx: {
                                                    cursor: "pointer"
                                                },
                                                variant: "body2",
                                                children: "Add school or collage"
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                    disableGutters: true,
                                    divider: true,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                color: "action",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Home02/* default */.Z, {})
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                            disableTypography: true,
                                            primary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                variant: "subtitle2",
                                                children: [
                                                    "Lives in",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        color: "text.primary",
                                                        href: "#",
                                                        variant: "subtitle2",
                                                        children: "Bucharest"
                                                    })
                                                ]
                                            }),
                                            secondary: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                                color: "text.secondary",
                                                variant: "caption",
                                                children: [
                                                    "Originally from",
                                                    " ",
                                                    /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                                        color: "text.secondary",
                                                        href: "#",
                                                        variant: "caption",
                                                        children: "Rm. Valcea"
                                                    })
                                                ]
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                    disableGutters: true,
                                    divider: true,
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                                color: "action",
                                                children: /*#__PURE__*/ jsx_runtime_.jsx(Mail01/* default */.Z, {})
                                            })
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                            primary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "subtitle2",
                                                children: "katarina.smith@devias.io"
                                            })
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });

;// CONCATENATED MODULE: ./src/app/marketing/components/data-display/detail-lists/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 















const page_components = [
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(DetailList1, {}),
        title: "Detail list 1"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(DetailList2, {}),
        title: "Detail list 2"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(DetailList3, {}),
        title: "Detail list 3"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(DetailList4, {}),
        title: "Detail list 4"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(DetailList5, {}),
        title: "Detail list 5"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(DetailList6, {}),
        title: "Detail list 6"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(DetailList7, {}),
        title: "Detail list 7"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(DetailList8, {}),
        title: "Detail list 8"
    }
];
const Page = ()=>{
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Components: Detail Lists"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Layout */.A, {
                title: "Detail Lists",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "main",
                    sx: {
                        flexGrow: 1,
                        py: 8
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                        maxWidth: "lg",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                            spacing: 8,
                            children: page_components.map((component)=>/*#__PURE__*/ jsx_runtime_.jsx(previewer/* Previewer */.M, {
                                    title: component.title,
                                    children: component.element
                                }, component.title))
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 903268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.usePathname)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 488141:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ useSettings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34383);


const useSettings = ()=>(0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__/* .SettingsContext */ .J6);


/***/ }),

/***/ 72188:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/data-display/detail-lists/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,3380,4755,6609,5055,5006,2983,8470,1920,8115,2391,9225,9543,7680,4018,9274,4368], () => (__webpack_exec__(229790)));
module.exports = __webpack_exports__;

})();