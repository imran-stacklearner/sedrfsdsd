(() => {
var exports = {};
exports.id = 1004;
exports.ids = [1004];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 588625:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'marketing',
        {
        children: [
        'components',
        {
        children: [
        'charts',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 65213, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/charts/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 586068)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/charts/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/marketing/components/charts/page"
  

/***/ }),

/***/ 35431:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 404540))

/***/ }),

/***/ 404540:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/layouts/components/index.ts + 2 modules
var components = __webpack_require__(898394);
// EXTERNAL MODULE: ./src/sections/components/previewer.tsx
var previewer = __webpack_require__(213718);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Card/index.js
var Card = __webpack_require__(176395);
var Card_default = /*#__PURE__*/__webpack_require__.n(Card);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardContent/index.js
var CardContent = __webpack_require__(457582);
var CardContent_default = /*#__PURE__*/__webpack_require__.n(CardContent);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardHeader/index.js
var CardHeader = __webpack_require__(260493);
var CardHeader_default = /*#__PURE__*/__webpack_require__.n(CardHeader);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/styles/index.js
var styles = __webpack_require__(522166);
// EXTERNAL MODULE: ./src/components/chart.tsx
var chart = __webpack_require__(400929);
;// CONCATENATED MODULE: ./src/sections/components/charts/chart-1.tsx







const chartSeries = [
    {
        name: "This week",
        data: [
            30,
            40,
            25,
            50,
            49,
            21,
            70,
            51
        ]
    },
    {
        name: "Last week",
        data: [
            23,
            12,
            54,
            61,
            32,
            56,
            81,
            19
        ]
    }
];
const useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.warning.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        grid: {
            borderColor: theme.palette.divider,
            strokeDashArray: 2,
            xaxis: {
                lines: {
                    show: false
                }
            },
            yaxis: {
                lines: {
                    show: true
                }
            }
        },
        legend: {
            labels: {
                colors: theme.palette.text.secondary
            },
            show: true
        },
        plotOptions: {
            bar: {
                columnWidth: "40%"
            }
        },
        stroke: {
            colors: [
                "transparent"
            ],
            show: true,
            width: 2
        },
        theme: {
            mode: theme.palette.mode
        },
        xaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            },
            categories: [
                "Sun",
                "Mon",
                "Tue",
                "Wed",
                "Thu",
                "Fri",
                "Sat",
                "Sun"
            ],
            labels: {
                style: {
                    colors: theme.palette.text.secondary
                }
            }
        },
        yaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            },
            labels: {
                style: {
                    colors: theme.palette.text.secondary
                }
            }
        }
    };
};
const Chart1 = ()=>{
    const chartOptions = useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Sales"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                        height: 300,
                        options: chartOptions,
                        series: chartSeries,
                        type: "bar"
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/sections/components/charts/chart-2.tsx







const chart_2_chartSeries = [
    {
        name: "Page Views",
        data: [
            3350,
            1840,
            2254,
            5780,
            9349,
            5241,
            2770,
            2051,
            3764,
            2385,
            5912,
            8323
        ]
    },
    {
        name: "Session Duration",
        data: [
            35,
            41,
            62,
            42,
            13,
            18,
            29,
            37,
            36,
            51,
            32,
            35
        ]
    }
];
const chart_2_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.warning.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        grid: {
            borderColor: theme.palette.divider,
            strokeDashArray: 2,
            xaxis: {
                lines: {
                    show: false
                }
            },
            yaxis: {
                lines: {
                    show: true
                }
            }
        },
        legend: {
            horizontalAlign: "right",
            labels: {
                colors: theme.palette.text.secondary
            },
            position: "top",
            show: true
        },
        markers: {
            hover: {
                size: undefined,
                sizeOffset: 2
            },
            radius: 2,
            shape: "circle",
            size: 4,
            strokeWidth: 0
        },
        stroke: {
            curve: "smooth",
            dashArray: [
                0,
                3
            ],
            lineCap: "butt",
            width: 3
        },
        theme: {
            mode: theme.palette.mode
        },
        xaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            },
            categories: [
                "01 Jan",
                "02 Jan",
                "03 Jan",
                "04 Jan",
                "05 Jan",
                "06 Jan",
                "07 Jan",
                "08 Jan",
                "09 Jan",
                "10 Jan",
                "11 Jan",
                "12 Jan"
            ],
            labels: {
                style: {
                    colors: theme.palette.text.secondary
                }
            }
        },
        yaxis: [
            {
                axisBorder: {
                    show: false
                },
                axisTicks: {
                    show: false
                },
                labels: {
                    style: {
                        colors: theme.palette.text.secondary
                    }
                }
            },
            {
                axisBorder: {
                    show: false
                },
                axisTicks: {
                    show: false
                },
                labels: {
                    style: {
                        colors: theme.palette.text.secondary
                    }
                },
                opposite: true
            }
        ]
    };
};
const Chart2 = ()=>{
    const chartOptions = chart_2_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Analytics"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                        height: 300,
                        options: chartOptions,
                        series: chart_2_chartSeries,
                        type: "line"
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
;// CONCATENATED MODULE: ./src/sections/components/charts/chart-3.tsx








const chart_3_chartSeries = [
    83
];
const chart_3_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main
        ],
        fill: {
            opacity: 1,
            type: "solid"
        },
        labels: [
            "System Health"
        ],
        plotOptions: {
            radialBar: {
                dataLabels: {
                    name: {
                        color: theme.palette.text.primary,
                        fontFamily: theme.typography.fontFamily
                    },
                    value: {
                        color: theme.palette.text.secondary
                    }
                },
                hollow: {
                    size: "60%"
                },
                track: {
                    background: theme.palette.background.default
                }
            }
        },
        states: {
            active: {
                filter: {
                    type: "none"
                }
            },
            hover: {
                filter: {
                    type: "none"
                }
            }
        },
        theme: {
            mode: theme.palette.mode
        }
    };
};
const Chart3 = ()=>{
    const chartOptions = chart_3_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "sm",
            children: /*#__PURE__*/ jsx_runtime_.jsx((Card_default()), {
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                            height: 300,
                            options: chartOptions,
                            series: chart_3_chartSeries,
                            type: "radialBar"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            align: "center",
                            color: "text.secondary",
                            component: "p",
                            variant: "caption",
                            children: "This shouldn't be bellow 80%"
                        })
                    ]
                })
            })
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/DotsHorizontal.js
var DotsHorizontal = __webpack_require__(66519);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./src/components/scrollbar.tsx
var scrollbar = __webpack_require__(851716);
;// CONCATENATED MODULE: ./src/sections/components/charts/chart-4.tsx











const chart_4_chartSeries = [
    {
        name: "Performance",
        data: [
            10,
            5,
            11,
            20,
            13,
            28,
            18,
            4,
            13,
            12,
            13,
            5
        ]
    }
];
const chart_4_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            },
            zoom: {
                enabled: false
            }
        },
        colors: [
            theme.palette.primary.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            gradient: {
                opacityFrom: 0.4,
                opacityTo: 0.1,
                stops: [
                    0,
                    100
                ]
            },
            type: "gradient"
        },
        grid: {
            borderColor: theme.palette.divider,
            strokeDashArray: 2,
            xaxis: {
                lines: {
                    show: false
                }
            },
            yaxis: {
                lines: {
                    show: true
                }
            }
        },
        markers: {
            size: 6,
            strokeColors: theme.palette.background.default,
            strokeWidth: 3
        },
        stroke: {
            curve: "smooth"
        },
        theme: {
            mode: theme.palette.mode
        },
        xaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            },
            categories: [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
            ],
            labels: {
                offsetY: 5,
                style: {
                    colors: theme.palette.text.secondary
                }
            }
        },
        yaxis: {
            labels: {
                formatter: (value)=>value > 0 ? `${value}K` : `${value}`,
                offsetX: -10,
                style: {
                    colors: theme.palette.text.secondary
                }
            }
        }
    };
};
const Chart4 = ()=>{
    const chartOptions = chart_4_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    action: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                        })
                    }),
                    title: "Performance Over Time"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                            sx: {
                                height: 375,
                                minWidth: 500,
                                position: "relative"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                                height: 350,
                                options: chartOptions,
                                series: chart_4_chartSeries,
                                type: "area"
                            })
                        })
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: external "next/dist/compiled/react"
var react_ = __webpack_require__(18038);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ArrowRight.js
var ArrowRight = __webpack_require__(394284);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/CardActions/index.js
var CardActions = __webpack_require__(640362);
var CardActions_default = /*#__PURE__*/__webpack_require__.n(CardActions);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/List/index.js
var List = __webpack_require__(854436);
var List_default = /*#__PURE__*/__webpack_require__.n(List);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItem/index.js
var ListItem = __webpack_require__(790777);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemText/index.js
var ListItemText = __webpack_require__(846517);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText);
// EXTERNAL MODULE: ./src/hooks/use-mounted.ts
var use_mounted = __webpack_require__(887408);
;// CONCATENATED MODULE: ./src/utils/get-random-int.ts
const getRandomInt = (min, max)=>{
    min = Math.ceil(min);
    max = Math.floor(max);
    return Math.floor(Math.random() * (max - min + 1)) + min;
};

;// CONCATENATED MODULE: ./src/utils/wait.ts
const wait = (time)=>new Promise((res)=>setTimeout(res, time));

;// CONCATENATED MODULE: ./src/sections/components/charts/chart-5.tsx



















const pages = [
    {
        pathname: "/projects",
        views: 24
    },
    {
        pathname: "/chat",
        views: 21
    },
    {
        pathname: "/cart",
        views: 15
    },
    {
        pathname: "/checkout",
        views: 8
    }
];
const initialState = [
    163,
    166,
    161,
    159,
    99,
    163,
    173,
    166,
    167,
    183,
    176,
    172
];
const useChartSeries = ()=>{
    const isMounted = (0,use_mounted/* useMounted */.s)();
    const intervalRef = (0,react_.useRef)(undefined);
    const [data, setData] = (0,react_.useState)(initialState);
    const tickRate = 3000;
    const delay = 500;
    const handleTick = (0,react_.useCallback)(async (value)=>{
        if (isMounted()) {
            setData((prevState)=>{
                const newData = [
                    ...prevState
                ];
                // Remove the first value and add a null value to keep the same bar length
                newData.shift();
                newData.push(null);
                return newData;
            });
        }
        await wait(delay);
        if (isMounted()) {
            setData((prevState)=>{
                const newData = [
                    ...prevState
                ];
                newData.pop();
                newData.push(value);
                return newData;
            });
        }
    }, [
        isMounted
    ]);
    const subscribe = (0,react_.useMemo)(()=>(handler)=>{
            intervalRef.current = setInterval(()=>{
                const value = getRandomInt(100, 200);
                handler(value);
            }, tickRate);
            return ()=>{
                clearInterval(intervalRef.current);
            };
        }, []);
    (0,react_.useEffect)(()=>subscribe(handleTick), // eslint-disable-next-line react-hooks/exhaustive-deps
    [
        subscribe
    ]);
    return [
        {
            name: "Events",
            data
        }
    ];
};
const chart_5_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        grid: {
            show: false
        },
        legend: {
            show: false
        },
        plotOptions: {
            bar: {
                columnWidth: "40"
            }
        },
        states: {
            active: {
                filter: {
                    type: "none"
                }
            },
            hover: {
                filter: {
                    type: "none"
                }
            }
        },
        stroke: {
            colors: [
                "transparent"
            ],
            show: true,
            width: 2
        },
        theme: {
            mode: theme.palette.mode
        },
        xaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            },
            categories: [
                ""
            ],
            labels: {
                show: false
            }
        },
        yaxis: {
            labels: {
                show: false
            }
        }
    };
};
const Chart5 = ()=>{
    const chartSeries = useChartSeries();
    const chartOptions = chart_5_useChartOptions();
    const pageViewsNow = (0,react_.useMemo)(()=>{
        const { data  } = chartSeries[0];
        const currentValue = data[data.length - 1];
        if (currentValue === null) {
            return data[data.length - 2] || 0;
        }
        return data[data.length - 1] || 0;
    }, [
        chartSeries
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "sm",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        action: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "h6",
                            children: pageViewsNow
                        }),
                        subheader: "Page views per second",
                        title: "Active users"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                        height: 200,
                        options: chartOptions,
                        series: chartSeries,
                        type: "bar"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                        children: pages.map((page)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                divider: true,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                        primary: page.pathname,
                                        primaryTypographyProps: {
                                            variant: "body2"
                                        }
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        variant: "subtitle2",
                                        children: page.views
                                    })
                                ]
                            }, page.pathname))
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                        sx: {
                            justifyContent: "flex-end"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                            }),
                            size: "small",
                            children: "See All"
                        })
                    })
                ]
            })
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@mui/system/colorManipulator.js
var colorManipulator = __webpack_require__(229551);
;// CONCATENATED MODULE: ./src/sections/components/charts/chart-6.tsx











const chart_6_chartSeries = [
    {
        name: "This year",
        data: [
            18,
            16,
            5,
            8,
            3,
            14,
            14,
            16,
            17,
            19,
            18,
            20
        ]
    },
    {
        name: "Last year",
        data: [
            12,
            11,
            4,
            6,
            2,
            9,
            9,
            10,
            11,
            12,
            13,
            13
        ]
    }
];
const chart_6_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            }
        },
        colors: [
            "#00ab57",
            (0,colorManipulator.alpha)("#00ab57", 0.25)
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        grid: {
            borderColor: theme.palette.divider,
            strokeDashArray: 2,
            xaxis: {
                lines: {
                    show: false
                }
            },
            yaxis: {
                lines: {
                    show: true
                }
            }
        },
        legend: {
            show: false
        },
        plotOptions: {
            bar: {
                columnWidth: "20px"
            }
        },
        stroke: {
            colors: [
                "transparent"
            ],
            show: true,
            width: 2
        },
        theme: {
            mode: theme.palette.mode
        },
        xaxis: {
            axisBorder: {
                color: theme.palette.divider,
                show: true
            },
            axisTicks: {
                color: theme.palette.divider,
                show: true
            },
            categories: [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
            ],
            labels: {
                offsetY: 5,
                style: {
                    colors: theme.palette.text.secondary
                }
            }
        },
        yaxis: {
            labels: {
                formatter: (value)=>value > 0 ? `${value}K` : `${value}`,
                offsetX: -10,
                style: {
                    colors: theme.palette.text.secondary
                }
            }
        }
    };
};
const Chart6 = ()=>{
    const chartOptions = chart_6_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    action: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(DotsHorizontal/* default */.Z, {})
                        })
                    }),
                    title: "Financial Stats"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            minWidth: 700,
                            px: 2
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                            height: 375,
                            options: chartOptions,
                            series: chart_6_chartSeries,
                            type: "bar"
                        })
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/InfoCircle.js
var InfoCircle = __webpack_require__(359825);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tooltip/index.js
var Tooltip = __webpack_require__(556020);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip);
;// CONCATENATED MODULE: ./src/sections/components/charts/chart-7.tsx










const chart_7_chartSeries = [
    {
        name: "Organic",
        data: [
            3350,
            1840,
            2254,
            5780,
            9349,
            5241,
            2770,
            2051,
            3764,
            2385,
            5912,
            8323
        ]
    },
    {
        name: "Referral",
        data: [
            35,
            41,
            62,
            42,
            13,
            18,
            29,
            37,
            36,
            51,
            32,
            35
        ]
    },
    {
        name: "Social Media",
        data: [
            100,
            122,
            50,
            300,
            250,
            400,
            312,
            200,
            10,
            60,
            90,
            400
        ]
    }
];
const chart_7_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.info.main,
            theme.palette.warning.main
        ],
        grid: {
            borderColor: theme.palette.divider,
            strokeDashArray: 2,
            xaxis: {
                lines: {
                    show: false
                }
            },
            yaxis: {
                lines: {
                    show: true
                }
            }
        },
        markers: {
            hover: {
                size: undefined,
                sizeOffset: 2
            },
            radius: 2,
            shape: "circle",
            size: 4,
            strokeWidth: 0
        },
        stroke: {
            curve: "smooth",
            lineCap: "butt",
            width: 3
        },
        theme: {
            mode: theme.palette.mode
        },
        xaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: true
            },
            categories: [
                "01 Jan",
                "02 Jan",
                "03 Jan",
                "04 Jan",
                "05 Jan",
                "06 Jan",
                "07 Jan",
                "08 Jan",
                "09 Jan",
                "10 Jan",
                "11 Jan",
                "12 Jan"
            ],
            labels: {
                style: {
                    colors: theme.palette.text.secondary
                }
            }
        },
        yaxis: [
            {
                axisBorder: {
                    show: false
                },
                axisTicks: {
                    show: false
                },
                labels: {
                    show: false
                }
            },
            {
                axisTicks: {
                    show: false
                },
                axisBorder: {
                    show: false
                },
                labels: {
                    show: false
                },
                opposite: true
            },
            {
                axisTicks: {
                    show: false
                },
                axisBorder: {
                    show: false
                },
                labels: {
                    show: false
                },
                opposite: true
            }
        ]
    };
};
const Chart7 = ()=>{
    const chartOptions = chart_7_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    action: /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                        title: "Chart 7 Source by channel",
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(InfoCircle/* default */.Z, {})
                        })
                    }),
                    title: "Traffic Sources"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                        height: 350,
                        options: chartOptions,
                        series: chart_7_chartSeries,
                        type: "line"
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/sections/components/charts/chart-8.tsx














const labels = [
    "Linkedin",
    "Facebook",
    "Instagram",
    "Twitter",
    "Other"
];
const chart_8_chartSeries = [
    10,
    10,
    20,
    10,
    70
];
const chart_8_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.light,
            theme.palette.warning.light,
            theme.palette.success.light,
            theme.palette.info.light,
            theme.palette.neutral[700]
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        labels,
        legend: {
            labels: {
                colors: theme.palette.text.secondary
            },
            show: true
        },
        plotOptions: {
            pie: {
                expandOnClick: false
            }
        },
        states: {
            active: {
                filter: {
                    type: "none"
                }
            },
            hover: {
                filter: {
                    type: "none"
                }
            }
        },
        stroke: {
            width: 0
        },
        theme: {
            mode: theme.palette.mode
        },
        tooltip: {
            fillSeriesColor: false
        }
    };
};
const Chart8 = ()=>{
    const chartOptions = chart_8_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "sm",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        action: /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                            title: "Traffic by Social Media platforms",
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(InfoCircle/* default */.Z, {})
                            })
                        }),
                        title: "Social Media Sources"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                        children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                            height: 300,
                            options: chartOptions,
                            series: chart_8_chartSeries,
                            type: "donut"
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((CardActions_default()), {
                        sx: {
                            justifyContent: "flex-end"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                            color: "inherit",
                            endIcon: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(ArrowRight/* default */.Z, {})
                            }),
                            size: "small",
                            children: "See all"
                        })
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./src/sections/components/charts/chart-9.tsx







const chart_9_chartSeries = [
    {
        name: "New Customers",
        data: [
            31,
            40,
            28,
            51,
            42,
            109,
            100,
            120,
            80,
            42,
            90,
            140
        ]
    },
    {
        name: "Up/Cross-Selling",
        data: [
            11,
            32,
            45,
            32,
            34,
            52,
            41,
            80,
            96,
            140,
            30,
            100
        ]
    }
];
const chart_9_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.warning.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            type: "solid",
            opacity: 0
        },
        grid: {
            borderColor: theme.palette.divider,
            strokeDashArray: 2,
            xaxis: {
                lines: {
                    show: false
                }
            },
            yaxis: {
                lines: {
                    show: true
                }
            }
        },
        markers: {
            strokeColors: theme.palette.background.paper,
            size: 6
        },
        stroke: {
            curve: "straight",
            width: 2
        },
        theme: {
            mode: theme.palette.mode
        },
        xaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            },
            categories: [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
            ]
        }
    };
};
const Chart9 = ()=>{
    const chartOptions = chart_9_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Sales Revenue"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                        height: 360,
                        options: chartOptions,
                        series: chart_9_chartSeries,
                        type: "area"
                    })
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/numeral/numeral.js
var numeral = __webpack_require__(518470);
var numeral_default = /*#__PURE__*/__webpack_require__.n(numeral);
;// CONCATENATED MODULE: ./src/sections/components/charts/chart-10.tsx










const chart_10_chartSeries = [
    14859,
    35690,
    45120
];
const chart_10_labels = [
    "Strategy",
    "Outsourcing",
    "Marketing"
];
const chart_10_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.info.main,
            theme.palette.warning.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        labels: chart_10_labels,
        legend: {
            show: false
        },
        stroke: {
            colors: [
                theme.palette.background.paper
            ],
            width: 1
        },
        theme: {
            mode: theme.palette.mode
        },
        tooltip: {
            fillSeriesColor: false
        }
    };
};
const Chart10 = ()=>{
    const chartOptions = chart_10_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "md",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        title: "Cost Breakdown"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                                height: 260,
                                options: chartOptions,
                                series: chart_10_chartSeries,
                                type: "pie"
                            }),
                            chart_10_chartSeries.map((item, index)=>{
                                const amount = numeral_default()(item).format("$0,0.00");
                                return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                                    sx: {
                                        alignItems: "center",
                                        display: "flex",
                                        p: 1
                                    },
                                    children: [
                                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                            sx: {
                                                backgroundColor: chartOptions.colors[index],
                                                borderRadius: "50%",
                                                height: 8,
                                                width: 8
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            sx: {
                                                ml: 2
                                            },
                                            variant: "subtitle2",
                                            children: chart_10_labels[index]
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                            sx: {
                                                flexGrow: 1
                                            }
                                        }),
                                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                            color: "text.secondary",
                                            variant: "subtitle2",
                                            children: amount
                                        })
                                    ]
                                }, index);
                            })
                        ]
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./src/sections/components/charts/chart-11.tsx











const chart_11_chartSeries = [
    {
        name: "Sales",
        data: [
            {
                x: "Email",
                y: 37530
            },
            {
                x: "Facebook",
                y: 90590
            },
            {
                x: "GDN",
                y: 52717
            },
            {
                x: "Instagram",
                y: 62935
            },
            {
                x: "Google Ads Search",
                y: 13219
            }
        ]
    }
];
const chart_11_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: false,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.info.main,
            theme.palette.warning.main,
            theme.palette.error.main,
            theme.palette.success.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        grid: {
            borderColor: theme.palette.divider,
            strokeDashArray: 2,
            xaxis: {
                lines: {
                    show: true
                }
            },
            yaxis: {
                lines: {
                    show: false
                }
            }
        },
        legend: {
            show: false
        },
        plotOptions: {
            bar: {
                horizontal: true,
                barHeight: "45",
                distributed: true
            }
        },
        theme: {
            mode: theme.palette.mode
        },
        tooltip: {
            y: {
                formatter: (value)=>numeral_default()(value).format("$0,0.00")
            }
        },
        xaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            }
        },
        yaxis: {
            labels: {
                show: false
            }
        }
    };
};
const Chart11 = ()=>{
    const chartOptions = chart_11_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "md",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                        title: "Incremental Sales"
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)((CardContent_default()), {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                                height: 350,
                                options: chartOptions,
                                series: chart_11_chartSeries,
                                type: "bar"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                                direction: "row",
                                flexWrap: "wrap",
                                spacing: 3,
                                sx: {
                                    mt: 3
                                },
                                children: chart_11_chartSeries[0].data.map((item, index)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                                        direction: "row",
                                        spacing: 1,
                                        sx: {
                                            alignItems: "center",
                                            display: "flex",
                                            p: 1
                                        },
                                        children: [
                                            /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                                sx: {
                                                    backgroundColor: chartOptions.colors[index],
                                                    borderRadius: "50%",
                                                    height: 8,
                                                    width: 8
                                                }
                                            }),
                                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                                variant: "subtitle2",
                                                children: item.x
                                            })
                                        ]
                                    }, item.x))
                            })
                        ]
                    })
                ]
            })
        })
    });
};

;// CONCATENATED MODULE: ./src/sections/components/charts/chart-12.tsx









const chart_12_chartSeries = [
    {
        name: "Trimester 1",
        data: [
            12,
            24,
            36,
            48,
            60,
            72,
            24
        ]
    },
    {
        name: "Trimester 2",
        data: [
            7,
            16,
            47,
            58,
            40,
            49,
            43
        ]
    },
    {
        name: "Trimester 3",
        data: [
            11,
            27,
            24,
            32,
            82,
            56,
            21
        ]
    }
];
const chart_12_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            stacked: true,
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main,
            (0,colorManipulator.alpha)(theme.palette.primary.main, 0.8),
            (0,colorManipulator.alpha)(theme.palette.primary.main, 0.4)
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            opacity: 1,
            type: "solid"
        },
        grid: {
            borderColor: theme.palette.divider,
            strokeDashArray: 2,
            xaxis: {
                lines: {
                    show: false
                }
            },
            yaxis: {
                lines: {
                    show: true
                }
            }
        },
        legend: {
            show: false
        },
        states: {
            active: {
                filter: {
                    type: "none"
                }
            },
            hover: {
                filter: {
                    type: "none"
                }
            }
        },
        stroke: {
            colors: [
                "transparent"
            ],
            show: true,
            width: 2
        },
        theme: {
            mode: theme.palette.mode
        },
        xaxis: {
            axisBorder: {
                show: false
            },
            axisTicks: {
                show: false
            },
            categories: [
                "Capital One",
                "Ally Bank",
                "ING",
                "Ridgewood",
                "BT Transilvania",
                "CEC",
                "CBC"
            ],
            labels: {
                style: {
                    colors: theme.palette.text.secondary
                }
            }
        },
        yaxis: {
            labels: {
                offsetX: -12,
                style: {
                    colors: theme.palette.text.secondary
                }
            }
        }
    };
};
const Chart12 = ()=>{
    const chartOptions = chart_12_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    subheader: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        color: "text.secondary",
                        variant: "body2",
                        children: "Trimester"
                    }),
                    title: "Total Transactions"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(scrollbar/* Scrollbar */.L, {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            height: 336,
                            minWidth: 500,
                            px: 2
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                            height: 300,
                            options: chartOptions,
                            series: chart_12_chartSeries,
                            type: "bar"
                        })
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/sections/components/charts/chart-13.tsx







const chart_13_chartSeries = [
    {
        name: "BTC",
        data: [
            56,
            77,
            54,
            65,
            55,
            72,
            80,
            74,
            67,
            77,
            83,
            94
        ]
    },
    {
        name: "ETH",
        data: [
            65,
            64,
            32,
            45,
            54,
            76,
            82,
            80,
            85,
            78,
            82,
            95
        ]
    }
];
const chart_13_useChartOptions = ()=>{
    const theme = (0,styles.useTheme)();
    return {
        chart: {
            background: "transparent",
            toolbar: {
                show: false
            }
        },
        colors: [
            theme.palette.primary.main,
            theme.palette.warning.main
        ],
        dataLabels: {
            enabled: false
        },
        fill: {
            gradient: {
                opacityFrom: 0.5,
                opacityTo: 0,
                stops: [
                    0,
                    100
                ]
            },
            type: "gradient"
        },
        grid: {
            borderColor: theme.palette.divider,
            strokeDashArray: 2
        },
        stroke: {
            width: 2
        },
        theme: {
            mode: theme.palette.mode
        },
        xaxis: {
            axisTicks: {
                show: false
            },
            axisBorder: {
                show: false
            },
            categories: [
                "Jan",
                "Feb",
                "Mar",
                "Apr",
                "May",
                "Jun",
                "Jul",
                "Aug",
                "Sep",
                "Oct",
                "Nov",
                "Dec"
            ],
            tickAmount: 5
        }
    };
};
const Chart13 = ()=>{
    const chartOptions = chart_13_useChartOptions();
    return /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Card_default()), {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((CardHeader_default()), {
                    title: "Analytics"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((CardContent_default()), {
                    children: /*#__PURE__*/ jsx_runtime_.jsx(chart/* Chart */.k, {
                        height: 280,
                        options: chartOptions,
                        series: chart_13_chartSeries,
                        type: "area"
                    })
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./src/app/marketing/components/charts/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 




















const page_components = [
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart1, {}),
        title: "Chart 1"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart2, {}),
        title: "Chart 2"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart3, {}),
        title: "Chart 3"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart4, {}),
        title: "Chart 4"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart5, {}),
        title: "Chart 5"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart6, {}),
        title: "Chart 6"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart7, {}),
        title: "Chart 7"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart8, {}),
        title: "Chart 8"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart9, {}),
        title: "Chart 9"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart10, {}),
        title: "Chart 10"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart11, {}),
        title: "Chart 11"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart12, {}),
        title: "Chart 12"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Chart13, {}),
        title: "Chart 13"
    }
];
const Page = ()=>{
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Components: Charts"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Layout */.A, {
                title: "Charts",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "main",
                    sx: {
                        flexGrow: 1,
                        py: 8
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                        maxWidth: "lg",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                            spacing: 8,
                            children: page_components.map((component)=>/*#__PURE__*/ jsx_runtime_.jsx(previewer/* Previewer */.M, {
                                    title: component.title,
                                    children: component.element
                                }, component.title))
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 851716:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "L": () => (/* binding */ Scrollbar)
/* harmony export */ });
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(804609);
/* harmony import */ var simplebar_react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(simplebar_react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(522166);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__);


const Scrollbar = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_0__.styled)((simplebar_react__WEBPACK_IMPORTED_MODULE_1___default()))``;


/***/ }),

/***/ 887408:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "s": () => (/* binding */ useMounted)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const useMounted = ()=>{
    const isMounted = (0,react__WEBPACK_IMPORTED_MODULE_0__.useRef)(false);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        isMounted.current = true;
        return ()=>{
            isMounted.current = false;
        };
    }, []);
    return (0,react__WEBPACK_IMPORTED_MODULE_0__.useCallback)(()=>isMounted.current, []);
};


/***/ }),

/***/ 903268:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* reexport safe */ next_navigation__WEBPACK_IMPORTED_MODULE_0__.usePathname)
/* harmony export */ });
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(59483);
/* harmony import */ var next_navigation__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_navigation__WEBPACK_IMPORTED_MODULE_0__);
// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js



/***/ }),

/***/ 488141:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "r": () => (/* binding */ useSettings)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18038);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(34383);


const useSettings = ()=>(0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(src_contexts_settings__WEBPACK_IMPORTED_MODULE_1__/* .SettingsContext */ .J6);


/***/ }),

/***/ 65213:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/charts/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,3380,4609,5006,2983,8470,9535,6519,9189,7680,4018,9274,929], () => (__webpack_exec__(588625)));
module.exports = __webpack_exports__;

})();