(() => {
var exports = {};
exports.id = 2699;
exports.ids = [2699];
exports.modules = {

/***/ 497783:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/@edge-runtime/cookies");

/***/ }),

/***/ 18038:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react");

/***/ }),

/***/ 798704:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-dom/server-rendering-stub");

/***/ }),

/***/ 397897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react-server-dom-webpack/client");

/***/ }),

/***/ 556786:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/compiled/react/jsx-runtime");

/***/ }),

/***/ 261090:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/app-render/get-segment-param.js");

/***/ }),

/***/ 378652:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/server/future/helpers/interception-routes.js");

/***/ }),

/***/ 903280:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/app-router-context.js");

/***/ }),

/***/ 262381:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/bloom-filter/index.js");

/***/ }),

/***/ 492796:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/head-manager-context.js");

/***/ }),

/***/ 669274:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/hooks-client-context.js");

/***/ }),

/***/ 734014:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/i18n/normalize-locale-path.js");

/***/ }),

/***/ 278524:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/is-plain-object.js");

/***/ }),

/***/ 878020:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/mitt.js");

/***/ }),

/***/ 664406:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/page-path/denormalize-page-path.js");

/***/ }),

/***/ 424964:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router-context.js");

/***/ }),

/***/ 611751:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/add-path-prefix.js");

/***/ }),

/***/ 746220:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/compare-states.js");

/***/ }),

/***/ 110299:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-next-pathname-info.js");

/***/ }),

/***/ 623938:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/format-url.js");

/***/ }),

/***/ 329565:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-asset-path-from-route.js");

/***/ }),

/***/ 735789:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/get-next-pathname-info.js");

/***/ }),

/***/ 921668:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/handle-smooth-scroll.js");

/***/ }),

/***/ 43773:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/interpolate-as.js");

/***/ }),

/***/ 801897:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-bot.js");

/***/ }),

/***/ 901428:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-dynamic.js");

/***/ }),

/***/ 271109:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/is-local-url.js");

/***/ }),

/***/ 474639:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/omit.js");

/***/ }),

/***/ 528854:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-path.js");

/***/ }),

/***/ 491292:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/parse-relative-url.js");

/***/ }),

/***/ 734567:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/path-has-prefix.js");

/***/ }),

/***/ 393297:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/remove-trailing-slash.js");

/***/ }),

/***/ 687782:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-href.js");

/***/ }),

/***/ 836052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/resolve-rewrites.js");

/***/ }),

/***/ 584226:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-matcher.js");

/***/ }),

/***/ 95052:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/router/utils/route-regex.js");

/***/ }),

/***/ 803349:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/server-inserted-html.js");

/***/ }),

/***/ 359232:
/***/ ((module) => {

"use strict";
module.exports = require("next/dist/shared/lib/utils.js");

/***/ }),

/***/ 439491:
/***/ ((module) => {

"use strict";
module.exports = require("assert");

/***/ }),

/***/ 582361:
/***/ ((module) => {

"use strict";
module.exports = require("events");

/***/ }),

/***/ 657147:
/***/ ((module) => {

"use strict";
module.exports = require("fs");

/***/ }),

/***/ 113685:
/***/ ((module) => {

"use strict";
module.exports = require("http");

/***/ }),

/***/ 795687:
/***/ ((module) => {

"use strict";
module.exports = require("https");

/***/ }),

/***/ 822037:
/***/ ((module) => {

"use strict";
module.exports = require("os");

/***/ }),

/***/ 371017:
/***/ ((module) => {

"use strict";
module.exports = require("path");

/***/ }),

/***/ 12781:
/***/ ((module) => {

"use strict";
module.exports = require("stream");

/***/ }),

/***/ 76224:
/***/ ((module) => {

"use strict";
module.exports = require("tty");

/***/ }),

/***/ 257310:
/***/ ((module) => {

"use strict";
module.exports = require("url");

/***/ }),

/***/ 473837:
/***/ ((module) => {

"use strict";
module.exports = require("util");

/***/ }),

/***/ 959796:
/***/ ((module) => {

"use strict";
module.exports = require("zlib");

/***/ }),

/***/ 199884:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.r(__webpack_exports__);
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "AppRouter": () => (/* reexport default from dynamic */ next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default.a),
/* harmony export */   "GlobalError": () => (/* reexport default from dynamic */ next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default.a),
/* harmony export */   "LayoutRouter": () => (/* reexport default from dynamic */ next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default.a),
/* harmony export */   "RenderFromTemplateContext": () => (/* reexport default from dynamic */ next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default.a),
/* harmony export */   "StaticGenerationSearchParamsBailoutProvider": () => (/* reexport default from dynamic */ next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default.a),
/* harmony export */   "__next_app_webpack_require__": () => (/* binding */ __next_app_webpack_require__),
/* harmony export */   "actionAsyncStorage": () => (/* reexport safe */ next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__.actionAsyncStorage),
/* harmony export */   "createSearchParamsBailoutProxy": () => (/* reexport safe */ next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__.createSearchParamsBailoutProxy),
/* harmony export */   "decodeAction": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeAction),
/* harmony export */   "decodeReply": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.decodeReply),
/* harmony export */   "originalPathname": () => (/* binding */ originalPathname),
/* harmony export */   "pages": () => (/* binding */ pages),
/* harmony export */   "preconnect": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preconnect),
/* harmony export */   "preloadFont": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadFont),
/* harmony export */   "preloadStyle": () => (/* reexport safe */ next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__.preloadStyle),
/* harmony export */   "renderToReadableStream": () => (/* reexport safe */ react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__.renderToReadableStream),
/* harmony export */   "requestAsyncStorage": () => (/* reexport safe */ next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__.requestAsyncStorage),
/* harmony export */   "serverHooks": () => (/* reexport module object */ next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__),
/* harmony export */   "staticGenerationAsyncStorage": () => (/* reexport safe */ next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__.staticGenerationAsyncStorage),
/* harmony export */   "staticGenerationBailout": () => (/* reexport safe */ next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__.staticGenerationBailout),
/* harmony export */   "tree": () => (/* binding */ tree)
/* harmony export */ });
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(18829);
/* harmony import */ var next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_app_router__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(745226);
/* harmony import */ var next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_layout_router__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(942872);
/* harmony import */ var next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_render_from_template_context__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(228412);
/* harmony import */ var next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_error_boundary__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(901839);
/* harmony import */ var next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_async_storage__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(968214);
/* harmony import */ var next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_request_async_storage__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(567797);
/* harmony import */ var next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_action_async_storage__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(579282);
/* harmony import */ var next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_bailout__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(723785);
/* harmony import */ var next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_static_generation_searchparams_bailout_provider__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(575183);
/* harmony import */ var next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_searchparams_bailout_proxy__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(415815);
/* harmony import */ var next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(next_dist_client_components_hooks_server_context__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var react_server_dom_webpack_server_edge__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(176370);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(650515);
/* harmony import */ var next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(next_dist_server_app_render_rsc_preloads__WEBPACK_IMPORTED_MODULE_12__);

    const tree = {
        children: [
        '',
        {
        children: [
        'marketing',
        {
        children: [
        'components',
        {
        children: [
        'modals',
        {
        children: ['__PAGE__', {}, {
          page: [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 872497, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/modals/page.tsx"],
          
        }]
      },
        {
          
          
        }
      ]
      },
        {
          
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 586068)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/layout.tsx"],
          
        }
      ]
      },
        {
          'layout': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 948550)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/layout.tsx"],
'not-found': [() => Promise.resolve(/* import() eager */).then(__webpack_require__.t.bind(__webpack_require__, 789499, 23)), "/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/not-found.tsx"],
          
        }
      ]
      }.children;
    const pages = ["/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/modals/page.tsx"];

    
    
    
    

    

    
    

    
    
    

    

    
    const __next_app_webpack_require__ = __webpack_require__
    

    const originalPathname = "/marketing/components/modals/page"
  

/***/ }),

/***/ 446200:
/***/ ((__unused_webpack_module, __unused_webpack_exports, __webpack_require__) => {

Promise.resolve(/* import() eager */).then(__webpack_require__.bind(__webpack_require__, 403189))

/***/ }),

/***/ 403189:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ page)
});

// EXTERNAL MODULE: external "next/dist/compiled/react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(556786);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Box/index.js
var Box = __webpack_require__(746661);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Container/index.js
var Container = __webpack_require__(963246);
var Container_default = /*#__PURE__*/__webpack_require__.n(Container);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Stack/index.js
var Stack = __webpack_require__(705537);
// EXTERNAL MODULE: ./src/components/seo.tsx
var seo = __webpack_require__(839566);
// EXTERNAL MODULE: ./src/hooks/use-page-view.ts
var use_page_view = __webpack_require__(846099);
// EXTERNAL MODULE: ./src/layouts/components/index.ts + 2 modules
var components = __webpack_require__(898394);
// EXTERNAL MODULE: ./src/sections/components/previewer.tsx
var previewer = __webpack_require__(213718);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Attachment01.js
var Attachment01 = __webpack_require__(517163);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Expand01.js
var Expand01 = __webpack_require__(471600);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Image01.js
var Image01 = __webpack_require__(97484);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/X.js
var X = __webpack_require__(180501);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Button/index.js
var Button = __webpack_require__(898511);
var Button_default = /*#__PURE__*/__webpack_require__.n(Button);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Divider/index.js
var Divider = __webpack_require__(973638);
var Divider_default = /*#__PURE__*/__webpack_require__.n(Divider);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/IconButton/index.js
var IconButton = __webpack_require__(916816);
var IconButton_default = /*#__PURE__*/__webpack_require__.n(IconButton);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Input/index.js
var Input = __webpack_require__(378382);
var Input_default = /*#__PURE__*/__webpack_require__.n(Input);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Paper/index.js
var Paper = __webpack_require__(427561);
var Paper_default = /*#__PURE__*/__webpack_require__.n(Paper);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/SvgIcon/index.js
var SvgIcon = __webpack_require__(381394);
var SvgIcon_default = /*#__PURE__*/__webpack_require__.n(SvgIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Tooltip/index.js
var Tooltip = __webpack_require__(556020);
var Tooltip_default = /*#__PURE__*/__webpack_require__.n(Tooltip);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Typography/index.js
var Typography = __webpack_require__(243360);
var Typography_default = /*#__PURE__*/__webpack_require__.n(Typography);
// EXTERNAL MODULE: ./src/components/quill-editor.tsx
var quill_editor = __webpack_require__(354131);
;// CONCATENATED MODULE: ./src/sections/components/modals/modal-1.tsx
















const Modal1 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Paper_default()), {
            elevation: 12,
            sx: {
                display: "flex",
                flexDirection: "column",
                margin: 3,
                maxWidth: "100%",
                minHeight: 500,
                mx: "auto",
                outline: "none",
                width: 600
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    spacing: 1,
                    sx: {
                        px: 2,
                        py: 1
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            sx: {
                                flexGrow: 1
                            },
                            variant: "h6",
                            children: "New Message"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(Expand01/* default */.Z, {})
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(X/* default */.Z, {})
                            })
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                    disableUnderline: true,
                    fullWidth: true,
                    placeholder: "To",
                    sx: {
                        p: 1,
                        borderBottom: 1,
                        borderBottomColor: "divider",
                        borderBottomStyle: "solid"
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Input_default()), {
                    disableUnderline: true,
                    fullWidth: true,
                    placeholder: "Subject",
                    sx: {
                        p: 1,
                        borderBottom: 1,
                        borderBottomColor: "divider",
                        borderBottomStyle: "solid"
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(quill_editor/* QuillEditor */.B, {
                    placeholder: "Leave a message",
                    sx: {
                        border: "none",
                        flexGrow: 1
                    }
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    alignItems: "center",
                    direction: "row",
                    justifyContent: "space-between",
                    spacing: 3,
                    sx: {
                        p: 2
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            alignItems: "center",
                            direction: "row",
                            spacing: 1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                    title: "Attach image",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                        size: "small",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Image01/* default */.Z, {})
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Tooltip_default()), {
                                    title: "Attach file",
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                                        size: "small",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(Attachment01/* default */.Z, {})
                                        })
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                variant: "contained",
                                children: "Send"
                            })
                        })
                    ]
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemIcon/index.js
var ListItemIcon = __webpack_require__(126765);
var ListItemIcon_default = /*#__PURE__*/__webpack_require__.n(ListItemIcon);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemText/index.js
var ListItemText = __webpack_require__(846517);
var ListItemText_default = /*#__PURE__*/__webpack_require__.n(ListItemText);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/MenuItem/index.js
var MenuItem = __webpack_require__(662360);
var MenuItem_default = /*#__PURE__*/__webpack_require__.n(MenuItem);
;// CONCATENATED MODULE: ./src/sections/components/modals/modal-2.tsx







const languageOptions = [
    {
        icon: "/assets/flags/flag-uk.svg",
        label: "English"
    },
    {
        icon: "/assets/flags/flag-de.svg",
        label: "German"
    },
    {
        icon: "/assets/flags/flag-es.svg",
        label: "Spanish"
    }
];
const Modal2 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Paper_default()), {
            elevation: 12,
            sx: {
                width: 240,
                mx: "auto"
            },
            children: languageOptions.map((option)=>/*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                                sx: {
                                    display: "flex",
                                    height: 20,
                                    width: 20,
                                    "& img": {
                                        width: "100%"
                                    }
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx("img", {
                                    alt: option.label,
                                    src: option.icon
                                })
                            })
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                            primary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "subtitle2",
                                children: option.label
                            })
                        })
                    ]
                }, option.label))
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/SearchMd.js
var SearchMd = __webpack_require__(219057);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/InputAdornment/index.js
var InputAdornment = __webpack_require__(79150);
var InputAdornment_default = /*#__PURE__*/__webpack_require__.n(InputAdornment);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/OutlinedInput/index.js
var OutlinedInput = __webpack_require__(877829);
var OutlinedInput_default = /*#__PURE__*/__webpack_require__.n(OutlinedInput);
;// CONCATENATED MODULE: ./src/sections/components/modals/modal-3.tsx











const Modal3 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Paper_default()), {
            elevation: 12,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        p: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                        sx: {
                            display: "flex",
                            justifyContent: "flex-end"
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((IconButton_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                children: /*#__PURE__*/ jsx_runtime_.jsx(X/* default */.Z, {})
                            })
                        })
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        p: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                        maxWidth: "md",
                        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                            sx: {
                                alignItems: "center",
                                display: "flex"
                            },
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((OutlinedInput_default()), {
                                    fullWidth: true,
                                    placeholder: "Search...",
                                    startAdornment: /*#__PURE__*/ jsx_runtime_.jsx((InputAdornment_default()), {
                                        position: "start",
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: /*#__PURE__*/ jsx_runtime_.jsx(SearchMd/* default */.Z, {})
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                    size: "large",
                                    sx: {
                                        ml: 2
                                    },
                                    variant: "contained",
                                    children: "Search"
                                })
                            ]
                        })
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/date-fns/index.js
var date_fns = __webpack_require__(66609);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Avatar/index.js
var Avatar = __webpack_require__(217296);
var Avatar_default = /*#__PURE__*/__webpack_require__.n(Avatar);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Link/index.js
var Link = __webpack_require__(115917);
var Link_default = /*#__PURE__*/__webpack_require__.n(Link);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/List/index.js
var List = __webpack_require__(854436);
var List_default = /*#__PURE__*/__webpack_require__.n(List);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItem/index.js
var ListItem = __webpack_require__(790777);
var ListItem_default = /*#__PURE__*/__webpack_require__.n(ListItem);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/ListItemAvatar/index.js
var ListItemAvatar = __webpack_require__(372355);
var ListItemAvatar_default = /*#__PURE__*/__webpack_require__.n(ListItemAvatar);
// EXTERNAL MODULE: ./src/components/presence.tsx
var presence = __webpack_require__(159356);
;// CONCATENATED MODULE: ./src/sections/components/modals/modal-4.tsx












const now = new Date();
const contacts = [
    {
        id: "5e8891ab188cd2855e6029b7",
        avatar: "/assets/avatars/avatar-alcides-antonio.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Alcides Antonio"
    },
    {
        id: "5e887a62195cc5aef7e8ca5d",
        avatar: "/assets/avatars/avatar-marcus-finn.png",
        isActive: false,
        lastActivity: (0,date_fns.subHours)(now, 2).getTime(),
        name: "Marcus Finn"
    },
    {
        id: "5e887ac47eed253091be10cb",
        avatar: "/assets/avatars/avatar-carson-darrin.png",
        isActive: false,
        lastActivity: (0,date_fns.subMinutes)(now, 15).getTime(),
        name: "Carson Darrin"
    },
    {
        id: "5e887b209c28ac3dd97f6db5",
        avatar: "/assets/avatars/avatar-fran-perez.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Fran Perez"
    },
    {
        id: "5e887b7602bdbc4dbb234b27",
        avatar: "/assets/avatars/avatar-jie-yan-song.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Jie Yan Song"
    },
    {
        id: "5e86805e2bafd54f66cc95c3",
        avatar: "/assets/avatars/avatar-miron-vitold.png",
        isActive: false,
        lastActivity: (0,date_fns.subDays)(now, 2).getTime(),
        name: "Miron Vitold"
    },
    {
        id: "5e887a1fbefd7938eea9c981",
        avatar: "/assets/avatars/avatar-penjani-inyene.png",
        isActive: false,
        lastActivity: (0,date_fns.subHours)(now, 6).getTime(),
        name: "Penjani Inyene"
    },
    {
        id: "5e887d0b3d090c1b8f162003",
        avatar: "/assets/avatars/avatar-omar-darboe.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Omar Darobe"
    },
    {
        id: "5e88792be2d4cfb4bf0971d9",
        avatar: "/assets/avatars/avatar-siegbert-gottfried.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Siegbert Gottfried"
    },
    {
        id: "5e8877da9a65442b11551975",
        avatar: "/assets/avatars/avatar-iulia-albu.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Iulia Albu"
    },
    {
        id: "5e8680e60cba5019c5ca6fda",
        avatar: "/assets/avatars/avatar-nasimiyu-danai.png",
        isActive: true,
        lastActivity: now.getTime(),
        name: "Nasimiyu Danai"
    }
];
const Modal4 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Paper_default()), {
            elevation: 12,
            sx: {
                maxWidth: 320,
                mx: "auto",
                p: 2
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                    variant: "h6",
                    children: "Contacts"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        mt: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                        disablePadding: true,
                        children: contacts.map((contact)=>{
                            const showOnline = contact.isActive;
                            const lastActivity = !contact.isActive && contact.lastActivity ? (0,date_fns.formatDistanceToNowStrict)(contact.lastActivity) : undefined;
                            return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                                disableGutters: true,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                            src: contact.avatar
                                        })
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                        disableTypography: true,
                                        primary: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                            color: "text.primary",
                                            noWrap: true,
                                            underline: "none",
                                            variant: "subtitle2",
                                            children: contact.name
                                        })
                                    }),
                                    showOnline && /*#__PURE__*/ jsx_runtime_.jsx(presence/* Presence */.z, {
                                        size: "small",
                                        status: "online"
                                    }),
                                    lastActivity && /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Typography_default()), {
                                        color: "text.secondary",
                                        noWrap: true,
                                        variant: "caption",
                                        children: [
                                            lastActivity,
                                            " ago"
                                        ]
                                    })
                                ]
                            }, contact.id);
                        })
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/CreditCard02.js
var CreditCard02 = __webpack_require__(600925);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/MessageChatSquare.js
var MessageChatSquare = __webpack_require__(332500);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/ShoppingCart03.js
var ShoppingCart03 = __webpack_require__(515869);
;// CONCATENATED MODULE: ./src/sections/components/modals/modal-5.tsx
















const modal_5_now = new Date();
const notifications = [
    {
        id: "5e8883f1b51cc1956a5a1ec0",
        createdAt: (0,date_fns.subHours)(modal_5_now, 2).getTime(),
        description: "Dummy text",
        title: "Your order is placed",
        type: "order_placed"
    },
    {
        id: "5e8883f7ed1486d665d8be1e",
        createdAt: (0,date_fns.subDays)(modal_5_now, 1).getTime(),
        description: "You have 32 unread messages",
        title: "New message received",
        type: "new_message"
    },
    {
        id: "5e8883fca0e8612044248ecf",
        createdAt: (0,date_fns.subDays)(modal_5_now, 3).getTime(),
        description: "Dummy text",
        title: "Your item is shipped",
        type: "item_shipped"
    },
    {
        id: "5e88840187f6b09b431bae68",
        createdAt: (0,date_fns.subDays)(modal_5_now, 7).getTime(),
        description: "You have 32 unread messages",
        title: "New message received",
        type: "new_message"
    }
];
const iconsMap = {
    item_shipped: /*#__PURE__*/ jsx_runtime_.jsx(ShoppingCart03/* default */.Z, {}),
    new_message: /*#__PURE__*/ jsx_runtime_.jsx(MessageChatSquare/* default */.Z, {}),
    order_placed: /*#__PURE__*/ jsx_runtime_.jsx(CreditCard02/* default */.Z, {})
};
const Modal5 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Paper_default()), {
            elevation: 12,
            sx: {
                maxWidth: 320,
                mx: "auto"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        p: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "h6",
                        children: "Notifications"
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((List_default()), {
                    disablePadding: true,
                    children: notifications.map((notification)=>{
                        const icon = iconsMap[notification.type];
                        return /*#__PURE__*/ (0,jsx_runtime_.jsxs)((ListItem_default()), {
                            divider: true,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((ListItemAvatar_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                        sx: {
                                            backgroundColor: "primary.main",
                                            color: "primary.contrastText"
                                        },
                                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                            children: icon
                                        })
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                    primary: /*#__PURE__*/ jsx_runtime_.jsx((Link_default()), {
                                        color: "text.primary",
                                        sx: {
                                            cursor: "pointer"
                                        },
                                        underline: "none",
                                        variant: "subtitle2",
                                        children: notification.title
                                    }),
                                    secondary: notification.description
                                })
                            ]
                        }, notification.id);
                    })
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        display: "flex",
                        justifyContent: "center",
                        p: 1
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        size: "small",
                        children: "Mark all as read"
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Settings01.js
var Settings01 = __webpack_require__(636015);
// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/User01.js
var User01 = __webpack_require__(325055);
;// CONCATENATED MODULE: ./src/sections/components/modals/modal-6.tsx












const Modal6 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Paper_default()), {
            elevation: 12,
            sx: {
                maxWidth: 320,
                mx: "auto"
            },
            children: [
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                    sx: {
                        p: 2
                    },
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            variant: "subtitle2",
                            children: "demo@devias.io"
                        }),
                        /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                            color: "text.secondary",
                            variant: "subtitle2",
                            children: "Devias"
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx((Divider_default()), {}),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                    sx: {
                        mt: 2
                    },
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(User01/* default */.Z, {})
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                    primary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "subtitle2",
                                        children: "Profile"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)((MenuItem_default()), {
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx((ListItemIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                        children: /*#__PURE__*/ jsx_runtime_.jsx(Settings01/* default */.Z, {})
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx((ListItemText_default()), {
                                    primary: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "subtitle2",
                                        children: "Settings"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        p: 2
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        fullWidth: true,
                        variant: "outlined",
                        children: "Logout"
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@mui/material/node/FormControlLabel/index.js
var FormControlLabel = __webpack_require__(128353);
var FormControlLabel_default = /*#__PURE__*/__webpack_require__.n(FormControlLabel);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/Switch/index.js
var Switch = __webpack_require__(877876);
var Switch_default = /*#__PURE__*/__webpack_require__.n(Switch);
// EXTERNAL MODULE: ./node_modules/@mui/material/node/TextField/index.js
var TextField = __webpack_require__(28379);
var TextField_default = /*#__PURE__*/__webpack_require__.n(TextField);
;// CONCATENATED MODULE: ./src/sections/components/modals/modal-7.tsx









const Modal7 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Paper_default()), {
            elevation: 12,
            sx: {
                maxWidth: 320,
                mx: "auto"
            },
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        pt: 3,
                        px: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "h6",
                        children: "Settings"
                    })
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                    sx: {
                        p: 3
                    },
                    spacing: 3,
                    children: [
                        /*#__PURE__*/ jsx_runtime_.jsx((TextField_default()), {
                            fullWidth: true,
                            label: "Theme",
                            select: true,
                            SelectProps: {
                                native: true
                            },
                            children: [
                                "Light",
                                "Dark",
                                "Nature"
                            ].map((theme)=>/*#__PURE__*/ jsx_runtime_.jsx("option", {
                                    value: theme,
                                    children: theme
                                }, theme))
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                            spacing: 1,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {}),
                                        label: "RTL"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {}),
                                        label: "Responsive font sizes"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {}),
                                        label: "Compact"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((FormControlLabel_default()), {
                                        control: /*#__PURE__*/ jsx_runtime_.jsx((Switch_default()), {}),
                                        label: "Rounded Corners"
                                    })
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    sx: {
                        pb: 3,
                        px: 3
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        fullWidth: true,
                        variant: "contained",
                        children: "Save Settings"
                    })
                })
            ]
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/AlertTriangle.js
var AlertTriangle = __webpack_require__(568537);
;// CONCATENATED MODULE: ./src/sections/components/modals/modal-8.tsx










const Modal8 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "sm",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Paper_default()), {
                elevation: 12,
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        direction: "row",
                        spacing: 2,
                        sx: {
                            display: "flex",
                            p: 3
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                sx: {
                                    backgroundColor: "error.lightest",
                                    color: "error.main"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(AlertTriangle/* default */.Z, {})
                                })
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        variant: "h5",
                                        children: "Deactivate account"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                        color: "text.secondary",
                                        sx: {
                                            mt: 1
                                        },
                                        variant: "body2",
                                        children: "Are you sure you want to deactivate your account? All of your data will be permanently removed. This action cannot be undone."
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                        sx: {
                            display: "flex",
                            justifyContent: "flex-end",
                            pb: 3,
                            px: 3
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                color: "inherit",
                                sx: {
                                    mr: 2
                                },
                                children: "Cancel"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                sx: {
                                    backgroundColor: "error.main",
                                    "&:hover": {
                                        backgroundColor: "error.dark"
                                    }
                                },
                                variant: "contained",
                                children: "Deactivate"
                            })
                        ]
                    })
                ]
            })
        })
    });

// EXTERNAL MODULE: ./node_modules/@untitled-ui/icons-react/build/esm/Check.js
var Check = __webpack_require__(756427);
;// CONCATENATED MODULE: ./src/sections/components/modals/modal-9.tsx









const Modal9 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "sm",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Paper_default()), {
                elevation: 12,
                sx: {
                    p: 3,
                    display: "flex",
                    flexDirection: "column",
                    alignItems: "center"
                },
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                        sx: {
                            backgroundColor: "success.lightest",
                            color: "success.main",
                            mb: 2
                        },
                        children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                            children: /*#__PURE__*/ jsx_runtime_.jsx(Check/* default */.Z, {})
                        })
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        variant: "h5",
                        children: "Payment successful"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                        align: "center",
                        color: "text.secondary",
                        sx: {
                            mt: 1
                        },
                        variant: "body2",
                        children: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Provident facere eum obcaecati pariatur magnam eius fugit nostrum sint enim, amet rem aspernatur distinctio tempora repudiandae, maiores quod. Ad, expedita assumenda!"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                        fullWidth: true,
                        size: "large",
                        sx: {
                            mt: 4
                        },
                        variant: "contained",
                        children: "Go back to dashboard"
                    })
                ]
            })
        })
    });

;// CONCATENATED MODULE: ./src/sections/components/modals/modal-10.tsx










const Modal10 = ()=>/*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
        sx: {
            backgroundColor: (theme)=>theme.palette.mode === "dark" ? "neutral.800" : "neutral.100",
            p: 3
        },
        children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
            maxWidth: "sm",
            children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)((Paper_default()), {
                elevation: 12,
                sx: {
                    p: 3
                },
                children: [
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Box["default"], {
                        sx: {
                            display: "flex",
                            flexDirection: "column",
                            alignItems: "center"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Avatar_default()), {
                                sx: {
                                    backgroundColor: "success.lightest",
                                    color: "success.main",
                                    mb: 2
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((SvgIcon_default()), {
                                    children: /*#__PURE__*/ jsx_runtime_.jsx(Check/* default */.Z, {})
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                variant: "h5",
                                children: "Payment successful"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Typography_default()), {
                                align: "center",
                                color: "text.secondary",
                                sx: {
                                    mt: 1
                                },
                                variant: "body2",
                                children: "Lorem ipsum dolor, sit amet consectetur adipisicing elit. Provident facere eum obcaecati pariatur magnam eius fugit nostrum sint enim, amet rem aspernatur distinctio tempora repudiandae, maiores quod. Ad, expedita assumenda!"
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)(Stack["default"], {
                        alignItems: "center",
                        direction: "row",
                        spacing: 3,
                        sx: {
                            mt: 4
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                color: "inherit",
                                fullWidth: true,
                                size: "large",
                                children: "Cancel"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx((Button_default()), {
                                fullWidth: true,
                                size: "large",
                                variant: "contained",
                                children: "Deactivate"
                            })
                        ]
                    })
                ]
            })
        })
    });

;// CONCATENATED MODULE: ./src/app/marketing/components/modals/page.tsx
/* __next_internal_client_entry_do_not_use__  auto */ 

















const page_components = [
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Modal1, {}),
        title: "Modal 1"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Modal2, {}),
        title: "Modal 2"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Modal3, {}),
        title: "Modal 3"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Modal4, {}),
        title: "Modal 4"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Modal5, {}),
        title: "Modal 5"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Modal6, {}),
        title: "Modal 6"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Modal7, {}),
        title: "Modal 7"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Modal8, {}),
        title: "Modal 8"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Modal9, {}),
        title: "Modal 9"
    },
    {
        element: /*#__PURE__*/ jsx_runtime_.jsx(Modal10, {}),
        title: "Modal 10"
    }
];
const Page = ()=>{
    (0,use_page_view/* usePageView */.a)();
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx(seo/* Seo */.p, {
                title: "Components: Modals"
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(components/* Layout */.A, {
                title: "Modals",
                children: /*#__PURE__*/ jsx_runtime_.jsx(Box["default"], {
                    component: "main",
                    sx: {
                        flexGrow: 1,
                        py: 8
                    },
                    children: /*#__PURE__*/ jsx_runtime_.jsx((Container_default()), {
                        maxWidth: "lg",
                        children: /*#__PURE__*/ jsx_runtime_.jsx(Stack["default"], {
                            spacing: 8,
                            children: page_components.map((component)=>/*#__PURE__*/ jsx_runtime_.jsx(previewer/* Previewer */.M, {
                                    title: component.title,
                                    children: component.element
                                }, component.title))
                        })
                    })
                })
            })
        ]
    });
};
/* harmony default export */ const page = (Page);


/***/ }),

/***/ 872497:
/***/ ((module, __unused_webpack_exports, __webpack_require__) => {

/* __next_internal_client_entry_do_not_use__  auto */ const { createProxy  } = __webpack_require__(835985);
module.exports = createProxy("/Users/pratikdhody/Documents/GitHub/fg/fg-web/src/app/marketing/components/modals/page.tsx");


/***/ })

};
;

// load runtime
var __webpack_require__ = require("../../../../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [9235,632,3380,4755,6609,5055,9894,5006,2983,9535,7484,925,8537,8795,7680,95,4018,9274,4131], () => (__webpack_exec__(199884)));
module.exports = __webpack_exports__;

})();