import { SettingsContext } from './settings-context';

export const SettingsConsumer = SettingsContext.Consumer;
