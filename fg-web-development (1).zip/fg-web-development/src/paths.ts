export const paths = {
  index: "/",
  checkout: "/checkout",
  pricing: "/pricing",
  auth: {
    login: "/auth/login",
  },
  authDemo: {
    forgotPassword: {
      classic: "/auth-demo/forgot-password/classic",
      modern: "/auth-demo/forgot-password/modern",
    },
    login: {
      classic: "/auth-demo/login/classic",
      modern: "/auth-demo/login/modern",
    },
    register: {
      classic: "/auth-demo/register/classic",
      modern: "/auth-demo/register/modern",
    },
    resetPassword: {
      classic: "/auth-demo/reset-password/classic",
      modern: "/auth-demo/reset-password/modern",
    },
    verifyCode: {
      classic: "/auth-demo/verify-code/classic",
      modern: "/auth-demo/verify-code/modern",
    },
  },
  dashboard: {
    index: "/",
    academy: {
      index: "/academy",
      courseDetails: "/academy/courses/:courseId",
    },
    account: "/account",
    analytics: "/analytics",
    blank: "/blank",
    memberFeedback: "/member-feedback",
    marketingContact: "/marketing-contact",
    contact: "/contact",
    chat: "/chat",
    vouchers: {
      index: "/vouchers",
      //   details: "/vouchers/:voucherId",
      //   edit: "/vouchers/:voucherId/edit",
    },
    teeTimes: "/tee-times",
    fileManager: "/file-manager",
    invoices: {
      index: "/invoices",
      details: "/invoices/:orderId",
    },
    jobs: {
      index: "/jobs",
      create: "/jobs/create",
      companies: {
        details: "/jobs/companies/:companyId",
      },
    },
    kanban: "/kanban",
    logistics: {
      index: "/logistics",
      fleet: "/logistics/fleet",
    },
    mail: "/mail",
    social: {
      index: "/social",
      profile: "/social/profile",
      feed: "/social/feed",
    },
  },
  components: {
    index: "/components",
    dataDisplay: {
      detailLists: "/components/data-display/detail-lists",
      tables: "/components/data-display/tables",
      quickStats: "/components/data-display/quick-stats",
    },
    lists: {
      groupedLists: "/components/lists/grouped-lists",
      gridLists: "/components/lists/grid-lists",
    },
    forms: "/components/forms",
    modals: "/components/modals",
    charts: "/components/charts",
    buttons: "/components/buttons",
    typography: "/components/typography",
    colors: "/components/colors",
    inputs: "/components/inputs",
  },
  docs: "https://support.futuregolf.com.au",
  notAuthorized: "/errors/401",
  notFound: "/errors/404",
  serverError: "/errors/500",
};
