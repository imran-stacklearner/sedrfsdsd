import { subDays, subHours, subMinutes, subSeconds } from "date-fns";

import type { Voucher } from "src/types/voucher";

const now = new Date();

export const vouchers: Voucher[] = [
  {
    id: 1814451,
    userId: "2996",
    claimedDate: "2023-08-07 21:27:50.000000",
    voucherType: "3",
    userLastName: "Dhody",
    userGolfLink: "123",
    verifiedDate: "",
    voucherCode: "111111",
    userFirstName: "Pratik",
    partnerRating: 0,
    status: "1",
    numberOfRangeBallsReceived: "50",
  },
];

export const voucher: Voucher = {
  id: 1814451,
  userId: "2996",
  claimedDate: "2023-08-07 21:27:50.000000",
  voucherType: "3",
  userLastName: "Dhody",
  userGolfLink: "123",
  verifiedDate: "",
  voucherCode: "111111",
  userFirstName: "Pratik",
  partnerRating: 0,
  status: "1",
  numberOfRangeBallsReceived: "50",
};
