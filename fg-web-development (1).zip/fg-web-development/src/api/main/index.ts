import type { Voucher } from "src/types/voucher";
import { applyPagination } from "src/utils/apply-pagination";
import { applySort } from "src/utils/apply-sort";
import { deepCopy } from "src/utils/deep-copy";

import { voucher, vouchers } from "./data";
import { decode } from "src/utils/jwt";
import axios from "axios";
import { useAuth } from "src/hooks/use-auth";
import { STORAGE_KEY } from "src/contexts/auth/auth-provider";
import { authApi } from "src/api/auth";
import { Values } from "src/sections/dashboard/voucher/voucher-drawer/voucher-details";

type GetVouchersRequest = {
  filters?: {
    query: string;
    hasAcceptedMarketing?: boolean;
    isProspect?: boolean;
    isReturning?: boolean;
  };
  page?: number;
  rowsPerPage?: number;
  sortBy?: string;
  sortDir?: "asc" | "desc";
};

type GetVouchersResponse = Promise<{
  data: Voucher[];
  count: number;
}>;

class MainApi {
  async getVouchers(
    request: GetVouchersRequest,
    vouchers: Voucher[] = []
  ): Promise<GetVouchersResponse> {
    const { filters, page, rowsPerPage, sortBy, sortDir } = request;

    let data = deepCopy(vouchers) as Voucher[];
    let count = data.length;

    if (typeof filters !== "undefined") {
      data = data.filter((voucher) => {
        if (typeof filters.query !== "undefined" && filters.query !== "") {
          let queryMatched = false;
          const properties: (
            | "userFirstName"
            | "userLastName"
            | "voucherCode"
            | "userGolfLink"
          )[] = [
            "userFirstName",
            "userLastName",
            "voucherCode",
            "userGolfLink",
          ];

          if (voucher) {
            // Check if voucher is not null or undefined
            properties.forEach((property) => {
              const propertyValue = voucher[property];
              if (propertyValue && typeof propertyValue === "string") {
                // Check if the property value is a non-null string
                if (
                  propertyValue
                    .toLowerCase()
                    .includes(filters.query.toLowerCase())
                ) {
                  queryMatched = true;
                }
              }
            });
          }

          if (!queryMatched) {
            return false;
          }
        }
        return true;
      });

      count = data.length;
    }

    if (typeof sortBy !== "undefined" && typeof sortDir !== "undefined") {
      data = applySort(data, sortBy, sortDir);
    }

    if (typeof page !== "undefined" && typeof rowsPerPage !== "undefined") {
      data = applyPagination(data, page, rowsPerPage);
    }

    return Promise.resolve({
      data,
      count,
    });
  }

  putVoucher(id: number, key: string, value: string): any {
    const accessToken = window.localStorage.getItem(STORAGE_KEY);

    return new Promise(async (resolve, reject) => {
      try {
        // Decode access token
        const decodedToken = decode(String(accessToken)) as any;

        try {
          if (!decodedToken.token) {
            reject(new Error("Invalid authorization token"));
            return;
          }

          const requestData = {
            id,
            key,
            value,
          };

          // Make an HTTP POST request to the API
          const response = await axios.put(
            process.env.NEXT_PUBLIC_API_URL + "/putPost",
            requestData,
            {
              headers: {
                Authorization: `Bearer ${decodedToken.token}`,
              },
            }
          );

          resolve({ response });
        } catch (err) {
          reject(new Error("Please check your data request"));
        }
      } catch (err) {
        console.error("[Voucher Api]: ", err);
        reject(new Error("Internal server error"));
      }
    });
  }
  postPartnerFeedback(type: 1 | 2, values: any, files?: File[]): any {
    //type 1 = member feedback
    //type 2 = marketing/other feedback
    const accessToken = window.localStorage.getItem(STORAGE_KEY);
    return new Promise(async (resolve, reject) => {
      try {
        // Decode access token
        const decodedToken = decode(String(accessToken)) as any;

        try {
          if (!decodedToken.token) {
            reject(new Error("Invalid authorization token"));
            return;
          }
          const postData =
            type === 1
              ? {
                  type: type,
                  "wpcf-pmf-full-name": values.name,
                  "wpcf-pmf-feedback-date": Math.floor(
                    values.feedbackDate.getTime() / 1000
                  ),
                  "wpcf-pmf-feedback": values.feedback,
                  "wpcf-pmf-user-id": "",
                  "partner-name": values.partnerName,
                  files: files,
                }
              : {
                  type: type,
                  partnerName: values.partnerName,
                  name: values.name,
                  email: values.email,
                  number: values.number,
                  enquiryType: values.enquiryType,
                  message: values.message,
                };

          // Make an HTTP POST request to the API
          const response = await axios.post(
            process.env.NEXT_PUBLIC_API_URL + "/postPartnerFeedback",
            postData,
            {
              headers: {
                Authorization: `Bearer ${decodedToken.token}`,
              },
            }
          );
          resolve({ response });
        } catch (err) {
          reject(new Error("Please check your data request"));
        }
      } catch (err) {
        console.error("[Main Api]: ", err);
        reject(new Error("Internal server error"));
      }
    });
  }
}

export const mainApi = new MainApi();
