import type { User } from "src/types/user";
import { createResourceId } from "src/utils/create-resource-id";
import { decode, JWT_EXPIRES_IN, JWT_SECRET, sign } from "src/utils/jwt";
import { wait } from "src/utils/wait";
import axios from "axios";

import { users } from "./data";

const STORAGE_KEY = "users";

// NOTE: We use localStorage since memory storage is lost after page reload.
//  This should be replaced with a server call that returns DB persisted data.

const getPersistedUsers = (): User[] => {
  try {
    const data = localStorage.getItem(STORAGE_KEY);

    if (!data) {
      return [];
    }

    return JSON.parse(data) as User[];
  } catch (err) {
    console.error(err);
    return [];
  }
};

type SignInRequest = {
  email: string;
  password: string;
};

type SignInResponse = Promise<{
  accessToken: string;
}>;

type SignUpRequest = {
  email: string;
  name: string;
  password: string;
};

type SignUpResponse = Promise<{
  accessToken: string;
}>;

type MeRequest = {
  accessToken: string;
};

type MeResponse = Promise<User>;

class AuthApi {
  async signIn(request: SignInRequest): SignInResponse {
    const { email, password } = request;

    return new Promise(async (resolve, reject) => {
      try {
        try {
          // Make an HTTP POST request to the API
          const response = await axios.post(
            process.env.NEXT_PUBLIC_API_URL + "/getToken",
            {
              grant_type: "password",
              username: email,
              password: password,
            }
          );

          // Create the access token
          const accessToken = sign(
            {
              token: process.env.NEXT_PUBLIC_TMP_TOKEN
                ? process.env.NEXT_PUBLIC_TMP_TOKEN
                : response.data.message.access_token,
            },
            JWT_SECRET,
            {
              expiresIn: JWT_EXPIRES_IN,
            }
          );

          resolve({ accessToken });
        } catch (err) {
          reject(new Error("Please check your email and password"));
        }
      } catch (err) {
        console.error("[Auth Api]: ", err);
        reject(new Error("Internal server error"));
      }
    });
  }
  getPartner(request: MeRequest): MeResponse {
    const { accessToken } = request;

    return new Promise(async (resolve, reject) => {
      try {
        // Decode access token
        const decodedToken = decode(String(accessToken)) as any;

        try {
          if (!decodedToken.token) {
            reject(new Error("Invalid authorization token"));
            return;
          }

          // Make an HTTP POST request to the API
          const response = await axios.get(
            process.env.NEXT_PUBLIC_API_URL + "/getPartner",
            {
              headers: {
                Authorization: `Bearer ${decodedToken.token}`,
              },
            }
          );

          if (!response.data.isPartner) {
            reject(
              new Error(
                "Your account does not have access to use this portal. Please contact us at partnerships@futuregolf.com.au"
              )
            );
          }
          resolve({
            id: response.data.ID,
            firstName: response.data.firstName,
            lastName: response.data.lastName,
            email: response.data.email,
            registeredDate: response.data.registeredDate,
            isPartner: response.data.isPartner,
            linkedPartnerId: response.data.linkedPartnerId,
            name: response.data.name,
            status: response.data.status,
            facebookHandle: response.data.facebookHandle,
            instagramHandle: response.data.instagramHandle,
            vouchers: response.data.vouchers,
          });
        } catch (err) {
          reject(new Error("Please check your email and password"));
        }
      } catch (err) {
        console.error("[Auth Api]: ", err);
        reject(new Error("Internal server error"));
      }
    });
  }
}

export const authApi = new AuthApi();
