import type { User } from "src/types/user";

export const users: User[] = [
  {
    id: 2996,
    firstName: "Pratik",
    lastName: "Dhody",
    email: "pratikdhody@gmail.com",
    registeredDate: "2019-02-14T09:20:46.000Z",
    isPartner: 1,
    linkedPartnerId: "220",
    name: "Mt Derrimut Golf Club",
    status: "publish",
    facebookHandle: "mtderrimutgc",
    instagramHandle: "mtderrimutgc",
    teeTimes: [
      {
        records: [
          {
            userId: "2996",
            teeTime: 2221823,
            bookedOn: "1999-12-09 00:00:00",
          },
          {
            userId: "1938",
            teeTime: 2221820,
            bookedOn: "1999-12-09 00:00:00",
          },
          {
            userId: "",
            teeTime: 2221821,
            bookedOn: "",
          },
          {
            userId: "",
            teeTime: 2221822,
            bookedOn: "",
          },
        ],
        teeTime: "2023-12-01 07:00:00",
        courseName: "",
        eligibility: "The Addict",
      },
    ],
    vouchers: [
      {
        id: 1814451,
        status: "1",
        userId: "2996",
        claimedDate: "07/08/2023 09:27:50 PM",
        voucherCode: "7a7jvex5s1",
        voucherType: "3",
        userLastName: "Dhody",
        partnerRating: 0,
        verifiedDate: "",
        userFirstName: "Pratik",
        numberOfRangeBallsReceived: "50",
      },
    ],
  },
];
