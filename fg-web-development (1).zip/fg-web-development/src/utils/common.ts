export const VOUCHER_TYPES = {
  "1": { name: "Round of golf" },
  "2": { name: "Round of mini golf" },
  "3": { name: "Bucket of range balls" },
  "6": { name: "Skillest voucher" },
  "7": { name: "X-Golf $10 Credit voucher" },
  "8": { name: "X-Golf $25 Credit voucher" },
  "9": { name: "X-Golf $50 Credit voucher" },
  "10": { name: "X-Golf $75 Credit voucher" },
  undefined: { name: "Error" },
};

export const VOUCHER_STATUS = {
  "1": { name: "Pending" },
  "2": { name: "Verified" },
  "3": { name: "Cancelled" },
  "6": { name: "Expired" },
  undefined: { name: "Error" },
};

export const labels: { [index: string]: string } = {
  0: "No rating given",
  1: "Very bad",
  2: "Negative",
  3: "Average",
  4: "Great",
  5: "Brilliant",
};

export function getLabelText(value: number) {
  return `${value} Star${value !== 1 ? "s" : ""}, ${labels[value]}`;
}
