// import { STORAGE_KEY } from "src/contexts/auth/auth-provider";
import { decode } from "./jwt";

export const fetcher = (url: RequestInfo | URL) => {
  const accessToken = window.localStorage.getItem("accessToken");
  const decodedToken = decode(String(accessToken)) as any;

  return fetch(url, {
    headers: {
      Authorization: `Bearer ${decodedToken.token}`, // Include the access token in the headers
    },
  })
    .then((res) => res.json())
    .catch((err) => {
      throw err;
    });
};
