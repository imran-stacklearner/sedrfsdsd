export enum Issuer {
  JWT = "JWT",
}
