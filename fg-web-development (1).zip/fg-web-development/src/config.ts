export const enableDevTools =
  process.env.NEXT_PUBLIC_ENABLE_REDUX_DEV_TOOLS === "true";

export const gtmConfig = {
  containerId: process.env.NEXT_PUBLIC_GTM_CONTAINER_ID,
};

export const mapboxConfig = {
  apiKey: process.env.NEXT_PUBLIC_MAPBOX_API_KEY,
};
