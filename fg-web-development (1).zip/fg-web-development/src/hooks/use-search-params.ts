// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js

export { useSearchParams } from 'next/navigation';
