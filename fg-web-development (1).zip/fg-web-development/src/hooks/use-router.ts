// NOTE: We only re-export the useRouter to maintain consistency between CRA and Next.js

export { useRouter } from 'next/navigation';
