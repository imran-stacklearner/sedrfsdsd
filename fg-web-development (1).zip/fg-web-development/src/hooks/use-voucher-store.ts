import { Voucher } from "src/types/voucher";
import { fetcher } from "src/utils/fetcher";
import useSWR from "swr";
import { deepCopy } from "src/utils/deep-copy";
import { applySort } from "src/utils/apply-sort";
import { applyPagination } from "src/utils/apply-pagination";

export interface VouchersSearchState {
  filters: Filters;
  page: number;
  rowsPerPage: number;
  sortBy?: string;
  sortDir?: SortDir;
}

export interface Filters {
  query?: string;
  status?: string;
}

export type SortDir = "asc" | "desc";

export interface VouchersStoreState {
  vouchers: Voucher[];
  vouchersCount: number;
  data?: any;
  searchState?: any;
  mutate?: any;
  isLoading?: boolean;
}

export const useVouchersStore = (
  searchState: VouchersSearchState
): VouchersStoreState => {
  const { data, error, mutate } = useSWR(
    process.env.NEXT_PUBLIC_API_URL + "/getPartner",
    fetcher,
    {
      revalidateOnFocus: true,
    }
  );

  const isLoading = !data && !error;

  if (data && data.vouchers) {
    let filteredData = deepCopy(data.vouchers) as Voucher[];
    let count = filteredData.length;

    if (typeof searchState.filters !== "undefined") {
      // filter for search text
      filteredData = filteredData.filter((voucher: Voucher) => {
        if (
          typeof searchState.filters.query !== "undefined" &&
          searchState.filters.query !== ""
        ) {
          let queryMatched = false;
          const properties: (
            | "userFirstName"
            | "userLastName"
            | "voucherCode"
            | "userGolfLink"
          )[] = [
            "userFirstName",
            "userLastName",
            "voucherCode",
            "userGolfLink",
          ];

          if (voucher) {
            // Check if voucher is not null or undefined
            properties.forEach((property) => {
              const propertyValue = voucher[property];
              if (propertyValue && typeof propertyValue === "string") {
                // Check if the property value is a non-null string
                if (
                  propertyValue
                    .toLowerCase()
                    .includes(String(searchState.filters?.query).toLowerCase())
                ) {
                  queryMatched = true;
                }
              }
            });
          }

          if (!queryMatched) {
            return false;
          }
        }
        return true;
      });

      // filter for tabs
      filteredData = filteredData.filter((voucher: Voucher) => {
        if (
          typeof searchState.filters.status !== "undefined" &&
          searchState.filters.status !== ""
        ) {
          if (voucher) {
            // tab filtering
            if (typeof searchState.filters.status !== "undefined") {
              const statusMatched = searchState?.filters?.status.includes(
                voucher.status
              );

              if (!statusMatched) {
                return false;
              }
            }
          }
        }
        return true;
      });

      count = filteredData.length;
    }

    if (
      typeof searchState.sortBy !== "undefined" &&
      typeof searchState.sortDir !== "undefined"
    ) {
      filteredData = applySort(
        filteredData,
        searchState.sortBy,
        searchState.sortDir
      );
    }
    if (
      typeof searchState.page !== "undefined" &&
      typeof searchState.rowsPerPage !== "undefined"
    ) {
      filteredData = applyPagination(
        filteredData,
        searchState.page,
        searchState.rowsPerPage
      );
    }

    return {
      vouchers: filteredData,
      vouchersCount: count,
      data: data,
      searchState: searchState,
      mutate,
    };
  }

  return {
    vouchers: [],
    vouchersCount: 0,
    data: data,
    mutate,
    isLoading,
  };
};
