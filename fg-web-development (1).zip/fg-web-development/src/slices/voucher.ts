import type { PayloadAction } from "@reduxjs/toolkit";
import { createSlice } from "@reduxjs/toolkit";

import type { Voucher } from "src/types/voucher";

interface VoucherState {
  vouchers: Voucher[];
}

type GetVouchersAction = PayloadAction<Voucher[]>;

type UpdateVoucherAction = PayloadAction<Voucher>;

const initialState: VoucherState = {
  vouchers: [],
};

const reducers = {
  getVouchers(state: VoucherState, action: GetVouchersAction): void {
    state.vouchers = action.payload;
  },
  updateEvent(state: VoucherState, action: UpdateVoucherAction): void {
    const event = action.payload;

    state.vouchers = state.vouchers.map((_event) => {
      if (_event.id === event.id) {
        return event;
      }

      return _event;
    });
  },
};

export const slice = createSlice({
  name: "vouchers",
  initialState,
  reducers,
});

export const { reducer } = slice;
