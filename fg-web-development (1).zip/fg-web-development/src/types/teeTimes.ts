export interface TeeTime {
  teeTime: string;
  courseName?: string;
  eligibility?: string;
  records: TeeTimeRecord[];
}

export interface TeeTimeRecord {
  userId?: string;
  teeTime: number;
  bookedOn?: string;
  userGolfLink?: string;
  userLastName?: string;
  userFirstName?: string;
  relatedFreeRoundId: string;
  partnerRating: number;
}
