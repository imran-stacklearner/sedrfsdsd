import { Voucher } from "./voucher";

export interface User {
  id: number;
  firstName?: string;
  lastName?: string;
  name?: string;

  email?: string;
  registeredDate?: string;
  isPartner?: number;
  linkedPartnerId: string;
  vouchers: Voucher[];
  [key: string]: any;
}
