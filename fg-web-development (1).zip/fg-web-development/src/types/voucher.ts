import { VOUCHER_STATUS, VOUCHER_TYPES } from "src/utils/common";

export interface Voucher {
  id: number;
  userId?: string;
  claimedDate?: string;
  voucherType?: keyof typeof VOUCHER_TYPES;
  userLastName?: string;
  userGolfLink?: string;
  verifiedDate?: string;
  voucherCode?: string;
  userFirstName?: string;
  partnerRating: number;
  status: keyof typeof VOUCHER_STATUS;
  numberOfRangeBallsReceived: string;
}

export type VoucherStatus = "1" | "2" | "3" | "4";
