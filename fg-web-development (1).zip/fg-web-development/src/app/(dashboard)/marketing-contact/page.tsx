"use client";

import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import { Seo } from "src/components/seo";
import { usePageView } from "src/hooks/use-page-view";
import { ContactForm } from "src/sections/contact/contact-form";

const Page = () => {
  usePageView();

  return (
    <>
      <Seo title="Marketing Support" />
      <Box component="main">
        <Box>
          <Container maxWidth="xl">
            <Box sx={{ py: 3 }}>
              <Stack
                alignItems="flex-start"
                direction="row"
                justifyContent="space-between"
                spacing={4}
              >
                <div>
                  <Typography variant="h4">Marketing Support</Typography>
                </div>
              </Stack>
            </Box>
            <ContactForm enquiryType="1" />
          </Container>
        </Box>
      </Box>
    </>
  );
};

export default Page;
