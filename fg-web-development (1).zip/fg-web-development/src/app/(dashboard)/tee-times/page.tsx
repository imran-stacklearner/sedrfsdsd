"use client";

import type { ChangeEvent, MouseEvent } from "react";
import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import Box from "@mui/material/Box";
import Card from "@mui/material/Card";
import Container from "@mui/material/Container";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import { Seo } from "src/components/seo";
import { useMounted } from "src/hooks/use-mounted";
import { usePageView } from "src/hooks/use-page-view";
import { TeeTimeListSearch } from "src/sections/dashboard/teeTimes/tee-time-list-search";
import { TeeTimeListTable } from "src/sections/dashboard/teeTimes/tee-time-list-table";
import { useDialog } from "src/hooks/use-dialog";
import { CardContent, Divider, Pagination, SvgIcon } from "@mui/material";
import { OverviewHelp } from "src/sections/dashboard/overview/overview-help";
import useSWR from "swr";
import { fetcher } from "src/utils/fetcher";
import { deepCopy } from "src/utils/deep-copy";
import { TeeTime, TeeTimeRecord } from "src/types/teeTimes";
import { applySort } from "src/utils/apply-sort";
import { applyPagination } from "src/utils/apply-pagination";
import { mainApi } from "src/api/main";
import toast from "react-hot-toast";
import { VoucherListContainer } from "src/sections/dashboard/voucher/voucher-list-container";
import { VoucherDrawer } from "src/sections/dashboard/voucher/voucher-drawer";
import { VoucherListSearch } from "src/sections/dashboard/voucher/voucher-list-search";
import { format, isAfter, isBefore } from "date-fns";
import { Voucher } from "src/types/voucher";
import { useVouchersStore } from "src/hooks/use-voucher-store";
import { SnackBar } from "src/components/snack-bar";

interface Filters {
  query?: string;
  status?: string;
}

type SortDir = "asc" | "desc";

interface TeeTimeSearchState {
  filters: Filters;
  page: number;
  rowsPerPage: number;
  sortBy: string;
  sortDir: "asc" | "desc";
}

const useTeeTimesSearch = () => {
  const [state, setState] = useState<TeeTimeSearchState>({
    filters: {
      query: undefined,
      status: undefined,
    },
    page: 0,
    rowsPerPage: 20,
    sortBy: "id",
    sortDir: "desc",
  });

  const handleFiltersChange = useCallback((filters: Filters): void => {
    setState((prevState) => ({
      ...prevState,
      filters,
    }));
  }, []);

  const handleSortChange = useCallback((sortDir: SortDir): void => {
    setState((prevState) => ({
      ...prevState,
      sortDir,
    }));
  }, []);

  const handlePageChange = useCallback(
    (event: MouseEvent<HTMLButtonElement> | null, page: number): void => {
      setState((prevState) => ({
        ...prevState,
        page,
      }));
    },
    []
  );

  const handleRowsPerPageChange = useCallback(
    (event: ChangeEvent<HTMLInputElement>): void => {
      setState((prevState) => ({
        ...prevState,
        rowsPerPage: parseInt(event.target.value, 20),
      }));
    },
    []
  );

  return {
    handleFiltersChange,
    handleSortChange,
    handlePageChange,
    handleRowsPerPageChange,
    state,
  };
};

interface TeeTimesStoreState {
  teeTimes: TeeTime[];
  teeTimesCount: number;
  data?: any;
  searchState?: any;
  mutate?: any;
  isLoading?: boolean;
}

const useTeeTimesStore = (
  searchState: TeeTimeSearchState
): TeeTimesStoreState => {
  const { data, error, mutate } = useSWR(
    process.env.NEXT_PUBLIC_API_URL + "/getPartner",
    fetcher,
    {
      revalidateOnFocus: true,
    }
  );

  const isLoading = !data && !error;

  if (data && data.teeTimes) {
    let filteredData = deepCopy(data.teeTimes) as TeeTime[];
    let count = filteredData.length;

    if (typeof searchState.filters !== "undefined") {
      // filter for search text

      console.log("search", searchState);
      filteredData = filteredData.filter((teeTime: TeeTime) => {
        if (
          typeof searchState.filters.query !== "undefined" &&
          searchState.filters.query !== ""
        ) {
          let queryMatched = false;

          const properties: (
            | "userFirstName"
            | "userLastName"
            | "userGolfLink"
            | "userId"
          )[] = ["userFirstName", "userLastName", "userGolfLink", "userId"];

          if (teeTime) {
            // Check if voucher is not null or undefined
            properties.forEach((property) => {
              teeTime.records.forEach((record) => {
                const propertyValue = record[property];

                if (propertyValue && typeof propertyValue === "string") {
                  // Check if the property value is a non-null string
                  if (
                    propertyValue
                      .toLowerCase()
                      .includes(
                        String(searchState.filters?.query).toLowerCase()
                      )
                  ) {
                    queryMatched = true;
                  }
                }
              });
            });
          }

          if (!queryMatched) {
            return false;
          }
        }
        return true;
      });

      // filter for tabs
      filteredData = filteredData.filter((teeTime: TeeTime) => {
        if (
          typeof searchState.filters.status !== "undefined" &&
          searchState.filters.status !== ""
        ) {
          if (teeTime) {
            // tab filtering
            if (typeof searchState.filters.status !== "undefined") {
              const teeTimeDate = new Date(teeTime.teeTime);

              const statusMatched =
                searchState?.filters?.status === "upcoming"
                  ? isAfter(teeTimeDate, new Date())
                  : searchState?.filters?.status === "past"
                  ? isBefore(teeTimeDate, new Date())
                  : true;

              if (!statusMatched) {
                return false;
              }
            }
          }
        }
        return true;
      });

      count = filteredData.length;
    }

    if (
      typeof searchState.sortBy !== "undefined" &&
      typeof searchState.sortDir !== "undefined"
    ) {
      filteredData = applySort(
        filteredData,
        searchState.sortBy,
        searchState.sortDir
      );
    }
    if (
      typeof searchState.page !== "undefined" &&
      typeof searchState.rowsPerPage !== "undefined"
    ) {
      filteredData = applyPagination(
        filteredData,
        searchState.page,
        searchState.rowsPerPage
      );
    }

    return {
      teeTimes: filteredData,
      teeTimesCount: count,
      data: data,
      searchState: searchState,
      mutate,
    };
  }

  return {
    teeTimes: [],
    teeTimesCount: 0,
    data: data,
    mutate,
    isLoading,
  };
};

const useCurrentVoucher = (
  vouchers: Voucher[],
  voucherId?: number
): Voucher | undefined => {
  return useMemo((): Voucher | undefined => {
    if (!voucherId) {
      return undefined;
    }
    return vouchers.find((voucher) => Number(voucher.id) === Number(voucherId));
  }, [vouchers, voucherId]);
};

const Page = () => {
  const rootRef = useRef<HTMLDivElement | null>(null);
  const teeTimesSearch = useTeeTimesSearch();
  const teeTimesStore = useTeeTimesStore(teeTimesSearch.state);
  const vouchersStore = useVouchersStore(teeTimesSearch.state);
  const dialog = useDialog<number>();
  const currentVoucher = useCurrentVoucher(vouchersStore.vouchers, dialog.data);
  const [showSnack, setShowSnackBar] = useState({
    open: false,
    message: "",
    type: "success",
  });

  usePageView();
  const [pagination, setPagination]: any = useState({
    data: teeTimesStore.teeTimes,
    offset: 0,
    numberPerPage: 20,
    pageCount: 0,
    currentData: [],
  });

  useEffect(() => {
    setPagination({
      data: teeTimesStore.teeTimes,
      offset: 0,
      numberPerPage: 20,
      pageCount: 0,
      currentData: [],
    });
  }, [teeTimesStore.teeTimesCount]);

  useEffect(() => {
    if (teeTimesStore.data && teeTimesStore.teeTimesCount > 0) {
      setPagination((prevState) => ({
        ...prevState,
        data: teeTimesStore.teeTimes,
        pageCount: prevState.data.length / prevState.numberPerPage,
        currentData: teeTimesStore.teeTimes.slice(
          pagination.offset,
          pagination.offset + pagination.numberPerPage
        ),
      }));
    }
  }, [
    teeTimesStore.searchState,
    teeTimesStore.data,
    teeTimesStore.teeTimesCount,
    pagination.numberPerPage,
    pagination.offset,
  ]);

  useEffect(() => {
    if (!teeTimesStore?.data) teeTimesStore.mutate();
  }, [teeTimesStore?.data]);

  const handlePageClick = (_, value) => {
    const selected = value;
    const offset = (selected - 1) * pagination.numberPerPage;
    setPagination({ ...pagination, offset });
  };

  const handleClose = useCallback((): void => {
    setShowSnackBar({ ...showSnack, open: false, message: "" });
  }, []);

  const handleVoucherOpen = useCallback(
    (relatedFreeRoundId: number): void => {
      // Close drawer if is the same order
      if (dialog.open && dialog.data === relatedFreeRoundId) {
        dialog.handleClose();
        return;
      }
      dialog.handleOpen(relatedFreeRoundId);
    },
    [dialog]
  );

  const handleRatingUpdate = async (
    teeTimeRecord: TeeTimeRecord,
    rating: number
  ) => {
    try {
      const response = await mainApi.putVoucher(
        Number(teeTimeRecord.relatedFreeRoundId),
        "wpcf-partner-rating",
        String(rating)
      );

      if (response.response.status === 200) {
        teeTimesStore.mutate();

        toast.success(
          `Success, rating for ${teeTimeRecord.userFirstName} has been updated`
        );
      }
    } catch (err) {
      toast.error(
        `Whoops, there was an error in rating ${teeTimeRecord.userFirstName}`
      );
    }
  };

  return (
    <>
      <Seo title="Dedicated Tee Times" />
      <Box
        component="main"
        sx={{
          display: "flex",
          flex: "1 1 auto",
          overflow: "hidden",
          position: "relative",
        }}
      >
        <VoucherListContainer open={dialog.open}>
          <Container maxWidth="xl">
            <Box sx={{ py: 3 }}>
              <Stack alignItems="flex-start" direction="row" spacing={4}>
                <div>
                  <Typography variant="h4">Dedicated FG Tee Times</Typography>
                </div>
              </Stack>
            </Box>
            <Divider />
            <TeeTimeListSearch
              onFiltersChange={teeTimesSearch.handleFiltersChange}
              //   onSortChange={teeTimesSearch.handleSortChange}
              sortBy={teeTimesSearch.state.sortBy}
              sortDir={teeTimesSearch.state.sortDir}
            />
            <Divider />
            <TeeTimeListTable
              count={teeTimesStore.teeTimesCount}
              items={pagination.currentData}
              onPageChange={teeTimesSearch.handlePageChange}
              onRowsPerPageChange={teeTimesSearch.handleRowsPerPageChange}
              page={teeTimesSearch.state.page}
              rowsPerPage={teeTimesSearch.state.rowsPerPage}
              onRatingUpdate={handleRatingUpdate}
              onOpenVoucher={handleVoucherOpen}
            />
            <Divider />
            <Box sx={{ py: 3, display: "flex" }}>
              <Pagination
                sx={{ marginLeft: "auto" }}
                color="primary"
                count={pagination.pageCount}
                onChange={handlePageClick}
                showFirstButton
                showLastButton
              />
            </Box>
          </Container>
        </VoucherListContainer>

        <VoucherDrawer
          container={rootRef.current}
          onClose={dialog.handleClose}
          open={dialog.open}
          voucher={currentVoucher}
          //   onRatingUpdate={handleRatingUpdate}
        />
      </Box>
    </>
  );
};

export default Page;
