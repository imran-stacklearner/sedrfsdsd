"use client";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import { Seo } from "src/components/seo";
import { usePageView } from "src/hooks/use-page-view";
import { VoucherDetails } from "src/sections/dashboard/voucher/voucher-drawer/voucher-details";

const Page = () => {
  usePageView();

  return (
    <>
      <Seo title="Feedback: Create" />
      <Box
        component="main"
        sx={{
          display: "flex",
          flex: "1 1 auto",
          overflow: "hidden",
          position: "relative",
        }}
      >
        <Container maxWidth="xl">
          <Stack spacing={2}>
            <Box sx={{ py: 3 }}>
              <Stack alignItems="flex-start" direction="row" spacing={4}>
                <div>
                  <Typography variant="h4">Provide Member Feedback</Typography>
                </div>
              </Stack>
            </Box>

            <VoucherDetails />
          </Stack>
        </Container>
      </Box>
    </>
  );
};

export default Page;
