"use client";

import { ChangeEvent, MouseEvent, useEffect } from "react";
import { useCallback, useMemo, useRef, useState } from "react";
import Box from "@mui/material/Box";
import Divider from "@mui/material/Divider";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import { Seo } from "src/components/seo";
import { useDialog } from "src/hooks/use-dialog";
import { usePageView } from "src/hooks/use-page-view";
import { VoucherListContainer } from "src/sections/dashboard/voucher/voucher-list-container";
import { VoucherListSearch } from "src/sections/dashboard/voucher/voucher-list-search";
import { VoucherListTable } from "src/sections/dashboard/voucher/voucher-list-table";
import { Voucher } from "src/types/voucher";
import { mainApi } from "src/api/main";
import React from "react";
import Container from "@mui/material/Container";
import { VoucherDrawer } from "src/sections/dashboard/voucher/voucher-drawer";
import { labels } from "src/utils/common";
import { SnackBar } from "src/components/snack-bar";
import { Pagination } from "@mui/material";
import { utcToZonedTime } from "date-fns-tz";
import {
  Filters,
  SortDir,
  VouchersSearchState,
  useVouchersStore,
} from "src/hooks/use-voucher-store";

const useVouchersSearch = () => {
  const [state, setState] = useState<VouchersSearchState>({
    filters: {
      query: undefined,
      status: undefined,
    },
    page: 0,
    rowsPerPage: 20,
    sortBy: "id",
    sortDir: "desc",
  });

  const handleFiltersChange = useCallback((filters: Filters): void => {
    setState((prevState) => ({
      ...prevState,
      filters,
    }));
  }, []);

  const handleSortChange = useCallback((sortDir: SortDir): void => {
    setState((prevState) => ({
      ...prevState,
      sortDir,
    }));
  }, []);

  const handlePageChange = useCallback(
    (event: MouseEvent<HTMLButtonElement> | null, page: number): void => {
      setState((prevState) => ({
        ...prevState,
        page,
      }));
    },
    []
  );

  const handleRowsPerPageChange = useCallback(
    (event: ChangeEvent<HTMLInputElement>): void => {
      setState((prevState) => ({
        ...prevState,
        rowsPerPage: parseInt(event.target.value, 20),
      }));
    },
    []
  );

  return {
    handleFiltersChange,
    handleSortChange,
    handlePageChange,
    handleRowsPerPageChange,
    state,
  };
};

const useCurrentVoucher = (
  vouchers: Voucher[],
  voucherId?: number
): Voucher | undefined => {
  return useMemo((): Voucher | undefined => {
    if (!voucherId) {
      return undefined;
    }

    return vouchers.find((voucher) => voucher.id === voucherId);
  }, [vouchers, voucherId]);
};

const Page = () => {
  const rootRef = useRef<HTMLDivElement | null>(null);
  const vouchersSearch = useVouchersSearch();
  const vouchersStore = useVouchersStore(vouchersSearch.state);
  const dialog = useDialog<number>();
  const currentVoucher = useCurrentVoucher(vouchersStore.vouchers, dialog.data);
  const [showSnack, setShowSnackBar] = useState({
    open: false,
    message: "",
    type: "success",
  });
  const [previousData, setPreviousData] = useState({
    type: "",
    id: 0,
    value: 0,
  });

  usePageView();

  const [pagination, setPagination]: any = useState({
    data: vouchersStore.vouchers,
    offset: 0,
    numberPerPage: 20,
    pageCount: 0,
    currentData: [],
  });

  useEffect(() => {
    setPagination({
      data: vouchersStore.vouchers,
      offset: 0,
      numberPerPage: 20,
      pageCount: 0,
      currentData: [],
    });
  }, [vouchersStore.vouchersCount]);

  useEffect(() => {
    if (vouchersStore.data && vouchersStore.vouchersCount > 0) {
      setPagination((prevState) => ({
        ...prevState,
        data: vouchersStore.vouchers,
        pageCount: prevState.data.length / prevState.numberPerPage,
        currentData: vouchersStore.vouchers.slice(
          pagination.offset,
          pagination.offset + pagination.numberPerPage
        ),
      }));
    }
  }, [
    vouchersStore.searchState,
    vouchersStore.data,
    vouchersStore.vouchersCount,
    pagination.numberPerPage,
    pagination.offset,
  ]);

  useEffect(() => {
    if (!vouchersStore?.data) vouchersStore.mutate();
  }, [vouchersStore?.data]);

  const handlePageClick = (_, value) => {
    const selected = value;
    const offset = (selected - 1) * pagination.numberPerPage;
    setPagination({ ...pagination, offset });
  };

  const handleClose = useCallback((): void => {
    setShowSnackBar({ ...showSnack, open: false, message: "" });
  }, []);

  const handleVoucherOpen = useCallback(
    (voucher: Voucher): void => {
      // Close drawer if is the same order
      if (dialog.open && dialog.data === voucher.id) {
        dialog.handleClose();
        return;
      }
      dialog.handleOpen(voucher.id);
    },
    [dialog]
  );

  const handleVoucherUpdate = async (voucher: Voucher, result: string) => {
    try {
      const timestampString = Math.floor(
        utcToZonedTime(new Date(), "Australia/Melbourne").getTime() / 1000
      ).toString();

      const response = await mainApi.putVoucher(
        Number(Number(voucher?.id)),
        "wpcf-verified-at",
        timestampString
      );

      await mainApi.putVoucher(
        Number(voucher?.id),
        "wpcf-fg-free-round-status",
        result
      );

      if (response.response.status === 200) {
        vouchersStore.mutate();

        setShowSnackBar({
          ...showSnack,
          open: true,
          type: "success",
          message: `Success, voucher ${voucher.voucherCode} has been marked as verified`,
        });

        setPreviousData({
          type: "voucherUpdate",
          id: Number(voucher.id),
          value: 0,
        });
      }
    } catch (err) {
      setShowSnackBar({
        ...showSnack,
        open: true,
        type: "error",
        message: `Whoops, there was an error in updating voucher ${voucher.voucherCode}`,
      });
    }
  };

  const handleRatingUpdate = async (
    voucher: Voucher,
    rating: number,
    previousRating: number
  ) => {
    try {
      const response = await mainApi.putVoucher(
        Number(voucher.id),
        "wpcf-partner-rating",
        String(rating)
      );

      if (response.response.status === 200) {
        vouchersStore.mutate();

        setShowSnackBar({
          ...showSnack,
          open: true,
          type: "success",
          message: `Success, rating for ${voucher.userFirstName} has been updated to ${labels[rating]}!`,
        });
        setPreviousData({
          type: "ratingUpdate",
          id: Number(voucher.id),
          value: previousRating,
        });
      }
    } catch (err) {
      setShowSnackBar({
        ...showSnack,
        open: true,
        type: "error",
        message: `Whoops, there was an error in rating ${voucher.userFirstName}`,
      });
    }
  };

  const handleRatingUndo = async () => {
    try {
      const response = await mainApi.putVoucher(
        previousData.id,
        "wpcf-partner-rating",
        String(previousData.value)
      );

      if (response.response.status === 200) {
        vouchersStore.mutate();

        setShowSnackBar({
          ...showSnack,
          open: true,
          type: "success",
          message: `Success, rating has been updated to back to ${
            labels[previousData.value]
          }!`,
        });
        setPreviousData({ type: "ratingUpdate", id: 0, value: 0 });
      }
    } catch (err) {
      console.log("error", err);
    }
  };

  const handleVoucherUndo = async () => {
    try {
      const response = await mainApi.putVoucher(
        previousData.id,
        "wpcf-verified-at",
        ""
      );

      await mainApi.putVoucher(
        previousData?.id,
        "wpcf-fg-free-round-status",
        "1" // update back to claimed status
      );

      if (response.response.status === 200) {
        vouchersStore.mutate();

        setShowSnackBar({
          ...showSnack,
          open: true,
          type: "success",
          message: `Success, voucher has been marked as unverified`,
        });
        setPreviousData({ type: "voucherUpdate", id: 0, value: 0 });
      }
    } catch (err) {
      console.log("error", err);
    }
  };

  return (
    <>
      <Seo title="Round Vouchers" />
      <Box
        component="main"
        ref={rootRef}
        sx={{
          display: "flex",
          flex: "1 1 auto",
          overflow: "hidden",
          position: "relative",
        }}
      >
        <SnackBar
          text={showSnack.message}
          open={showSnack.open}
          onClose={handleClose}
          setUndo={
            previousData.id > 0
              ? previousData.type === "ratingUpdate"
                ? handleRatingUndo
                : previousData.type === "voucherUpdate"
                ? handleVoucherUndo
                : undefined
              : undefined
          }
        />

        <VoucherListContainer open={dialog.open}>
          <Container maxWidth="xl">
            <Box sx={{ py: 3 }}>
              <Stack
                alignItems="flex-start"
                direction="row"
                justifyContent="space-between"
                spacing={4}
              >
                <div>
                  <Typography variant="h4">Vouchers</Typography>
                </div>
              </Stack>
            </Box>
            <Divider />
            <VoucherListSearch
              onFiltersChange={vouchersSearch.handleFiltersChange}
              onSortChange={vouchersSearch.handleSortChange}
              sortBy={vouchersSearch.state.sortBy}
              sortDir={vouchersSearch.state.sortDir}
            />
            <Divider />

            <VoucherListTable
              count={vouchersStore.vouchersCount}
              items={pagination.currentData}
              onPageChange={vouchersSearch.handlePageChange}
              onRowsPerPageChange={vouchersSearch.handleRowsPerPageChange}
              page={vouchersSearch.state.page}
              rowsPerPage={vouchersSearch.state.rowsPerPage}
              onMarkAsVerified={handleVoucherUpdate}
              onOpenVoucher={handleVoucherOpen}
              onRatingUpdate={handleRatingUpdate}
              isLoading={vouchersStore.isLoading}
            />
            <Divider />

            <Box sx={{ py: 3, display: "flex" }}>
              <Pagination
                sx={{ marginLeft: "auto" }}
                color="primary"
                count={pagination.pageCount}
                onChange={handlePageClick}
                showFirstButton
                showLastButton
              />
            </Box>
          </Container>
        </VoucherListContainer>
        <VoucherDrawer
          container={rootRef.current}
          onClose={dialog.handleClose}
          open={dialog.open}
          voucher={currentVoucher}
          onRatingUpdate={handleRatingUpdate}
        />
      </Box>
    </>
  );
};

export default Page;
