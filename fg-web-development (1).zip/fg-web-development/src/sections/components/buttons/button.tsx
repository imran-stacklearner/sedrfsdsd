import type { FC, ButtonHTMLAttributes, ReactNode } from "react";
import { useState } from "react";
import MuiButton from "@mui/material/Button";
import { ButtonProps } from "@mui/material/Button";

import { CircularProgress } from "@mui/material";

// Define a generic type that extends ButtonHTMLAttributes

export const Button: FC<ButtonProps & { children: ReactNode }> = ({
  children,
  ...props
}) => {
  return (
    <MuiButton {...props}>
      {props.disabled ? (
        <CircularProgress size={24} color="inherit" /> // Show a spinner when disabled.
      ) : (
        children
      )}
    </MuiButton>
  );
};
