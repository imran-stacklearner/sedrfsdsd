import React, { ChangeEvent, FC, MouseEvent } from "react";
import PropTypes from "prop-types";
import CheckCircleIcon from "@untitled-ui/icons-react/build/esm/CheckCircle";
import Box from "@mui/material/Box";
import IconButton from "@mui/material/IconButton";
import Link from "@mui/material/Link";
import SvgIcon from "@mui/material/SvgIcon";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TableRow from "@mui/material/TableRow";
import { format, fromUnixTime } from "date-fns";
import { Scrollbar } from "src/components/scrollbar";
import type { Voucher, VoucherStatus } from "src/types/voucher";
import { AlertHexagon, Star01 } from "@untitled-ui/icons-react";
import Tooltip from "@mui/material/Tooltip";
import { SeverityPill, SeverityPillColor } from "src/components/severity-pill";
import { getLabelText, labels } from "src/utils/common";
import Rating from "@mui/material/Rating";
import { CircularProgress, Typography } from "@mui/material";

export const statusMap: Record<VoucherStatus, SeverityPillColor> = {
  1: "success",
  2: "info",
  3: "warning",
  4: "success",
};

interface VoucherListTableProps {
  count?: number;
  items?: Voucher[];
  onDeselectAll?: () => void;
  onDeselectOne?: (customerId: string) => void;
  onPageChange?: (
    event: MouseEvent<HTMLButtonElement> | null,
    newPage: number
  ) => void;
  onRowsPerPageChange?: (event: ChangeEvent<HTMLInputElement>) => void;
  onSelect?: (voucherId: number) => void;
  onSelectAll?: () => void;
  page?: number;
  rowsPerPage?: number;
  selected?: string[];
  onMarkAsVerified: (voucher: Voucher, result: string) => void;
  onOpenVoucher: (voucher: Voucher) => void;
  isLoading?: boolean;
  onRatingUpdate(
    voucher: Voucher,
    rating: number,
    previousRating: number
  ): void;
}

export const VoucherListTable: FC<VoucherListTableProps> = (props) => {
  const {
    items = [],
    onMarkAsVerified,
    onOpenVoucher,
    onRatingUpdate,
    selected = [],
    isLoading,
  } = props;

  // Initialize hover state for each item
  const [hoverStates, setHoverStates] = React.useState(items.map(() => -1));

  return (
    <div>
      <Box sx={{ position: "relative" }}>
        <Scrollbar>
          <Table stickyHeader size="small" aria-label="a dense table">
            <TableHead>
              <TableRow>
                <TableCell align="center">Member Rating</TableCell>
                <TableCell align="center">Action</TableCell>
                <TableCell align="center">Name</TableCell>
                <TableCell align="center">Claimed On</TableCell>
                <TableCell align="center">GOLF Link</TableCell>
                <TableCell align="center">Voucher Code</TableCell>
                <TableCell align="center">Verified On</TableCell>
              </TableRow>
            </TableHead>
            <TableBody>
              {items.length > 0 &&
                items.map((voucher, index) => {
                  const isSelected = selected.includes(String(voucher.id));
                  const hoverState = hoverStates[index]; // Get hover state for the current row

                  // Create a hover state for the current row
                  return (
                    <TableRow hover key={voucher.id} selected={isSelected}>
                      <TableCell align="center">
                        <Rating
                          name="hover-feedback"
                          value={voucher.partnerRating}
                          getLabelText={getLabelText}
                          onChange={(event, newValue) =>
                            onRatingUpdate(
                              voucher,
                              newValue ?? 0,
                              voucher.partnerRating
                            )
                          }
                          onChangeActive={(event, newHover) => {
                            // Update the hover state for the current row
                            const newHoverStates = [...hoverStates];
                            newHoverStates[index] = newHover;
                            setHoverStates(newHoverStates);
                          }}
                          emptyIcon={
                            <Star01
                              style={{ opacity: 0.55 }}
                              fontSize="inherit"
                            />
                          }
                        />
                        <Box sx={{ ml: 2 }}>
                          {
                            labels[
                              hoverState !== -1 &&
                              hoverState !== null &&
                              hoverState !== undefined
                                ? hoverState
                                : voucher.partnerRating
                            ]
                          }
                        </Box>
                      </TableCell>
                      <TableCell align="center">
                        {voucher.status === "1" && (
                          <Tooltip title="Mark as verified">
                            <IconButton
                              onClick={() => onMarkAsVerified(voucher, "2")}
                            >
                              <SvgIcon>
                                <CheckCircleIcon />
                              </SvgIcon>
                            </IconButton>
                          </Tooltip>
                        )}
                        <Tooltip title="Provide member feedback">
                          <IconButton onClick={() => onOpenVoucher(voucher)}>
                            <SvgIcon>
                              <AlertHexagon />
                            </SvgIcon>
                          </IconButton>
                        </Tooltip>
                      </TableCell>
                      <TableCell align="center">
                        {voucher.userFirstName} {voucher.userLastName}
                      </TableCell>
                      <TableCell align="center">
                        {voucher.claimedDate}
                      </TableCell>
                      <TableCell align="center">
                        {Number(voucher.userGolfLink)
                          ? voucher.userGolfLink
                          : "Unknown"}
                      </TableCell>
                      <TableCell align="center">
                        {voucher.voucherCode}
                      </TableCell>
                      <TableCell align="center">
                        {voucher.verifiedDate ||
                        ["2"].includes(voucher.status) ? (
                          format(
                            fromUnixTime(Number(voucher.verifiedDate)),
                            "dd/MM/yyyy hh:mm a"
                          )
                        ) : ["4"].includes(voucher.status) ? (
                          "Expired"
                        ) : (
                          <Tooltip title="Mark as verified">
                            <Link
                              variant="inherit"
                              onClick={() => onMarkAsVerified(voucher, "2")}
                            >
                              <SeverityPill color="warning">
                                Mark as verified
                              </SeverityPill>
                            </Link>
                          </Tooltip>
                        )}
                      </TableCell>
                    </TableRow>
                  );
                })}
            </TableBody>
          </Table>
          {!isLoading && items.length <= 0 && (
            <Typography py={6} variant="body2" align="center">
              😔 No vouchers found.
            </Typography>
          )}

          {isLoading && items.length <= 0 && (
            <Box
              py={5}
              sx={{
                display: "flex",
                flexDirection: "column",
                alignItems: "center",
                justifyContent: "center",
              }}
            >
              <CircularProgress size={20} />
              <Typography py={1} variant="body2" align="center">
                Loading
              </Typography>
            </Box>
          )}
        </Scrollbar>
      </Box>
    </div>
  );
};

VoucherListTable.propTypes = {
  count: PropTypes.number,
  items: PropTypes.array,
  onDeselectAll: PropTypes.func,
  onDeselectOne: PropTypes.func,
  onPageChange: PropTypes.func,
  onRowsPerPageChange: PropTypes.func,
  onSelect: PropTypes.func,
  onSelectAll: PropTypes.func,
  page: PropTypes.number,
  rowsPerPage: PropTypes.number,
  selected: PropTypes.array,
};
