import React from "react";
import { useState, type FC, useCallback, useEffect } from "react";
import PropTypes from "prop-types";
import Stack from "@mui/material/Stack";
import Typography from "@mui/material/Typography";
import * as Yup from "yup";
import { Voucher } from "src/types/voucher";
import { getLabelText, labels } from "src/utils/common";
import { statusMap } from "../voucher-list-table";
import { paths } from "src/paths";
import { RouterLink } from "src/components/router-link";
import toast from "react-hot-toast";
import {
  Box,
  Card,
  Grid,
  OutlinedInput,
  FormHelperText,
  FormControl,
  FormLabel,
  Rating,
} from "@mui/material";
import { FileDropzone } from "src/components/file-dropzone";
import { DateTimePicker } from "@mui/x-date-pickers";
import { useAuth } from "src/hooks/use-auth";
import { fileToBase64 } from "src/utils/file-to-base64";
import { useFormik } from "formik";
import { useMounted } from "src/hooks/use-mounted";
import { useRouter } from "src/hooks/use-router";
import { useSearchParams } from "src/hooks/use-search-params";
import { mainApi } from "src/api/main";
import { Star01 } from "@untitled-ui/icons-react";
import { Button } from "src/sections/components/buttons/button";

interface VoucherDetailsProps {
  voucher?: Voucher;
  onClose?: () => void;
  viaVoucher?: boolean;
  onRatingUpdate?(
    voucher: Voucher,
    rating: number,
    previousRating: number
  ): void;
}

export interface Values {
  name: string;
  feedbackDate: Date;

  rating: number;
  partnerName: string;
  feedback: string;
  submit: null;
}

export const VoucherDetails: FC<VoucherDetailsProps> = (props) => {
  const { voucher, onClose, onRatingUpdate, viaVoucher } = props;
  const [cover, setCover] = useState<string | null>();
  const user = useAuth();
  const isMounted = useMounted();
  const router = useRouter();
  const searchParams = useSearchParams();
  const returnTo = searchParams.get("returnTo");
  const [files, setFiles] = useState<File[]>([]);
  const [hoverState, setHoverState] = useState(voucher?.partnerRating || 0);
  // Initialize hover state for each item

  useEffect(() => {
    setFiles([]);
  }, [open]);

  const handleDrop = useCallback((newFiles: File[]): void => {
    setFiles((prevFiles) => {
      return [...prevFiles, ...newFiles];
    });
  }, []);

  const handleRemove = useCallback((file: File): void => {
    setFiles((prevFiles) => {
      return prevFiles.filter((_file) => _file !== file);
    });
  }, []);

  const handleRemoveAll = useCallback((): void => {
    setFiles([]);
  }, []);

  const initialValues: Values = {
    name: `${voucher?.userFirstName ?? ""} ${voucher?.userLastName ?? ""}`,
    feedbackDate: new Date(),
    rating: voucher?.partnerRating ?? 0,
    feedback: "",
    partnerName: user?.user?.name ?? "",
    submit: null,
  };

  const validationSchema = Yup.object({
    name: Yup.string().max(255).required("Member name is required"),
    feedback: Yup.string().max(750).required("Feedback is required"),
  });

  function resetForm() {
    formik.resetForm();
    setFiles([]);
    onClose?.();
  }

  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: async (values, helpers): Promise<void> => {
      const base64FilePromises = files.map((file) => fileToBase64(file));
      try {
        const base64Files = await Promise.all(base64FilePromises);
        const res = await mainApi.postPartnerFeedback(
          1,
          values,
          // @ts-ignore
          base64Files
        );

        if (res.response.status === 200) {
          toast.success("Feedback submitted to Future Golf");
          resetForm();
        } else {
          toast.error(`Whoops, there was an error in submitting this feedback`);
        }
      } catch (err) {
        console.error(err);

        if (isMounted()) {
          helpers.setStatus({ success: false });
          helpers.setErrors({ submit: err.message });
          helpers.setSubmitting(false);
        }
      }
    },
  });

  let statusColor;
  if (voucher?.status && statusMap[voucher.status]) {
    statusColor = statusMap[voucher.status];
  } else {
    statusColor = "warning"; // Default value
  }

  return (
    <Stack spacing={6}>
      <form noValidate onSubmit={formik.handleSubmit}>
        <Stack spacing={3}>
          <Card
            elevation={16}
            sx={{
              borderRadius: 1,
              justifyContent: "space-between",
              px: 3,
              py: 2,
            }}
          >
            <Grid xs={12} sm={6}>
              <FormControl fullWidth>
                <FormLabel
                  sx={{
                    color: "text.primary",
                    mb: 1,
                  }}
                >
                  Member Name
                </FormLabel>

                <OutlinedInput
                  error={!!(formik.touched.name && formik.errors.name)}
                  fullWidth
                  placeholder="John Smith"
                  disabled={viaVoucher}
                  name="name"
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  type="text"
                  value={formik.values.name}
                />
              </FormControl>
            </Grid>

            {voucher?.partnerRating && onRatingUpdate && (
              <Grid xs={12} sm={6}>
                <FormControl fullWidth>
                  <FormLabel
                    sx={{
                      color: "text.primary",
                      mt: 2,
                      mb: 1,
                    }}
                  >
                    Rating
                  </FormLabel>

                  <Rating
                    name="hover-feedback"
                    value={voucher.partnerRating}
                    getLabelText={getLabelText}
                    onChange={(event, newValue) =>
                      onRatingUpdate(
                        voucher,
                        newValue ?? 0,
                        voucher.partnerRating
                      )
                    }
                    onChangeActive={(event, newHover) => {
                      setHoverState(newHover);
                    }}
                    emptyIcon={
                      <Star01 style={{ opacity: 0.55 }} fontSize="inherit" />
                    }
                  />
                  <Box sx={{ ml: 2 }}>
                    {
                      labels[
                        hoverState !== -1 &&
                        hoverState !== null &&
                        hoverState !== undefined
                          ? hoverState
                          : voucher.partnerRating
                      ]
                    }
                  </Box>
                </FormControl>
              </Grid>
            )}
          </Card>

          <Card
            elevation={16}
            sx={{
              borderRadius: 1,
              justifyContent: "space-between",
              px: 3,
              py: 2,
            }}
          >
            <Grid xs={12} sm={6}>
              <FormControl fullWidth>
                <FormLabel
                  sx={{
                    color: "text.primary",
                    mb: 1,
                  }}
                >
                  Feedback Date
                </FormLabel>

                <DateTimePicker
                  label="Feedback Date"
                  onChange={formik.handleChange}
                  value={formik.values.feedbackDate}
                  format="dd/MM/yyyy hh:mm a"
                />
              </FormControl>
            </Grid>

            <Grid xs={12} sm={6}>
              <FormControl fullWidth>
                <FormLabel
                  sx={{
                    color: "text.primary",
                    mt: 2,
                    mb: 1,
                  }}
                >
                  Feedback
                </FormLabel>

                <OutlinedInput
                  error={!!(formik.touched.feedback && formik.errors.feedback)}
                  fullWidth
                  placeholder="Your feedback..."
                  minRows={4}
                  multiline
                  name="feedback"
                  onBlur={formik.handleBlur}
                  onChange={formik.handleChange}
                  type="text"
                  value={formik.values.feedback}
                />
              </FormControl>
            </Grid>
          </Card>

          <Card
            elevation={16}
            sx={{
              borderRadius: 1,
              justifyContent: "space-between",
              px: 3,
              py: 2,
            }}
          >
            <Grid xs={12} sm={6}>
              <FormControl fullWidth>
                <FormLabel
                  sx={{
                    color: "text.primary",
                    mb: 1,
                  }}
                >
                  Attachments
                  <Typography variant="subtitle2">
                    Maximum of 10 files
                  </Typography>
                  <Typography variant="subtitle2">(optional)</Typography>
                </FormLabel>

                <FileDropzone
                  accept={{
                    "image/*": [],
                    "application/pdf": [".pdf"],
                  }}
                  caption="(PDF, JPG, PNG or SVG files only)"
                  files={files}
                  onDrop={handleDrop}
                  onRemove={handleRemove}
                  onRemoveAll={handleRemoveAll}
                />
              </FormControl>
            </Grid>
          </Card>
        </Stack>
        <Card
          elevation={16}
          sx={{
            alignItems: "center",
            borderRadius: 1,
            display: "flex",
            justifyContent: "space-between",
            mt: 2,
            mb: 8,
            px: 3,
            py: 2,
          }}
        >
          <Typography
            variant="subtitle2"
            sx={{
              fontWeight: 300,
            }}
          >
            We appreciate your feedback,
            <Typography variant="subtitle2">{user.user?.name}</Typography>
          </Typography>
          <Stack alignItems="center" direction="row" spacing={2}>
            {!voucher && (
              <Button
                color="inherit"
                //     component={RouterLink}
                href={paths.dashboard.memberFeedback}
                onClick={() => (resetForm(), toast.error("Feedback cancelled"))}
              >
                Cancel
              </Button>
            )}
            {formik.errors.submit && (
              <FormHelperText error sx={{ mt: 3 }}>
                {formik.errors.submit as string}
              </FormHelperText>
            )}

            <Button
              disabled={formik.isSubmitting}
              type="submit"
              variant="contained"
            >
              Submit feedback
            </Button>
          </Stack>
        </Card>
      </form>
    </Stack>
  );
};

VoucherDetails.propTypes = {
  onApprove: PropTypes.func,
  onEdit: PropTypes.func,
  onReject: PropTypes.func,
  // @ts-ignore
  voucher: PropTypes.object,
};
