import React, { ChangeEvent, FC, MouseEvent, useState } from "react";
import PropTypes from "prop-types";
import CheckIcon from "@untitled-ui/icons-react/build/esm/Check";
import CheckCircleIcon from "@untitled-ui/icons-react/build/esm/CheckCircle";
import Snackbar from "@mui/material/Snackbar";
import MuiAlert, { AlertColor, AlertProps } from "@mui/material/Alert";
import Box from "@mui/material/Box";
import Button from "@mui/material/Button";
import IconButton from "@mui/material/IconButton";
import Link from "@mui/material/Link";
import Stack from "@mui/material/Stack";
import SvgIcon from "@mui/material/SvgIcon";
import Table from "@mui/material/Table";
import TableBody from "@mui/material/TableBody";
import TableCell from "@mui/material/TableCell";
import TableHead from "@mui/material/TableHead";
import TablePagination from "@mui/material/TablePagination";
import TableRow from "@mui/material/TableRow";
import { format, fromUnixTime } from "date-fns";
import { RouterLink } from "src/components/router-link";
import { Scrollbar } from "src/components/scrollbar";
import { paths } from "src/paths";
import type { Voucher } from "src/types/voucher";
import { TeeTime, TeeTimeRecord } from "src/types/teeTimes";
import Typography from "@mui/material/Typography";
import Rating from "@mui/material/Rating";
import { getLabelText, labels } from "src/utils/common";
import { AlertHexagon, Star01 } from "@untitled-ui/icons-react";
import { useAuth } from "src/hooks/use-auth";
import { CircularProgress, Divider, Tooltip } from "@mui/material";

interface ListTableProps {
  count?: number;
  items?: TeeTime[];
  onDeselectAll?: () => void;
  onDeselectOne?: (customerId: string) => void;
  onPageChange?: (
    event: MouseEvent<HTMLButtonElement> | null,
    newPage: number
  ) => void;
  onRowsPerPageChange?: (event: ChangeEvent<HTMLInputElement>) => void;
  onSelectAll?: () => void;
  onSelectOne?: (customerId: string) => void;
  page?: number;
  rowsPerPage?: number;
  selected?: string[];

  isLoading?: boolean;
  onRatingUpdate(record: TeeTimeRecord, rating: number): void;

  onOpenVoucher: (relatedFreeRoundId: number) => void;
}

export const TeeTimeListTable: FC<ListTableProps> = (props) => {
  const {
    count = 0,
    items = [],
    onDeselectAll,
    onDeselectOne,
    onPageChange = () => {},
    onRowsPerPageChange,
    onSelectAll,
    onSelectOne,
    onRatingUpdate,
    page = 0,
    rowsPerPage = 0,
    selected = [],
    isLoading,
    onOpenVoucher,
  } = props;

  // Initialize hover state for each item
  const [hoverStates, setHoverStates] = React.useState(items.map(() => -1));
  const user = useAuth();

  return (
    <Box sx={{ position: "relative" }}>
      <Scrollbar>
        <Table stickyHeader size="small" aria-label="a dense table">
          <TableHead>
            <TableRow>
              <TableCell align="center">Course Name</TableCell>
              <TableCell align="center">Date/Time</TableCell>
              <TableCell align="center">Player 1</TableCell>
              <TableCell align="center">Player 2</TableCell>
              <TableCell align="center">Player 3</TableCell>
              <TableCell align="center">Player 4</TableCell>
            </TableRow>
          </TableHead>
          <TableBody>
            {items.map((teeTime) => {
              const isSelected = selected.includes(String(teeTime.teeTime));
              return (
                <TableRow hover key={teeTime.teeTime} selected={isSelected}>
                  <TableCell align="center">
                    {teeTime.courseName?.trim() === ""
                      ? user?.user?.name
                      : teeTime.courseName}
                  </TableCell>
                  <TableCell align="center">
                    {format(new Date(teeTime.teeTime), "dd/MM/yyyy hh:mm a")}
                  </TableCell>
                  {teeTime.records &&
                    teeTime.records.map((record, index) => {
                      const hoverState = hoverStates[index]; // Get hover state for the current row

                      return (
                        <>
                          <TableCell align="center">
                            {record.userFirstName} {record.userLastName}
                            <Typography variant="body2">
                              {`(${
                                record.userGolfLink
                                  ? record.userGolfLink
                                  : "No GOLF Link Number"
                              })`}
                            </Typography>
                            {record.userFirstName && (
                              <>
                                <Rating
                                  name="hover-feedback"
                                  value={record.partnerRating}
                                  getLabelText={getLabelText}
                                  onChange={(event, newValue) =>
                                    onRatingUpdate(record, newValue ?? 0)
                                  }
                                  onChangeActive={(event, newHover) => {
                                    // Update the hover state for the current row
                                    const newHoverStates = [...hoverStates];
                                    newHoverStates[index] = newHover;
                                    setHoverStates(newHoverStates);
                                  }}
                                  emptyIcon={
                                    <Star01
                                      style={{ opacity: 0.55 }}
                                      fontSize="inherit"
                                    />
                                  }
                                />
                                <Box>
                                  {
                                    labels[
                                      hoverState !== -1 &&
                                      hoverState !== null &&
                                      hoverState !== undefined
                                        ? hoverState
                                        : record.partnerRating
                                    ]
                                  }
                                </Box>
                              </>
                            )}
                            <Tooltip title="Provide member feedback">
                              <IconButton
                                onClick={() =>
                                  onOpenVoucher(
                                    Number(record.relatedFreeRoundId)
                                  )
                                }
                              >
                                <SvgIcon>
                                  <AlertHexagon />
                                </SvgIcon>
                              </IconButton>
                            </Tooltip>
                          </TableCell>
                        </>
                      );
                    })}
                </TableRow>
              );
            })}
          </TableBody>
        </Table>
        {!isLoading && items.length <= 0 && (
          <Typography py={6} variant="body2" align="center">
            😔 No Tee Times found.
          </Typography>
        )}

        {isLoading && items.length <= 0 && (
          <Box
            py={5}
            sx={{
              display: "flex",
              flexDirection: "column",
              alignItems: "center",
              justifyContent: "center",
            }}
          >
            <CircularProgress size={20} />
            <Typography py={1} variant="body2" align="center">
              Loading
            </Typography>
          </Box>
        )}
      </Scrollbar>
    </Box>
  );
};

TeeTimeListTable.propTypes = {
  count: PropTypes.number,
  items: PropTypes.array,
  onDeselectAll: PropTypes.func,
  onDeselectOne: PropTypes.func,
  onPageChange: PropTypes.func,
  onRowsPerPageChange: PropTypes.func,
  onSelectAll: PropTypes.func,
  onSelectOne: PropTypes.func,
  page: PropTypes.number,
  rowsPerPage: PropTypes.number,
  selected: PropTypes.array,
};
