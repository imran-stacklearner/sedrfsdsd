import type { FC } from "react";
import { ChangeEvent, FormEvent, useCallback, useRef, useState } from "react";
import PropTypes from "prop-types";
import SearchMdIcon from "@untitled-ui/icons-react/build/esm/SearchMd";
import Box from "@mui/material/Box";
import Divider from "@mui/material/Divider";
import InputAdornment from "@mui/material/InputAdornment";
import OutlinedInput from "@mui/material/OutlinedInput";
import Stack from "@mui/material/Stack";
import SvgIcon from "@mui/material/SvgIcon";
import Tab from "@mui/material/Tab";
import Tabs from "@mui/material/Tabs";
import { useUpdateEffect } from "src/hooks/use-update-effect";

interface Filters {
  query?: string;
  status?: string;
}

type TabValue = "all" | "upcoming" | "past";

interface TabOption {
  label: string;
  value: TabValue;
}

const tabs: TabOption[] = [
  {
    label: "All",
    value: "all",
  },
  {
    label: "Upcoming",
    value: "upcoming",
  },
  {
    label: "Past",
    value: "past",
  },
];

type SortDir = "asc" | "desc";

interface TeeTimeListSearchProps {
  onFiltersChange?: (filters: Filters) => void;
  sortBy?: string;
  sortDir?: SortDir;
}

export const TeeTimeListSearch: FC<TeeTimeListSearchProps> = (props) => {
  const { onFiltersChange } = props;
  const queryRef = useRef<HTMLInputElement | null>(null);
  const [currentTab, setCurrentTab] = useState<TabValue>("all");
  const [filters, setFilters] = useState<Filters>({
    query: undefined,
    status: undefined,
  });

  const handleFiltersUpdate = useCallback(() => {
    onFiltersChange?.(filters);
  }, [filters, onFiltersChange]);

  useUpdateEffect(() => {
    handleFiltersUpdate();
  }, [filters, handleFiltersUpdate]);

  const handleTabsChange = useCallback(
    (event: ChangeEvent<any>, tab: TabValue): void => {
      setCurrentTab(tab);
      const status = tab === "all" ? undefined : tab;
      setFilters((prevState) => ({
        ...prevState,
        status,
      }));
    },
    []
  );

  const handleQueryChange = useCallback(
    (event: FormEvent<HTMLFormElement>): void => {
      event.preventDefault();
      const query = queryRef.current?.value || "";

      setFilters((prevState) => ({
        ...prevState,
        query,
      }));
    },
    []
  );

  return (
    <>
      <Tabs
        indicatorColor="primary"
        onChange={handleTabsChange}
        scrollButtons="auto"
        sx={{ px: 3 }}
        textColor="primary"
        value={currentTab}
        variant="scrollable"
      >
        {tabs.map((tab) => (
          <Tab key={tab.value} label={tab.label} value={tab.value} />
        ))}
      </Tabs>
      <Divider />
      <Stack alignItems="center" direction="row" flexWrap="wrap" sx={{ py: 2 }}>
        <Box
          component="form"
          onChange={handleQueryChange}
          onSubmit={handleQueryChange}
          sx={{ flexGrow: 1 }}
        >
          <OutlinedInput
            defaultValue=""
            fullWidth
            inputProps={{ ref: queryRef }}
            placeholder="Search members..."
            startAdornment={
              <InputAdornment position="start">
                <SvgIcon>
                  <SearchMdIcon />
                </SvgIcon>
              </InputAdornment>
            }
          />
        </Box>
      </Stack>
    </>
  );
};

TeeTimeListSearch.propTypes = {
  onFiltersChange: PropTypes.func,
};
