import type { FC, FormEvent } from "react";
import Box from "@mui/material/Box";
import FormControl from "@mui/material/FormControl";
import FormLabel from "@mui/material/FormLabel";
import Grid from "@mui/material/Unstable_Grid2";
import MenuItem from "@mui/material/MenuItem";
import OutlinedInput from "@mui/material/OutlinedInput";
import Select from "@mui/material/Select";
import Typography from "@mui/material/Typography";
import { useAuth } from "src/hooks/use-auth";
import toast from "react-hot-toast";
import * as Yup from "yup";
import { useFormik } from "formik";
import { FormHelperText, TextField } from "@mui/material";
import { useMounted } from "src/hooks/use-mounted";
import { mainApi } from "src/api/main";
import { Button } from "../components/buttons/button";

export interface ContactFormValues {
  partnerName?: string;
  name?: string;
  email?: string;
  number?: string;
  enquiryType?: string;
  message?: string;
  submit?: null;
}

export const ContactForm: FC<ContactFormValues> = (props) => {
  const { enquiryType = "1" } = props;

  const user = useAuth();
  const isMounted = useMounted();

  const initialValues: ContactFormValues = {
    partnerName: user.user?.name || "",
    name: "",
    email: user.user?.email || "",
    number: "",
    enquiryType: enquiryType,
    message: "",
    submit: null,
  };

  const validationSchema = Yup.object({
    name: Yup.string().max(255).required("Name is required"),
    email: Yup.string()
      .email("Must be a valid email")
      .max(255)
      .required("Email is required"),
    number: Yup.string().max(12).required("Number is required"),
    enquiryType: Yup.string().max(2).required("Enquiry type is required"),
    message: Yup.string()
      .min(100)
      .required("Message is required & a must be a minimum or 100 characters"),
  });

  function resetForm() {
    formik.resetForm();
  }

  const formik = useFormik({
    initialValues,
    validationSchema,
    onSubmit: async (values, helpers): Promise<void> => {
      try {
        const res = await mainApi.postPartnerFeedback(2, values);

        console.log("res", res);

        if (res.response.status === 200) {
          toast.success(
            "Your request has been submitted. We will be in touch with you shortly."
          );
          resetForm();
        } else {
          toast.error(`Whoops, there was an error in submitting this request`);
        }
      } catch (err) {
        console.error(err);

        if (isMounted()) {
          helpers.setStatus({ success: false });
          helpers.setErrors({ submit: err.message });
          helpers.setSubmitting(false);
        }
      }
    },
  });

  return (
    <form noValidate onSubmit={formik.handleSubmit}>
      <Grid container spacing={3}>
        <Grid xs={12} sm={6}>
          <FormControl fullWidth>
            <FormLabel
              sx={{
                color: "text.primary",
                mb: 1,
              }}
            >
              Partner
            </FormLabel>

            <OutlinedInput
              error={
                !!(formik.touched.partnerName && formik.errors.partnerName)
              }
              fullWidth
              disabled
              name="partnerName"
              required
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              type="text"
              value={formik.values.partnerName}
            />
          </FormControl>
        </Grid>
        <Grid xs={12} sm={6}>
          <FormControl fullWidth>
            <FormLabel
              sx={{
                color: "text.primary",
                mb: 1,
              }}
            >
              Your Name
            </FormLabel>
            <OutlinedInput
              error={!!(formik.touched.name && formik.errors.name)}
              fullWidth
              required
              placeholder="John Smith"
              name="name"
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              type="text"
              value={formik.values.name}
            />
            {!!(formik.touched.name && formik.errors.name) && (
              <Box sx={{ mt: 2 }}>
                <FormHelperText error>{formik.errors.name}</FormHelperText>
              </Box>
            )}
          </FormControl>
        </Grid>
        <Grid xs={12} sm={6}>
          <FormControl fullWidth>
            <FormLabel
              sx={{
                color: "text.primary",
                mb: 1,
              }}
            >
              Email
            </FormLabel>
            <OutlinedInput
              error={!!(formik.touched.email && formik.errors.email)}
              fullWidth
              name="email"
              required
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              type="text"
              value={formik.values.email}
            />
            {!!(formik.touched.email && formik.errors.email) && (
              <Box sx={{ mt: 2 }}>
                <FormHelperText error>{formik.errors.email}</FormHelperText>
              </Box>
            )}
          </FormControl>
        </Grid>
        <Grid xs={12} sm={6}>
          <FormControl fullWidth>
            <FormLabel
              sx={{
                color: "text.primary",
                mb: 1,
              }}
            >
              Contact Number
            </FormLabel>
            <OutlinedInput
              error={!!(formik.touched.number && formik.errors.number)}
              fullWidth
              name="number"
              required
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              type="text"
              value={formik.values.number}
            />
            {!!(formik.touched.number && formik.errors.number) && (
              <Box sx={{ mt: 2 }}>
                <FormHelperText error>{formik.errors.number}</FormHelperText>
              </Box>
            )}
          </FormControl>
        </Grid>
        <Grid xs={12}>
          <FormControl fullWidth>
            <FormLabel
              sx={{
                color: "text.primary",
                mb: 1,
              }}
            >
              Enquiry Type
            </FormLabel>
            <Select
              error={
                !!(formik.touched.enquiryType && formik.errors.enquiryType)
              }
              fullWidth
              name="enquiryType"
              required
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              type="text"
              value={formik.values.enquiryType}
            >
              <MenuItem value={"1"}>Marketing</MenuItem>
              <MenuItem value={"2"}>Other</MenuItem>
            </Select>
          </FormControl>
        </Grid>
        <Grid xs={12}>
          <FormControl fullWidth>
            <FormLabel
              sx={{
                color: "text.primary",
                mb: 1,
              }}
            >
              Message
            </FormLabel>
            <OutlinedInput
              error={!!(formik.touched.message && formik.errors.message)}
              fullWidth
              name="message"
              required
              multiline
              rows={6}
              onBlur={formik.handleBlur}
              onChange={formik.handleChange}
              type="text"
              value={formik.values.message}
            />
            {!!(formik.touched.message && formik.errors.message) && (
              <Box sx={{ mt: 2 }}>
                <FormHelperText error>{formik.errors.message}</FormHelperText>
              </Box>
            )}
          </FormControl>
        </Grid>
      </Grid>
      <Box
        sx={{
          display: "flex",
          justifyContent: "center",
          mt: 3,
        }}
      >
        {formik.errors.submit && (
          <FormHelperText error sx={{ mt: 3 }}>
            {formik.errors.submit as string}
          </FormHelperText>
        )}
        <Button
          disabled={formik.isSubmitting}
          type="submit"
          fullWidth
          size="large"
          variant="contained"
        >
          Submit
        </Button>
      </Box>
      <Typography color="text.secondary" sx={{ my: 1 }} variant="body2">
        An email will be sent with this request and we will be in touch with you
        shortly.
      </Typography>
    </form>
  );
};
