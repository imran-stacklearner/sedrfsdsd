import { useState, type FC } from "react";
import Head from "next/head";
import PropTypes from "prop-types";
import React from "react";
import {
  Button,
  ButtonPropsColorOverrides,
  IconButton,
  Snackbar,
} from "@mui/material";
import { Close } from "@mui/icons-material";
import { OverridesStyleRules } from "@mui/material/styles/overrides";

interface SnackBarProps {
  text: string;
  open?: boolean;

  type?:
    | "inherit"
    | "primary"
    | "secondary"
    | "success"
    | "error"
    | "info"
    | "warning";
  onClose?: () => void;

  setUndo?: () => void;
}

export const SnackBar: FC<SnackBarProps> = (props) => {
  const { text, open, type = "success", onClose, setUndo } = props;

  const action = (
    <React.Fragment>
      {setUndo && (
        <Button color={type} size="small" onClick={setUndo}>
          UNDO
        </Button>
      )}
      <IconButton
        size="small"
        aria-label="close"
        color="inherit"
        onClick={onClose}
      >
        <Close fontSize="small" />
      </IconButton>
    </React.Fragment>
  );

  return (
    <Snackbar
      anchorOrigin={{ vertical: "top", horizontal: "center" }}
      open={open}
      autoHideDuration={6000}
      onClose={onClose}
      message={text}
      action={action}
    />
  );
};
