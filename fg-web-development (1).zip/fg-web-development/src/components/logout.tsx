import React, { FC, useState } from "react"; // Import React
import { SvgIcon } from "@mui/material";
import { LogOut01 } from "@untitled-ui/icons-react";
import { useCallback } from "react";
import { useAuth } from "src/hooks/use-auth";
import { useRouter } from "src/hooks/use-router";
import { paths } from "src/paths";
import PropTypes from "prop-types";
import toast from "react-hot-toast";
import { Issuer } from "src/utils/auth";
import { Button } from "src/sections/components/buttons/button";

interface LogoutProps {
  onClose?: () => void;
}

export const Logout: FC<LogoutProps> = (props) => {
  const { onClose } = props;
  const router = useRouter();
  const auth = useAuth();
  const [submitting, setSubmitting] = useState(false);

  const handleLogout = useCallback(async (): Promise<void> => {
    setSubmitting(true);
    try {
      onClose?.();

      switch (auth.issuer) {
        case Issuer.JWT: {
          await auth.signOut();
          break;
        }

        default: {
          console.warn("Using an unknown Auth Issuer, did not log out");
        }
      }

      router.push(paths.auth.login);
    } catch (err) {
      console.error(err);
      toast.error("Something went wrong!");
    }
    setSubmitting(false);
  }, [auth, router, onClose]);

  return (
    <Button
      fullWidth
      variant="contained"
      disabled={submitting}
      startIcon={
        <SvgIcon>
          <LogOut01 />
        </SvgIcon>
      }
      onClick={handleLogout}
      size="small"
    >
      Logout
    </Button>
  );
};

Logout.propTypes = {
  onClose: PropTypes.func,
};
