import type { FC } from "react";
import toast, {
  Toaster as HotToaster,
  Toast,
  ToastBar,
  useToaster,
} from "react-hot-toast";
import { alpha } from "@mui/system/colorManipulator";
import { useTheme } from "@mui/material/styles";
import { Button, Typography } from "@mui/material";

interface ToasterProps {
  onUndo?: () => void;
}
export const Toaster: React.FC<ToasterProps> = ({ onUndo }) => {
  const theme = useTheme();

  const handleUndo = (t: Toast) => {
    onUndo?.();
    toast.dismiss();
  };

  return (
    <HotToaster
      position="top-center"
      toastOptions={{
        style: {
          backdropFilter: "blur(6px)",
          background: alpha(theme.palette.neutral[900], 0.8),
          color: theme.palette.common.white,
          boxShadow: theme.shadows[16],
          minWidth: "fit-content",
        },
      }}
    >
      {(t) => (
        <ToastBar toast={t}>
          {({ icon, message }) => (
            <>
              {icon}
              {message}
              {t.type !== "loading" && onUndo && (
                <Button color="inherit" onClick={() => handleUndo(t)}>
                  <Typography color="white">Undo</Typography>
                </Button>
              )}
            </>
          )}
        </ToastBar>
      )}
    </HotToaster>
  );
};
