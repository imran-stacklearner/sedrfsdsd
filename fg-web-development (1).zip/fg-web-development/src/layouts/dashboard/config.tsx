import type { ReactNode } from "react";
import { useMemo } from "react";
import { useTranslation } from "react-i18next";
import Chip from "@mui/material/Chip";
import SvgIcon from "@mui/material/SvgIcon";
import Users03Icon from "src/icons/untitled-ui/duocolor/users-03";
import {
  Announcement01,
  MessageSquare01,
  WatchCircle,
} from "@untitled-ui/icons-react";
import { NotificationBox } from "@untitled-ui/icons-react";
import { tokens } from "src/locales/tokens";
import { paths } from "src/paths";

export interface Item {
  disabled?: boolean;
  external?: boolean;
  icon?: ReactNode;
  items?: Item[];
  label?: ReactNode;
  path?: string;
  title: string;
}

export interface Section {
  items: Item[];
  subheader?: string;
}

export const useSections = () => {
  const { t } = useTranslation();

  return useMemo(() => {
    return [
      {
        items: [
          {
            title: t(tokens.nav.overview),
            path: paths.dashboard.index,
            icon: (
              <SvgIcon fontSize="small">
                <Users03Icon />
              </SvgIcon>
            ),
          },
          {
            title: t(tokens.nav.list),
            path: paths.dashboard.teeTimes,
            icon: (
              <SvgIcon fontSize="small">
                <WatchCircle />
              </SvgIcon>
            ),
          },
          {
            title: t(tokens.nav.memberFeedback),
            path: paths.dashboard.memberFeedback,
            icon: (
              <SvgIcon fontSize="small">
                <NotificationBox />
              </SvgIcon>
            ),
          },
          {
            title: t(tokens.nav.marketing),
            path: paths.dashboard.marketingContact,
            icon: (
              <SvgIcon fontSize="small">
                <Announcement01 />
              </SvgIcon>
            ),
          },
          {
            title: t(tokens.nav.contact),
            path: paths.dashboard.contact,
            icon: (
              <SvgIcon fontSize="small">
                <MessageSquare01 />
              </SvgIcon>
            ),
          },
        ],
      },
    ];
  }, [t]);
};
